#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 7
#define VBOX_VERSION_MINOR 1
#define VBOX_VERSION_BUILD 12
#define VBOX_VERSION_STRING_RAW "7.1.12"
#define VBOX_VERSION_STRING "7.1.12_Debian"
#define VBOX_API_VERSION_STRING "7_1"

#define VBOX_PRIVATE_BUILD_DESC "Private build by sbuild"

#endif

#!/usr/bin/python3
"""Supply omitted SVG size ranges before installing the MiniOS icon themes."""
import configparser
import pathlib
import sys


def fix_index(path):
    path = pathlib.Path(path)
    index = configparser.ConfigParser(interpolation=None)
    index.optionxform = str
    with path.open(encoding="utf-8") as source:
        index.read_file(source)
    changed = False
    for section in index.sections():
        values = index[section]
        if values.get("Type") != "Scalable":
            continue
        size = values.getint("Size")
        if size <= 0:
            raise ValueError("Invalid scalable size in " + section)
        # GTK's non-FORCE_SIZE HiDPI lookup otherwise treats omitted bounds as
        # MinSize=MaxSize=Size, enlarging a 24px logical request to 48px before
        # rendering it at scale 2. Preserve explicitly specified upstream ranges.
        for key, value in (("MinSize", min(size, 16)), ("MaxSize", max(size, 512))):
            if key not in values:
                values[key] = str(value)
                changed = True
    if changed:
        with path.open("w", encoding="utf-8") as target:
            index.write(target)


if __name__ == "__main__":
    for argument in sys.argv[1:]:
        fix_index(argument)

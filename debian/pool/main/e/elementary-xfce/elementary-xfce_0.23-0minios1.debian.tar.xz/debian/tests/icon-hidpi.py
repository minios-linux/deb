#!/usr/bin/python3
"""Real GTK non-FORCE_SIZE header lookup against installed build output."""
import pathlib
import sys
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

Gtk.init([])
path = str(pathlib.Path(sys.argv[1]).resolve())
for theme in ("elementary-minios", "elementary-minios-dark"):
    icons = Gtk.IconTheme.new()
    icons.prepend_search_path(path)
    icons.set_custom_theme(theme)
    for name, size in (("org.xfce.settings.manager", 24), ("xfsm-logout", 24),
                       ("system-shutdown", 24), ("avatar-default", 32)):
        for scale in (1, 2):
            info = icons.lookup_icon_for_scale(name, size, scale, Gtk.IconLookupFlags(0))
            assert info is not None, (theme, name)
            assert info.get_filename().startswith(path), info.get_filename()
            image = info.load_icon()
            assert (image.get_width(), image.get_height()) == (size * scale, size * scale), (
                theme, name, size, scale, info.get_filename(), image.get_width(), image.get_height())
            print("PASS", theme, name, size, scale, image.get_width(), image.get_height())

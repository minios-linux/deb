#!/usr/bin/python3
import configparser
import importlib.util
import pathlib
import tempfile
import unittest

spec = importlib.util.spec_from_file_location(
    "icon_ranges", pathlib.Path(__file__).resolve().parents[1] / "fix-hidpi-icons.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class IconRanges(unittest.TestCase):
    def transform(self, sections):
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory) / "index.theme"
            path.write_text("[Icon Theme]\nName=Regression\n" + sections, encoding="utf-8")
            module.fix_index(path)
            once = path.read_text(encoding="utf-8")
            module.fix_index(path)
            self.assertEqual(once, path.read_text(encoding="utf-8"))
            index = configparser.ConfigParser(interpolation=None)
            index.read_string(once)
            return index

    def test_header_requests_fit_scalable_ranges(self):
        index = self.transform("[apps/48]\nSize=48\nType=Scalable\n"
                               "[status/64]\nSize=64\nType=Scalable\n")
        for section, requested in (("apps/48", 24), ("status/64", 32)):
            self.assertLessEqual(index[section].getint("MinSize"), requested)
            self.assertGreaterEqual(index[section].getint("MaxSize"), requested)

    def test_fixed_artwork_is_untouched(self):
        index = self.transform("[actions/24]\nSize=24\nType=Fixed\n")
        self.assertEqual(dict(index["actions/24"]), {"size": "24", "type": "Fixed"})

    def test_explicit_upstream_ranges_are_preserved(self):
        index = self.transform("[apps/scalable]\nSize=48\nType=Scalable\n"
                               "MinSize=8\nMaxSize=1024\n")
        self.assertEqual(index["apps/scalable"].getint("MinSize"), 8)
        self.assertEqual(index["apps/scalable"].getint("MaxSize"), 1024)

    def test_small_scalable_base_stays_in_its_range(self):
        index = self.transform("[status/scalable]\nSize=8\nType=Scalable\n")
        self.assertLessEqual(index["status/scalable"].getint("MinSize"), 8)


if __name__ == "__main__":
    unittest.main()

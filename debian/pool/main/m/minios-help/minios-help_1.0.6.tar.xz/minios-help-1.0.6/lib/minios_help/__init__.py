"""MiniOS Help application package."""

__version__ = "1.0.6"

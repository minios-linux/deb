#!/usr/bin/env python3
"""
MiniOS Session CLI

Command-line utility for managing MiniOS persistent sessions from within the running system.
This is the CLI-only version that performs actual session operations.
"""

import argparse
import fcntl
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import contextlib
import signal
import stat
from datetime import datetime
from pathlib import Path
import gettext
import getpass

# Handle SIGTERM to ensure finally blocks run (cleanup)
def _handle_sigterm(signum, frame):
    raise SystemExit(1)

signal.signal(signal.SIGTERM, _handle_sigterm)

# Internationalization setup
def _(message):
    """Translation function wrapper"""
    try:
        return gettext.dgettext('minios-session-manager', message)
    except Exception:
        return message

try:
    gettext.bindtextdomain('minios-session-manager', '/usr/share/locale')
    gettext.textdomain('minios-session-manager')
except Exception:
    pass

INITRD_CRYPTO_MARKER = '/run/initramfs/etc/minios-initramfs-crypt'


def luks_runtime_available():
    return bool(shutil.which('cryptsetup') and shutil.which('losetup') and
                os.path.isfile(INITRD_CRYPTO_MARKER))

class SessionManager:
    """Main class for managing MiniOS sessions"""

    MAX_ARCHIVE_EXTRACTED_BYTES = 8 * 1024 * 1024 * 1024
    DEFAULT_CONTAINER_SIZE_MB = 4000
    MAX_CONTAINER_SIZE_MB = 1000000

    def __init__(self, custom_sessions_dir=None):
        self.sessions_file = None
        self.sessions_dir = None
        self.current_session = None
        self.session_format = None  # 'json' or 'conf'
        self.custom_sessions_dir = custom_sessions_dir
        self._lock_fd = None
        self._lock_depth = 0
        
        # Setup cache directory and file in /tmp (clears on reboot)
        self.cache_dir = f"/tmp/minios-session-manager-{os.getuid()}"
        self.cache_file = os.path.join(self.cache_dir, "session_sizes.json")
        self._ensure_cache_dir()
        
            
        self._detect_session_storage()

    def _ensure_cache_dir(self):
        """Ensure cache directory exists"""
        try:
            os.makedirs(self.cache_dir, mode=0o700, exist_ok=True)
            cache_stat = os.stat(self.cache_dir)
            if cache_stat.st_uid != os.getuid() or not stat.S_ISDIR(cache_stat.st_mode):
                raise OSError("unsafe cache directory")
            os.chmod(self.cache_dir, 0o700)
        except OSError:
            # Never place a predictable cache file directly in shared /tmp.
            self.cache_dir = tempfile.mkdtemp(prefix="minios-session-manager-", dir=tempfile.gettempdir())
            self.cache_file = os.path.join(self.cache_dir, "session_sizes.json")

    def _load_size_cache(self):
        """Load size cache from /tmp"""
        if not os.path.exists(self.cache_file):
            return {}
        
        try:
            with open(self.cache_file, 'r') as f:
                data = json.load(f)
                # Validate cache against current sessions directory
                if data.get('sessions_dir') != self.sessions_dir:
                    return {}  # Cache invalid - different sessions directory
                return data.get('cache', {})
        except (json.JSONDecodeError, OSError):
            return {}

    def _save_size_cache(self, cache_data):
        """Save size cache to /tmp"""
        try:
            cache_content = {
                "version": "1.0",
                "sessions_dir": self.sessions_dir,
                "updated_at": time.time(),
                "cache": cache_data
            }
            
            with open(self.cache_file, 'w') as f:
                os.chmod(self.cache_file, 0o600)
                json.dump(cache_content, f, indent=2)
        except OSError:
            pass  # Ignore cache write failures

    def _make_temp_dir(self):
        """Create temporary directory in sessions directory

        Returns path to temporary directory that should be cleaned up after use
        """
        if not self.sessions_dir:
            raise OSError("sessions directory not found")
        return tempfile.mkdtemp(prefix=".tmp_", dir=self.sessions_dir)

    def _validate_session_id(self, session_id):
        """Return a canonical numeric ID or reject paths and metadata keys."""
        if not isinstance(session_id, str) or not re.fullmatch(r"[0-9]+", session_id):
            raise ValueError(_("Invalid session ID"))
        return session_id

    def _session_path(self, session_id, require_exists=False):
        """Resolve a session path while keeping it inside the configured root."""
        session_id = self._validate_session_id(session_id)
        if not self.sessions_dir:
            raise ValueError(_("Sessions directory not found"))
        root = os.path.realpath(self.sessions_dir)
        candidate = os.path.join(root, session_id)
        if os.path.commonpath([root, os.path.realpath(candidate)]) != root:
            raise ValueError(_("Invalid session path"))
        if require_exists and (not os.path.isdir(candidate) or os.path.islink(candidate)):
            raise ValueError(_("Session {} does not exist").format(session_id))
        return candidate

    @contextlib.contextmanager
    def _mutation_lock(self):
        """Serialize metadata and session-tree mutations across CLI processes."""
        if not self.sessions_dir:
            raise OSError("sessions directory not found")
        if self._lock_depth == 0:
            lock_path = os.path.join(self.sessions_dir, '.session.lock')
            flags = os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0)
            self._lock_fd = os.open(lock_path, flags, 0o600)
            lock_stat = os.fstat(self._lock_fd)
            if (not stat.S_ISREG(lock_stat.st_mode) or lock_stat.st_uid != os.geteuid()
                    or lock_stat.st_nlink != 1):
                os.close(self._lock_fd)
                self._lock_fd = None
                raise OSError("unsafe session lock file")
            os.fchmod(self._lock_fd, 0o600)
            fcntl.flock(self._lock_fd, fcntl.LOCK_EX)
        self._lock_depth += 1
        try:
            yield
        finally:
            self._lock_depth -= 1
            if self._lock_depth == 0 and self._lock_fd is not None:
                fcntl.flock(self._lock_fd, fcntl.LOCK_UN)
                os.close(self._lock_fd)
                self._lock_fd = None

    def _reserve_session(self):
        """Reserve a unique ID by creating its directory while holding the lock."""
        with self._mutation_lock():
            new_id = str(self._get_next_session_id())
            path = self._session_path(new_id)
            os.mkdir(path, 0o700)
            return new_id, path

    def _update_size_cache(self, session_id, size, mtime):
        """Update size cache for specific session"""
        cache_data = self._load_size_cache()
        cache_data[session_id] = {
            'size': size,
            'size_formatted': self._format_size(size),
            'mtime': mtime,
            'cached_at': time.time()
        }
        self._save_size_cache(cache_data)


    def _get_current_union_fs(self):
        """Get current union filesystem type"""
        try:
            # First check if union= parameter was used
            with open('/proc/cmdline', 'r') as f:
                cmdline = f.read().strip()
                union_match = re.search(r'union=(\w+)', cmdline)
                if union_match:
                    union_param = union_match.group(1)
                    if union_param in ['aufs', 'overlayfs']:
                        return union_param

            # Auto-detection based on kernel support
            with open('/proc/filesystems', 'r') as f:
                filesystems = f.read()
                if 'aufs' in filesystems:
                    return 'aufs'
                else:
                    return 'overlayfs'
        except (OSError, IOError):
            return 'unknown'

    def _get_system_version(self):
        """Get MiniOS system version"""
        try:
            release_file = "/etc/minios-release"
            if os.path.exists(release_file):
                with open(release_file, 'r') as f:
                    for line in f:
                        if line.startswith("VERSION="):
                            return line.split("=", 1)[1].strip().strip('"')
        except Exception:
            pass
        return "unknown"

    def _get_system_edition(self):
        """Get MiniOS system edition"""
        try:
            release_file = "/etc/minios-release"
            if os.path.exists(release_file):
                with open(release_file, 'r') as f:
                    for line in f:
                        if line.startswith("EDITION="):
                            return line.split("=", 1)[1].strip().strip('"')
        except Exception:
            pass
        return "unknown"

    def _check_free_space(self, path, required_mb):
        """Check if there is enough free space at the given path

        Args:
            path: Path to check (file or directory)
            required_mb: Required space in megabytes

        Returns:
            (bool, str): (has_space, error_message)
        """
        try:
            # Get the directory to check
            if os.path.isfile(path):
                check_path = os.path.dirname(path)
            else:
                check_path = path

            # Get filesystem stats
            stat = os.statvfs(check_path)

            # Calculate free space in bytes
            free_bytes = stat.f_bavail * stat.f_frsize
            free_mb = free_bytes / (1024 * 1024)

            # Add 10% buffer for safety
            required_with_buffer = required_mb * 1.1

            if free_mb < required_with_buffer:
                return False, _("Insufficient disk space: {} MB required, {} MB available").format(
                    int(required_with_buffer), int(free_mb))

            return True, None

        except Exception as e:
            return False, _("Unable to check free disk space: {}").format(str(e))

    def _detect_session_storage(self):
        """Detect where sessions are stored and in what format"""
        # If custom directory is specified, use it
        if self.custom_sessions_dir:
            if os.path.isdir(self.custom_sessions_dir):
                self.sessions_dir = os.path.realpath(self.custom_sessions_dir)
            else:
                return False
        else:
            # Common locations for session storage
            possible_paths = [
                "/run/initramfs/memory/data/minios/changes",
                "/lib/live/mount/medium/minios/changes",
            ]
            
            for path in possible_paths:
                if os.path.exists(path):
                    self.sessions_dir = path
                    break
        
        if not self.sessions_dir:
            return False
            
        # Check for session metadata files
        json_file = os.path.join(self.sessions_dir, "session.json")
        conf_file = os.path.join(self.sessions_dir, "session.conf")
        
        if os.path.exists(json_file):
            self.sessions_file = json_file
            self.session_format = "json"
        elif os.path.exists(conf_file):
            self.sessions_file = conf_file  
            self.session_format = "conf"
        
        return True




    def check_sessions_directory_status(self):
        """Check sessions directory status and write permissions"""
        if not self.sessions_dir:
            return {
                'success': False,
                'found': False,
                'writable': False,
                'sessions_dir': None,
                'error': _('Sessions directory not found')
            }
        
        # Check if directory exists
        if not os.path.exists(self.sessions_dir):
            return {
                'success': True,
                'found': False,
                'writable': False,
                'sessions_dir': self.sessions_dir,
                'error': _('Sessions directory does not exist')
            }
        
        fs_info, fs_error = self._detect_filesystem_type()
        fs_type = fs_info['type'] if fs_info else "unknown"
        
        # Check if directory is writable
        writable = False
        error_msg = None
        
        try:
            # SquashFS is always read-only
            if fs_error:
                writable = False
                error_msg = fs_error
            elif fs_info.get('is_readonly') or fs_type == 'squashfs':
                writable = False
                error_msg = _("Sessions directory is on a read-only filesystem")
            else:
                # Try to create a temporary file to test write access
                try:
                    import tempfile
                    with tempfile.NamedTemporaryFile(dir=self.sessions_dir, delete=True):
                        pass
                    writable = True
                except (OSError, PermissionError) as e:
                    writable = False
                    error_msg = _("Permission denied: {}").format(str(e))
        except Exception as e:
            writable = False
            error_msg = _("Error checking directory: {}").format(str(e))
        
        result = {
            'success': True,
            'found': True,
            'writable': writable,
            'sessions_dir': self.sessions_dir,
            'filesystem_type': fs_type
        }
        if error_msg:
            result['error'] = error_msg
        
        return result


    def _read_sessions_metadata(self):
        """Read session metadata from file"""
        if not self.sessions_file or not os.path.exists(self.sessions_file):
            return {"default": None, "sessions": {}}
            
        try:
            if self.session_format == "json":
                with open(self.sessions_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:  # conf format
                metadata = {"default": None, "sessions": {}}
                with open(self.sessions_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("default="):
                            metadata["default"] = line.split("=", 1)[1]
                        elif line.startswith("running="):
                            metadata["running"] = line.split("=", 1)[1]
                        elif line.startswith("session_"):
                            # Parse session_mode[1]=native format
                            parts = line.split("=", 1)
                            if len(parts) == 2:
                                key, value = parts
                                if "[" in key and "]" in key:
                                    field = key.split("[")[0].replace("session_", "")
                                    session_id = key.split("[")[1].split("]")[0]
                                    if session_id not in metadata["sessions"]:
                                        metadata["sessions"][session_id] = {}
                                    metadata["sessions"][session_id][field] = value
                return metadata
        except Exception as e:
            print(f"Error reading sessions metadata: {e}", file=sys.stderr)
            return {"default": None, "sessions": {}}

    def _write_sessions_metadata(self, metadata):
        """Atomically write session metadata, preserving the previous file on failure."""
        if not self.sessions_file:
            # Try to create sessions file if it doesn't exist
            if self.sessions_dir:
                json_file = os.path.join(self.sessions_dir, "session.json")
                if os.access(os.path.dirname(json_file), os.W_OK):
                    self.sessions_file = json_file
                    self.session_format = "json"
                else:
                    return False
            else:
                return False
            
        temp_name = None
        try:
            with self._mutation_lock():
                fd, temp_name = tempfile.mkstemp(prefix='.session-metadata-', dir=self.sessions_dir)
                with os.fdopen(fd, 'w', encoding='utf-8') as f:
                    if self.session_format == "json":
                        json.dump(metadata, f, indent=2)
                        f.write('\n')
                    else:  # conf format
                        f.write(f"default={metadata.get('default', '')}\n")
                        if 'running' in metadata:
                            f.write(f"running={metadata['running']}\n")
                        for session_id, session_data in metadata.get("sessions", {}).items():
                            for field, value in session_data.items():
                                f.write(f"session_{field}[{session_id}]={value}\n")
                    f.flush()
                    os.fsync(f.fileno())
                os.chmod(temp_name, 0o600)
                os.replace(temp_name, self.sessions_file)
                directory_fd = os.open(self.sessions_dir, os.O_DIRECTORY)
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
                return True
        except Exception as e:
            print(f"Error writing sessions metadata: {e}", file=sys.stderr)
            return False
        finally:
            if temp_name and os.path.exists(temp_name):
                os.unlink(temp_name)

    def list_sessions(self, include_running_check=True):
        """List all available sessions"""
        if not self.sessions_dir:
            return []
            
        sessions = []
        metadata = self._read_sessions_metadata()
        metadata.setdefault('sessions', {})
        
        # Get running session info for comparison (avoid recursion)
        running_id = None
        if include_running_check:
            running_session = self.get_running_session(avoid_recursion=True)
            if running_session and 'id' in running_session:
                running_id = running_session['id']
        
        # Find session directories (numeric names)
        for item in os.listdir(self.sessions_dir):
            path = os.path.join(self.sessions_dir, item)
            if os.path.isdir(path) and not os.path.islink(path) and item.isdigit():
                session_id = item
                session_data = metadata.get("sessions", {}).get(session_id, {})
                
                # Get directory stats
                stat = os.stat(path)
                size_info = self._get_session_size_info(path, session_data)
                
                sessions.append({
                    'id': session_id,
                    'path': path,
                    'mode': session_data.get('mode', 'unknown'),
                    'version': session_data.get('version', 'unknown'),
                    'edition': session_data.get('edition', 'unknown'),
                    'union': session_data.get('union', 'unknown'), 
                    'size': size_info['used_size'],
                    'size_display': size_info['display'],
                    'total_size': size_info.get('total_size'),
                    'total_size_mb': session_data.get('size'),  # Size from metadata in MB
                    'modified': datetime.fromtimestamp(stat.st_mtime),
                    'is_default': metadata.get('default') == session_id,
                    'is_running': session_id == running_id
                })
        
        # Sort by session ID
        sessions.sort(key=lambda x: int(x['id']))
        return sessions

    def _get_directory_size(self, path):
        """Get total size of directory in bytes with caching"""
        session_id = os.path.basename(path)
        
        try:
            # Get current directory modification time
            current_mtime = os.path.getmtime(path)
            
            # Load cache and check if valid
            cache_data = self._load_size_cache()
            session_cache = cache_data.get(session_id, {})
            cached_size = session_cache.get('size')
            cached_mtime = session_cache.get('mtime')
            
            # Check if cache is valid (mtime unchanged)
            if cached_size is not None and cached_mtime == current_mtime:
                return cached_size
            
            # Cache miss or outdated - recalculate
            actual_size = self._calculate_directory_size(path)
            
            # Update cache
            self._update_size_cache(session_id, actual_size, current_mtime)
            
            return actual_size
            
        except (OSError, PermissionError):
            # Fallback to direct calculation without caching
            return self._calculate_directory_size(path)

    def _calculate_directory_size(self, path):
        """Calculate actual directory size (original implementation)"""
        # Check if this is a dynfilefs session
        changes_file = os.path.join(path, "changes.dat")
        if os.path.exists(changes_file) or any(f.startswith("changes.dat") for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))):
            return self._get_dynfilefs_size(path)
        
        # Regular directory size calculation
        total = 0
        try:
            for dirpath, dirnames, filenames in os.walk(path):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    if os.path.exists(filepath):  # Check for broken symlinks
                        total += os.path.getsize(filepath)
        except (OSError, PermissionError):
            pass
        return total

    def _format_size(self, size_bytes):
        """Format size in human readable format"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f}{unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f}TB"

    def _check_dynfilefs_available(self):
        """Check if dynfilefs is available on the system"""
        try:
            result = subprocess.run(['which', 'dynfilefs'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if result.returncode == 0:
                return True
            # Also check for mount.dynfilefs
            result = subprocess.run(['which', 'mount.dynfilefs'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return result.returncode == 0
        except Exception:
            return False

    def _check_luks_available(self):
        """Check both the userspace tools and the initrd LUKS persistence hook."""
        if not shutil.which('cryptsetup') or not shutil.which('losetup'):
            return False, _("LUKS mode requires cryptsetup and util-linux.")
        if luks_runtime_available():
            return True, None
        return False, _("This MiniOS initrd does not support perchmode=luks. Boot an image with the LUKS persistence hook before creating or activating LUKS sessions.")

    def _detect_filesystem_type(self):
        """Detect the filesystem type of the MiniOS media"""
        if not self.sessions_dir:
            return None, _("Sessions directory not found")
        
        try:
            target = os.path.realpath(self.sessions_dir)
            best_mount = None
            with open('/proc/self/mountinfo', encoding='utf-8') as mounts:
                for line in mounts:
                    fields = line.rstrip('\n').split(' ')
                    separator = fields.index('-')
                    mount_point = fields[4].replace('\\040', ' ')
                    if target == mount_point or target.startswith(mount_point.rstrip('/') + '/'):
                        if best_mount is None or len(mount_point) > len(best_mount[0]):
                            best_mount = (mount_point, fields, separator)
            if best_mount is None:
                return None, _("Failed to determine filesystem information")
            _mount_point, fields, separator = best_mount
            filesystem_type = fields[separator + 1].lower()
            device = fields[separator + 2]
            mount_options = fields[5]
            super_options = fields[separator + 3] if len(fields) > separator + 3 else ''
            return {
                'type': filesystem_type,
                'device': device,
                'mount_options': mount_options,
                'is_readonly': 'ro' in mount_options.split(',') or 'ro' in super_options.split(','),
                'is_posix_compatible': filesystem_type in ['ext2', 'ext3', 'ext4', 'btrfs', 'xfs', 'f2fs', 'reiserfs', 'tmpfs']
            }, None
            
        except Exception as e:
            return None, _("Error detecting filesystem: {}").format(str(e))

    def _get_compatible_session_modes(self, filesystem_info):
        """Get list of compatible session modes for the filesystem"""
        if not filesystem_info or filesystem_info.get('is_readonly'):
            return []
        
        fs_type = filesystem_info['type']
        is_readonly = filesystem_info['is_readonly']
        is_posix = filesystem_info['is_posix_compatible']
        
        compatible_modes = []
        
        # Native mode: requires POSIX-compatible filesystem (ext2/3/4, btrfs, xfs, etc.)
        if is_posix:
            compatible_modes.append('native')
        
        # DynFileFS mode: works on all writable filesystems.
        compatible_modes.append('dynfilefs')
        
        # Raw mode: works on ALL writable filesystems (static images)
        compatible_modes.append('raw')
        luks_available, _luks_error = self._check_luks_available()
        if luks_available:
            compatible_modes.append('luks')
        
        return compatible_modes

    def _get_filesystem_limitations(self, filesystem_info):
        """Get filesystem-specific limitations"""
        limitations = {}
        
        if not filesystem_info:
            return limitations
        
        fs_type = filesystem_info['type']
        
        # FAT32 limitations
        if fs_type in ['vfat', 'fat32', 'msdos']:
            # Match perchsize's supported FAT32 policy exactly.
            limitations['max_file_size'] = 4000
            limitations['no_posix'] = True
            limitations['case_insensitive'] = True
        
        # NTFS limitations  
        elif fs_type in ['ntfs', 'ntfs-3g']:
            limitations['no_posix'] = True
            limitations['case_insensitive'] = True
        
        # exFAT limitations
        elif fs_type in ['exfat']:
            limitations['no_posix'] = True
            limitations['case_insensitive'] = True
        
        return limitations

    def _validate_target_mode(self, mode, size_mb=None):
        """Validate a requested storage mode against the actual target filesystem."""
        if mode not in ('native', 'dynfilefs', 'raw', 'luks'):
            return False, _("Invalid session mode")
        fs_info, error = self._detect_filesystem_type()
        if error or not fs_info:
            return False, error or _("Failed to determine filesystem information")
        if fs_info.get('is_readonly'):
            return False, _("Sessions directory is read-only")
        if mode not in self._get_compatible_session_modes(fs_info):
            return False, _("Session mode '{}' is not compatible with {} filesystem").format(mode, fs_info['type'])
        if size_mb is not None and size_mb <= 0:
            return False, _("Session size must be greater than zero")
        if mode == 'dynfilefs' and not self._check_dynfilefs_available():
            return False, _("DynFileFS is not available on this system. Please install dynfilefs package.")
        max_size = self._get_filesystem_limitations(fs_info).get('max_file_size')
        if mode == 'luks':
            luks_available, luks_error = self._check_luks_available()
            if not luks_available:
                return False, luks_error
        if mode in ('raw', 'luks') and max_size and size_mb and size_mb > max_size:
            return False, _("Container size {}MB exceeds FAT32 file size limit ({}MB).").format(size_mb, max_size)
        if mode in ('raw', 'luks') and size_mb and size_mb > self.MAX_CONTAINER_SIZE_MB:
            return False, _("Container size exceeds the 1TB limit.")
        return True, None

    def _luks_mapper_name(self):
        return 'minios-session-{}-{}'.format(os.getpid(), next(tempfile._get_candidate_names()))

    def _cryptsetup(self, command, password):
        """Run cryptsetup with the passphrase exclusively on its stdin."""
        result = subprocess.run(command, input=password + b'\n', stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
        if result.returncode:
            raise OSError(result.stderr.decode(errors='replace').strip() or 'cryptsetup failed')

    @contextlib.contextmanager
    def _mount_luks(self, image_file, password, writable):
        """Expose one LUKS file through an owned loop and mapper, then clean both."""
        if not password:
            raise ValueError(_("A LUKS passphrase is required."))
        loop_device = mapper_name = mount_point = None
        try:
            loop_result = subprocess.run(['losetup', '--find', '--show', '--', image_file],
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if loop_result.returncode:
                raise OSError(loop_result.stderr.decode(errors='replace').strip() or 'failed to attach loop device')
            loop_device = loop_result.stdout.decode().strip()
            mapper_name = self._luks_mapper_name()
            self._cryptsetup(['cryptsetup', 'open', '--type', 'luks', '--key-file', '-',
                              loop_device, mapper_name], password)
            mount_point = tempfile.mkdtemp(prefix='minios_luks_')
            options = [] if writable else ['-o', 'ro']
            subprocess.run(['mount'] + options + ['/dev/mapper/' + mapper_name, mount_point], check=True)
            yield mount_point
        finally:
            if mount_point:
                self._safe_unmount(mount_point)
                self._safe_rmtree(mount_point)
            if mapper_name:
                subprocess.run(['cryptsetup', 'close', mapper_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if loop_device:
                subprocess.run(['losetup', '--detach', loop_device], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def _create_luks_container(self, session_path, size_mb, password):
        """Create exactly one LUKS2/ext4 file, without a partition table or nesting."""
        image_file = os.path.join(session_path, 'changes.luks')
        size_bytes = size_mb * 1024 * 1024
        result = subprocess.run(['fallocate', '-l', str(size_bytes), image_file],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode:
            with open(image_file, 'wb') as image:
                image.truncate(size_bytes)
        loop_device = mapper_name = None
        try:
            loop_result = subprocess.run(['losetup', '--find', '--show', '--', image_file],
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if loop_result.returncode:
                raise OSError(loop_result.stderr.decode(errors='replace').strip() or 'failed to attach loop device')
            loop_device = loop_result.stdout.decode().strip()
            self._cryptsetup(['cryptsetup', 'luksFormat', '--type', 'luks2', '--batch-mode',
                              '--key-file', '-', loop_device], password)
            mapper_name = self._luks_mapper_name()
            self._cryptsetup(['cryptsetup', 'open', '--type', 'luks', '--key-file', '-',
                              loop_device, mapper_name], password)
            subprocess.run(['mke2fs', '-F', '-t', 'ext4', '/dev/mapper/' + mapper_name], check=True,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(['sync'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        finally:
            if mapper_name:
                subprocess.run(['cryptsetup', 'close', mapper_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if loop_device:
                subprocess.run(['losetup', '--detach', loop_device], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def _wait_for_mount(self, path, timeout=10):
        """Wait for a file or directory to appear (polling)"""
        start_time = time.time()
        while time.time() - start_time < timeout:
            if os.path.exists(path):
                return True
            time.sleep(0.1)
        return False

    def _safe_unmount(self, mount_point, max_retries=5, use_lazy=True):
        """
        Safely unmount a mount point with retries and optional lazy unmount.
        
        Returns True if unmounted successfully, False otherwise.
        """
        if not mount_point or not os.path.exists(mount_point):
            return True
        
        # Check if actually mounted
        try:
            result = subprocess.run(
                ['mountpoint', '-q', mount_point],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            if result.returncode != 0:
                return True  # Not mounted
        except (OSError, IOError):
            pass
        
        # Try normal unmount with retries
        for i in range(max_retries):
            subprocess.run(['sync'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            res = subprocess.run(
                ['umount', mount_point],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            if res.returncode == 0:
                return True
            time.sleep(0.5 * (i + 1))  # Increasing delay
        
        # Try lazy unmount as last resort
        if use_lazy:
            res = subprocess.run(
                ['umount', '-l', mount_point],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            if res.returncode == 0:
                return True
        
        return False

    def _safe_fusermount(self, mount_point, max_retries=5):
        """
        Safely unmount a FUSE mount point with retries.
        
        Returns True if unmounted successfully, False otherwise.
        """
        if not mount_point or not os.path.exists(mount_point):
            return True
        
        for i in range(max_retries):
            subprocess.run(['sync'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            res = subprocess.run(
                ['fusermount', '-u', mount_point],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            if res.returncode == 0:
                return True
            time.sleep(0.5 * (i + 1))
        
        # Try lazy unmount
        res = subprocess.run(
            ['fusermount', '-uz', mount_point],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        return res.returncode == 0

    def _cleanup_process(self, process, timeout=5):
        """
        Safely terminate and cleanup a subprocess.
        
        Sends SIGTERM, waits, then SIGKILL if needed.
        """
        if process is None:
            return
        
        # Check if already terminated
        if process.poll() is not None:
            return
        
        # Try graceful termination
        try:
            process.terminate()
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            # Force kill
            process.kill()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass
        
        # Close pipes to prevent resource leaks
        try:
            if process.stdout:
                process.stdout.close()
            if process.stderr:
                process.stderr.close()
        except (OSError, IOError):
            pass

    def _safe_rmtree(self, path):
        """
        Safely remove a directory tree, only if not a mount point.
        """
        if not path or not os.path.exists(path):
            return True
        
        # Check if it's a mount point - don't remove if still mounted
        try:
            result = subprocess.run(
                ['mountpoint', '-q', path],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            if result.returncode == 0:
                # Still mounted, don't remove
                return False
        except (OSError, IOError):
            pass
        
        try:
            shutil.rmtree(path, ignore_errors=True)
            return True
        except (OSError, IOError):
            return False

    @contextlib.contextmanager
    def _mount_session_read(self, session_path, mode, password=None):
        """Context manager to mount a session for reading"""
        mount_point = None
        virtual_mount = None
        process = None
        
        try:
            if mode == 'native':
                # Check for OverlayFS structure
                changes_dir = os.path.join(session_path, 'changes')
                if os.path.exists(changes_dir) and os.path.isdir(changes_dir):
                    yield changes_dir
                else:
                    yield session_path
            
            elif mode == 'dynfilefs':
                changes_file = os.path.join(session_path, 'changes.dat')
                if not os.path.exists(changes_file):
                    raise Exception(_("DynFileFS container not found"))
                
                # Use system temp for mount point
                mount_point = tempfile.mkdtemp(prefix="minios_dyn_read_")
                
                # Mount dynfilefs
                cmd = ['dynfilefs', '-f', changes_file, '-m', mount_point]
                process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                virtual_file = os.path.join(mount_point, 'virtual.dat')
                if not self._wait_for_mount(virtual_file):
                    raise Exception(_("Failed to mount dynfilefs (timeout)"))
                    
                # Mount virtual file
                virtual_mount = tempfile.mkdtemp(prefix="minios_virt_read_")
                subprocess.run(['mount', '-o', 'loop,ro', virtual_file, virtual_mount], check=True)
                
                # Check for OverlayFS structure inside
                changes_dir = os.path.join(virtual_mount, 'changes')
                if os.path.exists(changes_dir) and os.path.isdir(changes_dir):
                    yield changes_dir
                else:
                    yield virtual_mount
            
            elif mode == 'raw':
                image_file = os.path.join(session_path, 'changes.img')
                if not os.path.exists(image_file):
                    raise Exception(_("Raw image not found"))
                
                mount_point = tempfile.mkdtemp(prefix="minios_raw_read_")
                subprocess.run(['mount', '-o', 'loop,ro', image_file, mount_point], check=True)
                
                changes_dir = os.path.join(mount_point, 'changes')
                if os.path.exists(changes_dir) and os.path.isdir(changes_dir):
                    yield changes_dir
                else:
                    yield mount_point

            elif mode == 'luks':
                image_file = os.path.join(session_path, 'changes.luks')
                if not os.path.exists(image_file):
                    raise Exception(_("LUKS container not found"))
                with self._mount_luks(image_file, password, writable=False) as luks_mount:
                    changes_dir = os.path.join(luks_mount, 'changes')
                    yield changes_dir if os.path.isdir(changes_dir) else luks_mount
            
            else:
                raise Exception(_("Unknown session mode: {}").format(mode))
                
        finally:
            # Cleanup virtual mount first (if exists)
            if virtual_mount:
                self._safe_unmount(virtual_mount)
                self._safe_rmtree(virtual_mount)
            
            # Cleanup dynfilefs process and FUSE mount
            if process:
                if mount_point:
                    self._safe_fusermount(mount_point)
                self._cleanup_process(process)
            elif mode == 'raw' and mount_point:
                # Raw mode unmount
                self._safe_unmount(mount_point)
            
            # Cleanup mount point directory
            if mount_point:
                self._safe_rmtree(mount_point)

    @contextlib.contextmanager
    def _mount_session_write(self, session_path, mode, size_mb=None, password=None):
        """Context manager to mount a session for writing"""
        mount_point = None
        virtual_mount = None
        process = None
        
        try:
            os.makedirs(session_path, exist_ok=True)
            
            if mode == 'native':
                # Use changes directory for native sessions to match OverlayFS structure
                changes_dir = os.path.join(session_path, 'changes')
                os.makedirs(changes_dir, exist_ok=True)
                yield changes_dir
            
            elif mode == 'dynfilefs':
                if not size_mb: size_mb = 4000
                changes_file = os.path.join(session_path, 'changes.dat')
                mount_point = tempfile.mkdtemp(prefix="minios_dyn_write_")
                
                cmd = ['dynfilefs', '-f', changes_file, '-m', mount_point, '-s', str(size_mb), '-p', '4000']
                process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                virtual_file = os.path.join(mount_point, 'virtual.dat')
                if not self._wait_for_mount(virtual_file):
                    raise Exception(_("Failed to create dynfilefs (timeout)"))
                    
                # Only format if new (size check is a rough proxy, better to check if file existed before)
                # But here we assume we are setting up for write. 
                # If changes.dat didn't exist, dynfilefs created it empty.
                # We need to check if it has a filesystem.
                # For simplicity in this refactor, we assume if we are calling this, we might be creating or writing.
                # If it's a new session creation, we need to format.
                # Let's check if we can mount it first.
                
                virtual_mount = tempfile.mkdtemp(prefix="minios_virt_write_")
                mount_result = subprocess.run(['mount', '-o', 'loop', virtual_file, virtual_mount], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                if mount_result.returncode != 0:
                    # Not formatted, format it
                    subprocess.run(['mke2fs', '-F', '-t', 'ext4', virtual_file], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    subprocess.run(['sync'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    subprocess.run(['mount', '-o', 'loop', virtual_file, virtual_mount], check=True)
                
                yield virtual_mount
                
            elif mode == 'raw':
                if not size_mb: size_mb = 4000
                image_file = os.path.join(session_path, 'changes.img')
                size_bytes = size_mb * 1024 * 1024
                
                if not os.path.exists(image_file):
                    subprocess.run(['fallocate', '-l', str(size_bytes), image_file], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    if not os.path.exists(image_file) or os.path.getsize(image_file) < size_bytes:
                         with open(image_file, 'wb') as f: f.truncate(size_bytes)
                    # Format new image
                    subprocess.run(['mke2fs', '-F', '-t', 'ext4', image_file], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    subprocess.run(['sync'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                mount_point = tempfile.mkdtemp(prefix="minios_raw_write_")
                subprocess.run(['mount', '-o', 'loop', image_file, mount_point], check=True)
                
                yield mount_point

            elif mode == 'luks':
                image_file = os.path.join(session_path, 'changes.luks')
                if not os.path.exists(image_file):
                    self._create_luks_container(session_path, size_mb or self.DEFAULT_CONTAINER_SIZE_MB, password)
                with self._mount_luks(image_file, password, writable=True) as luks_mount:
                    yield luks_mount
                
        finally:
            # Cleanup virtual mount first (if exists)
            if virtual_mount:
                self._safe_unmount(virtual_mount)
                self._safe_rmtree(virtual_mount)
            
            # Cleanup dynfilefs process and FUSE mount
            if process:
                if mount_point:
                    self._safe_fusermount(mount_point)
                self._cleanup_process(process)
            elif mode == 'raw' and mount_point:
                # Raw mode unmount
                self._safe_unmount(mount_point)
            
            # Cleanup mount point directory
            if mount_point:
                self._safe_rmtree(mount_point)

    def _create_dynfilefs_session(self, session_path, initial_size_mb=1000):
        """Create a dynfilefs session structure"""
        temp_mount = None
        process = None
        try:
            changes_file = os.path.join(session_path, "changes.dat")
            temp_mount = tempfile.mkdtemp(prefix="minios_dyn_create_")
            process = subprocess.Popen([
                'dynfilefs', '-f', changes_file, '-m', temp_mount,
                '-s', str(initial_size_mb), '-p', '4000'
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            virtual_file = os.path.join(temp_mount, "virtual.dat")
            if not self._wait_for_mount(virtual_file):
                return False, _("Failed to create dynfilefs virtual file (timeout)")
            format_result = subprocess.run(
                ['mke2fs', '-F', '-t', 'ext4', virtual_file],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if format_result.returncode != 0:
                return False, _("Failed to format dynfilefs virtual file: {}").format(format_result.stderr.decode())
            subprocess.run(['sync'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return True, _("DynFileFS session created successfully")
        except Exception as e:
            return False, _("Error creating dynfilefs session: {}").format(str(e))
        finally:
            if temp_mount:
                self._safe_fusermount(temp_mount)
            self._cleanup_process(process)
            if temp_mount:
                self._safe_rmtree(temp_mount)

    def _get_dynfilefs_size(self, session_path):
        """Get the actual size of a dynfilefs session"""
        changes_file = os.path.join(session_path, "changes.dat")
        total_size = 0
        
        try:
            # Count all changes.dat.* files
            for file in os.listdir(session_path):
                if file.startswith("changes.dat"):
                    file_path = os.path.join(session_path, file)
                    if os.path.isfile(file_path):
                        total_size += os.path.getsize(file_path)
        except Exception:
            pass
        
        return total_size

    def _get_session_size_info(self, session_path, session_data):
        """Get comprehensive size information for a session"""
        session_mode = session_data.get('mode', 'unknown')
        stored_size = session_data.get('size')  # Size in MB from metadata

        # Convert stored_size to int if it's a string, and normalize to MB
        if stored_size is not None:
            try:
                stored_size = int(stored_size)
                # Auto-detect if stored as bytes vs MB
                # If > 100000, assume it's in bytes and convert to MB
                if stored_size > 100000:
                    stored_size = max(100, int(stored_size / (1024 * 1024)))
            except (ValueError, TypeError):
                stored_size = None

        if session_mode == 'dynfilefs':
            # For dynfilefs, show used/total format
            used_size = self._get_dynfilefs_size(session_path)
            if stored_size is not None:
                total_size_bytes = stored_size * 1024 * 1024
                display = f"{self._format_size(used_size)}/{self._format_size(total_size_bytes)}"
                return {
                    'used_size': used_size,
                    'total_size': total_size_bytes,
                    'display': display
                }
            else:
                # Fallback to just used size if no stored size
                display = self._format_size(used_size)
                return {
                    'used_size': used_size,
                    'display': display
                }
        
        elif session_mode == 'raw':
            # For raw, show total size (the image file size)
            image_file = os.path.join(session_path, "changes.img")
            if os.path.exists(image_file):
                size = os.path.getsize(image_file)
                display = self._format_size(size)
                return {
                    'used_size': size,
                    'display': display
                }

        elif session_mode == 'luks':
            image_file = os.path.join(session_path, 'changes.luks')
            if os.path.exists(image_file):
                size = os.path.getsize(image_file)
                return {'used_size': size, 'display': self._format_size(size), 'total_size': size}
            if stored_size:
                size = stored_size * 1024 * 1024
                return {'used_size': size, 'display': self._format_size(size), 'total_size': size}
            elif stored_size:
                # Fallback to stored size if image not found
                size_bytes = stored_size * 1024 * 1024
                display = self._format_size(size_bytes)
                return {
                    'used_size': size_bytes,
                    'display': display
                }
        
        # For native mode or fallback, calculate directory size
        size = self._get_directory_size(session_path)
        display = self._format_size(size)
        return {
            'used_size': size,
            'display': display
        }

    def get_current_session(self):
        """Get information about currently active session"""
        metadata = self._read_sessions_metadata()
        current_id = metadata.get('default')
        
        if not current_id:
            return None
            
        sessions = self.list_sessions(include_running_check=False)  # Avoid recursion
        for session in sessions:
            if session['id'] == current_id:
                return session
        return None

    def get_running_session(self, avoid_recursion=False):
        """Get information about currently running session"""
        # Read running session ID from metadata
        metadata = self._read_sessions_metadata()
        running_id = metadata.get('running')
        
        if not running_id:
            return None
            
        # Get session info for the running session
        return self._get_session_info(running_id, avoid_recursion)

    def set_running_session(self, session_id):
        """Set currently running session in metadata"""
        try:
            self._validate_session_id(session_id)
            with self._mutation_lock():
                metadata = self._read_sessions_metadata()
                metadata['running'] = session_id
                return self._write_sessions_metadata(metadata)
        except Exception as e:
            print(f"Error setting running session: {e}", file=sys.stderr)
            return False

    def clear_running_session(self):
        """Clear running session from metadata"""
        try:
            with self._mutation_lock():
                metadata = self._read_sessions_metadata()
                if 'running' in metadata:
                    del metadata['running']
                return self._write_sessions_metadata(metadata)
        except Exception as e:
            print(f"Error clearing running session: {e}", file=sys.stderr)
            return False

    def _get_session_info(self, session_id, avoid_recursion=False):
        """Helper to get session info by ID"""
        try:
            session_id = self._validate_session_id(session_id)
        except ValueError:
            return None
        if avoid_recursion:
            # Simple session info without full list
            session_path = self._session_path(session_id) if self.sessions_dir else None
            return {
                'id': session_id,
                'path': session_path,
                'mode': 'unknown',
                'version': 'unknown', 
                'edition': 'unknown',
                'union': 'unknown',
                'size': 0,
                'modified': None,
                'is_default': False
            }
        else:
            sessions = self.list_sessions(include_running_check=False)
            for session in sessions:
                if session['id'] == session_id:
                    return session
            # Session exists in cmdline but not in filesystem
            return {
                'id': session_id,
                'path': self._session_path(session_id) if self.sessions_dir else None,
                'mode': 'unknown',
                'version': 'unknown',
                'edition': 'unknown',
                'union': 'unknown',
                'size': 0,
                'modified': None,
                'is_default': False,
                'status': 'running_missing'
            }

    def activate_session(self, session_id):
        """Activate a session (set as default)"""
        if not self.sessions_dir:
            return False, _("Sessions directory not found")
            
        try:
            self._session_path(session_id, require_exists=True)
        except ValueError as e:
            return False, str(e)
        
        try:
            # Update metadata to set new default
            with self._mutation_lock():
                metadata = self._read_sessions_metadata()
                old_default = metadata.get("default")
                metadata["default"] = session_id
                updated = self._write_sessions_metadata(metadata)
            if updated:
                if old_default:
                    return True, _("Session {} activated (was session {})").format(session_id, old_default)
                else:
                    return True, _("Session {} activated").format(session_id)
            else:
                return False, _("Failed to update session metadata")
        except Exception as e:
            return False, _("Error activating session: {}").format(str(e))

    def create_session(self, session_mode="native", size_mb=None, password=None):
        """Create a new session"""
        if not self.sessions_dir:
            return False, _("Sessions directory not found")
        
        # Validate session mode
        valid_modes = ["native", "dynfilefs", "raw", "luks"]
        if session_mode not in valid_modes:
            return False, _("Invalid session mode. Must be one of: {}").format(", ".join(valid_modes))
        
        # Check if sessions directory is writable
        dir_status = self.check_sessions_directory_status()
        if not dir_status.get('writable', False):
            error_msg = dir_status.get('error', _("Sessions directory is not writable"))
            return False, error_msg
        
        valid_target, target_error = self._validate_target_mode(session_mode, size_mb)
        if not valid_target:
            return False, target_error
        
        # Check dynfilefs availability for dynfilefs mode
        if session_mode == "dynfilefs" and not self._check_dynfilefs_available():
            return False, _("DynFileFS is not available on this system. Please install dynfilefs package.")

        # Check free disk space
        required_mb = size_mb if size_mb else self.DEFAULT_CONTAINER_SIZE_MB
        has_space, space_error = self._check_free_space(self.sessions_dir, required_mb)
        if not has_space:
            return False, space_error

        try:
            new_id, session_path = self._reserve_session()
            
            # Initialize session based on mode
            if session_mode == "dynfilefs":
                # Set default size if not specified
                if size_mb is None:
                    size_mb = self.DEFAULT_CONTAINER_SIZE_MB

                success, message = self._create_dynfilefs_session(session_path, size_mb)
                if not success:
                    # Clean up on failure
                    try:
                        shutil.rmtree(session_path)
                    except Exception:
                        pass
                    return False, message
            
            elif session_mode == "raw":
                # Create raw image file
                if size_mb is None:
                    size_mb = self.DEFAULT_CONTAINER_SIZE_MB
                
                image_file = os.path.join(session_path, "changes.img")
                try:
                    # Create image file with fallocate (works on both sparse and non-sparse filesystems)
                    size_bytes = size_mb * 1024 * 1024
                    result = subprocess.run(['fallocate', '-l', str(size_bytes), image_file],
                                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    if result.returncode != 0:
                        # Fallback to truncate if fallocate not available
                        with open(image_file, 'wb') as f:
                            f.truncate(size_bytes)

                    # Format with ext4
                    format_cmd = ['mke2fs', '-F', '-t', 'ext4', image_file]
                    format_result = subprocess.run(format_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    # Sync to ensure filesystem is written (important for FAT32/NTFS)
                    subprocess.run(['sync'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

                    if format_result.returncode != 0:
                        shutil.rmtree(session_path)
                        return False, _("Failed to format raw image file: {}").format(format_result.stderr.decode())
                        
                except Exception as e:
                    shutil.rmtree(session_path)
                    return False, _("Failed to create raw image file: {}").format(str(e))

            elif session_mode == 'luks':
                size_mb = size_mb or self.DEFAULT_CONTAINER_SIZE_MB
                # Build outside the reserved directory, then atomically publish it.
                staging_path = self._make_temp_dir()
                try:
                    self._create_luks_container(staging_path, size_mb, password)
                    os.rmdir(session_path)
                    os.rename(staging_path, session_path)
                except Exception:
                    shutil.rmtree(staging_path, ignore_errors=True)
                    shutil.rmtree(session_path, ignore_errors=True)
                    raise
            
            # For native mode, just create empty directory (no special initialization needed)
            
            # Get system version and edition
            version = "unknown"
            edition = "unknown"
            union = self._get_current_union_fs()
            
            # Try to read from /etc/minios-release
            release_file = "/etc/minios-release"
            if os.path.exists(release_file):
                try:
                    with open(release_file, 'r') as f:
                        for line in f:
                            if line.startswith("VERSION="):
                                version = line.split("=", 1)[1].strip().strip('"')
                            elif line.startswith("EDITION="):
                                edition = line.split("=", 1)[1].strip().strip('"')
                except Exception:
                    pass
            
            # Keep the metadata read-modify-write transaction under one lock.
            with self._mutation_lock():
                metadata = self._read_sessions_metadata()
                metadata.setdefault("sessions", {})
                metadata["sessions"][new_id] = {
                    "mode": session_mode, "version": version, "edition": edition,
                    "union": union
                }
                if session_mode in ["dynfilefs", "raw", "luks"] and size_mb:
                    metadata["sessions"][new_id]["size"] = size_mb
                metadata_updated = self._write_sessions_metadata(metadata)
            if metadata_updated:
                # Use safer string formatting to avoid potential translation issues
                try:
                    if session_mode == "dynfilefs":
                        message = _("Session {} created successfully (mode: {}, size: {}MB)").format(new_id, session_mode, size_mb)
                    elif session_mode in ("raw", "luks"):
                        message = _("Session {} created successfully (mode: {}, size: {}MB)").format(new_id, session_mode, size_mb)
                    else:
                        message = _("Session {} created successfully (mode: {})").format(new_id, session_mode)
                    return True, message
                except Exception:
                    # Fallback to simple English message if translation fails
                    if session_mode in ["dynfilefs", "raw", "luks"] and size_mb is not None:
                        return True, f"Session {new_id} created successfully (mode: {session_mode}, size: {size_mb}MB)"
                    else:
                        return True, f"Session {new_id} created successfully (mode: {session_mode})"
            else:
                # Clean up on metadata failure
                try:
                    shutil.rmtree(session_path)
                except Exception:
                    pass
                return False, _("Failed to update session metadata")
                
        except Exception as e:
            return False, _("Error creating session: {}").format(str(e))

    def delete_session(self, session_id):
        """Delete a session"""
        if not self.sessions_dir:
            return False, _("Sessions directory not found")
            
        try:
            session_path = self._session_path(session_id, require_exists=True)
        except ValueError as e:
            return False, str(e)
        
        # Check if it's the current session
        current = self.get_current_session()
        if current and current['id'] == session_id:
            return False, _("Cannot delete currently active session")
        
        # Check if it's the running session
        running = self.get_running_session()
        if running and running['id'] == session_id:
            return False, _("Cannot delete currently running session")
        
        try:
            with self._mutation_lock():
                shutil.rmtree(session_path)
                metadata = self._read_sessions_metadata()
                if session_id in metadata.get("sessions", {}):
                    del metadata["sessions"][session_id]
                    if not self._write_sessions_metadata(metadata):
                        return False, _("Session deleted but failed to update session metadata")
            
            return True, _("Session {} deleted successfully").format(session_id)
        except Exception as e:
            return False, _("Error deleting session: {}").format(str(e))

    def cleanup_stale_temp_dirs(self, max_age_seconds=86400):
        """Clean up stale temporary directories in sessions folder"""
        if not self.sessions_dir or not os.path.exists(self.sessions_dir):
            return 0
            
        count = 0
        now = time.time()
        
        try:
            for item in os.listdir(self.sessions_dir):
                if item.startswith(".tmp_"):
                    path = os.path.join(self.sessions_dir, item)
                    if os.path.isdir(path):
                        try:
                            stat = os.stat(path)
                            if now - stat.st_mtime > max_age_seconds:
                                shutil.rmtree(path, ignore_errors=True)
                                count += 1
                        except OSError:
                            pass
        except OSError:
            pass
            
        return count

    def cleanup_old_sessions(self, days_threshold=30):
        """Clean up sessions older than specified days"""
        if days_threshold <= 0:
            return 0, [_('Days threshold must be greater than zero')]
        sessions = self.list_sessions()
        current = self.get_current_session()
        current_id = current['id'] if current else None
        running = self.get_running_session()
        running_id = running['id'] if running else None
        
        old_sessions = []
        cutoff_date = datetime.now().timestamp() - (days_threshold * 24 * 3600)
        
        for session in sessions:
            # Skip current (active) session, running session, and sessions newer than cutoff
            if (session['id'] != current_id and 
                session['id'] != running_id and 
                session['modified'].timestamp() < cutoff_date):
                old_sessions.append(session)
        
        deleted_count = 0
        errors = []
        
        for session in old_sessions:
            success, message = self.delete_session(session['id'])
            if success:
                deleted_count += 1
            else:
                errors.append(f"Session {session['id']}: {message}")
        
        # Also cleanup stale temp dirs (older than 1 day)
        self.cleanup_stale_temp_dirs(max_age_seconds=86400)
        
        return deleted_count, errors

    def resize_session(self, session_id, new_size_mb, password=None):
        """Resize a session to new size"""
        if not self.sessions_dir:
            return False, _("Sessions directory not found")
            
        try:
            session_path = self._session_path(session_id, require_exists=True)
        except ValueError as e:
            return False, str(e)
        if new_size_mb <= 0:
            return False, _("Session size must be greater than zero")
        with self._mutation_lock():
            # Hold the lock across the data change and metadata commit.  A
            # resize cannot be atomic at the filesystem level, so callers
            # never see a completed data resize with stale metadata.
            metadata = self._read_sessions_metadata()
            session_data = metadata.get("sessions", {}).get(session_id, {})
            session_mode = session_data.get("mode", "unknown")
            if session_mode not in ["dynfilefs", "raw", "luks"]:
                return False, _("Resize is only supported for dynfilefs, raw, and LUKS mode sessions")
            valid_target, target_error = self._validate_target_mode(session_mode, new_size_mb)
            if not valid_target:
                return False, target_error
            running = self.get_running_session()
            if running and running['id'] == session_id:
                return False, _("Cannot resize currently running session")
            try:
                if session_mode == "dynfilefs":
                    return self._resize_dynfilefs_session(session_path, new_size_mb, session_id, metadata)
                if session_mode == 'luks':
                    return self._resize_luks_session(session_path, new_size_mb, session_id, metadata, password)
                return self._resize_raw_session(session_path, new_size_mb, session_id, metadata)
            except Exception as e:
                return False, _("Error resizing session: {}").format(str(e))

    def _resize_dynfilefs_session(self, session_path, new_size_mb, session_id, metadata):
        """Resize a dynfilefs session"""
        changes_file = os.path.join(session_path, "changes.dat")
        if not os.path.exists(changes_file):
            return False, _("DynFileFS changes.dat file not found")
        
        try:
            # Get current total size from metadata
            current_total_size = metadata.get("sessions", {}).get(session_id, {}).get("size", 0)
            if isinstance(current_total_size, str):
                current_total_size = int(current_total_size)
            
            # Get actually used size
            used_size_bytes = self._get_dynfilefs_size(session_path)
            used_size_mb = used_size_bytes // (1024 * 1024)
            
            # Check both conditions: new size must be larger than both current total AND used size
            if new_size_mb <= current_total_size:
                return False, _("New size must be larger than current total size ({}MB)").format(current_total_size)
            
            if new_size_mb <= used_size_mb:
                return False, _("New size must be larger than used size ({}MB)").format(used_size_mb)
            
            # Create temporary mount point for resizing
            temp_mount = f"/tmp/dynfilefs_resize_{session_id}_{os.getpid()}"
            os.makedirs(temp_mount, exist_ok=True)
            
            try:
                # Mount dynfilefs with the new size - this will expand the virtual.dat file automatically
                mount_cmd = [
                    'dynfilefs', 
                    '-f', changes_file, 
                    '-m', temp_mount, 
                    '-s', str(new_size_mb),
                    '-d'  # Debug mode to run in foreground
                ]
                
                # Start dynfilefs process
                process = subprocess.Popen(mount_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                # Check if virtual.dat was created/resized
                virtual_file = os.path.join(temp_mount, "virtual.dat")
                if not self._wait_for_mount(virtual_file):
                    process.terminate()
                    return False, _("Failed to create/resize virtual.dat file (timeout)")
                
                # Now we need to resize the filesystem inside virtual.dat
                # Resize the filesystem (will perform necessary checks)
                resize_cmd = ['resize2fs', '-f', virtual_file]
                resize_result = subprocess.run(resize_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                if resize_result.returncode != 0:
                    process.terminate()
                    return False, _("Failed to resize filesystem: {}").format(resize_result.stderr.decode())
                
                # Terminate the dynfilefs process (unmount)
                process.terminate()
                process.wait()
                
            finally:
                # Clean up: ensure unmount and remove temp directory
                subprocess.run(['fusermount', '-u', temp_mount], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                try:
                    os.rmdir(temp_mount)
                except Exception:
                    pass
            
            # Update our session metadata with new size
            metadata["sessions"][session_id]["size"] = new_size_mb
            if not self._write_sessions_metadata(metadata):
                return False, _("Failed to update session metadata")
            
            return True, _("Session {} resized to {}MB successfully").format(session_id, new_size_mb)
            
        except Exception as e:
            return False, _("Failed to resize dynfilefs session: {}").format(str(e))

    def _resize_raw_session(self, session_path, new_size_mb, session_id, metadata):
        """Resize a raw session"""
        image_file = os.path.join(session_path, "changes.img")
        if not os.path.exists(image_file):
            return False, _("Raw image file not found")
        
        try:
            # Get current size
            original_size_bytes = os.path.getsize(image_file)
            current_size = original_size_bytes // (1024 * 1024)
            recorded_size = metadata.get("sessions", {}).get(session_id, {}).get("size")
            if isinstance(recorded_size, str):
                recorded_size = int(recorded_size)
            if current_size == new_size_mb and recorded_size != new_size_mb:
                # Recover an interrupted post-resize metadata commit without
                # touching an already-grown filesystem again.
                metadata["sessions"][session_id]["size"] = new_size_mb
                if self._write_sessions_metadata(metadata):
                    return True, _("Session {} resize metadata recovered").format(session_id)
                return False, _("Failed to recover resize metadata")
            if new_size_mb <= current_size:
                return False, _("New size must be larger than current size ({}MB)").format(current_size)
            
            # Truncate image file to new size
            new_size_bytes = new_size_mb * 1024 * 1024
            with open(image_file, 'r+b') as f:
                f.truncate(new_size_bytes)
                f.flush()
                os.fsync(f.fileno())
            
            # Resize the filesystem inside the image (will perform necessary checks)
            resize_cmd = ['resize2fs', '-f', image_file]
            resize_result = subprocess.run(resize_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            
            if resize_result.returncode != 0:
                # resize2fs failed before commit: restore the exact container
                # length so this operation is safely retryable.
                with open(image_file, 'r+b') as f:
                    f.truncate(original_size_bytes)
                    f.flush()
                    os.fsync(f.fileno())
                return False, _("Failed to resize filesystem: {}").format(resize_result.stderr.decode())
            
            # Update metadata with new size
            metadata["sessions"][session_id]["size"] = new_size_mb
            if not self._write_sessions_metadata(metadata):
                return False, _("Failed to update session metadata")
            
            return True, _("Session {} resized to {}MB successfully").format(session_id, new_size_mb)
            
        except Exception as e:
            return False, _("Failed to resize raw session: {}").format(str(e))

    def _resize_luks_session(self, session_path, new_size_mb, session_id, metadata, password):
        """Grow a LUKS file and its ext4 filesystem; shrinking is deliberately unsupported."""
        image_file = os.path.join(session_path, 'changes.luks')
        journal_path = os.path.join(session_path, '.luks-resize.json')
        if not os.path.exists(image_file):
            return False, _("LUKS container not found")
        original_size = os.path.getsize(image_file)
        current_size = original_size // (1024 * 1024)
        recorded_size = metadata.get('sessions', {}).get(session_id, {}).get('size')
        try:
            with open(journal_path, encoding='utf-8') as journal_file:
                pending_size = int(json.load(journal_file)['size'])
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError):
            pending_size = None
        if pending_size and current_size >= pending_size and recorded_size != pending_size:
            # A previous filesystem grow completed but its metadata commit did
            # not.  The journal makes that committed data state recoverable.
            metadata['sessions'][session_id]['size'] = pending_size
            if self._write_sessions_metadata(metadata):
                try:
                    os.unlink(journal_path)
                except OSError:
                    pass
                return True, _("Session {} resize metadata recovered").format(session_id)
            return False, _("Failed to recover resize metadata")
        if current_size == new_size_mb and recorded_size != new_size_mb:
            metadata['sessions'][session_id]['size'] = new_size_mb
            if self._write_sessions_metadata(metadata):
                return True, _("Session {} resize metadata recovered").format(session_id)
            return False, _("Failed to recover resize metadata")
        if new_size_mb <= current_size:
            return False, _("New size must be larger than current size ({}MB)").format(current_size)
        filesystem_grown = False
        temporary_journal = None
        try:
            fd, temporary_journal = tempfile.mkstemp(prefix='.luks-resize-', dir=session_path)
            with os.fdopen(fd, 'w') as journal_file:
                json.dump({'size': new_size_mb}, journal_file)
                journal_file.flush()
                os.fsync(journal_file.fileno())
            os.replace(temporary_journal, journal_path)
            with open(image_file, 'r+b') as image:
                image.truncate(new_size_mb * 1024 * 1024)
                image.flush()
                os.fsync(image.fileno())
            with self._mount_luks(image_file, password, writable=True) as mount_point:
                # The mapper is mounted, so resize its filesystem device directly.
                device = subprocess.run(['findmnt', '-no', 'SOURCE', '--target', mount_point],
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout.decode().strip()
                result = subprocess.run(['resize2fs', '-f', device], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if result.returncode:
                    raise OSError(result.stderr.decode(errors='replace'))
                filesystem_grown = True
            metadata['sessions'][session_id]['size'] = new_size_mb
            if not self._write_sessions_metadata(metadata):
                return False, _("Failed to update session metadata")
            try:
                os.unlink(journal_path)
            except OSError:
                pass
            return True, _("Session {} resized to {}MB successfully").format(session_id, new_size_mb)
        except Exception as error:
            # Never shrink a filesystem that may already have grown.
            if not filesystem_grown:
                with open(image_file, 'r+b') as image:
                    image.truncate(original_size)
                try:
                    os.unlink(journal_path)
                except OSError:
                    pass
            if temporary_journal and os.path.exists(temporary_journal):
                os.unlink(temporary_journal)
            return False, _("Failed to resize LUKS session: {}").format(str(error))

    def export_session(self, session_id, output_path, verify=True, password=None):
        """Export session to TAR.ZSTD archive (streaming)

        Args:
            session_id: ID of session to export
            output_path: Path to output file or directory
            verify: Verify archive after creation

        Returns:
            (success, message) tuple
        """
        # Get session info
        try:
            session_id = self._validate_session_id(session_id)
        except ValueError as e:
            return False, str(e)
        session_info = self._get_session_info(session_id)
        if not session_info:
            return False, _("Session #{} not found").format(session_id)

        try:
            session_path = self._session_path(session_id, require_exists=True)
        except ValueError as e:
            return False, str(e)

        # Check if session is running
        running = self.get_running_session()
        if running and running['id'] == session_id:
            return False, _("Cannot export currently running session")

        # Generate filename if output_path is directory
        if os.path.isdir(output_path):
            timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
            filename = f"session-{session_id}-{timestamp}.tar.zst"
            output_file = os.path.join(output_path, filename)
        else:
            output_file = output_path
            # Ensure .tar.zst extension
            if not output_file.endswith('.tar.zst'):
                output_file += '.tar.zst'

        output_dir = os.path.dirname(output_file) or '.'
        try:
            output_stat = os.lstat(output_file)
            if not stat.S_ISREG(output_stat.st_mode):
                return False, _("Export output must be a regular file")
        except FileNotFoundError:
            pass

        # Check free disk space (estimate: session size + 50% for compression overhead)
        session_size_mb = session_info.get('size', 0) / (1024 * 1024)
        estimated_archive_mb = session_size_mb * 1.5
        has_space, space_error = self._check_free_space(output_dir, estimated_archive_mb)
        if not has_space:
            return False, space_error

        temp_output = None
        try:
            output_fd, temp_output = tempfile.mkstemp(prefix='.session-export-', suffix='.tar.zst', dir=output_dir)
            os.close(output_fd)
            # Use temp directory in RAM (default temp) for metadata
            with tempfile.TemporaryDirectory() as meta_dir:
                # Prepare metadata
                metadata = self._prepare_export_metadata(session_info)
                metadata_file = os.path.join(meta_dir, 'metadata.json')
                with open(metadata_file, 'w') as f:
                    json.dump(metadata, f, indent=2)

                # Create human-readable info
                info_file = os.path.join(meta_dir, 'session.info')
                self._create_session_info_file(session_info, info_file)

                # Mount session and stream to archive
                with self._mount_session_read(session_path, session_info['mode'], password=password) as source_dir:
                    # Exclude list
                    excludes = [
                        '--exclude=workdir',
                        '--exclude=.wh..wh.orph',
                        '--exclude=.wh..wh.plnk',
                        '--exclude=.wh..wh.aufs'
                    ]
                    
                    # Construct tar command
                    # We use transform to put metadata at root and files in data/
                    # Use 'S' flag to prevent transforming symlink targets
                    cmd = [
                        'tar', '-cf', temp_output,
                        '--use-compress-program=zstd -3 -T0',
                        '-C', meta_dir, 'metadata.json', 'session.info',
                        '--transform', 's,^,data/,S',
                    ] + excludes + [
                        '-C', source_dir, '.'
                    ]
                    
                    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    if result.returncode != 0:
                        raise Exception(result.stderr.decode())

            # Verify if requested
            if verify:
                if not self._verify_export(temp_output):
                    return False, _("Export verification failed")

            file_size = os.path.getsize(temp_output)
            pkexec_uid = os.environ.get('PKEXEC_UID')
            if pkexec_uid is not None:
                os.chown(temp_output, int(pkexec_uid), -1)
            # os.replace is atomic and never follows an existing destination
            # symlink; the archive becomes visible only after verification.
            os.replace(temp_output, output_file)
            temp_output = None
            return True, _("Session exported successfully to {} ({})").format(
                output_file, self._format_size(file_size))

        except Exception as e:
            # Clean up on error
            return False, _("Export failed: {}").format(str(e))
        finally:
            if temp_output and os.path.exists(temp_output):
                os.unlink(temp_output)

    def _prepare_export_metadata(self, session_info):
        """Prepare minimal export metadata

        Only essential information for compatibility checks and auto-sizing.
        """
        metadata = {
            "version": "1.0",
            "date": datetime.now().isoformat() + 'Z',
            "session": {
                "mode": session_info['mode'],
                "version": session_info['version'],
                "edition": session_info['edition'],
                "union": session_info['union'],
                "size": session_info['size']
            }
        }

        return metadata

    def _create_session_info_file(self, session_info, output_path):
        """Create human-readable session info file"""
        lines = [
            "MiniOS Session Archive",
            "=" * 40,
            "",
            f"Version: {session_info['version']}",
            f"Edition: {session_info['edition']}",
            f"Union FS: {session_info['union']}",
            f"Size: {self._format_size(session_info['size'])}",
            "",
            f"Exported: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        ]

        with open(output_path, 'w') as f:
            f.write('\n'.join(lines))



    def _extract_session_to_files(self, session_path, mode, tmpdir):
        """Extract session data to raw file tree

        Args:
            session_path: Path to session directory
            mode: Session mode (native/dynfilefs/raw)
            tmpdir: Temporary directory for extraction

        Returns:
            Path to extracted files
        """
        extract_path = os.path.join(tmpdir, 'files')
        os.makedirs(extract_path)

        if mode == 'native':
            # Extract only the upperdir content, not OverlayFS structure
            # Check for OverlayFS structure (changes directory)
            changes_dir = os.path.join(session_path, 'changes')
            if os.path.exists(changes_dir) and os.path.isdir(changes_dir):
                # OverlayFS: extract from changes directory
                source_dir = changes_dir
            else:
                # AUFS or direct: files are in session_path itself
                source_dir = session_path

            # Copy files using rsync, excluding OverlayFS/AUFS metadata
            os.makedirs(extract_path, exist_ok=True)

            # Use rsync with filters to exclude problematic files
            # Keep user .wh.* files (AUFS whiteouts for deleted files)
            rsync_cmd = [
                'rsync', '-aH',  # archive mode + preserve hard links
                '--exclude=workdir',              # OverlayFS work directory
                '--exclude=.wh..wh.orph',         # AUFS orphan directory
                '--exclude=.wh..wh.plnk',         # AUFS pseudo-link directory
                '--exclude=.wh..wh.aufs',         # AUFS metadata file
                '--prune-empty-dirs',
            ]

            # Add trailing slashes for directory contents
            rsync_cmd.append(source_dir.rstrip('/') + '/')
            rsync_cmd.append(extract_path.rstrip('/') + '/')

            try:
                result = subprocess.run(rsync_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)

                # rsync may return 23 (partial transfer) if some special files couldn't be copied
                # This is acceptable (e.g., char devices, sockets)
                if result.returncode not in [0, 23, 24]:
                    stderr_text = result.stderr.decode() if result.stderr else ""
                    raise Exception(f"rsync failed with code {result.returncode}: {stderr_text}")

            except Exception as e:
                raise Exception(f"Failed to copy session files: {e}")

            return extract_path

        elif mode == 'dynfilefs':
            # Mount dynfilefs and extract files
            return self._extract_from_dynfilefs(session_path, extract_path)

        elif mode == 'raw':
            # Mount raw image and extract files
            return self._extract_from_raw(session_path, extract_path)

        else:
            raise Exception(_("Unknown session mode: {}").format(mode))





    def _verify_export(self, archive_file):
        """Verify TAR.ZSTD archive integrity"""
        try:
            # Test archive integrity
            cmd = ['tar', '-tf', archive_file, '--use-compress-program=zstd -T0']
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            if result.returncode != 0:
                return False

            # Verify metadata.json exists
            output = result.stdout.decode()
            if 'metadata.json' not in output or 'session.info' not in output:
                return False

            return True
        except Exception:
            return False

    def _validate_archive(self, archive_path):
        """Reject unsafe members and cap extraction before writing any data."""
        try:
            result = subprocess.run(
                ['tar', '-tvf', archive_path, '--use-compress-program=zstd -T0', '--numeric-owner'],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            if result.returncode != 0:
                return False, _("Invalid or unreadable archive")
            total_size = 0
            for line in result.stdout.decode('utf-8', 'strict').splitlines():
                # GNU tar verbose listings start with the member type; the
                # size is the third field when --numeric-owner is specified.
                fields = line.split(maxsplit=5)
                if len(fields) < 6 or fields[0][0] not in '-dlh':
                    return False, _("Archive contains an unsupported member type")
                try:
                    member_size = int(fields[2])
                except ValueError:
                    return False, _("Archive contains invalid member metadata")
                total_size += member_size
                if total_size > self.MAX_ARCHIVE_EXTRACTED_BYTES:
                    return False, _("Archive expands beyond the allowed size")
                name = fields[5].split(' -> ', 1)[0].split(' link to ', 1)[0]
                normalized = os.path.normpath(name)
                if (name.startswith('/') or '..' in Path(name).parts
                        or normalized in ('.', '..') or normalized.startswith('../')):
                    return False, _("Archive contains an unsafe member path")
                if normalized not in ('metadata.json', 'session.info', 'data') and not normalized.startswith('data/'):
                    return False, _("Archive contains files outside its data directory")
                if fields[0][0] in 'lh' and (' -> ' in fields[5] or ' link to ' in fields[5]):
                    target = fields[5].split(' -> ', 1)[-1].split(' link to ', 1)[-1]
                    target_path = os.path.normpath(target)
                    if (target.startswith('/') or '..' in Path(target).parts
                            or target_path == '..' or target_path.startswith('../')):
                        return False, _("Archive contains an unsafe link target")
            return True, None
        except (OSError, UnicodeDecodeError):
            return False, _("Invalid or unreadable archive")

    def _validate_import_metadata(self, metadata):
        """Validate the small, untrusted metadata document before using it."""
        if not isinstance(metadata, dict) or not isinstance(metadata.get('session'), dict):
            return False
        session = metadata['session']
        return (session.get('mode') in ('native', 'dynfilefs', 'raw', 'luks')
                and all(isinstance(session.get(key), str) for key in ('version', 'edition', 'union')))

    def import_session(self, archive_path, auto_convert=False, force_mode=None,
                       verify=True, skip_compatibility_check=False, password=None):
        """Import session from TAR.ZSTD archive (streaming)

        Args:
            archive_path: Path to archive file
            auto_convert: Automatically convert to compatible mode
            force_mode: Force specific mode (native/dynfilefs/raw)
            verify: Verify session integrity after import
            skip_compatibility_check: Skip compatibility checks

        Returns:
            (success, message) tuple
        """
        # Check archive exists
        if not os.path.exists(archive_path):
            return False, _("Archive file not found")

        # Detect and verify archive format
        if not archive_path.endswith('.tar.zst'):
            return False, _("Invalid archive format. Only .tar.zst files are supported.")

        try:
            valid_archive, archive_error = self._validate_archive(archive_path)
            if not valid_archive:
                return False, archive_error
            # Extract metadata directly from archive
            metadata = self._extract_metadata(archive_path)
            if not self._validate_import_metadata(metadata):
                return False, _("Invalid session archive: missing or corrupted metadata")

            # Compatibility checks
            if not skip_compatibility_check:
                compat_result = self._check_import_compatibility(metadata)
                if not compat_result['compatible']:
                    if not auto_convert and not force_mode:
                        return False, _("Incompatible session: {}").format(
                            ', '.join(compat_result['issues']))

            # Determine import mode
            import_mode = metadata['session']['mode']
            if force_mode:
                import_mode = force_mode
            elif auto_convert:
                import_mode = self._select_compatible_mode(metadata)

            valid_target, target_error = self._validate_target_mode(import_mode)
            if not valid_target:
                return False, target_error

            # Check free disk space
            session_size_bytes = metadata['session'].get('size', 4000 * 1024 * 1024)
            if isinstance(session_size_bytes, int) and session_size_bytes > 100000:
                required_mb = session_size_bytes / (1024 * 1024)
            else:
                required_mb = session_size_bytes if isinstance(session_size_bytes, int) else 4000
            has_space, space_error = self._check_free_space(self.sessions_dir, required_mb)
            if not has_space:
                return False, space_error

            # Reserve the destination before doing long-running extraction.
            new_id, session_path = self._reserve_session()
            
            # Determine size for container modes
            size_mb = None
            if import_mode in ['dynfilefs', 'raw', 'luks']:
                size_mb = max(100, int(required_mb))

            # Import directly using streaming
            try:
                with self._mount_session_write(session_path, import_mode, size_mb, password=password) as target_dir:
                    # The validated archive may only write data/ members.
                    cmd = [
                        'tar', '-xf', archive_path,
                        '--use-compress-program=zstd -T0',
                        '-C', target_dir,
                        '--no-same-owner', '--no-same-permissions',
                        '--delay-directory-restore',
                        '--strip-components=1',
                        '--wildcards', 'data/*'
                    ]
                    
                    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    if result.returncode != 0:
                        raise Exception(f"Extraction failed: {result.stderr.decode()}")

            except Exception as e:
                if os.path.exists(session_path):
                    shutil.rmtree(session_path)
                return False, _("Failed to import session data: {}").format(str(e))

            # Verify before committing metadata so failures never leave a
            # metadata entry pointing at a removed session directory.
            if verify:
                if not self._verify_session_integrity(new_id):
                    shutil.rmtree(session_path)
                    return False, _("Imported session failed verification")

            if not self._create_session_metadata(new_id, import_mode, metadata):
                shutil.rmtree(session_path, ignore_errors=True)
                return False, _("Failed to update session metadata")

            return True, _("Session imported successfully as #{}").format(new_id)

        except Exception as e:
            return False, _("Import failed: {}").format(str(e))

    def _extract_metadata(self, archive_path, tmpdir=None):
        """Extract and return metadata from archive (reads directly from archive)"""
        try:
            # Extract metadata.json to stdout
            cmd = ['tar', '-xO', '-f', archive_path,
                   '--use-compress-program=zstd',
                   'metadata.json']
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            if result.returncode != 0:
                # Try with data/ prefix (unified format)
                cmd = ['tar', '-xO', '-f', archive_path,
                       '--use-compress-program=zstd',
                       'data/metadata.json']
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                if result.returncode != 0:
                    return None

            # Parse JSON from stdout
            return json.loads(result.stdout.decode('utf-8'))
        except Exception:
            return None

    def _extract_archive(self, archive_path, extract_path):
        """Extract full archive"""
        cmd = ['tar', '-xf', archive_path,
               '--use-compress-program=zstd -T0',
               '-C', extract_path]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode != 0:
            raise Exception(result.stderr.decode())

    def _check_import_compatibility(self, metadata):
        """Check if imported session is compatible

        With unified export format, we only check version/edition/union.
        Mode compatibility is no longer checked since data is always raw files.
        """
        issues = []

        # Get current system info
        current_version = self._get_system_version()
        current_edition = self._get_system_edition()
        current_union = self._get_current_union_fs()

        session = metadata['session']

        # Check version (warning only, not blocking)
        if session['version'] != current_version:
            issues.append(_("Version mismatch: {} → {}").format(
                session['version'], current_version))

        # Check edition (warning only, not blocking)
        if session['edition'] != current_edition:
            issues.append(_("Edition mismatch: {} → {}").format(
                session['edition'], current_edition))

        # Check union FS (warning only, not blocking)
        if session['union'] != current_union:
            issues.append(_("Union FS mismatch: {} → {}").format(
                session['union'], current_union))

        # Note: Mode compatibility is NOT checked anymore
        # Archive contains raw files that can be imported as any mode

        return {
            'compatible': len(issues) == 0,
            'issues': issues,
            'warnings': len(issues) > 0
        }

    def _select_compatible_mode(self, metadata):
        """Select compatible mode for import"""
        fs_info, _err = self._detect_filesystem_type()
        if not fs_info:
            return 'native'

        compatible_modes = self._get_compatible_session_modes(fs_info)
        original_mode = metadata['session']['mode']

        # Try to keep original mode if compatible
        if original_mode in compatible_modes:
            return original_mode

        # Otherwise pick first compatible mode
        if compatible_modes:
            return compatible_modes[0]

        return 'native'









    def _get_next_session_id(self):
        """Get next available session ID"""
        existing_ids = []
        for item in os.listdir(self.sessions_dir):
            path = os.path.join(self.sessions_dir, item)
            if item.isdigit() and os.path.isdir(path) and not os.path.islink(path):
                existing_ids.append(int(item))

        if not existing_ids:
            return 1

        return max(existing_ids) + 1

    def _create_session_metadata(self, session_id, mode, import_metadata):
        """Create metadata entry for imported session"""
        with self._mutation_lock():
            metadata = self._read_sessions_metadata()
            metadata.setdefault('sessions', {})
            session_data = {
                'mode': mode, 'version': import_metadata['session']['version'],
                'edition': import_metadata['session']['edition'],
                'union': import_metadata['session']['union']
            }
            if mode in ['dynfilefs', 'raw', 'luks']:
                size = import_metadata['session'].get('size', 4000)
                if isinstance(size, int):
                    session_data['size'] = max(100, int(size / (1024 * 1024))) if size > 100000 else max(100, size)
            metadata['sessions'][str(session_id)] = session_data
            return self._write_sessions_metadata(metadata)

    def _verify_session_integrity(self, session_id):
        """Verify session integrity"""
        session_path = os.path.join(self.sessions_dir, str(session_id))
        return os.path.exists(session_path) and os.path.isdir(session_path)

    def copy_session(self, session_id, to_mode=None, size_mb=None, password=None):
        """Copy session, optionally converting mode

        Args:
            session_id: Source session ID
            to_mode: Target mode (None = same as source)
            size_mb: Size for dynfilefs/raw modes

        Returns:
            (success, message) tuple
        """
        # Get source session
        try:
            session_id = self._validate_session_id(session_id)
        except ValueError as e:
            return False, str(e)
        source_session = self._get_session_info(session_id)
        if not source_session:
            return False, _("Source session not found")

        try:
            source_path = self._session_path(session_id, require_exists=True)
        except ValueError as e:
            return False, str(e)
        source_mode = source_session['mode']

        # Determine target mode
        target_mode = to_mode if to_mode else source_mode
        valid_target, target_error = self._validate_target_mode(target_mode, size_mb)
        if not valid_target:
            return False, target_error
        if target_mode == 'luks' and size_mb is None and source_mode != 'luks':
            size_mb = self.DEFAULT_CONTAINER_SIZE_MB

        # Check if running
        running = self.get_running_session()
        if running and running['id'] == session_id:
            return False, _("Cannot copy currently running session")

        # Check free disk space
        source_size = source_session.get('size', 0)
        required_mb = size_mb if size_mb else (source_size / (1024 * 1024) if source_size > 100000 else 4000)
        has_space, space_error = self._check_free_space(self.sessions_dir, required_mb)
        if not has_space:
            return False, space_error

        new_id, target_path = self._reserve_session()

        try:
            if source_mode == target_mode:
                # Direct copy
                success = self._copy_session_direct(source_path, target_path, source_mode)
            else:
                # Copy with conversion
                success = self._copy_session_with_conversion(
                    source_path, target_path, source_mode, target_mode, size_mb, password)

            if not success:
                if os.path.exists(target_path):
                    shutil.rmtree(target_path)
                return False, _("Failed to copy session data")

            with self._mutation_lock():
                metadata = self._read_sessions_metadata()
                metadata.setdefault('sessions', {})
                metadata['sessions'][str(new_id)] = {
                    'mode': target_mode, 'version': source_session['version'],
                    'edition': source_session['edition'], 'union': source_session['union']
                }
                if target_mode in ['dynfilefs', 'raw', 'luks']:
                    if size_mb:
                        metadata['sessions'][str(new_id)]['size'] = size_mb
                    elif source_mode == target_mode and source_session.get('total_size_mb'):
                        metadata['sessions'][str(new_id)]['size'] = source_session['total_size_mb']
                if not self._write_sessions_metadata(metadata):
                    raise OSError(_("Failed to update session metadata"))

            return True, _("Session copied successfully to #{}").format(new_id)

        except Exception as e:
            if os.path.exists(target_path):
                shutil.rmtree(target_path)
            return False, _("Copy failed: {}").format(str(e))

    def _copy_session_direct(self, source_path, target_path, mode):
        """Direct copy of session without conversion"""
        try:
            if mode == 'native':
                # Ensure target directory exists (including 'changes' subdirectory if needed)
                # For native copy, we are copying contents of source_path (which might be .../changes)
                # to target_path.
                
                # If source path ends with 'changes', we should probably ensure target has 'changes' too
                # But _copy_session_direct receives raw paths.
                # Let's look at how it's called.
                # copy_session calls it with (source_path, target_path, mode)
                # source_path is .../100, target_path is .../101
                
                # Wait, _copy_session_direct does NOT use _mount_session_read/write!
                # It operates on raw paths!
                
                # If mode is native:
                # source_path is .../100
                # target_path is .../101
                
                # We need to check if source has 'changes' subdir
                source_changes = os.path.join(source_path, 'changes')
                if os.path.exists(source_changes) and os.path.isdir(source_changes):
                    real_source = source_changes
                    real_target = os.path.join(target_path, 'changes')
                else:
                    real_source = source_path
                    real_target = target_path
                    
                os.makedirs(real_target, exist_ok=True)

                # Use rsync for native copy to preserve attributes and handle special files
                # Exclude workdir and AUFS/OverlayFS metadata
                cmd = [
                    'rsync', '-aH',
                    '--exclude=workdir',
                    '--exclude=.wh..wh.orph',
                    '--exclude=.wh..wh.plnk',
                    '--exclude=.wh..wh.aufs',
                    real_source.rstrip('/') + '/',
                    real_target.rstrip('/') + '/'
                ]
                
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                # rsync may return 23 (partial transfer) if some special files couldn't be copied
                # This is acceptable (e.g., char devices, sockets)
                if result.returncode not in [0, 23, 24]:
                    print(f"DEBUG: rsync failed: {result.stderr.decode()}")
                    return False
                
                return True

            elif mode == 'dynfilefs':
                # Copy changes.dat files
                for file in os.listdir(source_path):
                    if file.startswith('changes.dat'):
                        shutil.copy2(
                            os.path.join(source_path, file),
                            os.path.join(target_path, file))
                return True

            elif mode == 'raw':
                # Copy changes.img
                shutil.copy2(
                    os.path.join(source_path, 'changes.img'),
                    os.path.join(target_path, 'changes.img'))
                return True

            elif mode == 'luks':
                shutil.copy2(os.path.join(source_path, 'changes.luks'),
                             os.path.join(target_path, 'changes.luks'))
                return True

            return False
        except Exception as e:
            print(f"DEBUG: _copy_session_direct failed: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _copy_session_with_conversion(self, source_path, target_path,
                                      source_mode, target_mode, size_mb=None, password=None):
        """Copy session with mode conversion"""
        try:
            # Direct copy using mounts
            with self._mount_session_read(source_path, source_mode, password=password) as source_dir:
                with self._mount_session_write(target_path, target_mode, size_mb, password=password) as target_dir:
                    # Copy files using rsync
                    cmd = [
                        'rsync', '-aH',
                        '--exclude=workdir',
                        '--exclude=.wh..wh.orph',
                        '--exclude=.wh..wh.plnk',
                        '--exclude=.wh..wh.aufs',
                        '--prune-empty-dirs',
                        source_dir.rstrip('/') + '/',
                        target_dir.rstrip('/') + '/'
                    ]
                    
                    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    if result.returncode not in [0, 23, 24]:
                        raise Exception(f"Rsync failed: {result.stderr.decode()}")
            
            return True

        except Exception as e:
            print(f"DEBUG: _copy_session_with_conversion failed: {e}")
            import traceback
            traceback.print_exc()
            return False

    def convert_session(self, session_id, target_mode, size_mb=None,
                       in_place=True, password=None):
        """Convert session storage mode

        Args:
            session_id: Session ID to convert
            target_mode: Target mode (native/dynfilefs/raw)
            size_mb: Size for dynfilefs/raw modes
            in_place: Convert in-place (vs create new session)

        Returns:
            (success, message) tuple
        """
        try:
            session_id = self._validate_session_id(session_id)
        except ValueError as e:
            return False, str(e)
        # --new-session must leave the original untouched and create a new ID.
        if not in_place:
            if password is None:
                return self.copy_session(session_id, to_mode=target_mode, size_mb=size_mb)
            return self.copy_session(session_id, to_mode=target_mode, size_mb=size_mb, password=password)

        # Get session
        session_info = self._get_session_info(session_id)
        if not session_info:
            return False, _("Session not found")

        source_mode = session_info['mode']

        # Check if conversion needed
        if source_mode == target_mode:
            return False, _("Session is already in {} mode").format(target_mode)

        # Check if session is running
        running = self.get_running_session()
        if running and running['id'] == session_id:
            return False, _("Cannot convert currently running session")

        # Check if session is active
        current = self.get_current_session()
        if current and current['id'] == session_id:
            return False, _("Cannot convert currently active session. "
                           "Please activate another session first.")

        valid_target, target_error = self._validate_target_mode(target_mode, size_mb)
        if not valid_target:
            return False, target_error

        # Set default size for dynfilefs/raw if not specified
        if target_mode in ['dynfilefs', 'raw', 'luks'] and not size_mb:
            # Try to use size from source session if available
            if session_info.get('total_size_mb'):
                size_mb = session_info['total_size_mb']
            elif source_mode == 'native' and session_info.get('size'):
                # For native sessions, use actual size + 100 MB
                size_mb = int(session_info['size'] / (1024 * 1024)) + 100
            else:
                size_mb = self.DEFAULT_CONTAINER_SIZE_MB

        session_path = self._session_path(session_id, require_exists=True)

        # Create new session with temporary name
        new_session_path = self._make_temp_dir()

        try:
            if not self._copy_session_with_conversion(session_path, new_session_path,
                                                       source_mode, target_mode, size_mb, password):
                raise OSError(_("Failed to copy session data"))

            # Keep a rollback copy until the durable metadata update succeeds.
            backup_path = self._make_temp_dir()
            os.rmdir(backup_path)
            with self._mutation_lock():
                os.rename(session_path, backup_path)
                os.rename(new_session_path, session_path)
                metadata = self._read_sessions_metadata()
                if session_id not in metadata.get('sessions', {}):
                    os.rename(session_path, new_session_path)
                    os.rename(backup_path, session_path)
                    raise OSError(_("Session metadata is missing"))
                metadata['sessions'][session_id]['mode'] = target_mode
                if target_mode in ['dynfilefs', 'raw', 'luks']:
                    metadata['sessions'][session_id]['size'] = size_mb
                else:
                    metadata['sessions'][session_id].pop('size', None)
                if not self._write_sessions_metadata(metadata):
                    os.rename(session_path, new_session_path)
                    os.rename(backup_path, session_path)
                    raise OSError(_("Failed to update session metadata"))
            shutil.rmtree(backup_path)

            return True, _("Session converted successfully from {} to {}").format(
                source_mode, target_mode)

        except Exception as e:
            # Clean up temp new session on error
            shutil.rmtree(new_session_path, ignore_errors=True)
            return False, _("Conversion failed: {}").format(str(e))



    def get_filesystem_info(self):
        """Get filesystem information and compatibility"""
        filesystem_info, error = self._detect_filesystem_type()
        if error:
            return None, error

        compatible_modes = self._get_compatible_session_modes(filesystem_info)
        limitations = self._get_filesystem_limitations(filesystem_info)

        return {
            'filesystem': filesystem_info,
            'compatible_modes': compatible_modes,
            'limitations': limitations
        }, None

def format_session_list(sessions):
    """Format session list for display"""
    if not sessions:
        return _("No sessions found")

    lines = []

    for session in sessions:
        status_parts = []
        if session['is_default']:
            status_parts.append(_("ACTIVE"))
        if session.get('is_running', False):
            status_parts.append(_("RUNNING"))
        
        status = f" ({', '.join(status_parts)})" if status_parts else ""
        modified_str = session['modified'].strftime("%Y-%m-%d %H:%M:%S") if session['modified'] else "unknown"
        size_str = SessionManager()._format_size(session['size'])
        
        lines.append(f"{_('Session')} #{session['id']}{status}")
        lines.append(f"  {_('Mode:').rstrip(':')} {session['mode']}")
        lines.append(f"  {_('Version:').rstrip(':')} {session['version']}")
        lines.append(f"  {_('Edition:').rstrip(':')} {session['edition']}")
        lines.append(f"  {_('Union FS:').rstrip(':')} {session['union']}")
        lines.append(f"  {_('Size:').rstrip(':')} {size_str}")
        
        # Add Total Size for dynfilefs sessions
        if session['mode'] == 'dynfilefs' and 'total_size_mb' in session and session['total_size_mb']:
            total_size_mb = session['total_size_mb']
            # Convert to int if it's a string
            if isinstance(total_size_mb, str):
                try:
                    total_size_mb = int(total_size_mb)
                except (ValueError, TypeError):
                    total_size_mb = 0
            
            if total_size_mb > 0:
                total_size_str = SessionManager()._format_size(total_size_mb * 1024 * 1024)
                lines.append(f"  {_('Total Size:').rstrip(':')} {total_size_str}")
        
        lines.append(f"  {_('Last Modified:').rstrip(':')} {modified_str}")
        lines.append("")

    return "\n".join(lines)

def format_sessions_json(sessions):
    """Format session list as JSON"""
    json_sessions = []
    for session in sessions:
        json_session = {
            'id': session['id'],
            'mode': session['mode'],
            'version': session['version'],
            'edition': session['edition'],
            'union': session['union'],
            'size': session['size'],
            'size_formatted': SessionManager()._format_size(session['size'])
        }
        
        # Add total_size fields right after size_formatted for dynfilefs sessions
        if session['mode'] == 'dynfilefs' and 'total_size_mb' in session and session['total_size_mb']:
            total_size_mb = session['total_size_mb']
            if isinstance(total_size_mb, str):
                try:
                    total_size_mb = int(total_size_mb)
                except (ValueError, TypeError):
                    total_size_mb = 0
            
            if total_size_mb > 0:
                total_size_bytes = total_size_mb * 1024 * 1024
                json_session['total_size'] = total_size_bytes
                json_session['total_size_formatted'] = SessionManager()._format_size(total_size_bytes)
        
        # Continue with remaining fields
        json_session.update({
            'modified': session['modified'].isoformat() if session['modified'] else None,
            'path': session['path'],
            'is_default': session['is_default'],
            'is_running': session.get('is_running', False)
        })

        # Add status if present (for running sessions)
        if 'status' in session:
            json_session['status'] = session['status']
        json_sessions.append(json_session)

    return json.dumps(json_sessions, indent=2, ensure_ascii=False)

def format_session_json(session):
    """Format single session as JSON"""
    if not session:
        return json.dumps(None)

    json_session = {
        'id': session['id'],
        'mode': session['mode'],
        'version': session['version'],
        'edition': session['edition'],
        'union': session['union'],
        'size': session['size'],
        'size_formatted': SessionManager()._format_size(session['size'])
    }

    # Add total_size fields right after size_formatted for dynfilefs sessions
    if session['mode'] == 'dynfilefs' and 'total_size_mb' in session and session['total_size_mb']:
        total_size_mb = session['total_size_mb']
        if isinstance(total_size_mb, str):
            try:
                total_size_mb = int(total_size_mb)
            except (ValueError, TypeError):
                total_size_mb = 0
        
        if total_size_mb > 0:
            total_size_bytes = total_size_mb * 1024 * 1024
            json_session['total_size'] = total_size_bytes
            json_session['total_size_formatted'] = SessionManager()._format_size(total_size_bytes)

    # Continue with remaining fields
    json_session.update({
        'modified': session['modified'].isoformat() if session['modified'] else None,
        'path': session['path'],
        'is_default': session['is_default']
    })

    # Add status if present (for running sessions)
    if 'status' in session:
        json_session['status'] = session['status']

    return json.dumps(json_session, indent=2, ensure_ascii=False)

def format_filesystem_info_json(fs_info):
    """Format filesystem info as JSON"""
    if not fs_info:
        return json.dumps({'error': 'Filesystem information not available'})

    return json.dumps(fs_info, indent=2, ensure_ascii=False)

def parse_perch_size(value):
    """Parse perchsize-compatible decimal units into MB."""
    match = re.fullmatch(r'([0-9]+)\s*([mMgGtT]?[bB]?)?', value)
    if not match:
        raise argparse.ArgumentTypeError('size must be a positive MB, GB, or TB value')
    number, unit = int(match.group(1)), match.group(2).lower()
    multiplier = 1000000 if unit.startswith('t') else 1000 if unit.startswith('g') else 1
    size_mb = number * multiplier
    if not size_mb or size_mb > SessionManager.MAX_CONTAINER_SIZE_MB:
        raise argparse.ArgumentTypeError('size must be between 1MB and 1TB')
    return size_mb

def luks_password_from_args(args, confirm=False):
    """Read an optional passphrase without ever putting it in argv or metadata."""
    if getattr(args, 'password_stdin', False):
        password = sys.stdin.buffer.readline().rstrip(b'\r\n')
        if confirm:
            confirmation = sys.stdin.buffer.readline().rstrip(b'\r\n')
            if password != confirmation:
                raise ValueError(_('LUKS passphrases do not match.'))
    elif confirm:
        password = getpass.getpass(_('LUKS passphrase: ')).encode()
        confirmation = getpass.getpass(_('Confirm LUKS passphrase: ')).encode()
        if password != confirmation:
            raise ValueError(_('LUKS passphrases do not match.'))
    else:
        return None
    if not password:
        raise ValueError(_('LUKS passphrase must not be empty.'))
    return password



def main():
    """Main application entry point"""
    import sys

    # Pre-check for flags before parsing
    json_output = '--json' in sys.argv
    help_requested = any(arg in ('-h', '--help') for arg in sys.argv[1:])

    # Check for root privileges
    if os.geteuid() != 0 and not help_requested:
        error_msg = _("This tool requires root privileges. Please run with sudo or through pkexec.")
        if json_output:
            print(json.dumps({"success": False, "error": error_msg}), file=sys.stderr)
        else:
            print(error_msg, file=sys.stderr)
        sys.exit(1)

    luks_available = luks_runtime_available()
    session_modes = ['native', 'dynfilefs', 'raw']
    if luks_available:
        session_modes.append('luks')

    parser = argparse.ArgumentParser(
        description=_('MiniOS Session Manager - Command line tool for managing persistent sessions'),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=_("""
GLOBAL OPTIONS:
  --json                    Output results in JSON format (can be used with any command)
  --sessions-dir PATH       Use custom sessions directory instead of default

COMMANDS:
  list                      List all available sessions with detailed information
  active                    Show currently active session (will boot next)
  running                   Show currently running session (current boot)
  info                      Show filesystem type and compatible session modes
  activate SESSION_ID       Activate specified session
  create [MODE] [SIZE]      Create new session using positional arguments
  delete SESSION_ID         Delete specified session
  cleanup [--days N]        Delete old sessions (default: 30 days)
  status                    Check sessions directory status and permissions
  resize SESSION_ID SIZE    Grow a container session
  export SESSION_ID PATH    Export session to .tar.zst archive
  import ARCHIVE            Import session from .tar.zst archive
  copy SESSION_ID           Copy session (optional: --to-mode, --size)
  convert SESSION_ID MODE   Convert session to different mode (optional: --size)

SESSION MODES:
  native                    Direct filesystem changes (requires POSIX-compatible filesystem)
  dynfilefs                 Dynamic file system overlay (works on any filesystem)
  raw                       Raw disk image (works on any filesystem, 4000MB default)

COMMAND BEHAVIOR:
  • create without MODE: Uses native mode (may fail on FAT32/NTFS/exFAT)
  • create without SIZE: Uses 4000MB for container modes
  • convert replaces the source by default; --new-session preserves it
  • cleanup without --days: Uses 30-day threshold for deletion
  • cleanup protects both active and running sessions from deletion

EXAMPLES:

  Basic Usage:
    minios-session list                           List all available sessions
    minios-session active                         Show which session will boot next
    minios-session running                        Show currently running session
    minios-session info                           Show filesystem compatibility info

  Session Management:
    minios-session activate 2                     Set session #2 as default for next boot
    minios-session delete 3                       Delete session #3 permanently
    minios-session cleanup --days 30              Delete sessions older than 30 days
    minios-session cleanup                        Delete sessions older than 30 days (default)

  Creating Sessions:
    minios-session create                         Create native session (filesystem changes)
    minios-session create native                  Create native session explicitly
    minios-session create dynfilefs               Create 4000MB dynfilefs session (default size)
    minios-session create dynfilefs 8000          Create 8000MB dynfilefs session
    minios-session create raw 2000                Create 2000MB raw disk image

  Session Operations:
    minios-session resize 2 4000                  Resize session #2 to 4000MB
    minios-session export 3 /tmp/backup.tar.zst   Export session #3 to archive
    minios-session import /tmp/backup.tar.zst     Import session from archive
    minios-session copy 2                         Copy session #2
    minios-session copy 2 --to-mode raw --size 3000  Copy session #2 as raw with 3000MB
    minios-session convert 3 dynfilefs --size 2000   Convert session #3 to dynfilefs with 2000MB

  Error Handling:
    minios-session create                         May fail on FAT32/NTFS/exFAT: "Use dynfilefs or raw mode"
    minios-session create raw 5000                Will fail on FAT32: MiniOS limits fixed containers to 4000MB

  JSON Output (for automation):
    minios-session --json list                    List sessions in JSON format
    minios-session active --json                  Get active session info as JSON
    minios-session info --json                    Get system info as JSON

  Custom Session Directory:
    minios-session --sessions-dir /mnt/usb/sessions list
    minios-session --sessions-dir /tmp/test create native

        """)
    )

    # Add global flags that can be used anywhere
    parser.add_argument('--json', action='store_true', help=_('Output in JSON format'))
    parser.add_argument('--sessions-dir', type=str, metavar='PATH', 
                       help=_('Custom path to sessions directory'))

    subparsers = parser.add_subparsers(dest='command', help=_('Available commands'))

    # Create parent parser with common arguments
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument('--json', action='store_true', help=_('Output in JSON format'))
    parent_parser.add_argument('--sessions-dir', type=str, metavar='PATH', 
                              help=_('Custom path to sessions directory'))
    if luks_available:
        parent_parser.add_argument('--password-stdin', action='store_true',
                                  help=_('Read a LUKS passphrase from standard input'))

    # List command
    list_parser = subparsers.add_parser('list', help=_('List all sessions'), parents=[parent_parser])

    # Active command (renamed from current for GUI consistency)
    active_parser = subparsers.add_parser('active', help=_('Show active session'), parents=[parent_parser])

    # Running command
    running_parser = subparsers.add_parser('running', help=_('Show running session'), parents=[parent_parser])

    # Info command
    info_parser = subparsers.add_parser('info', help=_('Show filesystem and compatibility information'), parents=[parent_parser])

    # Activate command
    activate_parser = subparsers.add_parser('activate', help=_('Activate a session'), parents=[parent_parser])
    activate_parser.add_argument('session_id', help=_('Session ID to activate'))

    # Create command
    create_parser = subparsers.add_parser('create', help=_('Create a new session'), parents=[parent_parser])
    create_parser.add_argument('mode', nargs='?', choices=session_modes,
                              default='native', help=_('Session mode (default: native)'))
    create_parser.add_argument('size', nargs='?', type=parse_perch_size, metavar='SIZE',
                              help=_('Size in MB, GB, or TB for container modes (default: 4000MB)'))

    # Delete command
    delete_parser = subparsers.add_parser('delete', help=_('Delete a session'), parents=[parent_parser])
    delete_parser.add_argument('session_id', help=_('Session ID to delete'))

    # Cleanup command
    cleanup_parser = subparsers.add_parser('cleanup', help=_('Clean up old sessions'), parents=[parent_parser])
    cleanup_parser.add_argument('--days', type=int, default=30, 
                               help=_('Delete sessions older than N days (default: 30)'))

    # Status command
    status_parser = subparsers.add_parser('status', help=_('Check sessions directory status'), parents=[parent_parser])

    # Resize command
    resize_parser = subparsers.add_parser('resize', help=_('Resize a session'), parents=[parent_parser])
    resize_parser.add_argument('session_id', help=_('Session ID to resize'))
    resize_parser.add_argument('size', type=parse_perch_size, metavar='SIZE', help=_('New size in MB, GB, or TB'))

    # Export command
    export_parser = subparsers.add_parser('export', help=_('Export session to archive'), parents=[parent_parser])
    export_parser.add_argument('session_id', help=_('Session ID to export'))
    export_parser.add_argument('output_path', help=_('Output file or directory path'))
    export_parser.add_argument('--no-verify', action='store_true', help=_('Skip archive verification'))

    # Import command
    import_parser = subparsers.add_parser('import', help=_('Import session from archive'), parents=[parent_parser])
    import_parser.add_argument('archive_path', help=_('Path to session archive (.tar.zst)'))
    import_parser.add_argument('--auto-convert', action='store_true',
                               help=_('Automatically convert to compatible mode'))
    import_parser.add_argument('--force-mode', choices=session_modes,
                               help=_('Force specific session mode'))
    import_parser.add_argument('--no-verify', action='store_true', help=_('Skip integrity verification'))
    import_parser.add_argument('--skip-compatibility-check', action='store_true',
                               help=_('Skip compatibility checks'))

    # Copy command
    copy_parser = subparsers.add_parser('copy', help=_('Copy a session'), parents=[parent_parser])
    copy_parser.add_argument('session_id', help=_('Session ID to copy'))
    copy_parser.add_argument('--to-mode', choices=session_modes,
                            help=_('Convert to different mode (optional)'))
    copy_parser.add_argument('--size', type=parse_perch_size, metavar='SIZE',
                            help=_('Size for a container target, in MB, GB, or TB'))

    # Convert command
    convert_parser = subparsers.add_parser('convert', help=_('Convert session mode'), parents=[parent_parser])
    convert_parser.add_argument('session_id', help=_('Session ID to convert'))
    convert_parser.add_argument('target_mode', choices=session_modes,
                               help=_('Target mode'))
    convert_parser.add_argument('--size', type=parse_perch_size, metavar='SIZE',
                               help=_('Size for a container target, in MB, GB, or TB'))
    convert_parser.add_argument('--new-session', action='store_true',
                               help=_('Create new session instead of in-place conversion'))

# GUI command removed - use minios-session-manager for GUI

    # Parse arguments - handle global flags that can appear anywhere
    # Extract global flags from any position
    global_json = '--json' in sys.argv
    sessions_dir = None

    # Find sessions-dir parameter
    for i, arg in enumerate(sys.argv):
        if arg == '--sessions-dir' and i + 1 < len(sys.argv):
            sessions_dir = sys.argv[i + 1]
            break
        elif arg.startswith('--sessions-dir='):
            sessions_dir = arg.split('=', 1)[1]
            break

    # Parse normally  
    args = parser.parse_args()

    # Apply global flags
    if global_json:
        args.json = True

    if sessions_dir and not hasattr(args, 'sessions_dir'):
        args.sessions_dir = sessions_dir
    elif sessions_dir:
        args.sessions_dir = sessions_dir

    # Initialize session manager with custom directory if specified
    custom_dir = getattr(args, 'sessions_dir', None)
    manager = SessionManager(custom_sessions_dir=custom_dir)

    if not manager.sessions_dir:
        if args.json:
            error_data = {
                "success": False,
                "error": _("Could not find sessions directory."),
                "details": _("This tool must be run from within a MiniOS live system with persistent sessions enabled.")
            }
            print(json.dumps(error_data), file=sys.stderr)
        else:
            print(_("Error: Could not find sessions directory."), file=sys.stderr)
            print(_("This tool must be run from within a MiniOS live system with persistent sessions enabled."), file=sys.stderr)
        sys.exit(1)

    # Handle commands
    if args.command == 'list':
        sessions = manager.list_sessions()
        if args.json:
            print(format_sessions_json(sessions))
        else:
            print(format_session_list(sessions))

    elif args.command == 'active':
        current = manager.get_current_session()
        if args.json:
            print(format_session_json(current))
        else:
            if current:
                print(_("Active session: #{}").format(current['id']))
                print(_("Mode: {}").format(current['mode']))
                print(_("Version: {}").format(current['version']))
                print(_("Edition: {}").format(current['edition']))
                print(_("Union FS: {}").format(current['union']))
                print(_("Size: {}").format(manager._format_size(current['size'])))
                print(_("Last Modified: {}").format(current['modified'].strftime("%Y-%m-%d %H:%M:%S") if current['modified'] else "unknown"))
            else:
                print(_("No active session found"))

    elif args.command == 'running':
        running = manager.get_running_session()
        if args.json:
            print(format_session_json(running))
        else:
            if running:
                print(_("Running session: #{}").format(running['id']))
                print(_("Mode: {}").format(running['mode']))
                print(_("Version: {}").format(running['version']))
                print(_("Edition: {}").format(running['edition']))
                print(_("Union FS: {}").format(running['union']))
                print(_("Size: {}").format(manager._format_size(running['size'])))
                if running['modified']:
                    print(_("Last Modified: {}").format(running['modified'].strftime("%Y-%m-%d %H:%M:%S")))
                if 'status' in running:
                    print(_("Status: {}").format(running['status']))
            else:
                print(_("No running session detected"))

    elif args.command == 'info':
        fs_info, error = manager.get_filesystem_info()
        if error:
            if args.json:
                print(json.dumps({'success': False, 'error': error}), file=sys.stderr)
            else:
                print(_("Error: {}").format(error), file=sys.stderr)
            sys.exit(1)
        
        if args.json:
            print(format_filesystem_info_json(fs_info))
        else:
            print(_("MiniOS Media Information:"))
            print("-" * 40)
            fs = fs_info['filesystem']
            print(_("Filesystem Type: {}").format(fs['type']))
            print(_("Device: {}").format(fs['device']))
            print(_("Mount Options: {}").format(fs['mount_options'] or _("none")))
            print(_("Read-only: {}").format(_("Yes") if fs['is_readonly'] else _("No")))
            print(_("POSIX Compatible: {}").format(_("Yes") if fs['is_posix_compatible'] else _("No")))
            print()
            
            print(_("Compatible Session Modes:"))
            compatible = fs_info['compatible_modes']
            if compatible:
                for mode in compatible:
                    print(f"  ✓ {mode}")
            else:
                print(_("  None (read-only media)"))
            print()
            
            limitations = fs_info['limitations']
            if limitations:
                print(_("Filesystem Limitations:"))
                if 'max_file_size' in limitations:
                    print(_("  • Maximum file size: {}MB ({:.1f}GB)").format(
                        limitations['max_file_size'], limitations['max_file_size'] / 1024))
                if 'no_posix' in limitations:
                    print(_("  • No POSIX features (no native mode support)"))
                if 'case_insensitive' in limitations:
                    print(_("  • Case-insensitive filenames"))
            else:
                print(_("No known limitations"))

    elif args.command == 'activate':
        success, message = manager.activate_session(args.session_id)
        if args.json:
            result = {"success": success, "message": message}
            print(json.dumps(result))
        else:
            print(message)
        sys.exit(0 if success else 1)

    elif args.command == 'create':
        try:
            password = luks_password_from_args(args, confirm=args.mode == 'luks')
        except ValueError as error:
            success, message = False, str(error)
        else:
            success, message = manager.create_session(args.mode, args.size, password=password)
        if args.json:
            result = {"success": success, "message": message}
            print(json.dumps(result))
        else:
            print(message)
        sys.exit(0 if success else 1)

    elif args.command == 'delete':
        success, message = manager.delete_session(args.session_id)
        if args.json:
            result = {"success": success, "message": message}
            print(json.dumps(result))
        else:
            print(message)
        sys.exit(0 if success else 1)

    elif args.command == 'cleanup':
        if args.days <= 0:
            message = _("Days threshold must be greater than zero")
            if args.json:
                print(json.dumps({"success": False, "message": message}))
            else:
                print(message, file=sys.stderr)
            sys.exit(1)
        deleted_count, errors = manager.cleanup_old_sessions(args.days)
        if args.json:
            result = {
                "success": len(errors) == 0,
                "deleted_count": deleted_count,
                "errors": errors,
                "message": _("Cleanup completed: {} sessions deleted").format(deleted_count)
            }
            print(json.dumps(result))
        else:
            print(_("Cleanup completed: {} sessions deleted").format(deleted_count))
            if errors:
                print(_("Errors:"))
                for error in errors:
                    print(f"  {error}")

    elif args.command == 'resize':
        success, message = manager.resize_session(args.session_id, args.size,
                                                  password=luks_password_from_args(args))
        if args.json:
            result = {
                "success": success,
                "message": message
            }
            print(json.dumps(result))
        else:
            print(message)
        sys.exit(0 if success else 1)

    elif args.command == 'status':
        status_info = manager.check_sessions_directory_status()
        if args.json:
            print(json.dumps(status_info))
        else:
            print(_("Sessions directory: {}").format(status_info.get('sessions_dir', 'N/A')))
            if status_info.get('found', False):
                print(_("Status: {}").format(_("Found")))
                if status_info.get('writable', False):
                    print(_("Access: {}").format(_("Writable")))
                else:
                    print(_("Access: {}").format(_("Read-only")))
                    if 'error' in status_info:
                        print(_("Reason: {}").format(status_info['error']))
                print(_("Filesystem type: {}").format(status_info.get('filesystem_type', 'unknown')))
            else:
                print(_("Status: {}").format(_("Not found")))
                if 'error' in status_info:
                    print(_("Error: {}").format(status_info['error']))

    elif args.command == 'export':
        verify = not args.no_verify
        success, message = manager.export_session(args.session_id, args.output_path, verify=verify,
                                                  password=luks_password_from_args(args))
        if args.json:
            result = {"success": success, "message": message}
            print(json.dumps(result))
        else:
            print(message)
        sys.exit(0 if success else 1)

    elif args.command == 'import':
        verify = not args.no_verify
        success, message = manager.import_session(
            args.archive_path,
            auto_convert=args.auto_convert,
            force_mode=args.force_mode,
            verify=verify,
            skip_compatibility_check=args.skip_compatibility_check,
            password=luks_password_from_args(args)
        )
        if args.json:
            result = {"success": success, "message": message}
            print(json.dumps(result))
        else:
            print(message)
        sys.exit(0 if success else 1)

    elif args.command == 'copy':
        success, message = manager.copy_session(
            args.session_id,
            to_mode=args.to_mode,
            size_mb=args.size,
            password=luks_password_from_args(args)
        )
        if args.json:
            result = {"success": success, "message": message}
            print(json.dumps(result))
        else:
            print(message)
        sys.exit(0 if success else 1)

    elif args.command == 'convert':
        in_place = not args.new_session
        success, message = manager.convert_session(
            args.session_id,
            args.target_mode,
            size_mb=args.size,
            in_place=in_place,
            password=luks_password_from_args(args)
        )
        if args.json:
            result = {"success": success, "message": message}
            print(json.dumps(result))
        else:
            print(message)
        sys.exit(0 if success else 1)


# GUI command removed

    else:
        parser.print_help()

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tests for minios_session SessionManager class.
"""

import sys
import os
import io
import contextlib
import json
import hashlib
import errno
import fcntl
import stat
import subprocess
import threading
import pytest
import tempfile
import shutil
from types import SimpleNamespace
from unittest.mock import call, patch, MagicMock, mock_open

# Add lib directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'lib'))


def test_luks_password_stdin_confirmation(monkeypatch):
    from minios_session import luks_password_from_args

    monkeypatch.setattr(sys, 'stdin', SimpleNamespace(buffer=io.BytesIO(b'secret\nsecret\n')))
    assert luks_password_from_args(SimpleNamespace(password_stdin=True), confirm=True) == b'secret'


def test_luks_password_stdin_confirmation_rejects_mismatch(monkeypatch):
    from minios_session import luks_password_from_args

    monkeypatch.setattr(sys, 'stdin', SimpleNamespace(buffer=io.BytesIO(b'secret\nother\n')))
    with pytest.raises(ValueError):
        luks_password_from_args(SimpleNamespace(password_stdin=True), confirm=True)


class TestSessionManagerInit:
    """Tests for SessionManager initialization."""

    def test_init_with_custom_dir(self, temp_sessions_dir):
        """Test initialization with custom sessions directory."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=True):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            assert sm.custom_sessions_dir == temp_sessions_dir

    def test_init_creates_cache_dir(self, temp_sessions_dir):
        """Test that cache directory is created on init."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', side_effect=lambda p: p == temp_sessions_dir):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            assert sm.cache_dir is not None

    def test_cache_symlink_does_not_chmod_target(self, temp_sessions_dir):
        from minios_session import SessionManager

        victim = tempfile.mkdtemp(prefix='minios-cache-victim-')
        cache_link = os.path.join(temp_sessions_dir, 'cache-link')
        os.chmod(victim, 0o777)
        os.symlink(victim, cache_link)
        sm = SessionManager.__new__(SessionManager)
        sm.cache_dir = cache_link
        sm.cache_file = os.path.join(cache_link, 'session_sizes.json')
        try:
            sm._ensure_cache_dir()
            assert stat.S_IMODE(os.stat(victim).st_mode) == 0o777
            assert sm.cache_dir != cache_link
            assert not os.path.islink(sm.cache_dir)
        finally:
            if sm.cache_dir != cache_link:
                shutil.rmtree(sm.cache_dir, ignore_errors=True)
            shutil.rmtree(victim, ignore_errors=True)


class TestFormatSize:
    """Tests for _format_size method."""

    def test_format_bytes(self, temp_sessions_dir):
        """Test formatting byte values."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=True):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            
            assert sm._format_size(0) == "0.0B"
            assert sm._format_size(500) == "500.0B"

    def test_format_kilobytes(self, temp_sessions_dir):
        """Test formatting kilobyte values."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=True):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            
            result = sm._format_size(1024)
            assert "KB" in result or "K" in result

    def test_format_megabytes(self, temp_sessions_dir):
        """Test formatting megabyte values."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=True):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            
            result = sm._format_size(1024 * 1024)
            assert "MB" in result or "M" in result

    def test_format_gigabytes(self, temp_sessions_dir):
        """Test formatting gigabyte values."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=True):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            
            result = sm._format_size(1024 * 1024 * 1024)
            assert "GB" in result or "G" in result


class TestGetCurrentUnionFs:
    """Tests for _get_current_union_fs method."""

    def test_detect_observed_aufs_root(self, temp_sessions_dir):
        """Test detecting AUFS from the effective root mount."""
        from minios_session import SessionManager

        mountinfo = '36 25 0:32 / / rw,relatime - aufs none rw\n'
        with patch('os.path.exists', return_value=True), \
             patch('builtins.open', side_effect=lambda *_args, **_kwargs: io.StringIO(mountinfo)):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            result = sm._get_current_union_fs()
            assert result == 'aufs'

    def test_detect_observed_overlay_root(self, temp_sessions_dir):
        """Test normalizing the kernel's overlay mount name."""
        from minios_session import SessionManager

        mountinfo = '36 25 0:32 / / rw,relatime - overlay overlay rw\n'
        with patch('os.path.exists', return_value=True), \
             patch('builtins.open', side_effect=lambda *_args, **_kwargs: io.StringIO(mountinfo)):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            result = sm._get_current_union_fs()
            assert result == 'overlayfs'

    def test_does_not_treat_supported_union_as_active(self, temp_sessions_dir):
        """Kernel support or command-line intent is not the observed root."""
        from minios_session import SessionManager

        mountinfo = '36 25 8:1 / / rw,relatime - ext4 /dev/sda1 rw\n'
        with patch('os.path.exists', return_value=True), \
             patch('builtins.open', side_effect=lambda *_args, **_kwargs: io.StringIO(mountinfo)):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            result = sm._get_current_union_fs()
            assert result == 'unknown'


class TestGetSystemVersion:
    """Tests for _get_system_version method."""

    def test_read_version_from_release_file(self, temp_sessions_dir, sample_minios_release):
        """Test reading version from minios-release file."""
        from minios_session import SessionManager
        
        def exists_side_effect(path):
            return path in [temp_sessions_dir, '/etc/minios-release']
        
        with patch('os.path.exists', side_effect=exists_side_effect), \
             patch('builtins.open', side_effect=lambda *_args, **_kwargs: io.StringIO(sample_minios_release)):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            version = sm._get_system_version()
            assert version == "5.1.1"

    def test_version_unknown_when_file_missing(self, temp_sessions_dir):
        """Test returning 'unknown' when release file is missing."""
        from minios_session import SessionManager
        
        def exists_side_effect(path):
            return path == temp_sessions_dir
        
        with patch('os.path.exists', side_effect=exists_side_effect):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            version = sm._get_system_version()
            assert version == "unknown"


class TestGetSystemEdition:
    """Tests for _get_system_edition method."""

    def test_read_edition_from_release_file(self, temp_sessions_dir, sample_minios_release):
        """Test reading edition from minios-release file."""
        from minios_session import SessionManager
        
        def exists_side_effect(path):
            return path in [temp_sessions_dir, '/etc/minios-release']
        
        with patch('os.path.exists', side_effect=exists_side_effect), \
             patch('builtins.open', side_effect=lambda *_args, **_kwargs: io.StringIO(sample_minios_release)):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            edition = sm._get_system_edition()
            assert edition == "standard"


class TestCheckFreeSpace:
    """Tests for _check_free_space method."""

    def test_sufficient_space(self, temp_sessions_dir):
        """Test when there is sufficient disk space."""
        from minios_session import SessionManager
        
        # Mock statvfs to return plenty of space
        mock_stat = MagicMock()
        mock_stat.f_bavail = 1000000
        mock_stat.f_frsize = 4096  # ~4GB free
        
        with patch('os.path.exists', return_value=True), \
             patch('os.path.isfile', return_value=False), \
             patch('os.statvfs', return_value=mock_stat):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            has_space, error = sm._check_free_space(temp_sessions_dir, 100)
            assert has_space is True
            assert error is None

    def test_insufficient_space(self, temp_sessions_dir):
        """Test when there is insufficient disk space."""
        from minios_session import SessionManager
        
        # Mock statvfs to return very little space
        mock_stat = MagicMock()
        mock_stat.f_bavail = 10
        mock_stat.f_frsize = 4096  # ~40KB free
        
        with patch('os.path.exists', return_value=True), \
             patch('os.path.isfile', return_value=False), \
             patch('os.statvfs', return_value=mock_stat):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            has_space, error = sm._check_free_space(temp_sessions_dir, 1000)  # Need 1GB
            assert has_space is False
            assert error is not None
            assert "Insufficient" in error


class TestReadSessionsMetadata:
    """Tests for _read_sessions_metadata method."""

    def test_read_json_format(self, temp_sessions_dir, sample_session_json):
        """Test reading JSON format metadata."""
        from minios_session import SessionManager
        
        json_path = os.path.join(temp_sessions_dir, "session.json")
        
        def exists_side_effect(path):
            return path in [temp_sessions_dir, json_path]
        
        with patch('os.path.exists', side_effect=exists_side_effect), \
             patch('builtins.open', mock_open(read_data=json.dumps(sample_session_json))):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            sm.sessions_file = json_path
            sm.session_format = "json"
            
            metadata = sm._read_sessions_metadata()
            assert metadata["default"] == "001"
            assert "001" in metadata["sessions"]
            assert metadata["sessions"]["001"]["mode"] == "native"

    def test_empty_metadata_when_file_missing(self, temp_sessions_dir):
        """Test returning empty metadata when file is missing."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', side_effect=lambda p: p == temp_sessions_dir):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            sm.sessions_file = None
            
            metadata = sm._read_sessions_metadata()
            assert metadata == {"default": None, "sessions": {}}


class TestCheckSessionsDirectoryStatus:
    """Tests for check_sessions_directory_status method."""

    def test_directory_not_found(self, temp_sessions_dir):
        """Test status when sessions directory is not found."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=False):
            sm = SessionManager(custom_sessions_dir="/nonexistent")
            sm.sessions_dir = None
            
            status = sm.check_sessions_directory_status()
            assert status['success'] is False
            assert status['found'] is False

    def test_directory_found_and_writable(self, temp_sessions_dir):
        """Test status when directory exists and is writable."""
        from minios_session import SessionManager

        filesystem_info = {
            'type': 'ext4',
            'device': '/dev/sda1',
            'mount_options': 'rw',
            'is_readonly': False,
            'is_posix_compatible': True,
        }
        with patch('os.path.exists', return_value=True), \
             patch.object(SessionManager, '_detect_filesystem_type',
                          return_value=(filesystem_info, None)), \
             patch('tempfile.NamedTemporaryFile'):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            sm.sessions_dir = temp_sessions_dir
            
            status = sm.check_sessions_directory_status()
            assert status['success'] is True
            assert status['found'] is True
            assert status['writable'] is True


class TestSafeUnmount:
    """Tests for _safe_unmount method."""

    def test_successful_unmount(self, temp_sessions_dir):
        """Test successful unmount operation."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=True), \
             patch('os.path.ismount', side_effect=[True, False]), \
             patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            result = sm._safe_unmount('/mnt/test')
            assert result is True

    def test_unmount_not_mounted(self, temp_sessions_dir):
        """Test unmount when path is not mounted."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=True), \
             patch('os.path.ismount', return_value=False):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            result = sm._safe_unmount('/mnt/test')
            assert result is True

    def test_unmount_with_retries(self, temp_sessions_dir):
        """Test unmount with retries on failure."""
        from minios_session import SessionManager
        
        call_count = [0]
        
        def run_side_effect(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] < 3:
                return MagicMock(returncode=1)
            return MagicMock(returncode=0)
        
        with patch('os.path.exists', return_value=True), \
             patch('os.path.ismount', side_effect=[True, True, True, False]), \
             patch('subprocess.run', side_effect=run_side_effect), \
             patch('time.sleep'):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            result = sm._safe_unmount('/mnt/test', max_retries=5)
            assert result is True
            assert call_count[0] >= 1


class TestPersistentMount:
    @pytest.mark.parametrize('session_name,layer,expected', [
        ('2', 'filesystem', 'minios-session-2-filesystem-'),
        ('2', 'backend', 'minios-session-2-backend-'),
        ('.tmp_conversion', 'filesystem',
         'minios-session-staging-filesystem-'),
    ])
    def test_mount_directory_naming_covers_sessions_and_staging(
            self, tmp_path, session_name, layer, expected):
        from minios_session import SessionManager

        with patch('minios_session.tempfile.mkdtemp',
                   return_value='/tmp/created') as create:
            assert SessionManager._make_session_mount_point(
                str(tmp_path / session_name), layer) == '/tmp/created'
        create.assert_called_once_with(prefix=expected)

    def test_list_json_exposes_mount_status_for_reopened_gui(self):
        from minios_session import format_sessions_json

        session = {
            'id': '2', 'mode': 'raw', 'version': '6.0',
            'edition': 'standard', 'union': 'overlayfs',
            'size': 123, 'modified': None, 'path': '/mock/2',
            'is_default': False, 'is_mounted': True,
            'mount_point': '/mounted/changes',
        }
        result = json.loads(format_sessions_json([session]))
        assert result[0]['is_mounted'] is True
        assert result[0]['mount_point'] == '/mounted/changes'

    def test_list_keeps_mounted_folder_path_after_owner_exits(self, tmp_path):
        from minios_session import SessionManager

        session_dir = tmp_path / '2'
        session_dir.mkdir()
        root = tmp_path / 'mounted'
        (root / 'changes').mkdir(parents=True)
        (session_dir / '.minios-session-mount').write_text(str(root) + '\n')
        manager = SessionManager(custom_sessions_dir=str(tmp_path))
        manager._read_sessions_metadata = MagicMock(return_value={
            'sessions': {'2': {'mode': 'raw'}}})
        manager._get_session_size_info = MagicMock(return_value={
            'used_size': 0, 'display': '0B'})

        with patch('minios_session.os.path.ismount',
                   side_effect=lambda path: path == str(root)):
            session = next(item for item in manager.list_sessions(
                include_running_check=False) if item['id'] == '2')

        assert session['is_mounted'] is True
        assert session['mount_point'] == str(root / 'changes')

    def test_orphaned_mounted_session_cannot_be_modified(self, tmp_path):
        from minios_session import SessionManager

        session_dir = tmp_path / '2'
        session_dir.mkdir()
        mount_root = tmp_path / 'mounted'
        mount_root.mkdir()
        (session_dir / '.minios-session-mount').write_text(
            str(mount_root) + '\n')
        manager = SessionManager(custom_sessions_dir=str(tmp_path))

        with patch('minios_session.os.path.ismount',
                   side_effect=lambda path: path == str(mount_root)):
            activated, activation_error = manager.activate_session('2')
            deleted, deletion_error = manager.delete_session('2')

        assert not activated and 'mounted or busy' in activation_error
        assert not deleted and 'mounted or busy' in deletion_error
        assert session_dir.is_dir()

    def test_mount_session_releases_global_lock_but_holds_session_lease(
            self, temp_sessions_dir):
        from minios_session import SessionManager

        os.mkdir(os.path.join(temp_sessions_dir, '2'))
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        events = []

        @contextlib.contextmanager
        def lock():
            events.append('lock-enter')
            try:
                yield
            finally:
                events.append('lock-exit')

        @contextlib.contextmanager
        def lease(session_id):
            events.append(('lease-enter', session_id))
            try:
                yield os.path.join(temp_sessions_dir, session_id)
            finally:
                events.append(('lease-exit', session_id))

        @contextlib.contextmanager
        def mounted(*args, **kwargs):
            events.append(('mount', args, kwargs))
            try:
                yield '/mnt/session/changes'
            finally:
                events.append('unmount')

        manager._mutation_lock = lock
        manager._session_lease = lease
        manager._read_sessions_metadata = lambda: {
            'default': '1', 'running': '3',
            'sessions': {'2': {'mode': 'raw', 'encryption': 'luks'}},
        }
        manager._mount_session_read = mounted

        with manager.mount_session('2', password=b'secret') as mount_point:
            assert mount_point == '/mnt/session/changes'
            assert events[:3] == [
                ('lease-enter', '2'), 'lock-enter', 'lock-exit']
            assert events[-1][0] == 'mount'

        assert events[-2:] == ['unmount', ('lease-exit', '2')]
        _name, args, kwargs = events[3]
        assert args == (os.path.join(temp_sessions_dir, '2'), 'raw')
        assert kwargs['password'] == b'secret'
        assert kwargs['encryption'] == 'luks'
        assert kwargs['writable'] is True
        assert kwargs['strict_cleanup'] is True
        assert kwargs['mount_state']['session_id'] == '2'

    def test_session_lease_blocks_only_the_same_session(self, temp_sessions_dir):
        from minios_session import SessionBusyError, SessionManager

        os.mkdir(os.path.join(temp_sessions_dir, '2'))
        os.mkdir(os.path.join(temp_sessions_dir, '3'))
        first = SessionManager(custom_sessions_dir=temp_sessions_dir)
        second = SessionManager(custom_sessions_dir=temp_sessions_dir)

        with first._session_lease('2'):
            with pytest.raises(SessionBusyError, match='mounted or busy'):
                with second._session_lease('2'):
                    pass
            with second._session_lease('3') as path:
                assert path == os.path.join(temp_sessions_dir, '3')

    def test_activation_cannot_target_mounted_session(self, temp_sessions_dir):
        from minios_session import SessionManager

        os.mkdir(os.path.join(temp_sessions_dir, '2'))
        mount_owner = SessionManager(custom_sessions_dir=temp_sessions_dir)
        command = SessionManager(custom_sessions_dir=temp_sessions_dir)

        with mount_owner._session_lease('2'):
            success, message = command.activate_session('2')

        assert not success
        assert 'mounted or busy' in message

    def test_reserved_destination_is_leased_until_publication(
            self, temp_sessions_dir):
        from minios_session import SessionManager

        owner = SessionManager(custom_sessions_dir=temp_sessions_dir)
        command = SessionManager(custom_sessions_dir=temp_sessions_dir)
        session_id, path, lease = owner._reserve_session(acquire_lease=True)
        try:
            success, message = command.delete_session(session_id)
            assert not success
            assert 'mounted or busy' in message
            assert os.path.isdir(path)
        finally:
            lease.close()

    def test_detached_mount_control_survives_client_disconnect(
            self, temp_sessions_dir):
        import socket
        import threading
        from minios_session import (_mount_socket_path, _send_mount_control,
                                    _serve_detached_mount, SessionManager)

        session_path = os.path.join(temp_sessions_dir, '2')
        os.mkdir(session_path)
        socket_path = os.path.join(temp_sessions_dir, 'control.sock')
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager.reclaim_mounted_session = MagicMock(return_value=(
            True, 'reclaimed', {'freed_bytes': 42}))
        manager._safe_unmount = MagicMock(return_value=True)
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as listener:
            listener.bind(socket_path)
            listener.listen(4)
            def serve():
                client = _serve_detached_mount(
                    manager, {'session_id': '2',
                              'filesystem_mount': '/mounted'}, listener)
                with client:
                    client.sendall(b'{"success":true}\n')

            worker = threading.Thread(
                target=serve)
            worker.start()
            try:
                with patch('minios_session._mount_socket_path',
                           return_value=socket_path):
                    # Simulate the first GUI exiting without an unmount request.
                    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                        client.connect(socket_path)
                    reply = _send_mount_control(manager, '2', 'reclaim', True)
                    assert reply['success'] and reply['reclaim']['freed_bytes'] == 42
                    assert _send_mount_control(manager, '2', 'unmount')['success']
            finally:
                worker.join(timeout=3)
                assert not worker.is_alive()

    def test_busy_unmount_keeps_owner_available_for_retry(self, temp_sessions_dir):
        import socket
        from minios_session import (_send_mount_control, _serve_detached_mount,
                                    SessionManager)

        os.mkdir(os.path.join(temp_sessions_dir, '2'))
        socket_path = os.path.join(temp_sessions_dir, 'control.sock')
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._safe_unmount = MagicMock(side_effect=(False, True))
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as listener:
            listener.bind(socket_path)
            listener.listen(4)
            finished = []

            def serve():
                client = _serve_detached_mount(
                    manager, {'filesystem_mount': '/mounted'}, listener)
                finished.append(True)
                with client:
                    client.sendall(b'{"success":true}\n')

            worker = threading.Thread(target=serve)
            worker.start()
            try:
                with patch('minios_session._mount_socket_path',
                           return_value=socket_path):
                    failed = _send_mount_control(manager, '2', 'unmount')
                    assert failed['success'] is False
                    assert 'backing storage was left attached' in failed['message']
                    assert not finished
                    assert _send_mount_control(manager, '2', 'unmount')['success']
                manager._safe_unmount.assert_has_calls([
                    call('/mounted', use_lazy=False),
                    call('/mounted', use_lazy=False)])
            finally:
                worker.join(timeout=3)
                assert not worker.is_alive()

    @pytest.mark.parametrize('failure', ['send', 'read'])
    def test_detached_mount_survives_control_connection_errors(self, failure):
        from minios_session import _serve_detached_mount

        manager = MagicMock()
        manager.reclaim_mounted_session.return_value = (True, 'reclaimed', {})
        manager._safe_unmount.return_value = True
        disconnected = MagicMock()
        stream = disconnected.makefile.return_value.__enter__.return_value
        stream.readline.return_value = '{"command":"reclaim"}\n'
        if failure == 'send':
            disconnected.sendall.side_effect = BrokenPipeError()
        else:
            stream.readline.side_effect = TimeoutError()
        unmount = MagicMock()
        unmount.makefile.return_value.__enter__.return_value.readline.return_value = (
            '{"command":"unmount"}\n')
        listener = MagicMock()
        listener.accept.side_effect = [(disconnected, None), (unmount, None)]

        assert _serve_detached_mount(
            manager, {'filesystem_mount': '/mounted'}, listener) is unmount
        disconnected.close.assert_called_once()
        unmount.close.assert_not_called()
        if failure == 'send':
            manager.reclaim_mounted_session.assert_called_once_with(
                {'filesystem_mount': '/mounted'}, compact=False)

    def test_reopened_gui_recognizes_mounted_session(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        children = [MagicMock() for _index in range(17)]
        gui.context_menu = MagicMock()
        gui.context_menu.get_children.return_value = children
        gui.mount_item = children[10]
        gui.change_passphrase_item = children[11]
        gui.open_mounted_folder_item = children[13]
        gui.reclaim_item = children[16]
        gui.sessions_writable = True
        gui._session_mounts = {}
        gui._sessions_by_id = {'2': {
            'is_mounted': True, 'mount_point': '/mounted/changes'}}
        row = SimpleNamespace(
            session_id='2', mode='dynblk', configuration_supported=True,
            is_active=False, is_running=False)

        gui._prepare_context_menu(row)

        gui.mount_item.set_label.assert_called_with('_Unmount Session')
        gui.mount_item.set_sensitive.assert_called_with(True)
        children[0].set_sensitive.assert_called_with(False)
        children[15].set_sensitive.assert_called_with(False)
        gui.open_mounted_folder_item.set_visible.assert_called_with(True)
        gui.open_mounted_folder_item.set_sensitive.assert_called_with(True)

        gui.selected_session_id = '2'
        gui._stop_session_mount = MagicMock()
        gui._on_context_mount(None)
        gui._stop_session_mount.assert_called_once_with('2')

    def test_gui_opens_session_and_mounted_folders_separately(self, tmp_path):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        session_path = tmp_path / '2'
        mounted_path = tmp_path / 'mounted' / 'changes'
        session_path.mkdir()
        mounted_path.mkdir(parents=True)
        gui.selected_session_id = '2'
        gui._session_mounts = {}
        gui._sessions_by_id = {'2': {
            'path': str(session_path), 'is_mounted': True,
            'mount_point': str(mounted_path)}}
        gui._show_error = MagicMock()

        with patch('minios_session_manager.subprocess.Popen') as opener:
            gui._on_context_open_folder(None)
            gui._on_context_open_mounted_folder(None)
            assert opener.call_args_list == [
                call(['xdg-open', str(session_path)]),
                call(['xdg-open', str(mounted_path)])]

            opener.reset_mock()
            gui._sessions_by_id['2']['is_mounted'] = False
            gui._on_context_open_mounted_folder(None)
            opener.assert_not_called()
            gui._show_error.assert_called_once_with(
                'Mounted session folder not found')

    def test_closing_gui_does_not_unmount_persistent_session(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._cli_process_lock = threading.Lock()
        gui._cli_process = None
        mount_process = MagicMock()
        gui._session_mounts = {'2': {'process': mount_process}}

        with patch('minios_session_manager.Gtk.main_quit'):
            gui._on_window_destroy(None)

        assert gui._closing is True
        mount_process.stdin.close.assert_not_called()
        mount_process.terminate.assert_not_called()

    @pytest.mark.parametrize('metadata, message', [
        ({'default': '2', 'sessions': {'2': {'mode': 'raw'}}}, 'active'),
        ({'running': '2', 'sessions': {'2': {'mode': 'raw'}}}, 'running'),
        ({'sessions': {'2': {'mode': 'native'}}}, 'cannot be mounted'),
        ({'sessions': {'2': {'mode': 'raw', 'encryption': 'future'}}},
         'Unsupported'),
    ])
    def test_mount_session_rejects_unsafe_configuration(
            self, temp_sessions_dir, metadata, message):
        from minios_session import SessionManager

        os.mkdir(os.path.join(temp_sessions_dir, '2'))
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._read_sessions_metadata = lambda: metadata
        manager._mount_session_read = MagicMock()

        with pytest.raises(ValueError, match=message):
            with manager.mount_session('2'):
                pass
        manager._mount_session_read.assert_not_called()

    @pytest.mark.parametrize('mode, container', [
        ('raw', 'changes.img'), ('dynfilefs', 'changes.dat')])
    def test_encrypted_mount_marker_records_filesystem_root(
            self, tmp_path, mode, container):
        from minios_session import SessionManager

        session = tmp_path / '2'
        session.mkdir()
        (session / container).touch()
        root = tmp_path / 'luks'
        (root / 'changes').mkdir(parents=True)
        manager = SessionManager(custom_sessions_dir=str(tmp_path))
        manager._read_sessions_metadata = MagicMock(return_value={
            'sessions': {'2': {'mode': mode, 'encryption': 'luks'}}})
        manager._session_configuration_supported = MagicMock(return_value=True)
        manager._wait_for_mount = MagicMock(return_value=True)
        manager._safe_unmount = MagicMock(return_value=True)
        manager._cleanup_process = MagicMock()
        luks = MagicMock()
        luks.__enter__.return_value = str(root)
        luks.__exit__.return_value = False
        manager._mount_luks = MagicMock(return_value=luks)
        manager._safe_rmtree = MagicMock(return_value=True)

        with patch('minios_session.subprocess.Popen'), \
                patch('minios_session.tempfile.mkdtemp',
                      return_value=str(tmp_path / 'dynfilefs')) as create, \
                patch('minios_session.os.path.ismount',
                      side_effect=lambda path: path == str(root)):
            with manager.mount_session('2', password=b'secret') as mounted:
                assert mounted == str(root / 'changes')
                assert (session / '.minios-session-mount').read_text() == str(root) + '\n'
                assert manager._detached_mount_exists(str(session))
        if mode == 'dynfilefs':
            create.assert_called_once_with(prefix='minios-session-2-backend-')
        manager._mount_luks.assert_called_once()
        assert manager._mount_luks.call_args[1]['session_path'] == str(session)

    def test_existing_raw_mount_is_writable_and_never_formats(self,
                                                               temp_sessions_dir):
        from minios_session import SessionManager

        session_path = os.path.join(temp_sessions_dir, '2')
        os.mkdir(session_path)
        open(os.path.join(session_path, 'changes.img'), 'wb').close()
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._safe_unmount = MagicMock(return_value=True)
        manager._safe_rmtree = MagicMock(return_value=True)

        with patch('minios_session.tempfile.mkdtemp',
                   return_value='/tmp/raw-mount') as create, \
                patch('minios_session.subprocess.run') as run:
            run.return_value = MagicMock(returncode=0)
            with manager._mount_session_read(
                    session_path, 'raw', writable=True,
                    strict_cleanup=True) as mount_point:
                assert mount_point == '/tmp/raw-mount'

        commands = [item[0][0] for item in run.call_args_list]
        assert ['mount', '-o', 'loop', os.path.join(session_path, 'changes.img'),
                '/tmp/raw-mount'] in commands
        assert not any(command and command[0] == 'mke2fs' for command in commands)
        create.assert_called_once_with(prefix='minios-session-2-filesystem-')
        manager._safe_unmount.assert_called_once_with(
            '/tmp/raw-mount', use_lazy=False)

    def test_busy_dynfilefs_mount_does_not_kill_backing_daemon(
            self, temp_sessions_dir):
        from minios_session import MountCleanupError, SessionManager

        session_path = os.path.join(temp_sessions_dir, '2')
        os.mkdir(session_path)
        open(os.path.join(session_path, 'changes.dat'), 'wb').close()
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._wait_for_mount = MagicMock(return_value=True)
        manager._safe_unmount = MagicMock(return_value=False)
        manager._cleanup_process = MagicMock()
        process = MagicMock()

        with patch('minios_session.tempfile.mkdtemp',
                   side_effect=['/tmp/dyn-mount', '/tmp/inner-mount']) as create, \
                patch('minios_session.subprocess.Popen', return_value=process), \
                patch('minios_session.subprocess.run',
                      return_value=MagicMock(returncode=0)):
            with pytest.raises(MountCleanupError):
                with manager._mount_session_read(
                        session_path, 'dynfilefs', writable=True,
                        strict_cleanup=True):
                    pass

        manager._cleanup_process.assert_not_called()
        assert [item[1]['prefix'] for item in create.call_args_list] == [
            'minios-session-2-backend-', 'minios-session-2-filesystem-']

    def test_mount_cli_json_password_line_and_lifetime_stdin(self, monkeypatch,
                                                              capsys):
        import minios_session

        manager = MagicMock()
        manager.sessions_dir = '/sessions'
        manager._validate_session_id.return_value = '2'
        manager._read_sessions_metadata.return_value = {
            'sessions': {'2': {'mode': 'raw', 'encryption': 'luks'}}}
        mount_context = MagicMock()
        mount_context.__enter__.return_value = '/mnt/session'
        mount_context.__exit__.return_value = False
        manager.mount_session.return_value = mount_context
        stdin = SimpleNamespace(buffer=io.BytesIO(b'secret\nlifetime-data'))

        monkeypatch.setattr(sys, 'stdin', stdin)
        monkeypatch.setattr(sys, 'argv', [
            'minios-session', 'mount', '2', '--password-stdin', '--json'])
        with patch('minios_session.os.geteuid', return_value=0), \
                patch('minios_session.luks_runtime_available', return_value=True), \
                patch('minios_session.SessionManager', return_value=manager), \
                pytest.raises(SystemExit) as exit_info:
            minios_session.main()

        assert exit_info.value.code == 0
        assert stdin.buffer.read() == b''
        manager.mount_session.assert_called_once()
        assert manager.mount_session.call_args[0] == ('2',)
        assert manager.mount_session.call_args[1]['password'] == b'secret'
        assert manager.mount_session.call_args[1]['mount_state'] == {}
        result = json.loads(capsys.readouterr().out)
        assert result == {
            'success': True,
            'message': 'Session 2 mounted read-write at /mnt/session',
            'mount_point': '/mnt/session',
            'session_id': '2',
        }

    def test_mount_cli_empty_password_returns_json_error(self, monkeypatch, capsys):
        import minios_session

        manager = MagicMock()
        manager.sessions_dir = '/sessions'
        manager._validate_session_id.return_value = '2'
        manager._read_sessions_metadata.return_value = {
            'sessions': {'2': {'mode': 'raw', 'encryption': 'luks'}}}
        monkeypatch.setattr(sys, 'stdin', SimpleNamespace(buffer=io.BytesIO(b'\n')))
        monkeypatch.setattr(sys, 'argv', [
            'minios-session', 'mount', '2', '--password-stdin', '--json'])
        with patch('minios_session.os.geteuid', return_value=0), \
                patch('minios_session.luks_runtime_available', return_value=True), \
                patch('minios_session.SessionManager', return_value=manager), \
                pytest.raises(SystemExit) as exit_info:
            minios_session.main()

        assert exit_info.value.code == 1
        result = json.loads(capsys.readouterr().out)
        assert result['success'] is False
        assert result['message'] == 'LUKS passphrase must not be empty.'
        assert result['mount_point'] is None
        manager.mount_session.assert_not_called()

    def test_mount_cli_ignores_repeated_interrupt_during_cleanup(self,
                                                                  monkeypatch):
        import minios_session

        manager = MagicMock()
        manager.sessions_dir = '/sessions'
        manager._validate_session_id.return_value = '2'
        manager._read_sessions_metadata.return_value = {
            'sessions': {'2': {'mode': 'raw', 'encryption': 'none'}}}
        mount_context = MagicMock()
        mount_context.__enter__.return_value = '/mnt/session'
        mount_context.__exit__.return_value = False
        manager.mount_session.return_value = mount_context
        signal_calls = []

        def record_signal(signal_number, handler):
            signal_calls.append((signal_number, handler))
            return 'previous-{}'.format(signal_number)

        monkeypatch.setattr(sys, 'stdin', io.StringIO(''))
        monkeypatch.setattr(sys, 'argv', [
            'minios-session', 'mount', '2', '--json'])
        with patch('minios_session.os.geteuid', return_value=0), \
                patch('minios_session.SessionManager', return_value=manager), \
                patch('minios_session.signal.signal', side_effect=record_signal), \
                pytest.raises(SystemExit) as exit_info:
            minios_session.main()

        assert exit_info.value.code == 0
        protected_signals = (
            minios_session.signal.SIGINT,
            minios_session.signal.SIGTERM,
            minios_session.signal.SIGHUP,
        )
        assert [item[0] for item in signal_calls] == list(protected_signals) * 3
        assert all(call[1] == minios_session.signal.SIG_IGN
                   for call in signal_calls[3:6])
        assert [call[1] for call in signal_calls[6:]] == [
            'previous-{}'.format(signal_number)
            for signal_number in protected_signals
        ]

    def test_mount_control_routes_reclaim_without_ending_mount(self,
                                                                monkeypatch,
                                                                capsys):
        import minios_session

        manager = MagicMock()
        manager.reclaim_mounted_session.return_value = (
            True, 'reclaimed', {'complete': True})
        request = json.dumps({
            'command': 'reclaim', 'request_id': 7, 'compact': True,
        }).encode() + b'\n'
        monkeypatch.setattr(
            sys, 'stdin', SimpleNamespace(buffer=io.BytesIO(request)))

        minios_session._serve_mount_control(manager, {'session_id': '2'})

        manager.reclaim_mounted_session.assert_called_once_with(
            {'session_id': '2'}, compact=True)
        assert json.loads(capsys.readouterr().out) == {
            'type': 'reclaim', 'request_id': 7, 'success': True,
            'message': 'reclaimed', 'reclaim': {'complete': True},
        }

    def test_completion_offers_mount_sessions_and_capability_password(self):
        completion = os.path.join(
            os.path.dirname(__file__), '..', 'completion', 'minios-session')
        with open(completion, encoding='utf-8') as stream:
            contents = stream.read()
        assert 'save mount change-passphrase create' in contents
        assert 'activate|save|mount|change-passphrase|delete|clone|reclaim)' in contents
        assert 'cmd_opts="--help --json --sessions-dir${luks_opt}"' in contents


class TestSafeRmtree:
    """Tests for _safe_rmtree method."""

    def test_successful_removal(self, temp_sessions_dir):
        """Test successful directory removal."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=True), \
             patch('shutil.rmtree') as mock_rmtree:
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            result = sm._safe_rmtree('/tmp/testdir')
            assert result is True
            mock_rmtree.assert_called()

    def test_removal_nonexistent_path(self, temp_sessions_dir):
        """Test removal of nonexistent path."""
        from minios_session import SessionManager
        
        def exists_side_effect(path):
            if path == temp_sessions_dir:
                return True
            return False
        
        with patch('os.path.exists', side_effect=exists_side_effect):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            result = sm._safe_rmtree('/nonexistent/path')
            assert result is True

    def test_removal_failure(self, temp_sessions_dir):
        """Test handling of removal failure."""
        from minios_session import SessionManager
        
        with patch('os.path.exists', return_value=True), \
             patch('shutil.rmtree', side_effect=OSError("Permission denied")), \
             patch('subprocess.run', return_value=MagicMock(returncode=1)):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            result = sm._safe_rmtree('/tmp/testdir')
            assert result is False


class TestMakeTempDir:
    """Tests for _make_temp_dir method."""

    def test_creates_temp_directory(self, temp_sessions_dir):
        """Test temporary directory creation."""
        from minios_session import SessionManager
        
        created_dirs = []
        
        def makedirs_side_effect(path, **kwargs):
            created_dirs.append(path)
        
        with patch('os.path.exists', return_value=True), \
             patch('os.makedirs', side_effect=makedirs_side_effect):
            sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
            sm.sessions_dir = temp_sessions_dir
            
            result = sm._make_temp_dir()
            assert result.startswith(temp_sessions_dir)
            assert '.tmp_' in result


class TestCliHelp:
    """Tests for help output."""

    def test_main_help_does_not_require_root(self, capsys):
        """Test that CLI help is available without root privileges."""
        from minios_session import main

        with patch.object(sys, 'argv', ['minios-session', '--help']), \
             patch('os.geteuid', return_value=1000), \
             pytest.raises(SystemExit) as exc:
            main()

        captured = capsys.readouterr()

        assert exc.value.code == 0
        assert 'usage:' in captured.out
        assert 'create [MODE] [SIZE]' in captured.out
        assert 'Mount a detached session read-write' in captured.out
        assert 'requires root privileges' not in captured.err

    def test_gui_launcher_help(self):
        """Test that GUI launcher prints a usage message."""
        launcher = os.path.join(os.path.dirname(__file__), '..', 'bin', 'minios-session-manager')

        result = subprocess.run(
            [launcher, '--help'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
            check=False,
        )

        assert result.returncode == 0
        assert 'Usage: minios-session-manager' in result.stdout
        assert 'minios-session --help' in result.stdout
        assert result.stderr == ''


class TestAuditRegressions:
    """Security and data-integrity regressions from the session storage audit."""

    def test_gui_cli_uses_python36_text_mode(self):
        import importlib.util
        import types

        gi = types.ModuleType('gi')
        gi.require_version = lambda *_args: None
        repository = types.ModuleType('gi.repository')
        repository.Gdk = MagicMock()
        repository.Gio = MagicMock()
        repository.Gtk = MagicMock()
        repository.GLib = MagicMock()
        repository.Pango = MagicMock()
        minios_gui = types.ModuleType('minios_gui')
        for name in ('BackgroundTask', 'OperationView', 'ProgressDialog',
                     'StatusBanner', 'apply_minios_css', 'ask_confirmation',
                     'choose_open_file', 'choose_save_file', 'new_header_bar',
                     'new_icon', 'show_error_dialog', 'show_info_dialog'):
            setattr(minios_gui, name, MagicMock())

        module_path = os.path.join(
            os.path.dirname(__file__), '..', 'lib', 'minios_session_manager.py')
        spec = importlib.util.spec_from_file_location(
            'minios_session_manager_python36_test', module_path)
        module = importlib.util.module_from_spec(spec)
        with patch.dict(sys.modules, {
                'gi': gi,
                'gi.repository': repository,
                'minios_gui': minios_gui}):
            spec.loader.exec_module(module)

        gui = object.__new__(module.SessionManagerGUI)
        gui.cli_command = 'minios-session'
        gui._cli_lock = module.threading.Lock()
        gui._cli_process_lock = module.threading.Lock()
        gui._cli_process = None
        gui._closing = False
        process = MagicMock(returncode=0)
        process.communicate.return_value = ('output', '')
        with patch.object(module.subprocess, 'Popen', return_value=process) as popen:
            assert gui._run_cli_command(['list', '--json'], 'input') == (
                True, 'output', '')

        kwargs = popen.call_args[1]
        assert kwargs['universal_newlines'] is True
        assert 'text' not in kwargs
        process.communicate.assert_called_once_with(input='input')

    def test_status_reports_missing_sessions_directory(self, tmp_path, capsys):
        import minios_session

        missing = str(tmp_path / 'missing-sessions')
        argv = ['minios-session', '--json', '--sessions-dir', missing, 'status']
        with patch('os.geteuid', return_value=0), patch.object(sys, 'argv', argv):
            minios_session.main()

        captured = capsys.readouterr()
        status = json.loads(captured.out)
        assert captured.err == ''
        assert status['found'] is False
        assert status['writable'] is False
        assert status['sessions_dir'] is None

    def test_gui_ram_only_refresh_does_not_query_missing_sessions(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._refresh_generation = 0
        gui.sessions_status = {'found': False, 'writable': False}
        gui._run_cli_command = MagicMock()
        gui._process_session_data = MagicMock()

        gui.refresh_session_list()

        gui._run_cli_command.assert_not_called()
        gui._process_session_data.assert_called_once_with(
            1, True, '[]', '', None, None)

    def test_gui_distinguishes_ram_only_status_from_query_failure(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._run_cli_command = MagicMock(return_value=(
            True, json.dumps({
                'success': False, 'found': False, 'writable': False,
                'sessions_dir': None,
                'error': 'Sessions directory not found',
            }), ''))
        status = gui._check_sessions_directory_status()
        assert status['found'] is False
        assert status['_query_error'] is False

        gui._run_cli_command = MagicMock(return_value=(
            False, '', 'Authorization cancelled'))
        status = gui._check_sessions_directory_status()
        assert status['found'] is False
        assert status['_query_error'] is True
        assert status['error'] == 'Authorization cancelled'

    def test_gui_rejects_non_object_status_response(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._run_cli_command = MagicMock(return_value=(True, '[]', ''))

        status = gui._check_sessions_directory_status()

        assert status['_query_error'] is True
        assert 'not an object' in status['error']

    @pytest.mark.parametrize('payload', [
        {},
        {'success': True, 'found': 'false', 'writable': 'false'},
        {'success': True, 'found': False, 'writable': True},
        {'success': True, 'found': True, 'writable': False},
        {'success': False, 'found': True, 'writable': False,
         'sessions_dir': '/changes', 'filesystem_type': 'ext4'},
        {'success': False, 'found': False, 'writable': False,
         'sessions_dir': None},
        {'success': True, 'found': True, 'writable': True,
         'sessions_dir': '/changes', 'filesystem_type': 'ext4',
         'error': 'unexpected'},
    ])
    def test_gui_rejects_invalid_status_schema(self, payload):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._run_cli_command = MagicMock(return_value=(
            True, json.dumps(payload), ''))

        status = gui._check_sessions_directory_status()

        assert status['_query_error'] is True

    def test_gui_query_error_does_not_render_ram_only_empty_state(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._refresh_generation = 0
        gui.sessions_status = {
            'found': False, 'writable': False, '_query_error': True,
            'error': 'Authorization cancelled',
        }
        gui._show_sessions_query_error_state = MagicMock()

        gui.refresh_session_list()

        gui._show_sessions_query_error_state.assert_called_once_with(1)

    def test_gui_retry_recovers_after_status_query_failure(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._status_retry_generation = 1
        gui._closing = False
        gui._filesystem_info = {}
        gui.sessions_status_banner = MagicMock()
        gui.sessions_status_retry = MagicMock()
        gui.create_btn = MagicMock()
        gui.import_btn = MagicMock()
        gui.cleanup_btn = MagicMock()
        gui.refresh_session_list = MagicMock()

        result = gui._finish_sessions_directory_status_retry(1, {
            'success': False, 'found': False, 'writable': False,
            'sessions_dir': None, 'error': 'Sessions directory not found',
            '_query_error': False,
        })

        assert result is False
        gui.sessions_status_retry.set_visible.assert_called_once_with(False)
        gui.sessions_status_retry.set_sensitive.assert_called_once_with(True)
        for button in (gui.create_btn, gui.import_btn, gui.cleanup_btn):
            button.set_sensitive.assert_called_once_with(False)
        gui.refresh_session_list.assert_called_once_with()

    def test_gui_retry_refreshes_visible_error_after_another_failure(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._status_retry_generation = 1
        gui._closing = False
        gui._filesystem_info = {}
        gui.sessions_status_banner = MagicMock()
        gui.sessions_status_retry = MagicMock()
        gui.create_btn = MagicMock()
        gui.import_btn = MagicMock()
        gui.cleanup_btn = MagicMock()
        gui.refresh_session_list = MagicMock()

        gui._finish_sessions_directory_status_retry(1, {
            'success': False, 'found': False, 'writable': False,
            '_query_error': True, 'error': 'Still unavailable',
        })

        gui.sessions_status_retry.set_visible.assert_called_once_with(True)
        gui.refresh_session_list.assert_called_once_with()

    def test_gui_retry_runs_status_query_in_background_task(self):
        import minios_session_manager as module

        gui = object.__new__(module.SessionManagerGUI)
        gui._status_retry_generation = 0
        gui.window = MagicMock()
        gui.sessions_status_banner = MagicMock()
        gui.sessions_status_retry = MagicMock()
        task = MagicMock()
        task.start.return_value = task
        with patch.object(module, 'BackgroundTask', return_value=task) as factory:
            gui._retry_sessions_directory_status(None)

        gui.sessions_status_retry.set_sensitive.assert_called_once_with(False)
        gui.sessions_status_retry.set_visible.assert_called_once_with(False)
        assert callable(factory.call_args[0][0])
        assert callable(factory.call_args[0][1])
        task.start.assert_called_once_with()

    def test_gui_hides_healthy_session_status_banner(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._status_pending = False
        gui.sessions_writable = True
        gui.sessions_status = {
            'success': True, 'found': True, 'writable': True,
            '_query_error': False,
        }
        gui.sessions_status_banner = MagicMock()
        gui.sessions_status_banner.label = MagicMock()

        gui._update_sessions_status_banner()

        gui.sessions_status_banner.set_intent.assert_called_once_with('success')
        gui.sessions_status_banner.set_visible.assert_called_once_with(False)

    def test_gui_keeps_actionable_session_status_banner_visible(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._status_pending = False
        gui.sessions_writable = False
        gui.sessions_status = {
            'success': True, 'found': True, 'writable': False,
            '_query_error': False,
        }
        gui.sessions_status_banner = MagicMock()
        gui.sessions_status_banner.label = MagicMock()

        gui._update_sessions_status_banner()

        gui.sessions_status_banner.set_intent.assert_called_once_with('error')
        gui.sessions_status_banner.set_visible.assert_called_once_with(True)

    def test_gui_loading_overlay_locks_and_restores_footer_actions(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui.sessions_writable = True
        gui._filesystem_info = {'filesystem': {'type': 'ext4'}}
        gui.create_btn = MagicMock()
        gui.import_btn = MagicMock()
        gui.cleanup_btn = MagicMock()
        gui.loading_box = MagicMock()
        gui.loading_label = MagicMock()

        gui._show_loading(True)
        for button in (gui.create_btn, gui.import_btn, gui.cleanup_btn):
            button.set_sensitive.assert_called_once_with(False)

        gui._show_loading(False)
        for button in (gui.create_btn, gui.import_btn, gui.cleanup_btn):
            assert button.set_sensitive.call_args_list == [call(False), call(True)]

    def test_stale_fetch_error_does_not_change_current_refresh(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._refresh_generation = 2
        gui._show_error = MagicMock()
        gui._show_loading = MagicMock()

        assert gui._process_session_fetch_error(1, 'stale') is False
        gui._show_error.assert_not_called()
        gui._show_loading.assert_not_called()

    @pytest.mark.parametrize('payload, expected', [
        ({
            'filesystem': {'type': 'ext4'},
            'compatible_modes': ['native', 'squashfs'],
            'limitations': {},
        }, True),
        ({}, False),
        ({
            'filesystem': {'type': 'ext4'},
            'compatible_modes': ['native'],
            'limitations': {'max_file_size': True},
        }, False),
    ])
    def test_gui_validates_filesystem_info_schema(self, payload, expected):
        from minios_session_manager import SessionManagerGUI

        assert SessionManagerGUI._valid_filesystem_info(payload) is expected

    @pytest.mark.parametrize('output', ['{}', '[null]', '["bad"]'])
    def test_gui_rejects_invalid_session_list_schema_without_clearing_rows(
            self, output):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._refresh_generation = 1
        gui.sessions_list = MagicMock()
        gui.sessions_list.get_children.return_value = [MagicMock()]
        gui._show_error = MagicMock()
        gui._show_loading = MagicMock()

        gui._process_session_data(1, True, output, '', None, None)

        gui._show_error.assert_called_once_with(
            'Failed to parse session list JSON: '
            'response does not match the session list schema')
        gui.sessions_list.remove.assert_not_called()
        gui._show_loading.assert_called_once_with(False)

    @pytest.mark.parametrize('mode, expected_size', [
        ('dynfilefs', '80.1MB / 16GB'),
        ('dynblk', '80.1MB / 16GB'),
        ('vmdk', '80.1MB / 16GB'),
        ('native', '80.1MB'),
    ])
    def test_gui_shows_capacity_for_thin_session_modes(self, mode,
                                                       expected_size):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._refresh_generation = 1
        gui.sessions_writable = True
        gui.sessions_list = MagicMock()
        gui.sessions_list.get_children.return_value = []
        gui._create_session_row = MagicMock()
        gui._update_footer_sensitivity = MagicMock()
        gui._show_loading = MagicMock()
        session = {
            'id': '1', 'mode': mode, 'encryption': 'none',
            'configuration_supported': True, 'version': '20260922',
            'edition': 'standard', 'union': 'aufs', 'size': 84000000,
            'size_formatted': '80.1MB', 'total_size': 17179869184,
            'total_size_formatted': '16GB', 'modified': None,
            'path': '/changes/1', 'is_default': False, 'is_running': False,
        }

        gui._process_session_data(
            1, True, json.dumps([session]), '', None, None)

        assert gui._create_session_row.call_args[0][7] == expected_size

    def test_gui_mount_context_is_limited_to_detached_container_sessions(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        children = [MagicMock() for _index in range(17)]
        gui.context_menu = MagicMock()
        gui.context_menu.get_children.return_value = children
        gui.mount_item = children[10]
        gui.change_passphrase_item = children[11]
        gui.open_mounted_folder_item = children[13]
        gui.reclaim_item = children[16]
        gui.sessions_writable = True
        gui._session_mounts = {}
        gui._sessions_by_id = {}
        row = SimpleNamespace(
            session_id='2', mode='dynblk', configuration_supported=True,
            is_active=False, is_running=False)

        gui._prepare_context_menu(row)

        gui.mount_item.set_visible.assert_called_once_with(True)
        gui.mount_item.set_label.assert_called_once_with('_Mount Session')
        gui.mount_item.set_sensitive.assert_called_once_with(True)

        gui._session_mounts['2'] = {'process': MagicMock()}
        gui._prepare_context_menu(row)
        gui.mount_item.set_label.assert_called_with('_Unmount Session')
        gui.mount_item.set_sensitive.assert_called_with(True)
        children[0].set_sensitive.assert_called_with(False)
        children[6].set_sensitive.assert_called_with(False)
        children[15].set_sensitive.assert_called_with(False)

    def test_gui_mount_does_not_block_a_different_session(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        children = [MagicMock() for _index in range(17)]
        gui.context_menu = MagicMock()
        gui.context_menu.get_children.return_value = children
        gui.mount_item = children[10]
        gui.change_passphrase_item = children[11]
        gui.open_mounted_folder_item = children[13]
        gui.reclaim_item = children[16]
        gui.sessions_writable = True
        gui._session_mounts = {'2': {
            'ready': True, 'stopping': False, 'reclaiming': False}}
        gui._sessions_by_id = {}
        row = SimpleNamespace(
            session_id='3', mode='dynblk', configuration_supported=True,
            is_active=False, is_running=False)

        gui._prepare_context_menu(row)

        gui.mount_item.set_label.assert_called_once_with('_Mount Session')
        gui.mount_item.set_sensitive.assert_called_once_with(True)
        gui.reclaim_item.set_sensitive.assert_called_once_with(True)
        children[0].set_sensitive.assert_called_once_with(True)
        children[6].set_sensitive.assert_called_once_with(True)
        children[15].set_sensitive.assert_called_once_with(True)
        gui.open_mounted_folder_item.set_visible.assert_called_once_with(False)

    def test_gui_change_passphrase_is_limited_to_detached_luks_session(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        children = [MagicMock() for _index in range(17)]
        gui.context_menu = MagicMock()
        gui.context_menu.get_children.return_value = children
        gui.mount_item = children[10]
        gui.change_passphrase_item = children[11]
        gui.open_mounted_folder_item = children[13]
        gui.reclaim_item = children[16]
        gui.sessions_writable = True
        gui.selected_session_id = '2'
        gui._session_mounts = {}
        gui._sessions_by_id = {'2': {
            'mode': 'dynblk', 'encryption': 'luks',
            'is_running': False, 'is_default': False}}
        gui._prompt_luks_change_passphrase = MagicMock(
            return_value='old\nnew\nnew\n')
        gui._start_cli_task = MagicMock()
        gui._show_loading = MagicMock()
        row = SimpleNamespace(
            session_id='2', mode='dynblk', configuration_supported=True,
            is_active=False, is_running=False)

        gui._prepare_context_menu(row)
        gui.change_passphrase_item.set_visible.assert_called_with(True)
        gui.change_passphrase_item.set_sensitive.assert_called_with(True)
        gui._on_context_change_passphrase(None)
        assert gui._start_cli_task.call_args[0][0] == [
            'change-passphrase', '2', '--json', '--password-stdin']
        assert gui._start_cli_task.call_args[0][2] == 'old\nnew\nnew\n'

        gui._start_cli_task.reset_mock()
        gui._session_mounts['2'] = {'ready': True}
        gui._prepare_context_menu(row)
        gui.change_passphrase_item.set_sensitive.assert_called_with(False)
        gui._on_context_change_passphrase(None)
        gui._start_cli_task.assert_not_called()

    def test_gui_change_passphrase_reports_backend_failure(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._show_loading = MagicMock()
        gui._show_error = MagicMock()
        gui._show_info = MagicMock()
        gui._on_change_passphrase_complete(
            False, '{"success":false,"message":"incorrect old key"}', '')
        gui._show_error.assert_called_once_with('incorrect old key')
        gui._show_info.assert_not_called()

    def test_gui_change_passphrase_dialog_confirms_new_key(self):
        import minios_session_manager as module

        gui = object.__new__(module.SessionManagerGUI)
        gui.window = MagicMock()
        gui._show_error = MagicMock()
        dialog = MagicMock()
        dialog.run.return_value = module.Gtk.ResponseType.OK
        entries = [MagicMock(), MagicMock(), MagicMock()]
        for entry, secret in zip(entries, ('old', 'new', 'new')):
            entry.get_text.return_value = secret

        with patch('minios_session_manager.Gtk.Dialog', return_value=dialog), \
                patch('minios_session_manager.Gtk.Entry', side_effect=entries), \
                patch('minios_session_manager.Gtk.Label'), \
                patch('minios_session_manager._style_dialog_affirmative'):
            assert gui._prompt_luks_change_passphrase() == 'old\nnew\nnew\n'
        for entry in entries:
            entry.set_visibility.assert_called_once_with(False)
        gui._show_error.assert_not_called()

        entries[2].get_text.return_value = 'different'
        with patch('minios_session_manager.Gtk.Dialog', return_value=dialog), \
                patch('minios_session_manager.Gtk.Entry', side_effect=entries), \
                patch('minios_session_manager.Gtk.Label'), \
                patch('minios_session_manager._style_dialog_affirmative'):
            assert gui._prompt_luks_change_passphrase() is None
        gui._show_error.assert_called_once()

    @pytest.mark.parametrize('mode', ('dynfilefs', 'dynblk', 'vmdk', 'raw'))
    def test_gui_mount_action_starts_supported_detached_session(self, mode):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui.selected_session_id = '2'
        gui._session_mounts = {}
        gui._sessions_by_id = {'2': {
            'mode': mode, 'encryption': 'none', 'is_default': False,
            'is_running': False,
        }}
        gui._start_session_mount = MagicMock()

        gui._on_context_mount(None)

        gui._start_session_mount.assert_called_once_with(
            '2', ['mount', '2', '--json', '--persistent'], None)

    def test_gui_unmount_action_closes_existing_mount_lifetime(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui.selected_session_id = '2'
        gui._session_mounts = {'2': {'process': MagicMock()}}
        gui._stop_session_mount = MagicMock()

        gui._on_context_mount(None)

        gui._stop_session_mount.assert_called_once_with('2')

    def test_gui_mount_badge_uses_shared_accent_style(self):
        import minios_session_manager as module

        gui = object.__new__(module.SessionManagerGUI)
        row = SimpleNamespace(
            status_box=MagicMock(), mount_badge=None, is_mounted=False)
        badge = MagicMock()

        with patch('minios_session_manager.Gtk.Label', return_value=badge):
            gui._set_session_row_mounted(row, True)

        badge.get_style_context.return_value.add_class.assert_has_calls([
            call('badge'), call('badge-accent')])
        assert 'MOUNTED' in badge.set_markup.call_args[0][0]
        row.status_box.pack_start.assert_called_once_with(
            badge, False, False, 0)
        badge.show.assert_called_once_with()
        assert row.mount_badge is badge
        assert row.is_mounted is True

        gui._set_session_row_mounted(row, False)

        row.status_box.remove.assert_called_once_with(badge)
        assert row.mount_badge is None
        assert row.is_mounted is False

    def test_gui_mount_lifecycle_updates_visible_badge(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        process = MagicMock()
        gui._session_mounts = {'2': {
            'process': process, 'generation': 3, 'mount_point': None,
            'stopping': False, 'ready': False, 'message': None,
        }}
        gui._closing = False
        gui._update_session_mount_badge = MagicMock()
        gui._show_loading = MagicMock()
        gui.refresh_session_list = MagicMock()
        gui._show_error = MagicMock()

        with patch('minios_session_manager.subprocess.Popen'):
            gui._on_session_mount_ready('2', 3, '/mnt/session')
        gui._update_session_mount_badge.assert_called_once_with('2', True)

        gui._update_session_mount_badge.reset_mock()
        gui._on_session_mount_exited('2', 3, 0, '')
        gui._update_session_mount_badge.assert_called_once_with('2', False)

    def test_gui_normal_unmount_does_not_report_unexpected_disconnect(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        state = {'generation': 3, 'ready': True, 'stopping': False}
        gui._session_mounts = {'2': state}
        gui._closing = False
        gui._show_loading = MagicMock()
        gui._show_error = MagicMock()
        gui._update_session_mount_badge = MagicMock()
        gui.refresh_session_list = MagicMock()
        gui._start_cli_task = MagicMock()

        gui._stop_session_mount('2')
        assert state['stopping'] is True
        args, _kwargs = gui._start_cli_task.call_args
        assert args[0] == ['mount-control', '2', 'unmount', '--json']
        args[1](True, '{"success":true}', '')
        assert state['stopping'] is True

        gui._on_session_mount_exited('2', 3, 0, '')
        gui._show_error.assert_not_called()
        assert '2' not in gui._session_mounts

    @pytest.mark.parametrize('owner_exits_first', (False, True))
    def test_gui_failed_unmount_shows_one_error(self, owner_exits_first):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        state = {'generation': 3, 'ready': True, 'stopping': False}
        gui._session_mounts = {'2': state}
        gui._closing = False
        gui._show_loading = MagicMock()
        gui._show_error = MagicMock()
        gui._update_session_mount_badge = MagicMock()
        gui.refresh_session_list = MagicMock()
        gui._start_cli_task = MagicMock()
        gui._cli_error_text = lambda _output: 'DynBlk device was left attached'

        gui._stop_session_mount('2')
        finished = gui._start_cli_task.call_args[0][1]
        if owner_exits_first:
            gui._on_session_mount_exited('2', 3, 1, 'DynBlk cleanup failed')
        finished(False, '{"success":false}', '')
        if not owner_exits_first:
            gui._on_session_mount_exited('2', 3, 1, 'DynBlk cleanup failed')

        gui._show_error.assert_called_once()
        assert state['unmount_error_reported'] is True

    def test_gui_failed_unmount_retry_can_report_a_new_error(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        state = {'stopping': False}
        gui._session_mounts = {'2': state}
        gui._show_loading = MagicMock()
        gui._show_error = MagicMock()
        gui.refresh_session_list = MagicMock()
        gui._start_cli_task = MagicMock()
        gui._cli_error_text = lambda _output: 'Cannot contact mount owner'

        for attempt in range(2):
            gui._stop_session_mount('2')
            gui._start_cli_task.call_args[0][1](False, '', 'connection failed')
            assert state['stopping'] is False
            assert gui._show_error.call_count == attempt + 1

    def test_gui_requests_reclaim_through_mounted_session_process(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        process = MagicMock()
        gui._session_mounts = {'2': {
            'process': process, 'generation': 3, 'mount_point': '/mnt/session',
            'stopping': False, 'ready': True, 'message': None,
            'reclaiming': False, 'reclaim_request_id': None,
        }}
        gui._mount_request_generation = 0
        gui._show_loading = MagicMock()
        gui._start_cli_task = MagicMock()

        gui._request_mounted_reclaim('2', True)

        assert gui._start_cli_task.call_args[0][0] == [
            'mount-control', '2', 'reclaim', '--json', '--compact']
        process.stdin.write.assert_not_called()
        assert gui._session_mounts['2']['reclaiming'] is True
        gui._show_loading.assert_called_once_with(
            True, 'Reclaiming mounted session space...')

    def test_gui_footer_remains_available_while_session_is_mounted(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._loading_visible = False
        gui._session_mounts = {'2': {'ready': True}}
        gui.sessions_writable = True
        gui._filesystem_info = {'filesystem': {'type': 'ext4'}}
        gui.create_btn = MagicMock()
        gui.import_btn = MagicMock()
        gui.cleanup_btn = MagicMock()

        gui._update_footer_sensitivity()

        gui.create_btn.set_sensitive.assert_called_once_with(True)
        gui.import_btn.set_sensitive.assert_called_once_with(True)
        gui.cleanup_btn.set_sensitive.assert_called_once_with(True)

    def test_loading_overlay_can_be_shown_again_after_initial_hide(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui.loading_box = MagicMock()
        gui.loading_box.get_style_context.return_value = MagicMock()
        gui.loading_spinner = MagicMock()
        gui.loading_label = MagicMock()

        gui._show_loading(False)
        gui._show_loading(True, 'Working')

        calls = gui.loading_box.set_visible.call_args_list
        assert calls[0][0] == (False,)
        assert calls[1][0] == (True,)
        gui.loading_box.set_state.assert_any_call('idle')
        gui.loading_box.set_state.assert_any_call('running')
        gui.loading_label.set_text.assert_any_call('Working')

    def test_gui_decodes_structured_cli_errors(self):
        from minios_session_manager import SessionManagerGUI

        error = json.dumps({
            'success': False,
            'error': 'Не удалось найти каталог сессий.',
            'details': 'Сохранение сессий не включено.',
        })
        message = SessionManagerGUI._cli_error_text(error)

        assert message == (
            'Не удалось найти каталог сессий.\n\n'
            'Сохранение сессий не включено.')
        assert '\\u' not in message

    def test_gui_creation_failure_uses_structured_stdout_message(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._show_loading = MagicMock()
        gui._show_error = MagicMock()
        output = json.dumps({
            'success': False,
            'message': 'Failed to create dynblk session: path rejected',
        })

        gui._on_session_creation_complete(False, output, '', None)

        gui._show_loading.assert_called_once_with(False)
        gui._show_error.assert_called_once_with(
            'Failed to create session: '
            'Failed to create dynblk session: path rejected')

    def test_gui_creation_failure_without_detail_has_no_empty_colon(self):
        from minios_session_manager import SessionManagerGUI

        gui = object.__new__(SessionManagerGUI)
        gui._show_loading = MagicMock()
        gui._show_error = MagicMock()

        gui._on_session_creation_complete(False, '', '', None)

        gui._show_error.assert_called_once_with('Failed to create session')

    @pytest.mark.parametrize('document', [
        '{"success":false,"success":true}',
        '{"value":NaN}',
        '{"value":Infinity}',
    ])
    def test_gui_strict_json_rejects_ambiguous_documents(self, document):
        import minios_session_manager as module

        with pytest.raises(ValueError):
            module._strict_json_loads(document)

    def test_session_id_cannot_escape_custom_sessions_dir(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        for session_id in ('../outside', '/tmp/outside', '1/../2', ''):
            with pytest.raises(ValueError):
                sm._session_path(session_id)

    def test_reservation_creates_distinct_session_directories(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        first_id, first_path = sm._reserve_session()
        second_id, second_path = sm._reserve_session()

        assert (first_id, second_id) == ('1', '2')
        assert os.path.isdir(first_path)
        assert os.path.isdir(second_path)

    def test_free_space_check_fails_closed(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        with patch('os.statvfs', side_effect=OSError('unavailable')):
            has_space, error = sm._check_free_space(temp_sessions_dir, 100)

        assert has_space is False
        assert 'unavailable' in error

    def test_readonly_filesystem_has_no_mutable_modes(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        assert sm._get_compatible_session_modes({
            'is_readonly': True, 'is_posix_compatible': True, 'type': 'ext4'
        }) == []

    def test_squashfs_mode_requires_exact_staging_filesystem(self,
                                                              temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        ext4_modes = sm._get_compatible_session_modes({
            'is_readonly': False, 'is_posix_compatible': True, 'type': 'ext4'
        })
        vfat_modes = sm._get_compatible_session_modes({
            'is_readonly': False, 'is_posix_compatible': False, 'type': 'vfat'
        })
        assert 'squashfs' in ext4_modes
        assert 'squashfs' not in vfat_modes


    def test_fat32_container_limit_matches_perchsize_policy(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        assert sm._get_filesystem_limitations({'type': 'vfat'})['max_file_size'] == 4000

    def test_metadata_write_uses_atomic_replace(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.sessions_file = os.path.join(temp_sessions_dir, 'session.json')
        sm.session_format = 'json'
        with patch('os.replace', wraps=os.replace) as replace:
            assert sm._write_sessions_metadata({'default': None, 'sessions': {}})

        assert replace.call_count == 2
        replaced_targets = [call[0][1] for call in replace.call_args_list]
        assert sm.sessions_file in replaced_targets
        assert os.path.exists(os.path.join(temp_sessions_dir, 'session.conf'))
        with open(sm.sessions_file, encoding='utf-8') as metadata_file:
            assert json.load(metadata_file) == {'default': None, 'sessions': {}}

    def test_metadata_directory_sync_failure_is_commit_uncertain(self,
                                                                  temp_sessions_dir):
        from minios_session import MetadataCommitUncertain, SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        path = os.path.join(temp_sessions_dir, 'session.conf')
        real_fsync = os.fsync

        def fsync(descriptor):
            if stat.S_ISDIR(os.fstat(descriptor).st_mode):
                raise OSError(errno.EIO, 'injected directory sync failure')
            return real_fsync(descriptor)

        with patch('os.fsync', side_effect=fsync), \
             pytest.raises(MetadataCommitUncertain):
            sm._atomic_write_metadata_file(
                path, 'conf', {'default': None, 'sessions': {}})

        assert os.path.exists(path)

    def test_conf_primary_keeps_json_in_sync(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.sessions_file = os.path.join(temp_sessions_dir, 'session.conf')
        sm.session_format = 'conf'
        with patch('os.replace', wraps=os.replace) as replace:
            assert sm._write_sessions_metadata({'default': None, 'sessions': {}})

        assert replace.call_count == 2
        with open(os.path.join(temp_sessions_dir, 'session.conf'),
                  encoding='utf-8') as metadata_file:
            assert 'default=' in metadata_file.read()
        with open(os.path.join(temp_sessions_dir, 'session.json'),
                  encoding='utf-8') as metadata_file:
            assert json.load(metadata_file) == {'default': None, 'sessions': {}}

    def test_new_store_writes_equivalent_formats(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        assert sm._write_sessions_metadata(
            {'default': '1', 'sessions': {'1': {'mode': 'dynfilefs'}}})
        assert sm.sessions_file == os.path.join(temp_sessions_dir, 'session.json')
        assert sm.session_format == 'json'

        json_path = os.path.join(temp_sessions_dir, 'session.json')
        conf_path = os.path.join(temp_sessions_dir, 'session.conf')
        assert os.path.exists(conf_path)
        assert os.path.exists(json_path)
        with open(conf_path, encoding='utf-8') as mirror:
            content = mirror.read()
        assert 'default=1' in content
        assert 'session_mode[1]=dynfilefs' in content
        with open(json_path, encoding='utf-8') as metadata_file:
            assert json.load(metadata_file)['sessions']['1']['mode'] == 'dynfilefs'

    def test_detection_prefers_json_when_both_formats_exist(self, temp_sessions_dir):
        from minios_session import SessionManager

        with open(os.path.join(temp_sessions_dir, 'session.json'), 'w') as f:
            json.dump({'default': '9', 'sessions': {}}, f)
        with open(os.path.join(temp_sessions_dir, 'session.conf'), 'w') as f:
            f.write('default=1\nsession_mode[1]=native\n')

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        assert sm.sessions_file == os.path.join(temp_sessions_dir, 'session.json')
        assert sm.session_format == 'json'
        assert sm._write_sessions_metadata({'default': '2', 'sessions': {}})
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            assert json.load(metadata_file)['default'] == '2'
        with open(os.path.join(temp_sessions_dir, 'session.conf')) as metadata_file:
            assert metadata_file.readline().strip() == 'default=2'

    def test_malformed_selected_json_blocks_metadata_mutation(self, temp_sessions_dir):
        from minios_session import SessionManager

        json_path = os.path.join(temp_sessions_dir, 'session.json')
        conf_path = os.path.join(temp_sessions_dir, 'session.conf')
        with open(json_path, 'w') as metadata_file:
            metadata_file.write('{invalid')
        with open(conf_path, 'w') as metadata_file:
            metadata_file.write('default=1\nsession_mode[1]=native\n')

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        assert sm.metadata_valid is False
        assert not sm._write_sessions_metadata({'default': '2', 'sessions': {}})
        with open(conf_path) as metadata_file:
            assert metadata_file.readline().strip() == 'default=1'

    def test_malformed_selected_conf_blocks_metadata_mutation(self, temp_sessions_dir):
        from minios_session import SessionManager

        conf_path = os.path.join(temp_sessions_dir, 'session.conf')
        with open(conf_path, 'w') as metadata_file:
            metadata_file.write('default=1\nsession_mode[1]garbage=raw\n')

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        assert sm._read_sessions_metadata() == {'default': None, 'sessions': {}}
        assert sm.metadata_valid is False
        assert not sm._write_sessions_metadata({
            'default': '1', 'sessions': {'1': {'mode': 'native'}}})
        with open(conf_path) as metadata_file:
            assert 'session_mode[1]garbage=raw' in metadata_file.read()

    def test_metadata_rejects_conf_value_injection(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        metadata = {
            'default': '1',
            'sessions': {'1': {'version': '5.0\nsession_mode[1]=raw'}},
        }

        assert not sm._write_sessions_metadata(metadata)
        assert not os.path.exists(os.path.join(temp_sessions_dir, 'session.conf'))
        assert not os.path.exists(os.path.join(temp_sessions_dir, 'session.json'))

    def test_json_publication_failure_leaves_current_conf(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        json_path = os.path.join(temp_sessions_dir, 'session.json')
        conf_path = os.path.join(temp_sessions_dir, 'session.conf')
        real_replace = os.replace

        def replace(src, dst):
            if dst == json_path:
                raise OSError('json publication failed')
            return real_replace(src, dst)

        with patch('os.replace', side_effect=replace):
            assert sm._write_sessions_metadata({
                'default': '1', 'sessions': {'1': {'mode': 'native'}}})

        assert sm.sessions_file == conf_path
        assert sm.session_format == 'conf'
        assert not os.path.exists(json_path)
        with open(conf_path) as metadata_file:
            assert 'session_mode[1]=native' in metadata_file.read()

    def test_json_only_store_survives_conf_fallback_failure(self, temp_sessions_dir):
        from minios_session import SessionManager

        json_path = os.path.join(temp_sessions_dir, 'session.json')
        original = {'default': '1', 'sessions': {'1': {'mode': 'native'}}}
        with open(json_path, 'w') as metadata_file:
            json.dump(original, metadata_file)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)

        with patch.object(sm, '_atomic_write_metadata_file',
                          side_effect=OSError('conf publication failed')):
            assert not sm._write_sessions_metadata({
                'default': '2', 'sessions': {'2': {'mode': 'raw'}}})

        with open(json_path) as metadata_file:
            assert json.load(metadata_file) == original

    def test_existing_manager_falls_back_when_json_disappears(self, temp_sessions_dir):
        from minios_session import SessionManager

        writer = SessionManager(custom_sessions_dir=temp_sessions_dir)
        assert writer._write_sessions_metadata({
            'default': '1', 'sessions': {'1': {'mode': 'native'}}})
        existing = SessionManager(custom_sessions_dir=temp_sessions_dir)
        json_path = os.path.join(temp_sessions_dir, 'session.json')
        real_replace = os.replace

        def replace(src, dst):
            if dst == json_path:
                raise OSError('json publication failed')
            return real_replace(src, dst)

        with patch('os.replace', side_effect=replace):
            assert writer._write_sessions_metadata({
                'default': '2',
                'sessions': {
                    '1': {'mode': 'native'},
                    '2': {'mode': 'raw'},
                },
            })

        metadata = existing._read_sessions_metadata()
        assert metadata['default'] == '2'
        assert set(metadata['sessions']) == {'1', '2'}
        assert existing.session_format == 'conf'

    def test_dynfilefs_admission_uses_thin_floor(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.check_sessions_directory_status = lambda: {'writable': True}
        sm._validate_target_mode = lambda mode, size=None: (True, None)
        sm._check_dynfilefs_available = lambda: True

        captured = []

        def fake_check(path, required_mb):
            captured.append(required_mb)
            return False, "stop"

        sm._check_free_space = fake_check

        sm.create_session(session_mode='dynfilefs', size_mb=4000)
        sm.create_session(session_mode='dynblk', size_mb=sm.DYNBLK_DEFAULT_SIZE_MB)
        sm.create_session(session_mode='raw', size_mb=4000)

        # Thin backends admit on small floors; raw requires the full size.
        assert captured == [sm.DYNFILEFS_INITIAL_MB, sm.DYNBLK_INITIAL_MB, 4000]

    def test_cleanup_rejects_nonpositive_days(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        removed, errors = sm.cleanup_old_sessions(0)
        assert removed == 0
        assert len(errors) == 1

    def test_native_copy_preserves_whiteouts(self, temp_sessions_dir):
        from minios_session import SessionManager

        source = os.path.join(temp_sessions_dir, '1')
        target = os.path.join(temp_sessions_dir, '2')
        os.mkdir(source)
        os.mkdir(target)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        with patch('subprocess.run', return_value=MagicMock(returncode=0)) as run:
            assert sm._copy_session_direct(source, target, 'native')

        command = run.call_args[0][0]
        assert '--exclude=.wh.*' not in command

    def test_native_copy_rejects_partial_rsync(self, temp_sessions_dir):
        from minios_session import SessionManager

        source = os.path.join(temp_sessions_dir, '1')
        target = os.path.join(temp_sessions_dir, '2')
        os.mkdir(source)
        os.mkdir(target)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        partial = MagicMock(returncode=23, stderr=b'partial transfer')
        with patch('subprocess.run', return_value=partial):
            assert sm._copy_session_direct(source, target, 'native') is False

    def test_conversion_rejects_partial_rsync(self, temp_sessions_dir):
        from minios_session import SessionManager

        source = os.path.join(temp_sessions_dir, '1')
        target = os.path.join(temp_sessions_dir, '2')
        os.mkdir(source)
        os.mkdir(target)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        source_mount = MagicMock()
        source_mount.__enter__.return_value = source
        target_mount = MagicMock()
        target_mount.__enter__.return_value = target
        partial = MagicMock(returncode=24, stderr=b'vanished source file')
        with patch.object(sm, '_mount_session_read', return_value=source_mount), \
                patch.object(sm, '_mount_session_write', return_value=target_mount), \
                patch('subprocess.run', return_value=partial):
            assert sm._copy_session_with_conversion(
                source, target, 'native', 'raw', 100) is False

    def test_convert_new_session_delegates_to_copy_without_replacing_source(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        with patch.object(sm, 'copy_session', return_value=(True, 'copied')) as copy:
            assert sm.convert_session('1', 'raw', size_mb=100, in_place=False) == (True, 'copied')

        copy.assert_called_once_with(
            '1', to_mode='raw', size_mb=100, source_password=None,
            target_password=None, to_encryption='none')

    def test_mutation_lock_uses_directory_inode(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        with sm._mutation_lock():
            other = os.open(temp_sessions_dir, os.O_RDONLY | os.O_DIRECTORY)
            try:
                with pytest.raises(BlockingIOError):
                    fcntl.flock(other, fcntl.LOCK_EX | fcntl.LOCK_NB)
            finally:
                os.close(other)
        assert not os.path.exists(os.path.join(temp_sessions_dir, '.session.lock'))

    def test_mutation_lock_rejects_replaced_directory_symlink(self, tmp_path):
        from minios_session import SessionManager

        sessions = tmp_path / 'sessions'
        sessions.mkdir()
        sm = SessionManager(custom_sessions_dir=str(sessions))
        real = tmp_path / 'real-sessions'
        sessions.rename(real)
        sessions.symlink_to(real, target_is_directory=True)
        with pytest.raises(OSError):
            with sm._mutation_lock():
                pass

    def test_archive_validation_rejects_path_escape_and_special_members(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        unsafe_path = MagicMock(returncode=0, stdout=b'-rw-r--r-- 0/0 1 2026-01-01 00:00 ../outside\n')
        special_file = MagicMock(returncode=0, stdout=b'crw-r--r-- 0/0 0 2026-01-01 00:00 data/device\n')
        with patch('subprocess.run', return_value=unsafe_path):
            assert sm._validate_archive('session.tar.zst')[0] is False
        with patch('subprocess.run', return_value=special_file):
            assert sm._validate_archive('session.tar.zst')[0] is False

    def test_archive_validation_has_independent_extraction_limit(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        listing = ('-rw-r--r-- 0/0 {} 2026-01-01 00:00 data/large\n'.format(
            sm.MAX_ARCHIVE_EXTRACTED_BYTES + 1)).encode()
        with patch('subprocess.run', return_value=MagicMock(returncode=0, stdout=listing)):
            assert sm._validate_archive('session.tar.zst')[0] is False

    def test_archive_validation_accepts_data_members_only(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        listing = b''.join((
            b'-rw-r--r-- 0/0 2 2026-01-01 00:00 metadata.json\n',
            b'-rw-r--r-- 0/0 2 2026-01-01 00:00 session.info\n',
            b'drwxr-xr-x 0/0 0 2026-01-01 00:00 data/\n',
            b'-rw-r--r-- 0/0 1 2026-01-01 00:00 data/file\n',
        ))
        with patch('subprocess.run', return_value=MagicMock(returncode=0, stdout=listing)):
            assert sm._validate_archive('session.tar.zst') == (True, None)


class TestSquashfsGating:
    @staticmethod
    def _manager(temp_sessions_dir):
        from minios_session import SessionManager

        session_path = os.path.join(temp_sessions_dir, '1')
        os.mkdir(session_path)
        payload = b'hsqs-snapshot'
        with open(os.path.join(session_path, 'changes.sb'), 'wb') as artifact:
            artifact.write(payload)
        with open(os.path.join(temp_sessions_dir, 'session.json'), 'w') as metadata_file:
            json.dump({
                'default': '2',
                'sessions': {
                    '1': {'mode': 'squashfs', 'version': '5.0',
                          'edition': 'standard', 'union': 'overlayfs',
                          'policy': 'manual',
                          'digest': hashlib.sha256(payload).hexdigest(),
                          'compressed': len(payload), 'uncompressed': 0,
                          'entries': 0},
                    '2': {'mode': 'native', 'version': '5.0',
                          'edition': 'standard', 'union': 'overlayfs'},
                },
            }, metadata_file)
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._get_current_union_fs = lambda: 'overlayfs'
        return manager

    def test_activation_accepts_legacy_squashfs_without_policy_as_manual(self,
                                                                       temp_sessions_dir):
        sm = self._manager(temp_sessions_dir)
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            metadata = json.load(metadata_file)
        metadata['sessions']['1'].pop('policy', None)
        with open(os.path.join(temp_sessions_dir, 'session.json'), 'w') as metadata_file:
            json.dump(metadata, metadata_file)

        success, message = sm.activate_session('1')

        assert success is True and 'activated' in message
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            saved = json.load(metadata_file)
        assert saved['default'] == '1'
        assert 'policy' not in saved['sessions']['1']

    @pytest.mark.parametrize('policy', ('manual', 'shutdown'))
    def test_activation_accepts_supported_squashfs_policy(self, temp_sessions_dir, policy):
        sm = self._manager(temp_sessions_dir)
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            metadata = json.load(metadata_file)
        metadata['sessions']['1']['policy'] = policy
        with open(os.path.join(temp_sessions_dir, 'session.json'), 'w') as metadata_file:
            json.dump(metadata, metadata_file)

        success, message = sm.activate_session('1')

        assert success is True and 'activated' in message
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            assert json.load(metadata_file)['default'] == '1'

    def test_activation_rejects_changed_squashfs_without_changing_default(self,
                                                                          temp_sessions_dir):
        sm = self._manager(temp_sessions_dir)
        with open(os.path.join(temp_sessions_dir, '1', 'changes.sb'), 'ab') as artifact:
            artifact.write(b'changed')

        success, message = sm.activate_session('1')

        assert success is False and 'metadata' in message
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            assert json.load(metadata_file)['default'] == '2'

    def test_data_operations_reject_squashfs_before_reservation(self,
                                                                 temp_sessions_dir):
        sm = self._manager(temp_sessions_dir)
        output = os.path.join(temp_sessions_dir, 'export.tar.zst')

        with patch.object(sm, '_reserve_session',
                          side_effect=AssertionError('must not reserve')):
            copied, copy_message = sm.copy_session('1')
            converted, convert_message = sm.convert_session('1', 'native')
        exported, export_message = sm.export_session('1', output)

        assert copied is False and 'save support' in copy_message
        assert converted is False and 'save support' in convert_message
        assert exported is False and 'save support' in export_message
        assert not os.path.exists(output)

    def test_create_cleanup_removes_reservation_after_metadata_error(self,
                                                                      temp_sessions_dir):
        from minios_session import SessionManager

        with open(os.path.join(temp_sessions_dir, 'session.json'), 'w') as metadata_file:
            json.dump([], metadata_file)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.check_sessions_directory_status = lambda: {'writable': True}
        sm._validate_target_mode = lambda mode, size=None: (True, None)
        sm._check_free_space = lambda path, required_mb: (True, None)

        success, _message = sm.create_session('native')

        assert success is False
        assert not os.path.exists(os.path.join(temp_sessions_dir, '1'))


class TestSquashfsSave:
    @staticmethod
    def _footprint(uncompressed_size=2048, entry_count=12):
        regular_inodes = 1 if entry_count else 0
        return {
            'product_kind': 'minios-extraction-footprint',
            'schema_version': 1,
            'regular_file_bytes': uncompressed_size,
            'regular_file_inodes': regular_inodes,
            'directory_count': 1,
            'symlink_count': 0,
            'symlink_target_bytes': 0,
            'whiteout_count': 0,
            'inode_count': 1 + regular_inodes,
            'directory_entry_count': entry_count,
            'filename_bytes': entry_count * 6,
            'hardlink_reference_count': max(0, entry_count - regular_inodes),
            'xattr_count': 0,
            'xattr_name_bytes': 0,
            'xattr_value_bytes': 0,
            'compressor': 'zstd',
            'block_size': 1024 * 1024,
        }

    @staticmethod
    def _manager(temp_sessions_dir, running='1', previous=None):
        from minios_session import SessionManager

        session_path = os.path.join(temp_sessions_dir, '1')
        os.mkdir(session_path, 0o700)
        session = {
            'mode': 'squashfs', 'version': '5.0', 'edition': 'standard',
            'union': 'overlayfs', 'policy': 'shutdown',
        }
        if previous:
            session.update(previous)
        metadata = {'default': '1', 'sessions': {'1': session}}
        if running is not None:
            metadata['running'] = running
        with open(os.path.join(temp_sessions_dir, 'session.json'), 'w') as metadata_file:
            json.dump(metadata, metadata_file)
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._validate_squashfs_runtime = lambda _session_id: (True, None)
        return manager, session_path

    @staticmethod
    def _capture(payload=b'hsqs-new-snapshot', **overrides):
        def run(output_path, work_parent):
            assert os.path.dirname(output_path) == work_parent
            with open(output_path, 'wb') as output:
                output.write(payload)
            output_stat = os.stat(output_path)
            result = {
                'type': 'result',
                'product_kind': 'minios-tool-result',
                'schema_version': 1,
                'tool': 'savechanges',
                'operation': 'capture-module',
                'output': output_path,
                'output_identity': {
                    'device': output_stat.st_dev,
                    'inode': output_stat.st_ino,
                },
                'compressed_size': len(payload),
                'uncompressed_size': 2048,
                'entry_count': 12,
                'extraction_footprint': TestSquashfsSave._footprint(),
                'sha256': hashlib.sha256(payload).hexdigest(),
                'profile': 'exact',
                'union_backend': 'overlayfs',
            }
            result.update(overrides)
            return result
        return run

    def test_create_squashfs_captures_current_changes_and_publishes_metadata(
            self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.check_sessions_directory_status = lambda: {'writable': True}
        sm._validate_target_mode = lambda mode, size=None: (True, None)
        sm._check_free_space = lambda *_args: (_ for _ in ()).throw(
            AssertionError('fixed-size admission must not run for squashfs'))
        sm._get_current_union_fs = lambda: 'overlayfs'
        capture = self._capture()

        def locked_capture(output_path, work_parent):
            assert sm._lock_depth > 0
            return capture(output_path, work_parent)

        with patch.object(sm, '_run_savechanges', side_effect=locked_capture):
            success, message = sm.create_session('squashfs')

        assert success is True and 'squashfs' in message
        session_path = os.path.join(temp_sessions_dir, '1')
        with open(os.path.join(session_path, 'changes.sb'), 'rb') as artifact:
            assert artifact.read() == b'hsqs-new-snapshot'
        assert not any(name.startswith('.changes.sb.new-')
                       for name in os.listdir(session_path))
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            session = json.load(metadata_file)['sessions']['1']
        assert session['mode'] == 'squashfs'
        assert session['policy'] == 'shutdown'
        assert session['digest'] == hashlib.sha256(b'hsqs-new-snapshot').hexdigest()
        assert session['compressed'] == '17'
        assert session['uncompressed'] == '2048'
        assert session['entries'] == '12'
        assert session['generation'] == '1'
        assert session['union'] == 'overlayfs'

    def test_create_squashfs_accepts_manual_policy(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.check_sessions_directory_status = lambda: {'writable': True}
        sm._validate_target_mode = lambda mode, size=None: (True, None)
        sm._get_current_union_fs = lambda: 'overlayfs'
        with patch.object(sm, '_run_savechanges', side_effect=self._capture()):
            success, _message = sm.create_session('squashfs', policy='manual')

        assert success is True
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            session = json.load(metadata_file)['sessions']['1']
        assert session['policy'] == 'manual'

    def test_create_preserves_session_after_uncertain_metadata_commit(self,
                                                                      temp_sessions_dir):
        from minios_session import MetadataCommitUncertain, SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.check_sessions_directory_status = lambda: {'writable': True}
        sm._validate_target_mode = lambda mode, size=None: (True, None)
        sm._get_current_union_fs = lambda: 'overlayfs'

        def uncertain_commit(metadata):
            with open(os.path.join(temp_sessions_dir, 'session.json'), 'w') as metadata_file:
                json.dump(metadata, metadata_file)
            raise MetadataCommitUncertain('injected directory fsync failure')

        sm._write_sessions_metadata = uncertain_commit
        with patch.object(sm, '_run_savechanges', side_effect=self._capture()):
            success, message = sm.create_session('squashfs')

        assert success is False
        assert 'preserved' in message
        assert os.path.isfile(os.path.join(temp_sessions_dir, '1', 'changes.sb'))
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            assert '1' in json.load(metadata_file)['sessions']

    def test_create_squashfs_stores_periodic_save_interval(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.check_sessions_directory_status = lambda: {'writable': True}
        sm._validate_target_mode = lambda mode, size=None: (True, None)
        sm._get_current_union_fs = lambda: 'overlayfs'
        with patch.object(sm, '_run_savechanges', side_effect=self._capture()):
            success, _message = sm.create_session('squashfs', autosave=30)

        assert success is True
        with open(os.path.join(temp_sessions_dir, 'session.json')) as metadata_file:
            session = json.load(metadata_file)['sessions']['1']
        assert session['autosave'] == '30'

    def test_create_squashfs_rejects_too_frequent_periodic_save(self,
                                                                 temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        success, message = sm.create_session('squashfs', autosave=10)
        assert success is False
        assert 'interval' in message.lower()

    def test_runner_uses_fixed_exact_machine_contract(self, temp_sessions_dir):
        sm, session_path = self._manager(temp_sessions_dir)
        command = os.path.join(temp_sessions_dir, 'savechanges')
        with open(command, 'w') as executable:
            executable.write('#!/bin/sh\n')
        os.chmod(command, 0o700)
        sm.SAVECHANGES_COMMAND = command
        output_path = os.path.join(session_path, '.changes.sb.new-test')
        phases = [
            {'type': 'phase', 'phase': phase}
            for phase in sm.SAVECHANGES_PHASES
        ]
        result = {
            'type': 'result', 'product_kind': 'minios-tool-result',
            'schema_version': 1, 'tool': 'savechanges',
            'operation': 'capture-module', 'output': output_path,
            'output_identity': {'device': 1, 'inode': 2},
            'compressed_size': 4, 'uncompressed_size': 0,
            'entry_count': 0,
            'extraction_footprint': self._footprint(0, 0),
            'sha256': 'b' * 64,
            'profile': 'exact', 'union_backend': 'overlayfs',
        }
        stdout = ''.join(json.dumps(event) + '\n' for event in phases + [result])
        process = MagicMock(returncode=0)
        process.stdout = io.StringIO(stdout)

        seen_phases = []
        with patch('subprocess.Popen', return_value=process) as popen:
            assert sm._run_savechanges(
                output_path, session_path,
                progress_callback=seen_phases.append) == result

        assert seen_phases == list(sm.SAVECHANGES_PHASES)
        assert popen.call_args[0][0] == [
            command, '--json', '--profile', 'exact', '--work-parent',
            session_path, output_path,
        ]
        kwargs = popen.call_args[1]
        assert kwargs['start_new_session'] is True
        assert kwargs['universal_newlines'] is True
        assert 'PKEXEC_UID' not in kwargs['env']


    def test_save_fails_closed_without_runtime_authority(self, temp_sessions_dir):
        from minios_session import SessionManager

        session_path = os.path.join(temp_sessions_dir, '1')
        os.mkdir(session_path, 0o700)
        with open(os.path.join(temp_sessions_dir, 'session.json'), 'w') as metadata_file:
            json.dump({
                'default': '1', 'running': '1',
                'sessions': {'1': {'mode': 'squashfs'}},
            }, metadata_file)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)

        with patch.object(sm, '_run_savechanges',
                          side_effect=AssertionError('must not capture')):
            success, message, result = sm.save_session('1')

        assert success is False and 'custom sessions directory' in message
        assert result is None

    def test_runner_rejects_duplicate_and_nonfinite_json(self, temp_sessions_dir):
        sm, session_path = self._manager(temp_sessions_dir)
        command = os.path.join(temp_sessions_dir, 'savechanges')
        with open(command, 'w') as executable:
            executable.write('#!/bin/sh\n')
        os.chmod(command, 0o700)
        sm.SAVECHANGES_COMMAND = command
        output_path = os.path.join(session_path, '.changes.sb.new-test')
        valid_phases = ''.join(
            json.dumps({'type': 'phase', 'phase': phase}) + '\n'
            for phase in sm.SAVECHANGES_PHASES)

        for malformed in (
                '{"type":"result","type":"result"}\n',
                '{"type":"result","extra":NaN}\n'):
            process = MagicMock(returncode=0)
            process.stdout = io.StringIO(valid_phases + malformed)
            with patch('subprocess.Popen', return_value=process), \
                 pytest.raises(ValueError):
                sm._run_savechanges(output_path, session_path)

    def test_runner_rejects_malformed_extraction_footprint(self,
                                                            temp_sessions_dir):
        sm, session_path = self._manager(temp_sessions_dir)
        command = os.path.join(temp_sessions_dir, 'savechanges')
        with open(command, 'w') as executable:
            executable.write('#!/bin/sh\n')
        os.chmod(command, 0o700)
        sm.SAVECHANGES_COMMAND = command
        output_path = os.path.join(session_path, '.changes.sb.new-test')
        phases = [
            {'type': 'phase', 'phase': phase}
            for phase in sm.SAVECHANGES_PHASES
        ]
        base_result = {
            'type': 'result', 'product_kind': 'minios-tool-result',
            'schema_version': 1, 'tool': 'savechanges',
            'operation': 'capture-module', 'output': output_path,
            'output_identity': {'device': 1, 'inode': 2},
            'compressed_size': 4, 'uncompressed_size': 2048,
            'entry_count': 12, 'sha256': 'b' * 64,
            'profile': 'exact', 'union_backend': 'overlayfs',
        }
        missing_field = self._footprint()
        missing_field.pop('xattr_count')
        extra_field = self._footprint()
        extra_field['extra'] = 0
        wrong_product_kind = self._footprint()
        wrong_product_kind['product_kind'] = 'unknown'
        wrong_version = self._footprint()
        wrong_version['schema_version'] = 2
        wrong_version_type = self._footprint()
        wrong_version_type['schema_version'] = True
        wrong_value_type = self._footprint()
        wrong_value_type['symlink_count'] = False
        negative_value = self._footprint()
        negative_value['filename_bytes'] = -1
        empty_root = self._footprint()
        empty_root['directory_count'] = 0
        invalid_compressor = self._footprint()
        invalid_compressor['compressor'] = 'unknown'
        invalid_block_size = self._footprint()
        invalid_block_size['block_size'] = 0
        non_power_of_two_block = self._footprint()
        non_power_of_two_block['block_size'] = 10000
        wrong_uncompressed_size = self._footprint()
        wrong_uncompressed_size['regular_file_bytes'] += 1
        wrong_entry_count = self._footprint()
        wrong_entry_count['directory_entry_count'] += 1
        wrong_inode_count = self._footprint()
        wrong_inode_count['inode_count'] += 1
        malformed_footprints = (
            None, missing_field, extra_field, wrong_product_kind, wrong_version,
            wrong_version_type, wrong_value_type, negative_value, empty_root,
            invalid_compressor, invalid_block_size, non_power_of_two_block,
            wrong_uncompressed_size, wrong_entry_count, wrong_inode_count,
        )

        for footprint in malformed_footprints:
            result = dict(base_result, extraction_footprint=footprint)
            stdout = ''.join(
                json.dumps(event) + '\n' for event in phases + [result])
            process = MagicMock(returncode=0)
            process.stdout = io.StringIO(stdout)
            with patch('subprocess.Popen', return_value=process), \
                 pytest.raises(ValueError):
                sm._run_savechanges(output_path, session_path)




    def test_runtime_authority_accepts_matching_durable_boot_state(self,
                                                                    temp_sessions_dir):
        from minios_session import SessionManager

        state_path = os.path.join(temp_sessions_dir, 'boot-state')
        boot_id_path = os.path.join(temp_sessions_dir, 'boot-id')
        sessions_stat = os.stat(temp_sessions_dir)
        with open(state_path, 'w') as state_file:
            state_file.write(
                'boot_id=test-boot\nboot_level=ok\nmode=squashfs\nsession=1\n'
                'durable=1\nwritable=1\nsessions_device={}\nsessions_inode={}\n'
                'active_generation=current\ndynblk_device=none\n'
                'encryption=none\ncrypt_mapper=none\nloop_device=none\n'.format(
                    sessions_stat.st_dev, sessions_stat.st_ino))
        with open(boot_id_path, 'w') as boot_id_file:
            boot_id_file.write('test-boot\n')
        os.chmod(state_path, 0o600)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.custom_sessions_dir = None
        sm.BOOT_STATE_FILE = state_path
        sm.BOOT_ID_FILE = boot_id_path
        sm.SESSION_PATHS = (temp_sessions_dir,)
        filesystem = {
            'type': 'ext4', 'is_readonly': False, 'is_posix_compatible': True,
        }
        with patch.object(sm, '_detect_filesystem_type',
                          return_value=(filesystem, None)):
            assert sm._validate_squashfs_runtime('1') == (True, None)
        filesystem['type'] = 'vfat'
        filesystem['is_posix_compatible'] = False
        with patch.object(sm, '_detect_filesystem_type',
                          return_value=(filesystem, None)):
            valid, message = sm._validate_squashfs_runtime('1')
        assert valid is False
        assert 'cannot preserve exact capture metadata' in message



class TestLuksLayer:
    def test_change_passphrase_cli_reads_three_stdin_lines(self,
                                                         monkeypatch, capsys):
        import minios_session

        manager = MagicMock()
        manager.sessions_dir = '/sessions'
        manager.change_session_passphrase.return_value = (True, 'changed')
        monkeypatch.setattr(sys, 'stdin', SimpleNamespace(
            buffer=io.BytesIO(b'old-secret\nnew-secret\nnew-secret\n')))
        monkeypatch.setattr(sys, 'argv', [
            'minios-session', 'change-passphrase', '2',
            '--password-stdin', '--json'])
        with patch('minios_session.os.geteuid', return_value=0), \
                patch('minios_session.luks_runtime_available', return_value=True), \
                patch('minios_session.SessionManager', return_value=manager), \
                pytest.raises(SystemExit) as exit_info:
            minios_session.main()

        assert exit_info.value.code == 0
        assert json.loads(capsys.readouterr().out) == {
            'success': True, 'message': 'changed'}
        manager.change_session_passphrase.assert_called_once_with(
            '2', b'old-secret', b'new-secret')

    @pytest.mark.parametrize('mode', ('raw', 'dynfilefs', 'dynblk', 'vmdk'))
    def test_change_passphrase_uses_anonymous_fd_and_existing_backend(
            self, temp_sessions_dir, mode):
        from minios_session import SessionManager

        os.mkdir(os.path.join(temp_sessions_dir, '2'))
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._read_sessions_metadata = MagicMock(return_value={
            'sessions': {'2': {'mode': mode, 'encryption': 'luks'}}})
        manager._check_luks_available = MagicMock(return_value=(True, None))

        @contextlib.contextmanager
        def attached(session_path, backend):
            assert session_path == os.path.join(temp_sessions_dir, '2')
            assert backend == mode
            yield '/dev/dynblk7'

        manager._luks_rotation_device = MagicMock(side_effect=attached)

        def cryptsetup(args, **kwargs):
            assert args[0:2] == ['cryptsetup', 'luksChangeKey']
            assert b'old-secret\n' == kwargs['input']
            assert '--key-file' in args and '--new-keyfile-size' in args
            assert 'old-secret' not in ' '.join(args)
            assert 'new-secret' not in ' '.join(args)
            descriptor = kwargs['pass_fds'][0]
            assert args[-1] == (
                '/proc/self/fd/{}'.format(descriptor))
            assert os.read(descriptor, 4096) == b'new-secret\n'
            return MagicMock(returncode=0, stdout=b'', stderr=b'')

        with patch('minios_session.subprocess.run', side_effect=cryptsetup) as run:
            success, message = manager.change_session_passphrase(
                '2', b'old-secret', b'new-secret')
        assert success, message
        run.assert_called_once()
        manager._luks_rotation_device.assert_called_once()

    @pytest.mark.parametrize('status,encryption', [
        ('default', 'luks'), ('running', 'luks'), (None, 'none')])
    def test_change_passphrase_rejects_ineligible_session(
            self, temp_sessions_dir, status, encryption):
        from minios_session import SessionManager

        os.mkdir(os.path.join(temp_sessions_dir, '2'))
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        metadata = {'sessions': {'2': {'mode': 'raw', 'encryption': encryption}}}
        if status:
            metadata[status] = '2'
        manager._read_sessions_metadata = lambda: metadata
        manager._luks_rotation_device = MagicMock()
        success, _message = manager.change_session_passphrase(
            '2', b'old', b'new')
        assert not success
        manager._luks_rotation_device.assert_not_called()

    def test_change_passphrase_refuses_a_mounted_session(self, temp_sessions_dir):
        from minios_session import SessionManager

        os.mkdir(os.path.join(temp_sessions_dir, '2'))
        owner = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._luks_rotation_device = MagicMock()
        with owner._session_lease('2'):
            success, message = manager.change_session_passphrase(
                '2', b'old', b'new')
        assert not success and 'mounted or busy' in message
        manager._luks_rotation_device.assert_not_called()

    def test_change_passphrase_stdin_requires_matching_new_password(self,
                                                                  monkeypatch):
        from minios_session import luks_change_passwords_from_args

        monkeypatch.setattr(sys, 'stdin', SimpleNamespace(
            buffer=io.BytesIO(b'old\nnew\nnew\n')))
        assert luks_change_passwords_from_args(
            SimpleNamespace(password_stdin=True)) == (b'old', b'new')
        monkeypatch.setattr(sys, 'stdin', SimpleNamespace(
            buffer=io.BytesIO(b'old\nnew\ndifferent\n')))
        with pytest.raises(ValueError, match='do not match'):
            luks_change_passwords_from_args(SimpleNamespace(password_stdin=True))

    def test_perchsize_units_and_backend_neutral_integer_limit(self):
        from minios_session import parse_perch_size

        assert parse_perch_size('4000') == 4000
        assert parse_perch_size('4GB') == 4000
        assert parse_perch_size('1TB') == 1000000
        assert parse_perch_size('4TB') == 4000000
        with pytest.raises(Exception):
            parse_perch_size('100000000TB')

    def test_luks_capability_requires_versioned_initrd_marker(self, temp_sessions_dir,
                                                              monkeypatch):
        import minios_session
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        marker = os.path.join(temp_sessions_dir, 'crypt-marker')
        monkeypatch.setattr(minios_session, 'INITRD_CRYPTO_MARKER', marker)
        with patch('shutil.which', return_value='/usr/bin/tool'):
            open(marker, 'w').close()
            assert sm._check_luks_available()[0] is False
            with open(marker, 'w') as marker_file:
                marker_file.write('luks-layer-v1\n')
            assert sm._check_luks_available() == (True, None)

    def test_luks_is_an_encryption_not_a_storage_mode(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        filesystem = {'type': 'ext4', 'is_readonly': False, 'is_posix_compatible': True}
        assert 'luks' not in sm._get_compatible_session_modes(filesystem)

    def test_luks_support_is_backend_specific(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        with patch.object(sm, '_check_luks_available',
                          side_effect=lambda mode: (mode in ('raw', 'dynfilefs', 'dynblk'), None)):
            assert sm._get_compatible_encryptions('raw') == ['none', 'luks']
            assert sm._get_compatible_encryptions('native') == ['none']

    @pytest.mark.parametrize('mode', ('raw', 'dynfilefs', 'dynblk'))
    def test_encrypted_creation_preserves_backend_metadata(self, temp_sessions_dir,
                                                           mode):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.check_sessions_directory_status = lambda: {'writable': True}
        sm._validate_target_mode = lambda backend, size, encryption: (True, None)
        sm._check_free_space = lambda path, required: (True, None)
        sm._check_dynfilefs_available = lambda: True
        sm._get_current_union_fs = lambda: 'overlayfs'
        sm._create_dynfilefs_session = MagicMock(return_value=(True, 'created'))
        sm._create_dynblk_session = MagicMock(return_value=(True, 'created'))
        sm._format_luks_source = MagicMock()
        with patch('subprocess.run', return_value=MagicMock(
                returncode=1, stdout=b'', stderr=b'')):
            success, message = sm.create_session(
                mode, 64, password=b'secret', encryption='luks')

        assert success, message
        metadata = sm._read_sessions_metadata()['sessions']['1']
        assert metadata['mode'] == mode
        assert metadata['encryption'] == 'luks'
        if mode == 'raw':
            assert os.path.isfile(os.path.join(temp_sessions_dir, '1', 'changes.img'))
            sm._format_luks_source.assert_called_once()
        elif mode == 'dynfilefs':
            sm._create_dynfilefs_session.assert_called_once_with(
                os.path.join(temp_sessions_dir, '1'), 64,
                encryption='luks', password=b'secret')
        else:
            sm._create_dynblk_session.assert_called_once_with(
                os.path.join(temp_sessions_dir, '1'), 64,
                encryption='luks', password=b'secret', storage_format='dynblk')

    def test_unsupported_metadata_remains_listed_for_recovery(self,
                                                               temp_sessions_dir):
        from minios_session import SessionManager

        for session_id in ('1', '2'):
            os.mkdir(os.path.join(temp_sessions_dir, session_id))
        with open(os.path.join(temp_sessions_dir, 'session.json'), 'w') as metadata:
            json.dump({'sessions': {
                '1': {'mode': 'native', 'encryption': 'luks'},
                '2': {'mode': 'luks'},
            }}, metadata)

        sessions = SessionManager(
            custom_sessions_dir=temp_sessions_dir).list_sessions(
                include_running_check=False)
        assert [session['id'] for session in sessions] == ['1', '2']
        assert all(not session['configuration_supported'] for session in sessions)

    @pytest.mark.parametrize('operation', ('export', 'copy', 'convert'))
    def test_logical_operations_reject_unsupported_metadata(
            self, temp_sessions_dir, operation):
        from minios_session import SessionManager

        os.mkdir(os.path.join(temp_sessions_dir, '1'))
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm._get_session_info = lambda _session_id: {
            'id': '1', 'mode': 'native', 'encryption': 'luks',
            'configuration_supported': False,
        }

        if operation == 'export':
            success, message = sm.export_session('1', temp_sessions_dir)
        elif operation == 'copy':
            success, message = sm.copy_session('1')
        else:
            success, message = sm.convert_session('1', 'raw')

        assert not success
        assert 'unsupported persistence metadata' in message

    def test_logical_import_defaults_to_unencrypted_target(self,
                                                            temp_sessions_dir):
        from minios_session import SessionManager

        archive = os.path.join(temp_sessions_dir, 'encrypted.tar.zst')
        open(archive, 'wb').close()
        target = os.path.join(temp_sessions_dir, '1')
        os.mkdir(target)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm._validate_archive = lambda path: (True, None)
        sm._extract_metadata = lambda path: {'session': {
            'mode': 'raw', 'encryption': 'luks', 'version': '6.0',
            'edition': 'standard', 'union': 'overlayfs', 'size': 100,
        }}
        sm._check_import_compatibility = lambda metadata: {
            'compatible': True, 'issues': []}
        sm._validate_target_mode = lambda *args, **kwargs: (True, None)
        sm._check_free_space = lambda path, size: (True, None)
        sm._reserve_session = lambda acquire_lease=False: (
            '1', target, contextlib.ExitStack())
        mount_context = MagicMock()
        mount_context.__enter__.return_value = target
        mount_context.__exit__.return_value = False
        sm._mount_session_write = MagicMock(return_value=mount_context)
        sm._create_session_metadata = MagicMock(return_value=True)

        with patch('subprocess.run', return_value=MagicMock(
                returncode=0, stdout=b'', stderr=b'')):
            success, message = sm.import_session(archive, verify=False)

        assert success, message
        assert sm._mount_session_write.call_args[0][1] == 'raw'
        assert 'encryption' not in sm._mount_session_write.call_args[1]
        assert 'encryption' not in sm._create_session_metadata.call_args[1]

    def test_copy_is_logical_and_uses_independent_luks_passwords(self,
                                                                 temp_sessions_dir):
        from minios_session import SessionManager

        source_path = os.path.join(temp_sessions_dir, '1')
        os.mkdir(source_path)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm._get_session_info = lambda _session_id: {
            'mode': 'raw', 'encryption': 'luks', 'version': '6.0',
            'edition': 'standard', 'union': 'overlayfs', 'size': 64,
            'total_size_mb': 64,
        }
        sm._validate_target_mode = lambda mode, size, encryption: (True, None)
        sm.get_running_session = lambda: None
        sm._check_free_space = lambda path, size: (True, None)
        sm._copy_session_direct = MagicMock(
            side_effect=AssertionError('copy must not clone'))
        sm._copy_session_with_conversion = MagicMock(return_value=True)
        sm._read_sessions_metadata = lambda: {'sessions': {
            '1': {'mode': 'raw', 'encryption': 'luks'}}}
        published = []
        sm._write_sessions_metadata = lambda metadata: (
            published.append(metadata) or True)

        success, message = sm.copy_session(
            '1', source_password=b'source', target_password=b'target')

        assert success, message
        sm._copy_session_direct.assert_not_called()
        call = sm._copy_session_with_conversion.call_args
        assert call[1]['source_encryption'] == 'luks'
        assert call[1]['target_encryption'] == 'luks'
        assert call[1]['source_password'] == b'source'
        assert call[1]['target_password'] == b'target'
        target = published[-1]['sessions']['2']
        assert target['mode'] == 'raw'
        assert target['encryption'] == 'luks'

    def test_clone_physically_copies_backend_and_metadata(self,
                                                          temp_sessions_dir):
        from minios_session import SessionManager

        source_path = os.path.join(temp_sessions_dir, '1')
        os.mkdir(source_path)
        metadata = {'sessions': {'1': {
            'mode': 'raw', 'encryption': 'luks', 'size': '64',
            'version': '6.0', 'edition': 'standard', 'union': 'overlayfs'}}}
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm._get_session_info = lambda _session_id: dict(metadata['sessions']['1'])
        sm.get_running_session = lambda: None
        sm._copy_session_direct = MagicMock(return_value=True)
        sm._read_sessions_metadata = lambda: metadata
        published = []
        sm._write_sessions_metadata = lambda value: (
            published.append(value) or True)

        success, message = sm.clone_session('1')

        assert success, message
        sm._copy_session_direct.assert_called_once_with(
            source_path, os.path.join(temp_sessions_dir, '2'), 'raw')
        assert published[-1]['sessions']['2'] == metadata['sessions']['1']
        assert published[-1]['sessions']['2'] is not metadata['sessions']['1']

    def test_luks_creation_uses_loop_mapper_and_stdin_password(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        image = os.path.join(temp_sessions_dir, 'changes.img')
        loop = MagicMock(returncode=0, stdout=b'/dev/loop7\n', stderr=b'')
        ok = MagicMock(returncode=0, stdout=b'', stderr=b'')
        with patch('subprocess.run', side_effect=[loop, ok, ok, ok, ok, ok, ok]) as run:
            sm._format_luks_source(image, b'secret')

        commands = [call[0][0] for call in run.call_args_list]
        assert ['losetup', '--find', '--show', '--', image] in commands
        assert any(command[:3] == ['cryptsetup', 'luksFormat', '--type'] for command in commands)
        crypt_calls = [call for call in run.call_args_list if call[0][0][0] == 'cryptsetup']
        assert all(b'secret' not in call[0][0] for call in crypt_calls)
        assert all(call[1].get('input') == b'secret\n' for call in crypt_calls[:2])
        assert any(command[:2] == ['cryptsetup', 'close'] for command in commands)

    def test_encrypted_raw_target_observes_fat32_limit(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        with patch.object(sm, '_detect_filesystem_type', return_value=({'type': 'vfat', 'is_readonly': False,
                                                                         'is_posix_compatible': False}, None)), \
             patch.object(sm, '_check_luks_available', return_value=(True, None)):
            valid, message = sm._validate_target_mode('raw', 4096, 'luks')
        assert not valid
        assert 'FAT32' in message

    def test_luks_resize_recovers_durable_post_growth_metadata(self, temp_sessions_dir):
        from minios_session import SessionManager

        session_path = os.path.join(temp_sessions_dir, '1')
        os.mkdir(session_path)
        open(os.path.join(session_path, 'changes.img'), 'wb').close()
        journal_path = os.path.join(session_path, '.luks-resize.json')
        with open(journal_path, 'w') as journal:
            json.dump({'size': 6000}, journal)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        metadata = {'sessions': {'1': {
            'mode': 'raw', 'encryption': 'luks', 'size': 4000}}}
        with patch('os.path.getsize', return_value=6000 * 1024 * 1024), \
             patch.object(sm, '_write_sessions_metadata', return_value=True):
            success, message = sm._resize_luks_session(session_path, 7000, '1', metadata, b'password')

        assert success
        assert message
        assert metadata['sessions']['1']['size'] == 6000
        assert not os.path.exists(journal_path)


class TestSquashfsUserExperience:
    @staticmethod
    def _write_metadata(root, metadata):
        with open(os.path.join(root, 'session.json'), 'w') as handle:
            json.dump(metadata, handle)

    def test_list_uses_logical_size_and_saved_timestamp(self, temp_sessions_dir):
        from minios_session import SessionManager

        session_path = os.path.join(temp_sessions_dir, '1')
        os.mkdir(session_path)
        with open(os.path.join(session_path, 'changes.sb'), 'wb') as artifact:
            artifact.write(b'hsqs-small')
        self._write_metadata(temp_sessions_dir, {
            'default': '1',
            'sessions': {'1': {
                'mode': 'squashfs', 'version': '20260816',
                'edition': 'standard', 'union': 'overlayfs',
                'uncompressed': 9048675, 'compressed': 10,
                'saved': '2026-08-18T13:00:04Z',
            }},
        })
        session = SessionManager(custom_sessions_dir=temp_sessions_dir).list_sessions()[0]
        assert session['size'] == 9048675
        assert session['size_display'] == '8.6MB'
        assert session['modified'].isoformat() == '2026-08-18T13:00:04'

    def test_save_settings_are_independent(self, temp_sessions_dir):
        from minios_session import SessionManager

        session_path = os.path.join(temp_sessions_dir, '1')
        os.mkdir(session_path)
        self._write_metadata(temp_sessions_dir, {
            'default': '1', 'running': '1',
            'sessions': {'1': {'mode': 'squashfs', 'policy': 'shutdown'}},
        })
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        success, _message, settings = manager.set_squashfs_save_settings(
            '1', shutdown=False, autosave=30)
        assert success
        assert settings == {'shutdown': False, 'autosave': 30}
        with open(os.path.join(temp_sessions_dir, 'session.json')) as handle:
            session = json.load(handle)['sessions']['1']
        assert session['policy'] == 'manual'
        assert session['autosave'] == '30'

    def test_periodic_save_runs_only_when_due(self, temp_sessions_dir):
        from datetime import datetime
        from minios_session import SessionManager

        session_path = os.path.join(temp_sessions_dir, '1')
        os.mkdir(session_path)
        self._write_metadata(temp_sessions_dir, {
            'default': '1', 'running': '1',
            'sessions': {'1': {'mode': 'squashfs', 'autosave': 30,
                               'saved': '2026-08-18T11:00:00Z'}},
        })
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        original_open = open

        def open_with_uptime(path, *args, **kwargs):
            if path == '/proc/uptime':
                return io.StringIO('3600.0 0.0\n')
            return original_open(path, *args, **kwargs)

        with patch('builtins.open', side_effect=open_with_uptime), \
             patch.object(manager, 'save_session',
                          return_value=(True, 'saved', {'generation': 2})) as save:
            performed, success, _message, capture = manager.autosave_running_session(
                now=datetime(2026, 8, 18, 12, 0, 0))
        assert performed and success
        assert capture == {'generation': 2}
        save.assert_called_once_with('1')

        self._write_metadata(temp_sessions_dir, {
            'default': '1', 'running': '1',
            'sessions': {'1': {'mode': 'squashfs', 'autosave': 30,
                               'saved': '2026-08-18T11:45:00Z'}},
        })
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        with patch('builtins.open', side_effect=open_with_uptime), \
             patch.object(manager, 'save_session') as save:
            performed, success, _message, capture = manager.autosave_running_session(
                now=datetime(2026, 8, 18, 12, 0, 0))
        assert performed is False and success is True and capture is None
        save.assert_not_called()

    def test_running_squashfs_can_handoff_to_active_current_boot_snapshot(
            self, temp_sessions_dir):
        from minios_session import SessionManager

        for session_id in ('1', '2'):
            os.mkdir(os.path.join(temp_sessions_dir, session_id))
        self._write_metadata(temp_sessions_dir, {
            'default': '2', 'running': '1',
            'sessions': {
                '1': {'mode': 'squashfs', 'union': 'overlayfs'},
                '2': {'mode': 'squashfs', 'union': 'overlayfs',
                      'capture_boot_id': 'boot-1'},
            },
        })
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._current_boot_id = lambda: 'boot-1'
        manager._validate_squashfs_activation = lambda *_args: (True, None)
        manager._validate_squashfs_runtime = lambda *_args: (True, None)
        replaced = []
        manager._replace_boot_state_session = lambda old, new: replaced.append((old, new))

        success, message = manager.delete_session('1', handoff=True)
        assert success and message
        assert replaced == [('1', '2')]
        assert not os.path.exists(os.path.join(temp_sessions_dir, '1'))
        with open(os.path.join(temp_sessions_dir, 'session.json')) as handle:
            metadata = json.load(handle)
        assert metadata['default'] == '2'
        assert metadata['running'] == '2'
        assert '1' not in metadata['sessions']

    def test_running_squashfs_handoff_rejects_old_active_snapshot(
            self, temp_sessions_dir):
        from minios_session import SessionManager

        for session_id in ('1', '2'):
            os.mkdir(os.path.join(temp_sessions_dir, session_id))
        self._write_metadata(temp_sessions_dir, {
            'default': '2', 'running': '1',
            'sessions': {
                '1': {'mode': 'squashfs', 'union': 'overlayfs'},
                '2': {'mode': 'squashfs', 'union': 'overlayfs',
                      'capture_boot_id': 'older-boot'},
            },
        })
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager._current_boot_id = lambda: 'boot-1'
        manager._replace_boot_state_session = MagicMock()
        success, message = manager.delete_session('1', handoff=True)
        assert success is False
        assert 'during this boot' in message.lower()
        assert os.path.isdir(os.path.join(temp_sessions_dir, '1'))
        manager._replace_boot_state_session.assert_not_called()


class TestSquashfsSaveDelegation:
    @staticmethod
    def _manager(temp_sessions_dir, command):
        from minios_session import SessionManager
        manager = SessionManager(custom_sessions_dir=temp_sessions_dir)
        manager.custom_sessions_dir = None
        manager.SQUASHFS_SAVE_COMMAND = command
        os.mkdir(os.path.join(temp_sessions_dir, '1'))
        return manager

    @staticmethod
    def _command(temp_sessions_dir):
        command = os.path.join(temp_sessions_dir, 'minios-squashfs-save')
        with open(command, 'w') as executable:
            executable.write('#!/bin/sh\nexit 0\n')
        os.chmod(command, 0o700)
        return command

    def test_save_delegates_progress_to_tools_backend(self, temp_sessions_dir):
        command = self._command(temp_sessions_dir)
        manager = self._manager(temp_sessions_dir, command)
        output = ''.join(
            json.dumps({'phase': phase, 'type': 'phase'}) + '\n'
            for phase in manager.SAVECHANGES_PHASES)
        output += ('{"capture":{"generation":8},"message":'
                   '"Session 1 saved successfully","success":true}\n')
        process = MagicMock(returncode=0)
        process.stdout = io.StringIO(output)
        seen = []
        with patch('subprocess.Popen', return_value=process) as popen:
            success, message, capture = manager.save_session('1', progress_callback=seen.append)
        assert success is True
        assert message == 'Session 1 saved successfully'
        assert capture == {'generation': 8}
        assert seen == list(manager.SAVECHANGES_PHASES)
        assert popen.call_args[0][0] == [command, '1', '--json', '--progress']

    def test_shutdown_finalize_is_forwarded_to_tools_backend(self, temp_sessions_dir):
        command = self._command(temp_sessions_dir)
        manager = self._manager(temp_sessions_dir, command)
        process = MagicMock(returncode=0)
        process.stdout = io.StringIO(
            '{"capture":{"shutdown_finalized":true},"message":"saved","success":true}\n')
        with patch('subprocess.Popen', return_value=process) as popen:
            success, _message, capture = manager.save_session('1', finalize_shutdown=True)
        assert success is True
        assert capture['shutdown_finalized'] is True
        assert popen.call_args[0][0] == [
            command, '1', '--json', '--shutdown-finalize']

    def test_missing_tools_backend_fails_before_process_start(self, temp_sessions_dir):
        manager = self._manager(
            temp_sessions_dir, os.path.join(temp_sessions_dir, 'missing-backend'))
        with patch('subprocess.Popen', side_effect=AssertionError('must not run')):
            success, message, capture = manager.save_session('1')
        assert success is False
        assert 'backend is unavailable' in message
        assert capture is None

    @pytest.mark.parametrize('result', [
        '{"capture":{},"message":"saved","success":"false"}\n',
        '{"capture":{},"message":"saved","message":"again","success":true}\n',
        '{"capture":{},"message":"saved","success":NaN}\n',
        '[]\n',
    ])
    def test_delegated_save_rejects_malformed_results(self, temp_sessions_dir, result):
        command = self._command(temp_sessions_dir)
        manager = self._manager(temp_sessions_dir, command)
        process = MagicMock(returncode=0)
        process.stdout = io.StringIO(result)

        with patch('subprocess.Popen', return_value=process):
            success, _message, capture = manager.save_session('1')

        assert success is False
        assert capture is None


class TestDynBlkSessions:
    def test_compatible_modes_expose_dynblk_only_on_admitted_backing_fs(self):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        sm._check_dynblk_available = lambda: True
        sm._check_luks_available = lambda: (False, None)
        ext4 = {'type': 'ext4', 'is_readonly': False, 'is_posix_compatible': True}
        xfs = {'type': 'xfs', 'is_readonly': False, 'is_posix_compatible': True}
        assert 'dynblk' in sm._get_compatible_session_modes(ext4)
        assert 'dynblk' not in sm._get_compatible_session_modes(xfs)

    def test_dynblk_target_enforces_format_capacity(self):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        filesystem = {'type': 'ext4', 'is_readonly': False,
                      'is_posix_compatible': True}
        sm._detect_filesystem_type = lambda: (filesystem, None)
        sm._check_dynblk_available = lambda: True
        sm._check_luks_available = lambda: (False, None)
        with patch('minios_session.runtime_dynblk_max_size_mib', return_value=67108864):
            assert sm._validate_target_mode('dynblk', 4 * 1024 * 1024) == (True, None)
            valid, message = sm._validate_target_mode('dynblk', 67108865)
            assert valid is False
            assert '67108864 MiB' in message

    def test_dynblk_size_reports_parts_and_virtual_capacity(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        session = os.path.join(temp_sessions_dir, '1')
        os.mkdir(session)
        with open(os.path.join(session, 'volume000.db'), 'wb') as handle:
            handle.truncate(12288)
        with open(os.path.join(session, 'volume001.db'), 'wb') as handle:
            handle.truncate(4096)
        info = sm._get_session_size_info(session, {'mode': 'dynblk', 'size': 64})
        assert info['used_size'] == sum(os.stat(os.path.join(session, name)).st_blocks * 512
                                        for name in ('volume000.db', 'volume001.db'))
        assert info['total_size'] == 64 * 1024 * 1024

    def test_dynblk_direct_copy_preserves_all_parts(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        source = os.path.join(temp_sessions_dir, 'source')
        target = os.path.join(temp_sessions_dir, 'target')
        os.mkdir(source)
        os.mkdir(target)
        for index, content in ((0, b'header'), (3, b'payload'), (1000, b'high part')):
            with open(os.path.join(source, 'volume{:03d}.db'.format(index)), 'wb') as handle:
                handle.write(content)
        assert sm._copy_session_direct(source, target, 'dynblk') is True
        assert open(os.path.join(target, 'volume000.db'), 'rb').read() == b'header'
        assert open(os.path.join(target, 'volume003.db'), 'rb').read() == b'payload'
        assert open(os.path.join(target, 'volume1000.db'), 'rb').read() == b'high part'

    def test_dynblk_direct_copy_rejects_attached_source(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        source = os.path.join(temp_sessions_dir, 'source')
        target = os.path.join(temp_sessions_dir, 'target')
        os.mkdir(source)
        os.mkdir(target)
        volume = os.path.join(source, 'volume000.db')
        with open(volume, 'wb') as handle:
            handle.write(b'header')

        lock_fd = os.open(volume, os.O_RDONLY)
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            assert sm._copy_session_direct(source, target, 'dynblk') is False
            assert not os.path.exists(os.path.join(target, 'volume000.db'))
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            os.close(lock_fd)

    def test_dynblk_delete_rejects_attached_source(self, temp_sessions_dir):
        from minios_session import SessionManager

        session = os.path.join(temp_sessions_dir, '1')
        os.mkdir(session)
        volume = os.path.join(session, 'volume000.db')
        with open(volume, 'wb') as handle:
            handle.write(b'header')
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.get_current_session = lambda: None
        sm.get_running_session = lambda: None
        sm._read_sessions_metadata = lambda: {
            'sessions': {'1': {'mode': 'dynblk'}}}

        lock_fd = os.open(volume, os.O_RDONLY)
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            success, message = sm.delete_session('1')
            assert success is False
            assert 'busy' in message.lower() or 'attached' in message.lower()
            assert os.path.isfile(volume)
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            os.close(lock_fd)

    def test_copy_to_dynblk_normalizes_default_capacity_and_thin_admission(
            self, temp_sessions_dir):
        from minios_session import SessionManager

        source = os.path.join(temp_sessions_dir, '1')
        os.mkdir(source)
        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm._get_session_info = lambda _session_id: {
            'mode': 'raw', 'version': '6.0', 'edition': 'standard',
            'union': 'overlayfs', 'size': 4000,
        }
        sm.get_running_session = lambda: None
        validated = []
        sm._validate_target_mode = lambda mode, size: (
            validated.append((mode, size)) or (True, None))
        admitted = []
        sm._check_free_space = lambda path, size: (
            admitted.append((path, size)) or (True, None))
        conversion = []
        sm._copy_session_with_conversion = lambda *args: (
            conversion.append(args) or True)
        sm._read_sessions_metadata = lambda: {'sessions': {}}
        published = []
        sm._write_sessions_metadata = lambda metadata: (
            published.append(metadata) or True)

        success, _message = sm.copy_session('1', to_mode='dynblk')
        assert success is True
        assert validated == [('dynblk', sm.DYNBLK_DEFAULT_SIZE_MB)]
        assert admitted == [(temp_sessions_dir, sm.DYNBLK_INITIAL_MB)]
        assert conversion[0][4] == sm.DYNBLK_DEFAULT_SIZE_MB
        record = next(iter(published[-1]['sessions'].values()))
        assert record['mode'] == 'dynblk'
        assert record['size'] == sm.DYNBLK_DEFAULT_SIZE_MB

    def test_dynblk_creation_uses_native_cli_and_detaches(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        dynblk_calls = []
        sm._run_dynblk = lambda args: (
            dynblk_calls.append(list(args)) or
            SimpleNamespace(returncode=0, stdout=b'/dev/dynblk7\n', stderr=b''))
        completed = SimpleNamespace(returncode=0, stdout=b'', stderr=b'')

        with patch('minios_session.subprocess.run', return_value=completed) as run:
            success, _message = sm._create_dynblk_session(temp_sessions_dir, 4096)
        assert success is True
        assert dynblk_calls == [[
            'create', os.path.join(temp_sessions_dir, 'volume000.db'),
            '--size', '4096MiB', '--compression', 'none', '--format', 'dynblk', '--execute']]
        commands = [call[0][0] for call in run.call_args_list]
        assert ['mke2fs', '-F', '-t', 'ext4', '-E', 'nodiscard', '/dev/dynblk7'] in commands
        assert ['dynblk', 'unload', '/dev/dynblk7', '--execute'] in commands

    def test_dynblk_creation_passes_selected_compression(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        dynblk_calls = []
        sm._run_dynblk = lambda args: (
            dynblk_calls.append(list(args)) or
            SimpleNamespace(returncode=0, stdout=b'/dev/dynblk7\n', stderr=b''))
        sm._get_dynblk_compression_codecs = lambda: ('none', 'zstd')
        completed = SimpleNamespace(returncode=0, stdout=b'', stderr=b'')

        with patch('minios_session.subprocess.run', return_value=completed):
            success, _message = sm._create_dynblk_session(
                temp_sessions_dir, 4096, compression='zstd')
        assert success is True
        assert dynblk_calls[0] == [
            'create', os.path.join(temp_sessions_dir, 'volume000.db'),
            '--size', '4096MiB', '--compression', 'zstd', '--format', 'dynblk', '--execute']

    def test_dynblk_compression_is_rejected_with_luks(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        success, message = sm._create_session_locked(
            'dynblk', 4096, password=b'secret', encryption='luks',
            compression='zstd')
        assert success is False
        assert 'unavailable with LUKS' in message

    def test_dynblk_mount_uses_allocated_device_while_other_dynblk_can_exist(self,
                                                                            temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        volume = os.path.join(temp_sessions_dir, 'volume000.db')
        open(volume, 'wb').close()
        sm._run_dynblk = lambda args: SimpleNamespace(
            returncode=0, stdout=b'/dev/dynblk12\n', stderr=b'')
        sm._safe_unmount = lambda path, use_lazy=False: True
        sm._safe_rmtree = lambda path: None
        completed = SimpleNamespace(returncode=0, stdout=b'', stderr=b'')

        with patch('minios_session.os.path.exists', side_effect=lambda path: True), \
             patch('minios_session.tempfile.mkdtemp', return_value='/tmp/dynblk-mount'), \
             patch('minios_session.subprocess.run', return_value=completed) as run:
            with sm._mount_dynblk(temp_sessions_dir, writable=True) as mount_point:
                assert mount_point == '/tmp/dynblk-mount'

        commands = [call[0][0] for call in run.call_args_list]
        assert ['mount', '/dev/dynblk12', '/tmp/dynblk-mount'] in commands
        assert ['dynblk', 'unload', '/dev/dynblk12', '--execute'] in commands

    def test_failed_dynblk_creation_removes_reserved_session(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.check_sessions_directory_status = lambda: {'writable': True}
        sm._validate_target_mode = lambda _mode, _size: (True, None)
        sm._check_free_space = lambda _path, _size: (True, None)
        sm._create_dynblk_session = lambda _path, _size, **_kwargs: (False, 'dynblk failed')
        success, message = sm._create_session_locked('dynblk', 4096)

        assert success is False
        assert message == 'dynblk failed'
        assert not any(name.isdigit() for name in os.listdir(temp_sessions_dir))

    def test_failed_dynblk_detach_preserves_backing_session(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager(custom_sessions_dir=temp_sessions_dir)
        sm.check_sessions_directory_status = lambda: {'writable': True}
        sm._validate_target_mode = lambda _mode, _size: (True, None)
        sm._check_free_space = lambda _path, _size: (True, None)

        def fail_with_attached_volume(path, _size, **_kwargs):
            open(os.path.join(path, 'volume000.db'), 'wb').close()
            return False, 'detach failed'

        sm._create_dynblk_session = fail_with_attached_volume
        success, message = sm._create_session_locked('dynblk', 4096)

        assert success is False
        assert message == 'detach failed'
        session_dirs = [name for name in os.listdir(temp_sessions_dir) if name.isdigit()]
        assert session_dirs == ['1']
        assert os.path.isfile(os.path.join(temp_sessions_dir, '1', 'volume000.db'))

    def test_dynblk_resize_grows_virtual_device_and_filesystem(self, temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        volume = os.path.join(temp_sessions_dir, 'volume000.db')
        open(volume, 'wb').close()
        calls = []

        def run_dynblk(args):
            calls.append(list(args))
            stdout = b'/dev/dynblk9\n' if args and args[0] == 'load' else b''
            return SimpleNamespace(returncode=0, stdout=stdout, stderr=b'')

        sm._run_dynblk = run_dynblk
        sm._dynblk_status = lambda device: {'capacity_bytes': 4096 * 1024 * 1024}
        sm._write_sessions_metadata = lambda metadata: True
        metadata = {'sessions': {'7': {'mode': 'dynblk', 'size': 4096}}}
        completed = SimpleNamespace(returncode=0, stdout=b'', stderr=b'')
        with patch('minios_session.subprocess.run', return_value=completed) as run:
            success, _message = sm._resize_dynblk_session(
                temp_sessions_dir, 8192, '7', metadata)

        assert success is True
        assert ['load', volume, '--format', 'dynblk', '--execute'] in calls
        assert ['grow', '/dev/dynblk9', '8192MiB', '--execute'] in calls
        commands = [call[0][0] for call in run.call_args_list]
        assert ['e2fsck', '-p', '/dev/dynblk9'] in commands
        assert ['resize2fs', '-f', '/dev/dynblk9'] in commands
        assert ['dynblk', 'unload', '/dev/dynblk9', '--execute'] in commands
        assert metadata['sessions']['7']['size'] == 8192

    def test_dynblk_resize_recovers_after_device_grow_without_growing_twice(self,
                                                                           temp_sessions_dir):
        from minios_session import SessionManager

        sm = SessionManager.__new__(SessionManager)
        volume = os.path.join(temp_sessions_dir, 'volume000.db')
        open(volume, 'wb').close()
        calls = []
        sm._run_dynblk = lambda args: (
            calls.append(list(args)) or
            SimpleNamespace(returncode=0,
                            stdout=b'/dev/dynblk9\n' if args and args[0] == 'load' else b'',
                            stderr=b''))
        sm._dynblk_status = lambda device: {'capacity_bytes': 8192 * 1024 * 1024}
        sm._write_sessions_metadata = lambda metadata: True
        metadata = {'sessions': {'7': {'mode': 'dynblk', 'size': 4096}}}
        completed = SimpleNamespace(returncode=0, stdout=b'', stderr=b'')
        with patch('minios_session.subprocess.run', return_value=completed) as run:
            success, _message = sm._resize_dynblk_session(
                temp_sessions_dir, 8192, '7', metadata)

        assert success is True
        assert not any(call and call[0] == 'grow' for call in calls)
        commands = [call[0][0] for call in run.call_args_list]
        assert ['resize2fs', '-f', '/dev/dynblk9'] in commands
        assert metadata['sessions']['7']['size'] == 8192


def test_dynblk_compression_capabilities_come_from_run_initramfs(tmp_path):
    from minios_session import runtime_dynblk_compression_codecs

    kernel = '6.12-test'
    (tmp_path / 'lib' / 'modules' / kernel).mkdir(parents=True)

    def probe(command, **_kwargs):
        return SimpleNamespace(
            returncode=0 if command[-1] in ('crypto-lzo', 'crypto-zstd') else 1)

    with patch('minios_session.shutil.which', return_value='/usr/sbin/modprobe'), \
         patch('minios_session.subprocess.run', side_effect=probe) as run:
        assert runtime_dynblk_compression_codecs(
            str(tmp_path), kernel=kernel) == ('none', 'lzo', 'zstd')

    command = run.call_args_list[0][0][0]
    assert command[1:5] == ['-d', str(tmp_path), '-S', kernel]
    assert '--ignore-install' in command
    assert '--show-depends' in command


def test_dynblk_capability_requires_initrd_marker_and_module(temp_sessions_dir):
    from minios_session import INITRD_DYNBLK_MARKER, SessionManager

    sm = SessionManager.__new__(SessionManager)
    completed = SimpleNamespace(returncode=0)
    with patch('minios_session.secure_boot_enabled', return_value=False), \
         patch('minios_session.shutil.which', side_effect=lambda name: '/usr/bin/' + name), \
         patch('minios_session.os.path.isfile', side_effect=lambda path: path == INITRD_DYNBLK_MARKER), \
         patch('minios_session.subprocess.run', return_value=completed) as run:
        assert sm._check_dynblk_available() is True
        run.assert_called_once_with(
            ['modinfo', 'dynblk'], stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL)

    with patch('minios_session.secure_boot_enabled', return_value=False), \
         patch('minios_session.shutil.which', return_value='/usr/bin/tool'), \
         patch('minios_session.os.path.isfile', return_value=False):
        assert sm._check_dynblk_available() is False


def test_secure_boot_efivar_disables_dynblk_before_module_probe(tmp_path):
    from minios_session import SECURE_BOOT_GUID, SessionManager, secure_boot_enabled

    efivars = tmp_path / 'efivars'
    efivars.mkdir()
    variable = efivars / ('SecureBoot-' + SECURE_BOOT_GUID)
    variable.write_bytes(b'\x07\x00\x00\x00\x01')
    assert secure_boot_enabled(str(efivars)) is True

    sm = SessionManager.__new__(SessionManager)
    with patch('minios_session.secure_boot_enabled', return_value=True), \
         patch('minios_session.subprocess.run') as run:
        assert sm._check_dynblk_available() is False
        run.assert_not_called()

    sm._detect_filesystem_type = lambda: ({
        'type': 'ext4', 'is_readonly': False, 'is_posix_compatible': True,
    }, None)
    with patch('minios_session.secure_boot_enabled', return_value=True):
        valid, message = sm._validate_target_mode('dynblk', 16384)
        assert valid is False
        assert 'Secure Boot' in message

    variable.write_bytes(b'\x07\x00\x00\x00\x00')
    assert secure_boot_enabled(str(efivars)) is False

#!/usr/bin/python3
from __future__ import print_function

import ast
import importlib.machinery
import os
import shutil
import subprocess
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
XFCE = ROOT
SYNC_PATH = ROOT / 'bin/minios-thunar-uca-sync'
ACTIONS_PATH = ROOT / 'bin/minios-thunar-actions'
LOCALE_DIR = Path(os.environ.get(
    'MINIOS_THUNAR_TEST_LOCALE_DIR', str(ROOT / 'build/locale')))

sync = importlib.machinery.SourceFileLoader(
    'minios_thunar_uca_sync', str(SYNC_PATH)).load_module()
actions = importlib.machinery.SourceFileLoader(
    'minios_thunar_actions', str(ACTIONS_PATH)).load_module()


def ids(root):
    return [item.findtext('unique-id') for item in root.findall('action')]


def semantic(element):
    return (
        element.tag, tuple(sorted(element.attrib.items())), element.text or '',
        tuple(semantic(child) for child in list(element)))


def action_by_id(root, unique_id):
    for item in root.findall('action'):
        if item.findtext('unique-id') == unique_id:
            return item
    return None


class UcaSyncTests(unittest.TestCase):
    def test_clean_file_gets_actions_and_second_sync_is_idempotent(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, 'uca.xml')
            self.assertTrue(sync.sync_file(path, True))
            first = Path(path).read_bytes()
            root = ET.parse(path).getroot()
            self.assertEqual(ids(root), [
                sync.TERMINAL_ID, sync.CREATE_ID, sync.EXTRACT_ID,
                sync.ACTIVATE_ID, sync.DEACTIVATE_ID])
            self.assertFalse(sync.sync_file(path, True))
            self.assertEqual(Path(path).read_bytes(), first)

    def test_unknown_user_action_is_preserved_semantically(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, 'uca.xml')
            root = ET.Element('actions')
            user = ET.SubElement(root, 'action', {'custom': 'yes'})
            ET.SubElement(user, 'name').text = 'My Custom Action'
            ET.SubElement(user, 'unique-id').text = 'user-owned-id'
            ET.SubElement(user, 'command').text = 'printf %f'
            ET.SubElement(user, 'submenu').text = 'Tools'
            ET.SubElement(user, 'patterns').text = '*.txt'
            ET.SubElement(user, 'text-files')
            before = semantic(user)
            ET.ElementTree(root).write(path, encoding='UTF-8', xml_declaration=True)

            sync.sync_file(path, True)
            after_root = ET.parse(path).getroot()
            after = action_by_id(after_root, 'user-owned-id')
            self.assertIsNotNone(after)
            self.assertEqual(semantic(after), before)

    def test_user_action_order_is_preserved_across_minios_migration(self):
        root = ET.Element('actions')
        first = ET.SubElement(root, 'action')
        ET.SubElement(first, 'unique-id').text = 'user-first'
        legacy = ET.SubElement(root, 'action')
        ET.SubElement(legacy, 'unique-id').text = sync.CREATE_ID
        second = ET.SubElement(root, 'action')
        ET.SubElement(second, 'unique-id').text = 'user-second'
        legacy2 = ET.SubElement(root, 'action')
        ET.SubElement(legacy2, 'unique-id').text = sync.EXTRACT_ID
        third = ET.SubElement(root, 'action')
        ET.SubElement(third, 'unique-id').text = 'user-third'

        sync.sync_root(root, True)
        user_ids = [item.findtext('unique-id') for item in root.findall('action')
                    if item.findtext('unique-id') not in sync.KNOWN_IDS]
        self.assertEqual(user_ids, ['user-first', 'user-second', 'user-third'])

    def test_overlay_removes_only_runtime_actions(self):
        root = ET.Element('actions')
        sync.sync_root(root, True)
        sync.sync_root(root, False)
        self.assertEqual(ids(root), [
            sync.TERMINAL_ID, sync.CREATE_ID, sync.EXTRACT_ID])

    def test_applicability_matches_old_and_new_thunar(self):
        root = ET.Element('actions')
        sync.sync_root(root, True)
        create = action_by_id(root, sync.CREATE_ID)
        extract = action_by_id(root, sync.EXTRACT_ID)
        activate = action_by_id(root, sync.ACTIVATE_ID)
        deactivate = action_by_id(root, sync.DEACTIVATE_ID)
        self.assertEqual(create.findtext('patterns'), '*')
        self.assertIsNotNone(create.find('directories'))
        for item in (extract, activate, deactivate):
            self.assertEqual(item.findtext('patterns'), '*.sb')
            self.assertIsNotNone(item.find('other-files'))
        old_thunar_tags = {
            'actions', 'action', 'icon', 'name', 'unique-id', 'command',
            'description', 'patterns', 'startup-notify', 'directories',
            'audio-files', 'image-files', 'other-files', 'text-files',
            'video-files',
        }
        for element in root.iter():
            self.assertIn(element.tag, old_thunar_tags)

    def test_malformed_xml_is_not_destroyed(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, 'uca.xml')
            original = b'<actions><action><broken></actions>\n'
            Path(path).write_bytes(original)
            with self.assertRaises(ValueError):
                sync.sync_file(path, True)
            self.assertEqual(Path(path).read_bytes(), original)

    def test_locale_change_updates_only_minios_actions(self):
        root = ET.Element('actions')
        user = ET.SubElement(root, 'action')
        ET.SubElement(user, 'unique-id').text = 'custom'
        ET.SubElement(user, 'name').text = 'Untouched'
        user_before = semantic(user)
        old_translation = sync._
        sync._ = lambda text: 'A:' + text
        sync.sync_root(root, True)
        first_name = action_by_id(root, sync.CREATE_ID).findtext('name')
        sync._ = lambda text: 'B:' + text
        sync.sync_root(root, True)
        second_name = action_by_id(root, sync.CREATE_ID).findtext('name')
        sync._ = old_translation
        self.assertTrue(first_name.startswith('A:'))
        self.assertTrue(second_name.startswith('B:'))
        self.assertEqual(semantic(action_by_id(root, 'custom')), user_before)

    def test_compiled_catalogs_exist_for_supported_languages(self):
        for language in ('de', 'es', 'fr', 'id', 'it', 'pt', 'pt_BR', 'ru'):
            catalog = LOCALE_DIR / language / 'LC_MESSAGES/minios-thunar-actions.mo'
            self.assertTrue(catalog.is_file(), str(catalog))

    def test_gettext_english_and_russian_names(self):
        old_language = os.environ.get('LANGUAGE')
        try:
            os.environ['LANGUAGE'] = 'en'
            en = sync.translator(str(LOCALE_DIR))
            self.assertEqual(en('Create Module…'), 'Create Module…')
            os.environ['LANGUAGE'] = 'ru'
            ru = sync.translator(str(LOCALE_DIR))
            self.assertEqual(ru('Create Module…'), 'Создать модуль…')
            self.assertEqual(ru('Extract Module…'), 'Извлечь модуль…')
        finally:
            if old_language is None:
                os.environ.pop('LANGUAGE', None)
            else:
                os.environ['LANGUAGE'] = old_language


    def test_findmnt_check_uses_fixed_argv(self):
        with mock.patch.object(sync, 'findmnt_path', return_value='/usr/bin/findmnt'), \
                mock.patch.object(sync.subprocess, 'check_output', return_value='aufs\n') as check:
            self.assertEqual(sync.root_fstype(), 'aufs')
        check.assert_called_once_with(
            ['/usr/bin/findmnt', '-rn', '--mountpoint', '/', '-o', 'FSTYPE'],
            universal_newlines=True, stderr=sync.subprocess.DEVNULL)
    def test_compiled_catalogs_match_po_sources(self):
        msgfmt = shutil.which('msgfmt')
        if msgfmt is None:
            self.skipTest('msgfmt is not installed')
        with tempfile.TemporaryDirectory() as directory:
            for po in sorted((XFCE / 'po').glob('*.po')):
                expected = Path(directory) / (po.stem + '.mo')
                subprocess.check_call([msgfmt, '-o', str(expected), str(po)])
                installed = LOCALE_DIR / po.stem / 'LC_MESSAGES/minios-thunar-actions.mo'
                self.assertEqual(expected.read_bytes(), installed.read_bytes(), po.name)



class FrontendTests(unittest.TestCase):
    @mock.patch.object(actions.os, 'geteuid', return_value=1000)
    def test_conversion_argv_preserves_spaces_unicode_and_dash_names(self, _geteuid):
        source = '/tmp/Каталог с пробелами/-источник'
        target = '/tmp/Результат с пробелами.sb'
        self.assertEqual(
            actions.build_conversion_argv('create', source, target),
            ['/usr/bin/pkexec', '/usr/bin/dir2sb', '--json', '--allow-special',
             '--', source, target])
        self.assertEqual(
            actions.build_conversion_argv('extract', target, source),
            ['/usr/bin/pkexec', '/usr/bin/sb2dir', '--json', '--keep-ownership',
             '--allow-special', '--', target, source])

    def test_root_conversion_does_not_request_another_authorization(self):
        with mock.patch.object(actions.os, 'geteuid', return_value=0):
            argv = actions.build_conversion_argv('extract', '/module.sb', '/tree')
        self.assertEqual(argv, [
            '/usr/bin/sb2dir', '--json', '--keep-ownership', '--allow-special',
            '--', '/module.sb', '/tree'])

    def test_runtime_argv_is_fixed(self):
        path = '/tmp/модуль с пробелом/-test.sb'
        self.assertEqual(
            actions.build_runtime_argv('activate', path),
            ['/usr/bin/pkexec', '/usr/bin/sb', 'activate', path])
        self.assertEqual(
            actions.build_runtime_argv('deactivate', path),
            ['/usr/bin/pkexec', '/usr/bin/sb', 'deactivate', path])

    def test_subprocess_calls_never_use_shell_interpolation(self):
        tree = ast.parse(ACTIONS_PATH.read_text())
        calls = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            if isinstance(func, ast.Attribute) and func.attr in ('Popen', 'check_output'):
                calls.append(node)
                self.assertFalse(any(keyword.arg == 'shell' for keyword in node.keywords))
        self.assertEqual(len(calls), 1)


    def test_default_targets_are_siblings(self):
        self.assertEqual(
            actions.default_create_target('/home/live/work/firefox/'),
            '/home/live/work/firefox.sb')
        self.assertEqual(
            actions.default_extract_target('/home/live/work/firefox.sb'),
            '/home/live/work/firefox')

    def test_runtime_action_rechecks_aufs_before_starting_backend(self):
        with mock.patch.object(actions, 'root_fstype', return_value='overlay'), \
                mock.patch.object(actions, 'show_error') as error, \
                mock.patch.object(actions, 'RuntimeJob') as runtime:
            self.assertEqual(actions.run_runtime_action('activate', '/tmp/test.sb'), 1)
        runtime.assert_not_called()
        error.assert_called_once()

    def test_conversion_dialog_uses_shared_indeterminate_progress(self):
        source = ACTIONS_PATH.read_text()
        self.assertIn('apply_minios_css()', source)
        self.assertIn('self.dialog = ProgressDialog(', source)
        self.assertIn("self.view.set_state('running')", source)
        self.assertNotIn('Gtk.ProgressBar()', source)
        self.assertNotIn('Gtk.Spinner()', source)
        self.assertNotIn('set_fraction(', source)

    def test_jobs_use_command_runner_and_keep_conversion_cancellable(self):
        self.assertTrue(issubclass(actions.ConversionJob, actions.ProgressJob))
        self.assertTrue(issubclass(actions.RuntimeJob, actions.ProgressJob))
        source = ACTIONS_PATH.read_text()
        self.assertNotIn('subprocess.Popen(', source)
        self.assertIn('self.runner = CommandRunner(', source)
        self.assertIn('stderr_callback=self._handle_stderr_line', source)
        self.assertIn('maximum_output_bytes=1024 * 1024', source)
        self.assertIn("cancellable=True", source)

    def test_conversion_keeps_ndjson_validation_and_cancel_semantics(self):
        job = actions.ConversionJob.__new__(actions.ConversionJob)
        job.protocol_error = None
        job._phase = mock.Mock()
        job._handle_stdout_line('{"event":"phase","phase":"verify"}\n')
        job._phase.assert_called_once_with('verify')
        job._handle_stdout_line('not-json\n')
        self.assertIsNotNone(job.protocol_error)

        job.finished = False
        job.cancelled = False
        job.label = mock.Mock()
        job.runner = mock.Mock()
        with tempfile.TemporaryDirectory() as directory:
            job.cancel_marker = os.path.join(directory, 'cancel')
            job._on_response(None, actions.Gtk.ResponseType.CANCEL)
            self.assertTrue(os.path.isfile(job.cancel_marker))
        self.assertTrue(job.cancelled)
        job.runner.cancel.assert_called_once_with()

    def test_runtime_error_details_keep_stderr_separate_and_preferred(self):
        job = actions.RuntimeJob.__new__(actions.RuntimeJob)
        job.stderr = ['stderr detail']
        job.stdout = ['stdout detail']
        job.frontend_error = None
        job.returncode = 1
        self.assertEqual(job._result(), (False, 'stderr detail'))

    def test_standard_errors_use_minios_gui(self):
        with mock.patch.object(actions, 'show_error_dialog') as dialog:
            actions.show_error('Title', 'Message', 'Details', parent='parent')
        dialog.assert_called_once_with(
            'parent', 'Title', 'Message\n\nDetails')

    def test_target_chooser_uses_shared_helper_without_overwrite_acceptance(self):
        with mock.patch.object(actions, 'choose_save_file', return_value=None) as chooser:
            self.assertIsNone(actions.choose_target('/tmp/source', 'create'))
        self.assertFalse(chooser.call_args[1]['overwrite_confirmation'])

    def test_target_chooser_retries_from_selected_target(self):
        with mock.patch.object(
                actions, 'choose_save_file',
                side_effect=['/tmp/chosen/new-name', None]) as chooser, \
                mock.patch.object(actions.os.path, 'lexists', return_value=True), \
                mock.patch.object(actions, 'show_error') as error:
            self.assertIsNone(actions.choose_target('/tmp/source', 'create'))

        self.assertEqual(chooser.call_count, 2)
        self.assertEqual(chooser.call_args_list[1][1]['current_folder'],
                         '/tmp/chosen')
        self.assertEqual(chooser.call_args_list[1][1]['current_name'],
                         'new-name.sb')
        self.assertFalse(
            chooser.call_args_list[1][1]['overwrite_confirmation'])
        error.assert_called_once()


class PackageLayoutTests(unittest.TestCase):
    def test_session_hooks_are_packaged(self):
        early = ROOT / 'share/X11/Xsession.d/65minios-thunar-uca-sync'
        autostart = ROOT / 'share/xdg/autostart/minios-thunar-uca-sync.desktop'
        self.assertTrue(early.is_file())
        self.assertTrue(autostart.is_file())
        self.assertIn('/usr/bin/minios-thunar-uca-sync', early.read_text())
        self.assertIn('OnlyShowIn=XFCE;', autostart.read_text())

    def test_package_does_not_register_a_module_mime_type(self):
        files = [SYNC_PATH, ACTIONS_PATH]
        files.extend((ROOT / 'share').rglob('*'))
        content = '\n'.join(
            path.read_text(errors='ignore') for path in files if path.is_file())
        self.assertNotIn('application/x-minios-module', content)
        self.assertNotIn('<mime-type', content)

    def test_makefile_installs_only_thin_frontend_assets(self):
        makefile = (ROOT / 'Makefile').read_text()
        self.assertIn('minios-thunar-actions', makefile)
        self.assertIn('minios-thunar-uca-sync', makefile)
        self.assertIn('Xsession.d', makefile)
        self.assertNotIn('dir2sb.py', makefile)
        self.assertNotIn('sb2dir.py', makefile)

    def test_package_declares_minios_gui_api_dependency(self):
        control = (ROOT / 'debian/control').read_text()
        self.assertEqual(control.count('python3-minios-gui (>= 1.4.0)'), 2)


if __name__ == '__main__':
    unittest.main()

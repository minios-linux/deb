# MiniOS Tools

## Overview

A collection of command-line tools for managing MiniOS live systems and module bundles.

MiniOS Tools provides utilities for creating, managing, and customizing MiniOS live systems. These tools manage compressed filesystem bundles (.sb modules) and maintain live system configurations.

## Tools

### System Building
- **apt2sb** - Install packages from repositories and package them into modules
- **script2sb** - Package modules from changes made by installation scripts
- **chroot2sb** - Package modules using chroot environment

### Module Management
- **sb** - Activate, deactivate, and manage MiniOS bundles
- **dir2sb** - Convert directories to compressed .sb modules
- **sb2dir** - Extract .sb modules to directories
- **rmsbdir** - Refuse the retired unsafe module-directory removal operation
- **savechanges** - Save runtime changes to compressed bundles
- **minios-squashfs-save** - Atomically save the running SquashFS persistence snapshot; MiniOS core uses the bundled shutdown helper to invoke the same backend at poweroff

The SquashFS saver copies a stable view of session changes into a private
workspace in the trusted initrd tmpfs when memory permits. The compressor
writes directly to a private candidate in the session directory. After
verification and syncing, the saver atomically replaces `changes.sb`. The
temporary tree falls back to the session filesystem when RAM is insufficient;
the active snapshot remains intact until publication succeeds.

## Installation

These tools are typically included with MiniOS distributions. For manual installation:

```bash
make install
```

## Usage

Each tool includes built-in help:

```bash
dir2sb --help
apt2sb --help
# etc.
```

For detailed documentation, see the individual manual pages in the `doc/` directory.

## Language Support

Translations are provided for the command-line messages that use the localization layer:
- English (en_US)
- Russian (ru_RU)
- German (de_DE)
- Spanish (es_ES)
- Italian (it_IT)
- Indonesian (id_ID)
- Portuguese Brazil (pt_BR)
- Portuguese Portugal (pt_PT)
- French (fr_FR)

## Requirements

- Linux system with squashfs-tools
- Root privileges for most operations
- AUFS/OverlayFS support for some bundle operations

## Support

For issues and questions, visit: https://github.com/minios-linux/minios-live

## License

Distributed under the same license as MiniOS Linux.

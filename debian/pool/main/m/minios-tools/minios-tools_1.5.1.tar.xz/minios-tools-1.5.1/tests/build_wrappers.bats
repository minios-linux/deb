#!/usr/bin/env bats

setup() {
    BIN="$BATS_TEST_DIRNAME/../bin"
}

@test "build wrapper version queries are non-destructive" {
    run "$BIN/apt2sb" --version
    [ "$status" -eq 0 ]
    [[ $output == "apt2sb 1.2.4" ]]

    run "$BIN/script2sb" --version
    [ "$status" -eq 0 ]
    [[ $output == "script2sb 1.2.5" ]]

    run "$BIN/chroot2sb" --version
    [ "$status" -eq 0 ]
    [[ $output == "chroot2sb 1.0.4" ]]
}

@test "apt target release requires a value and install command" {
    run "$BIN/apt2sb" upgrade --target-release bionic
    [ "$status" -eq 1 ]
    [[ $output == *"valid only for install"* ]]

    run "$BIN/apt2sb" install --target-release
    [ "$status" -eq 1 ]
    [[ $output == *"requires an argument"* ]]
}

@test "wrapper sources propagate inner failures" {
    run grep -F 'Package operation failed; no module was created.' "$BIN/apt2sb"
    [ "$status" -eq 0 ]
    run grep -F 'Installation script failed; no module was created.' "$BIN/script2sb"
    [ "$status" -eq 0 ]
    run grep -F 'Chroot command failed; no module was created.' "$BIN/chroot2sb"
    [ "$status" -eq 0 ]
}

@test "build wrappers bind savechanges to their temporary mounted union" {
    local tool
    for tool in apt2sb script2sb chroot2sb; do
        run grep -F 'savechanges --mounted-root "$UNION"' "$BIN/$tool"
        [ "$status" -eq 0 ]
    done
}

@test "savechanges selects the inner standard OverlayFS changes directory" {
    run grep -F '[[ -d $candidate/changes && -d $candidate/workdir ]]' "$BIN/savechanges"
    [ "$status" -eq 0 ]
    run grep -F 'printf '\''%s\n'\'' "$candidate/changes"' "$BIN/savechanges"
    [ "$status" -eq 0 ]
}

@test "directory seeds copy complete contents without globbing" {
    run grep -F 'cp -a "$DIRECTORY"/. "$UNION/"' "$BIN/script2sb"
    [ "$status" -eq 0 ]
    run grep -F 'cp -a "$DIRECTORY"/. "$UNION/"' "$BIN/chroot2sb"
    [ "$status" -eq 0 ]
}

@test "unexpected wrapper operands fail instead of looping" {
    run timeout 2 "$BIN/script2sb" unexpected
    [ "$status" -eq 1 ]
    [[ $output == *"Unexpected argument: unexpected"* ]]

    run timeout 2 "$BIN/chroot2sb" unexpected
    [ "$status" -eq 1 ]
    [[ $output == *"Unexpected argument: unexpected"* ]]
}

@test "wrapper options reject missing values" {
    local tool option
    for tool in apt2sb script2sb chroot2sb; do
        for option in --name --level --comp --bext; do
            if [[ $tool == apt2sb ]]; then
                run "$BIN/$tool" install "$option"
            else
                run "$BIN/$tool" "$option"
            fi
            [ "$status" -eq 1 ]
            [[ $output == *"requires an argument"* ]]
        done
    done

    run "$BIN/script2sb" --script
    [ "$status" -eq 1 ]
    [[ $output == *"requires an argument"* ]]
}

@test "root build commands refuse unsupported live sessions early" {
    (( EUID == 0 )) || skip "requires root"
    [ ! -d /run/initramfs/memory/bundles ] || skip "running in a livekit MiniOS session"
    [ ! -d /lib/live/mount/bundles ] || skip "running in a live MiniOS session"

    local install_script="$BATS_TEST_TMPDIR/install.sh"
    printf '#!/bin/sh\nexit 0\n' >"$install_script"

    run "$BIN/apt2sb" install bash
    [ "$status" -eq 1 ]
    [[ $output == *"requires a supported MiniOS live session"* ]]

    run "$BIN/script2sb" --script "$install_script"
    [ "$status" -eq 1 ]
    [[ $output == *"requires a supported MiniOS live session"* ]]

    run "$BIN/chroot2sb"
    [ "$status" -eq 1 ]
    [[ $output == *"requires a supported MiniOS live session"* ]]
}

#!/bin/bash
set -euo pipefail

ROOT=$(cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

APPNAME=$(sed -n '1s/ .*//p' debian/changelog)
VERSION=$(sed -n '1s/^[^(]*(\([^)]*\)).*/\1/p' debian/changelog)
POTFILE=po/messages.pot
TMP_POT=""
TMP_PO=""

cleanup() {
    [[ -z $TMP_POT ]] || rm -f -- "$TMP_POT"
    [[ -z $TMP_PO ]] || rm -f -- "$TMP_PO"
}
trap cleanup EXIT

for command in xgettext msgmerge msgfmt; do
    command -v "$command" >/dev/null 2>&1 || {
        printf 'Required command not found: %s\n' "$command" >&2
        exit 1
    }
done

mapfile -d '' SOURCES < <(find bin -maxdepth 1 -type f -print0 | sort -z)
(( ${#SOURCES[@]} > 0 )) || {
    printf 'No source files found in bin/\n' >&2
    exit 1
}

mkdir -p po
TMP_POT=$(mktemp po/.messages.pot.XXXXXX)
xgettext \
    --language=Shell \
    --keyword=gettext \
    --from-code=UTF-8 \
    --package-name="$APPNAME" \
    --package-version="$VERSION" \
    --msgid-bugs-address=support@minios.dev \
    --copyright-holder='MiniOS Linux' \
    --output="$TMP_POT" \
    "${SOURCES[@]}"
mv -- "$TMP_POT" "$POTFILE"
TMP_POT=""

shopt -s nullglob
PO_FILES=(po/*.po)
shopt -u nullglob

for pofile in "${PO_FILES[@]}"; do
    TMP_PO=$(mktemp "${pofile}.XXXXXX")
    msgmerge --quiet "$pofile" "$POTFILE" >"$TMP_PO"
    msgfmt --check --check-format -o /dev/null "$TMP_PO"
    mv -- "$TMP_PO" "$pofile"
    TMP_PO=""
    printf 'Updated %s\n' "$pofile"
done

printf 'Updated %s (%d source messages)\n' "$POTFILE" "$(grep -c '^msgid ' "$POTFILE")"

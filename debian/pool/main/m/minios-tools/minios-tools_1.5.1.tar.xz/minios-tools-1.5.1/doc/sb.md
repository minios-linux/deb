% SB(1) MiniOS Live Manual

## NAME
**sb** - A utility for managing MiniOS bundles.

## SYNOPSIS
`sb COMMAND [OPTIONS]`

## DESCRIPTION
**sb** manages active MiniOS bundles and dispatches to the converter and
session-capture tools.

## COMMANDS

* `activate BUNDLE`
  Mounts a readable bundle and adds it to the AUFS root union.

* `deactivate BUNDLE`
  Removes an active bundle from the AUFS root union and unmounts it.

* `list`
  Lists active bundle mountpoints and backing files. It supports AUFS and the
  OverlayFS lower-directory listing, with a mounted-SquashFS fallback.

* `savechanges`
  Runs **savechanges** with the remaining arguments.

* `rm DIR` or `rmdir DIR`
  Always refuses. It does not load MiniOS configuration, require root, unmount,
  or remove the supplied path.

* `conv SOURCE TARGET`
  If *SOURCE* is a directory, runs **dir2sb**; otherwise it runs **sb2dir**.
  The arguments are passed to that converter.

* `help`
  Displays the script usage help.

* `version`
  Displays version information of the script.

## USAGE NOTES

1. Except for the refusal-only `rm` and `rmdir` aliases, **sb** requires root.
   The `help` and `version` queries do not read MiniOS configuration, but still
   require root.
2. `activate` and `deactivate` require AUFS support. `list` can also report an
   OverlayFS session.
3. The `conv` command checks that its first argument is readable before
   dispatching; provide both converter operands.

## EXAMPLES

- `sb activate example_bundle.sb`
- `sb deactivate example_bundle.sb`
- `sb list`
- `sb savechanges session.sb`
- `sb rm example_directory`
- `sb conv example_directory example.sb`
- `sb conv example.sb example_directory`

## SEE ALSO

[rmsbdir(1)](man:rmsbdir.1)

[sb2dir(1)](man:sb2dir.1)

[dir2sb(1)](man:dir2sb.1)

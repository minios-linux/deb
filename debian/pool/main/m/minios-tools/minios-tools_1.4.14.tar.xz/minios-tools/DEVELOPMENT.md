# minios-tools — Developer Notes

## Overview

`minios-tools` is a collection of command-line tools for managing MiniOS live
systems and `.sb` (SquashFS Bundle) modules:

| Tool | Purpose |
|------|---------|
| `sb` | Activate/deactivate/list modules at runtime |
| `sb2iso` | Build a bootable MiniOS ISO from the running system |
| `dir2sb` | Pack a directory into a `.sb` module |
| `sb2dir` | Extract a `.sb` module to a directory |
| `rmsbdir` | Remove a directory created by `sb2dir` |
| `savechanges` | Save runtime changes to a `.sb` module |
| `apt2sb` | Install APT packages and pack them into a module |
| `script2sb` | Run an install script and pack the result |
| `chroot2sb` | Open an interactive chroot and pack the changes |
| `minios-setup-keyboard` | Configure keyboard layout |
| `minios-virtual-resolution` | Set display resolution in a VM |

---

## Recent changes (1.4.14)

### `sb list` fix for OverlayFS (sb 1.0.3)

**Problem:** `sb list` failed on OverlayFS systems with:
```
bash: cd: /sys/fs/aufs/: No such file or directory
```
The original `print_branches()` unconditionally tried to `cd` into
`/sys/fs/aufs/` which only exists when AUFS is loaded.

**Fix:** `print_branches()` now detects the union filesystem type and uses the
appropriate method:

1. **AUFS** — original `/sys/fs/aufs` branch enumeration (unchanged).
2. **OverlayFS** — reads the `lowerdir=` option from the root overlay mount in
   `/proc/mounts`, reverses the order (overlayfs lists from high to low
   priority; AUFS convention is low to high), and resolves each bundle by
   basename under `$BUNDLES`.
3. **Fallback** — scans squashfs mounts directly under `$BUNDLES/`.

A helper `print_branch_entry()` was extracted to avoid duplication.

**Output format** is unchanged: tab-separated `<mountpoint>\t<source file>`,
one bundle per line, lowest priority first.

**File:** `bin/sb`, function `print_branches()` (lines ~99–148).  
**Version:** `sb 1.0.3`

---

## `sb list` output format

```
/run/initramfs/memory/bundles/00-core-amd64.sb\t/run/initramfs/memory/data/minios/00-core-amd64.sb
/run/initramfs/memory/bundles/01-kernel-...\t/run/initramfs/memory/data/minios/01-kernel-...
```

Consumed by:
- `minios-module-manager` — `tools.list_active_modules()` parses TSV with
  `line.split('\t')` and adds `size` via `os.path.getsize(source)`.
- `sb activate` / `sb deactivate` — use `print_branches` internally to detect
  already-activated bundles.

---

## Live system paths

| initramfs | `$LIVE` base | bundles | changes |
|-----------|-------------|---------|---------|
| livekit | `/run/initramfs/memory` | `$LIVE/bundles` | `$LIVE/changes` |
| dracut | `/lib/live/mount` | `$LIVE/bundles` | `$LIVE/changes` |

Detected at runtime by checking for the existence of `$LIVE/bundles`.

---

## OverlayFS note for GUI consumers

`sb activate` and `sb deactivate` require AUFS kernel support.  
On OverlayFS systems (current default), these commands refuse with:
```
AUFS is not supported by the <version> kernel.
```
GUI applications should detect this via `tools.aufs_supported()` (checks
`/proc/filesystems` for `aufs`) and disable activate/deactivate UI elements
accordingly, displaying a clear explanation to the user.

---

## Translation

Domain: `minios-tools`  
Languages: `de`, `es`, `fr`, `id`, `it`, `pt`, `pt_BR`, `ru`  
Template: `po/messages.pot`

The `lokit.yaml` target:
```yaml
- name: minios-tools
  format: gettext
  root: submodules/minios-tools
  template: po/messages.pot
  to: po/{lang}.po
```

To update translations after changing shell strings:
```sh
./update-po.sh
lokit translate --provider copilot --model gpt-4.1 --target minios-tools
make build
```

Shell strings are extracted with `xgettext --language=Shell --keyword=gettext`.

---

## Build & packaging

```sh
# Build Debian package:
dpkg-buildpackage -us -uc -b

# Install:
sudo dpkg -i ../minios-tools_1.4.14_all.deb
```

Build dependencies: `debhelper (>= 11)`, `gettext`, `pandoc`

Runtime dependencies: `bash >= 4.4`, `coreutils`, `gettext-base`, `grep`,
`sed`, `mawk`, `squashfs-tools >= 4.3`, `util-linux >= 2.31`

---

## Testing on the LiveCD VM

```
SSH:  127.0.0.1:41022
User: live  Password: evil
Root password: toor
live has passwordless sudo
```

Known hosts file: `/tmp/opencode/livecd_known_hosts`

```sh
# Copy and install:
sshpass -p evil scp -P 41022 \
    -o UserKnownHostsFile=/tmp/opencode/livecd_known_hosts \
    -o StrictHostKeyChecking=yes \
    ../minios-tools_1.4.14_all.deb live@127.0.0.1:/tmp/

sshpass -p evil ssh -p 41022 \
    -o UserKnownHostsFile=/tmp/opencode/livecd_known_hosts \
    -o StrictHostKeyChecking=yes live@127.0.0.1 \
    'sudo -n dpkg -i /tmp/minios-tools_1.4.14_all.deb'

# Test sb list on OverlayFS:
sshpass -p evil ssh -p 41022 \
    -o UserKnownHostsFile=/tmp/opencode/livecd_known_hosts \
    -o StrictHostKeyChecking=yes live@127.0.0.1 \
    'sudo -n sb list'
```

After VM recreation refresh the host key:
```sh
ssh-keygen -R '[127.0.0.1]:41022' -f /tmp/opencode/livecd_known_hosts
ssh-keyscan -p 41022 -t ed25519,rsa,ecdsa 127.0.0.1 >> /tmp/opencode/livecd_known_hosts
```

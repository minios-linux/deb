# MiniOS Artwork

## Overview

MiniOS desktop themes and artwork for some MiniOS-branded packages.

Artwork from earlier MiniOS versions is retained as source material and is not included in binary packages.

## Packages

  * minios6-artwork
  * minios6-wallpapers
  * minios6-wallpapers-minimum
  * minios6-wallpapers-flux
  * minios6-wallpapers-standard
  * minios6-wallpapers-toolbox
  * minios6-wallpapers-ultra

## License

Distributed under the GNU General Public License v3 or later.

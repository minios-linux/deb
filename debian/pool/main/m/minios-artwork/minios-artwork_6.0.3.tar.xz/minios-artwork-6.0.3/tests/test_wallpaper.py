"""Exercise wallpaper defaults against temporary roots, never host settings."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
import xml.etree.ElementTree as ET


HELPER = Path(os.environ.get(
    'MINIOS_ARTWORK_TEST_HELPER',
    str(Path(__file__).resolve().parents[1] / 'usr/lib/minios-artwork/configure-xfce-wallpaper'),
)).resolve()
WALLPAPER = '/usr/share/backgrounds/minios6-standard.jpg'
LEGACY = '<channel><property name="image-path" type="string" value="old.jpg"/><property name="keep" value="yes"/></channel>\n'


class WallpaperTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.xml = self.root / 'etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-desktop.xml'
        self.xml.parent.mkdir(parents=True)
        self.xml.write_text(LEGACY)
        self.image = self.root / WALLPAPER.lstrip('/')
        self.image.parent.mkdir(parents=True)
        self.image.write_bytes(b'test wallpaper')

    def run_helper(self, *arguments):
        environment = dict(os.environ, MINIOS_ARTWORK_ROOT=str(self.root))
        return subprocess.run([str(HELPER), *arguments], env=environment,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def set_suite(self, suite):
        (self.root / 'etc/os-release').write_text('VERSION_CODENAME="' + suite + '"\n')

    def test_modern_suites_include_dsi_and_existing_outputs(self):
        expected = 'Virtual-1 Virtual-2 Virtual1 eDP eDP-1 DSI-1 DSI-2 HDMI-A-0 HDMI-A-1 HDMI-1 HDMI-2 DP-1 DP-2 DP-3 LVDS-1 DVI-I-1 DVI-I-2'.split()
        for suite in ('resolute', 'trixie', 'excalibur', 'forky', 'sid'):
            with self.subTest(suite=suite):
                self.set_suite(suite)
                self.assertEqual(self.run_helper(WALLPAPER).returncode, 0)
                tree = ET.parse(self.xml)
                screen = tree.find("./property[@name='backdrop']/property[@name='screen0']")
                self.assertEqual({item.get('name') for item in screen},
                                 {'monitor' + output for output in expected})
                for output in expected:
                    monitor = screen.find("./property[@name='monitor" + output + "']")
                    self.assertEqual([item.get('name') for item in monitor],
                                     ['workspace' + str(i) for i in range(4)])
                    for workspace in monitor:
                        self.assertEqual(workspace.find("./property[@name='last-image']").get('value'), WALLPAPER)
                        self.assertEqual(workspace.find("./property[@name='image-style']").get('value'), '5')

    def test_legacy_configuration_preserves_other_settings(self):
        self.set_suite('bionic')
        self.assertEqual(self.run_helper(WALLPAPER).returncode, 0)
        self.assertEqual(self.xml.read_text(), LEGACY.replace('old.jpg', WALLPAPER))

    def test_missing_wallpaper_leaves_configuration_unchanged(self):
        self.set_suite('trixie')
        self.image.unlink()
        self.assertEqual(self.run_helper(WALLPAPER).returncode, 0)
        self.assertEqual(self.xml.read_text(), LEGACY)

    def test_missing_configuration_is_not_created(self):
        self.set_suite('trixie')
        self.xml.unlink()
        self.assertEqual(self.run_helper(WALLPAPER).returncode, 0)
        self.assertFalse(self.xml.exists())

    def test_missing_argument_fails_without_modifying_configuration(self):
        self.assertNotEqual(self.run_helper().returncode, 0)
        self.assertEqual(self.xml.read_text(), LEGACY)


if __name__ == '__main__':
    unittest.main()

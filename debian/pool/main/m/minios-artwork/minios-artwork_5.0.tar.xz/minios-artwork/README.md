# MiniOS Artwork
MiniOS desktop themes and artwork for some MiniOS-branded packages.

Packages provided include:
  * minios-artwork
  * minios-wallpapers

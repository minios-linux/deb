#!/bin/sh
# Native helper regression tests. Run from the project root using make test.
set -eu
export LC_ALL=C
MERGER=${MERGE_C_BINARY:-"$PWD/build/minios-update-dpkg-merge"}
WORK=$(mktemp -d "${TMPDIR:-/tmp}/minios-dpkg-merge.XXXXXXXX")
trap 'rm -rf "$WORK"' 0
trap 'exit 1' HUP INT TERM
# Undefined behaviour must also fail the sanitizer run.
export UBSAN_OPTIONS="${UBSAN_OPTIONS:+$UBSAN_OPTIONS:}halt_on_error=1"

record() {
    printf 'Package: %s\nArchitecture: %s\nVersion: %s\n' "$1" "${2:-amd64}" "${3:-1}"
    if [ -n "${4:-}" ]; then printf '%s\n' "$4"; fi
    printf '\n'
}
reset_case() {
    rm -rf "$WORK/info"
    mkdir "$WORK/info"
    for f in modules current previous expected; do : >"$WORK/$f"; done
    rm -f "$WORK/base" "$WORK/final"
}
merge() {
    "$MERGER" "$WORK/modules" "$WORK/current" "$WORK/previous" \
        "$WORK/info" "$WORK/base" "$WORK/final"
}
expect_failure() {
    rm -f "$WORK/base" "$WORK/final"
    if merge 2>"$WORK/error"; then
        printf 'Unexpected success: %s\n' "$1" >&2
        exit 1
    fi
    grep -F "$1" "$WORK/error" >/dev/null
    if grep -E 'AddressSanitizer|runtime error:' "$WORK/error" >/dev/null; then
        cat "$WORK/error" >&2
        exit 1
    fi
    test ! -e "$WORK/base"
    test ! -e "$WORK/final"
}
check_both() {
    cmp "$WORK/expected" "$WORK/base"
    cmp "$WORK/expected" "$WORK/final"
}
save_state() {
    cp "$WORK/base" "$WORK/previous"
    cp "$WORK/final" "$WORK/current"
}

while read -r older newer; do
    for direction in forward reverse; do
        reset_case
        record pkg amd64 "$newer" >"$WORK/expected"
        if [ "$direction" = forward ]; then
            record pkg amd64 "$older" >"$WORK/modules"
            record pkg amd64 "$newer" >>"$WORK/modules"
        else
            record pkg amd64 "$newer" >"$WORK/modules"
            record pkg amd64 "$older" >>"$WORK/modules"
        fi
        merge
        check_both
    done
done <<'VERSIONS'
1.0~~ 1.0~rc1
1.0~rc1 1.0
1.0 1.0-1
1.0-1~deb13u1 1.0-1
1.0-1 1.0-1+b1
1.0-9 1.0-10
1:99.9 2:0.1
18446744073709551616:1 36893488147419103232:1
VERSIONS
reset_case
record pkg amd64 1.0 'Description: first' >"$WORK/expected"
cp "$WORK/expected" "$WORK/modules"
record pkg amd64 1.00 >>"$WORK/modules"
merge
check_both
printf 'Version ordering and equal-version precedence: passed\n'

for version in '1-' a1 1_0 :1 x:1 '1 2' '1
 continuation'; do
    reset_case
    record pkg amd64 "$version" >"$WORK/modules"
    record pkg amd64 2 >>"$WORK/modules"
    expect_failure 'is not a valid version'
done
for invalid in \
    'Package: pkg\npAcKaGe: other\nVersion: 1\n\n' \
    'Package:   \nVersion: 1\n\n' \
    'Package: pkg\nVersion: 1\ninvalid\n\n' \
    ' continuation\nPackage: pkg\nVersion: 1\n\n'; do
    reset_case
    printf '%b' "$invalid" >"$WORK/modules"
    expect_failure 'Malformed status paragraph'
done

reset_case
record lib.foo amd64 >"$WORK/modules"
record lib.foo i386 >>"$WORK/modules"
cp "$WORK/modules" "$WORK/expected"
merge
check_both
for name in lib.foo.list .wh.lib.foo.list lib.foo:amd64.list; do
    reset_case
    record lib.foo >"$WORK/current"
    touch "$WORK/info/$name"
    merge
    cmp "$WORK/current" "$WORK/final"
done
reset_case
record lib.foo >"$WORK/current"
touch "$WORK/info/lib.foobar.list"
merge
test ! -s "$WORK/final"
reset_case
record pkg >"$WORK/modules"
record pkg >"$WORK/current"
record stale >>"$WORK/current"
merge
cmp "$WORK/modules" "$WORK/final"
: >"$WORK/current"
touch "$WORK/info/.wh.pkg.list"
merge
test ! -s "$WORK/final"

reset_case
record pkg amd64 1 'Description: text
 continuation' >"$WORK/modules"
cp "$WORK/modules" "$WORK/previous"
cp "$WORK/modules" "$WORK/expected"
printf 'version: 1\narchitecture: amd64\npackage: pkg\nDescription: text\n continuation\n\n' >"$WORK/current"
merge
check_both
for separator in '\n\n' '\n \n' '\n\t\n\n' '\n\r\n' '\n\013\n' '\n\f\n'; do
    reset_case
    printf 'Package: pkg\nArchitecture: amd64\nVersion: 1%b' "$separator" >"$WORK/modules"
    record second >>"$WORK/modules"
    record pkg >"$WORK/expected"
    record second >>"$WORK/expected"
    merge
    check_both
done
reset_case
printf 'Package: pkg\r\nArchitecture: amd64\r\nVersion: 1\r\n\r\n' >"$WORK/modules"
printf 'Package: pkg\r\nArchitecture: amd64\r\nVersion: 1\n\n' >"$WORK/expected"
merge
check_both
reset_case
{
    printf 'Package: pkg\nArchitecture: amd64\nVersion: 1\nDescription: long\n'
    i=0
    while [ "$i" -lt 20000 ]; do
        printf ' continuation\n'
        i=$((i + 1))
    done
    printf '\n'
} >"$WORK/modules"
cp "$WORK/modules" "$WORK/expected"
merge
check_both
printf 'Invalid input, multiarch, whiteouts, migration and multiline fields: passed\n'

# Persisted current is the preceding full merged output, not a delta.
reset_case
record core >"$WORK/core"
record shared >>"$WORK/core"
record shared amd64 2 >"$WORK/extra"
record extra >>"$WORK/extra"
cat "$WORK/core" "$WORK/extra" >"$WORK/modules"
merge
save_state
sed '/^Package: core$/a\
Status: hold ok installed' "$WORK/current" >"$WORK/held"
cat "$WORK/held" >"$WORK/current"
record local.pkg >>"$WORK/current"
touch "$WORK/info/local.pkg.list"
merge
save_state
cp "$WORK/core" "$WORK/modules"
merge
record core amd64 1 'Status: hold ok installed' >"$WORK/expected"
record local.pkg >>"$WORK/expected"
record shared >>"$WORK/expected"
# Field order is retained from the writable record.
sed '/^Status: hold ok installed$/d; /^Package: core$/a\
Status: hold ok installed' "$WORK/expected" >"$WORK/ordered"
cmp "$WORK/ordered" "$WORK/final"
save_state
cat "$WORK/core" "$WORK/extra" >"$WORK/modules"
merge
grep -q '^Package: extra$' "$WORK/final"
grep -q '^Version: 2$' "$WORK/final"
save_state
sed 's/^Version: 2$/Version: 0/' "$WORK/current" >"$WORK/downgraded"
cp "$WORK/downgraded" "$WORK/current"
touch "$WORK/info/shared.list"
merge
grep -q '^Version: 0$' "$WORK/final"
save_state
sed '/^Package: local.pkg$/,/^$/d' "$WORK/current" >"$WORK/removed"
cp "$WORK/removed" "$WORK/current"
touch "$WORK/info/.wh.local.pkg.list"
merge
if grep -q '^Package: local.pkg$' "$WORK/final"; then exit 1; fi
save_state
merge
cmp "$WORK/previous" "$WORK/base"
cmp "$WORK/current" "$WORK/final"
printf 'changes lifecycle and idempotence: passed\n'

reset_case
record pkg >"$WORK/modules"
cp "$WORK/modules" "$WORK/valid"
printf '\000' >>"$WORK/modules"
expect_failure 'embedded NUL'
cp "$WORK/valid" "$WORK/modules"
rm "$WORK/current"
ln -s current "$WORK/current"
expect_failure 'Cannot stat'
rm "$WORK/current"
: >"$WORK/current"
rm -r "$WORK/info"
ln -s info "$WORK/info"
expect_failure 'Cannot stat'
reset_case
record pkg >"$WORK/modules"
if [ -e /dev/full ]; then
    if "$MERGER" "$WORK/modules" "$WORK/current" "$WORK/previous" \
        "$WORK/info" /dev/full "$WORK/final" 2>"$WORK/error"; then
        printf 'Output write failure was ignored\n' >&2
        exit 1
    fi
    grep -F /dev/full "$WORK/error" >/dev/null
    test ! -e "$WORK/final"
fi
printf 'I/O failure handling: passed\n'

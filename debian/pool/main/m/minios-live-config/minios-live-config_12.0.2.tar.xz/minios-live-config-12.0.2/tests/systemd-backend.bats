#!/usr/bin/env bats

setup() {
    ROOT=$(CDPATH= cd -- "$BATS_TEST_DIRNAME/.." && pwd)
    tree=$(mktemp -d "${TMPDIR:-/tmp}/minios-systemd-test.XXXXXX")
    mkdir -p "$tree/usr/lib/systemd/system" "$tree/bin"
    cp "$ROOT/backend/systemd/live-config.systemd" "$tree/usr/lib/systemd/system/live-config.service"
    for action in postinst postrm; do
        sed -e "s|/usr/lib/systemd|$tree/usr/LIBSYSTEMD|g" \
            -e "s|/lib/systemd|$tree/lib/systemd|g" \
            -e 's|LIBSYSTEMD|lib/systemd|g' \
            "$ROOT/debian/minios-live-config-systemd.$action" >"$tree/$action"
    done
    export TEST_UNIT="$tree/lib/systemd/system/live-config.service"
    cat >"$tree/bin/deb-systemd-helper" <<'SH'
#!/bin/sh
# Old helper discovery contract; no service is started by this test.
test -r "$TEST_UNIT" || { echo 'legacy unit lookup failed' >&2; exit 1; }
SH
    chmod +x "$tree/bin/deb-systemd-helper"
    export PATH="$tree/bin:$PATH"
}

teardown() {
    [ -z "${tree:-}" ] || rm -rf -- "$tree"
}

@test "systemd backend supplies a legacy lookup path only on non-usrmerged systems" {
    mkdir -p "$tree/lib/systemd/system"
    run sh "$tree/postinst" configure
    [ "$status" -eq 0 ]
    [ -z "$output" ]
    [ "$(readlink "$TEST_UNIT")" = "$tree/usr/lib/systemd/system/live-config.service" ]
    run sh "$tree/postinst" configure
    [ "$status" -eq 0 ]
    sh "$tree/postrm" remove
    [ ! -L "$TEST_UNIT" ]
    [ -f "$tree/usr/lib/systemd/system/live-config.service" ]
}

@test "systemd backend does not duplicate or remove a merged-usr unit" {
    ln -s usr/lib "$tree/lib"
    sh "$tree/postinst" configure
    [ ! -L "$TEST_UNIT" ]
    sh "$tree/postrm" purge
    [ -f "$tree/usr/lib/systemd/system/live-config.service" ]
}

@test "systemd backend preserves an administrator mask or replacement" {
    mkdir -p "$tree/lib/systemd/system"
    ln -s /dev/null "$TEST_UNIT"
    sh "$tree/postinst" configure
    sh "$tree/postrm" purge
    [ "$(readlink "$TEST_UNIT")" = /dev/null ]
    rm "$TEST_UNIT"
    printf custom >"$TEST_UNIT"
    sh "$tree/postinst" configure
    sh "$tree/postrm" remove
    [ "$(cat "$TEST_UNIT")" = custom ]
}

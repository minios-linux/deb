#!/usr/bin/env bats

@test "release metadata matches VERSION" {
    ROOT=$(CDPATH= cd -- "$BATS_TEST_DIRNAME/.." && pwd)
    VERSION=$(cat "$ROOT/VERSION")
    [ "$(dpkg-parsechangelog -l "$ROOT/debian/changelog" -S Version)" = "$VERSION" ]
    for page in "$ROOT"/manpages/en/live-config.7 "$ROOT"/manpages/*/live-config.*.7; do
        grep '^\.TH ' "$page" | grep -F " $VERSION "
    done
    for catalog in "$ROOT"/manpages/po/*/live-config.7.po; do
        grep -Fx "msgid \"$VERSION\"" "$catalog"
        grep -Fx "msgstr \"$VERSION\"" "$catalog"
    done
    grep -Fx "msgid \"$VERSION\"" "$ROOT/manpages/pot/live-config.7.pot"
}

#!/bin/sh
# Run via unshare -Urnm sh tests/dpkg-reinstall-overlay.sh
set -eu
export LC_ALL=C
merger=$(realpath "${1:-build/minios-update-dpkg-merge}")
w=$(mktemp -d)
trap 'mountpoint -q "$w/root" && umount "$w/root"; rm -rf "$w"' EXIT
cd "$w"
mkdir -p root pkg/DEBIAN pkg/usr/share/demo pkg/usr/share/doc/review-demo
for v in 1 2; do
    mkdir "lower$v"
    printf 'Package: review-demo\nVersion: %s\nArchitecture: all\nMaintainer: Test <t@example.org>\nDescription: fixture\n' "$v" >pkg/DEBIAN/control
    echo "$v" >pkg/usr/share/demo/version
    echo "$v" >pkg/usr/share/demo/another
    echo doc >pkg/usr/share/doc/review-demo/README
    (cd pkg && md5sum usr/share/demo/* usr/share/doc/review-demo/README >DEBIAN/md5sums)
    dpkg-deb -b pkg "$v.deb"
    dpkg --path-exclude='/usr/share/doc/*' --log="$w/dpkg.log" --root="$w/lower$v" -i "$v.deb"
done
for mode in selection reinstall partial; do
    mkdir "$mode" "$mode-work"
    for v in 1 2; do
        mount -t overlay overlay -o "lowerdir=$w/lower$v,upperdir=$w/$mode,workdir=$w/$mode-work,userxattr" root
        if [ "$v" = 1 ]; then
            if [ "$mode" = reinstall ]; then
                dpkg --path-exclude='/usr/share/doc/*' --log="$w/dpkg.log" --root="$w/root" -i 1.deb
            elif [ "$mode" = partial ]; then
                touch root/var/lib/dpkg/info/review-demo.md5sums root/usr/share/demo/another
            fi
            echo 'review-demo hold' | dpkg --root="$w/root" --set-selections
            cp root/var/lib/dpkg/status current
        else
            "$merger" lower2/var/lib/dpkg/status current lower1/var/lib/dpkg/status \
                "$w/$mode/var/lib/dpkg/info" base root/var/lib/dpkg/status "$w/root"
            test ! -e root/usr/share/doc/review-demo/README
            expected=2
            [ "$mode" != reinstall ] || expected=1
            test "$(cat root/usr/share/demo/version)" = "$expected"
            test "$(dpkg-query --admindir="$w/root/var/lib/dpkg" -W -f='${Version} ${Status}' review-demo)" = "$expected hold ok installed"
        fi
        umount root
    done
done

/* MiniOS Live Config dpkg status merger.
 *
 * Arguments: module snapshot, writable status, previous module baseline,
 * writable info directory, new baseline output, final status output.
 * The caller owns locking and atomic publication of the two temporary outputs.
 */
#define _POSIX_C_SOURCE 200809L
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

typedef struct { char *raw, *key; GHashTable *fields; } Record;
/* Perl's byte-oriented \s includes vertical tab; g_ascii_isspace does not. */
static gboolean whitespace(unsigned char c) {
    return c == ' ' || (c >= '\t' && c <= '\r');
}
static GHashTable *table(void) { return g_hash_table_new(g_str_hash, g_str_equal); }
static void record_free(gpointer data) {
    Record *r = data;
    g_hash_table_destroy(r->fields);
    g_free(r->raw);
    g_free(r->key);
    g_free(r);
}
static const char *field(Record *r, const char *name) {
    const char *s = r ? g_hash_table_lookup(r->fields, name) : NULL;
    return s ? s : "";
}
static void malformed(const char *path, int number, const char *message) {
    fprintf(stderr, "Malformed status paragraph %d in %s: %s\n", number, path, message);
    exit(1);
}
/* Missing optional snapshots and /dev/null mean an empty input. Other stat
 * errors must not silently discard writable state. */
static gboolean input_exists(const char *path, gboolean directory) {
    struct stat st;
    if (stat(path, &st) != 0) {
        if (errno == ENOENT) return FALSE;
        fprintf(stderr, "Cannot stat %s: %s\n", path, strerror(errno));
        exit(1);
    }
    return directory ? S_ISDIR(st.st_mode) : S_ISREG(st.st_mode);
}

static void finish_field(GHashTable *fields, char *key, GString *value) {
    if (key) g_hash_table_insert(fields, key, g_string_free(value, FALSE));
}

static Record *record(char *text, const char *path, int number, gboolean module) {
    Record *r = g_new0(Record, 1);
    size_t length = strlen(text);
    while (length && whitespace(text[length - 1])) length--;
    r->raw = g_strndup(text, length);
    r->fields = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);
    char **lines = g_strsplit(r->raw, "\n", -1);
    char *current = NULL;
    GString *current_value = NULL;
    for (int i = 0; lines[i]; i++) {
        char *line = lines[i], *colon = strchr(line, ':');
        gboolean valid = colon && colon > line && g_ascii_isalnum(*line);
        if (valid) {
            for (char *p = line; p < colon; p++)
                if (!g_ascii_isalnum(*p) && *p != '-') valid = FALSE;
        }
        if (valid) {
            finish_field(r->fields, current, current_value);
            current = g_ascii_strdown(line, colon - line);
            if (g_hash_table_contains(r->fields, current)) {
                char *msg = g_strdup_printf("duplicate %.*s field", (int)(colon-line), line);
                malformed(path, number, msg);
            }
            char *value = colon + 1;
            while (*value == ' ' || *value == '\t') value++;
            current_value = g_string_new(value);
        } else if (current && (*line == ' ' || *line == '\t')) {
            /* Amortized linear append, including very long Description fields. */
            g_string_append_c(current_value, '\n');
            g_string_append(current_value, line + 1);
        } else if (*line) {
            char *msg = g_strdup_printf("invalid line '%s'", line);
            malformed(path, number, msg);
        }
    }
    finish_field(r->fields, current, current_value);
    g_strfreev(lines);
    const char *required[] = {"package", "version"};
    gboolean needs_version = module && !strstr(field(r, "status"), "not-installed");
    for (int i = 0; i < (needs_version ? 2 : 1); i++) {
        const char *s = field(r, required[i]);
        while (whitespace(*s)) s++;
        if (!*s) malformed(path, number, i ? "missing or empty Version field" : "missing or empty Package field");
    }
    r->key = g_strconcat(field(r, "package"), "\037", field(r, "architecture"), NULL);
    return r;
}
static int order(unsigned char c) {
    if (c == '~') return -1;
    if (!c || g_ascii_isdigit(c)) return 0;
    return g_ascii_isalpha(c) ? c : c + 256;
}
static int verrevcmp(const char *a, const char *b) {
    while (*a || *b) {
        while ((*a && !g_ascii_isdigit(*a)) || (*b && !g_ascii_isdigit(*b))) {
            int d = order(*a) - order(*b);
            if (d) return d;
            if (*a) a++;
            if (*b) b++;
        }
        while (*a == '0') a++;
        while (*b == '0') b++;
        int first = 0;
        while (g_ascii_isdigit(*a) && g_ascii_isdigit(*b)) {
            if (!first) first = *a - *b;
            a++; b++;
        }
        if (g_ascii_isdigit(*a)) return 1;
        if (g_ascii_isdigit(*b)) return -1;
        if (first) return first;
    }
    return 0;
}
/* Match Dpkg::Version's validation at comparison time, including its permissive
 * revision character set. Single, un-compared module versions are left alone,
 * just as in the original helper. */
static void validate_version(const char *s) {
    const char *colon = strchr(s, ':');
    if (colon && !colon[1]) colon = NULL;
    const char *upstream = colon ? colon + 1 : s;
    const char *revision = strrchr(upstream, '-');
    gboolean valid = *s && g_ascii_isdigit(*upstream);
    if (colon) {
        if (colon == s) valid = FALSE;
        for (const char *p = s; p < colon; p++)
            if (!g_ascii_isdigit(*p)) valid = FALSE;
    }
    if (revision && !revision[1]) valid = FALSE;
    for (const char *p = s; *p; p++)
        if (!g_ascii_isalnum(*p) && !strchr("-+:.~", *p)) valid = FALSE;
    if (!valid) {
        fprintf(stderr, "%s is not a valid version\n", s);
        exit(1);
    }
}
static int version_compare(const char *left, const char *right) {
    validate_version(left);
    validate_version(right);
    char *a = g_strdup(left), *b = g_strdup(right);
    char *ac = strchr(a, ':'), *bc = strchr(b, ':');
    if (ac && !ac[1]) ac = NULL;
    if (bc && !bc[1]) bc = NULL;
    if (ac) *ac = '\0';
    if (bc) *bc = '\0';
    /* Compare decimal strings rather than overflowing machine integers. */
    int result = verrevcmp(ac ? a : "0", bc ? b : "0");
    if (!result) {
        char *av = ac ? ac + 1 : a, *bv = bc ? bc + 1 : b;
        char *ar = strrchr(av, '-'), *br = strrchr(bv, '-');
        if (ar) *ar++ = '\0';
        if (br) *br++ = '\0';
        result = verrevcmp(av, bv);
        if (!result) result = verrevcmp(ar ? ar : "0", br ? br : "0");
    }
    g_free(a); g_free(b);
    return result;
}
static GHashTable *parse(const char *path, gboolean module) {
    GHashTable *records = g_hash_table_new_full(g_str_hash, g_str_equal, NULL, record_free);
    if (!input_exists(path, FALSE)) return records;
    char *text;
    GError *error = NULL;
    gsize length;
    if (!g_file_get_contents(path, &text, &length, &error)) {
        fprintf(stderr, "Cannot read %s: %s\n", path, error->message); exit(1);
    }
    if (memchr(text, '\0', length)) {
        fprintf(stderr, "Cannot parse %s: embedded NUL byte\n", path);
        exit(1);
    }
    int number = 0;
    char *paragraph = text;
    while (paragraph) {
        /* Equivalent to splitting on /\n\s*\n/: a run of whitespace is
         * a separator only through its last newline, leaving any indentation
         * after that newline in the next paragraph. Work in-place, linearly. */
        char *next = NULL;
        for (char *p = paragraph; *p;) {
            if (*p != '\n') { p++; continue; }
            char *end = p + 1, *last_newline = p;
            while (whitespace(*end)) {
                if (*end == '\n') last_newline = end;
                end++;
            }
            if (last_newline != p) {
                *p = '\0';
                next = last_newline + 1;
                break;
            }
            p = end;
        }
        char *p = paragraph;
        while (whitespace(*p)) p++;
        if (*p) {
            Record *r = record(paragraph, path, ++number, module);
            Record *old = g_hash_table_lookup(records, r->key);
            if (!module || !old || version_compare(field(r, "version"), field(old, "version")) > 0)
                g_hash_table_replace(records, r->key, r);
            else
                record_free(r);
        }
        paragraph = next;
    }
    g_free(text);
    return records;
}
enum field_scope { ALL_FIELDS, EXCEPT_STATUS, EXCEPT_TRIGGER_STATE };
static gboolean same_fields(Record *a, Record *b, enum field_scope scope) {
    if (!a || !b) return FALSE;
    guint a_size = g_hash_table_size(a->fields), b_size = g_hash_table_size(b->fields);
    const char *ignored[] = {"status", "triggers-pending", "triggers-awaited", NULL};
    guint n = scope == EXCEPT_TRIGGER_STATE ? 3 : scope == EXCEPT_STATUS ? 1 : 0;
    for (guint i = 0; i < n; i++) {
        a_size -= g_hash_table_contains(a->fields, ignored[i]);
        b_size -= g_hash_table_contains(b->fields, ignored[i]);
    }
    ignored[n] = NULL;
    if (a_size != b_size) return FALSE;
    GHashTableIter it; gpointer key, value;
    g_hash_table_iter_init(&it, a->fields);
    while (g_hash_table_iter_next(&it, &key, &value)) {
        if (g_strv_contains(ignored, key)) continue;
        const char *other = g_hash_table_lookup(b->fields, key);
        if (!other || strcmp(value, other)) return FALSE;
    }
    return TRUE;
}
static gboolean same(Record *a, Record *b) { return same_fields(a, b, ALL_FIELDS); }

/* Interpret Status only when separating desired selection from actual package
 * state. Do not impose a new full-record schema on all existing input paths. */
static char **status_words(Record *r) {
    char **pieces = g_strsplit_set(field(r, "status"), " \t\r\n\v\f", -1);
    char **words = g_new0(char *, 4);
    guint count = 0;
    for (guint i = 0; pieces[i]; i++) {
        if (!*pieces[i]) continue;
        if (count == 3) { count++; break; }
        words[count++] = g_strdup(pieces[i]);
    }
    g_strfreev(pieces);
    if (count == 3 &&
        g_strv_contains((const char *[]) {"unknown", "install", "hold", "deinstall", "purge", NULL}, words[0]) &&
        g_strv_contains((const char *[]) {"ok", "reinstreq", NULL}, words[1]) &&
        g_strv_contains((const char *[]) {"not-installed", "config-files", "half-installed", "unpacked",
            "half-configured", "triggers-awaited", "triggers-pending", "installed", NULL}, words[2]))
        return words;
    g_strfreev(words);
    return NULL;
}
static gboolean actual_state_changed(Record *current, Record *previous) {
    char **cur = status_words(current), **old = status_words(previous);
    gboolean changed = cur && old && (strcmp(cur[1], old[1]) || strcmp(cur[2], old[2]));
    g_strfreev(cur); g_strfreev(old);
    return changed;
}
static Record *rewrite_state(Record *base, const char *selection, char **words,
                             const char *pending, const char *awaited) {
    GString *raw = g_string_new(NULL);
    char **lines = g_strsplit(base->raw, "\n", -1);
    gboolean skip_continuations = FALSE;
    for (guint i = 0; lines[i]; i++) {
        gboolean continuation = lines[i][0] == ' ' || lines[i][0] == '\t';
        if (continuation && skip_continuations) continue;
        if (pending && (!g_ascii_strncasecmp(lines[i], "Triggers-Pending:", 17) ||
                        !g_ascii_strncasecmp(lines[i], "Triggers-Awaited:", 17))) {
            skip_continuations = TRUE;
            continue;
        }
        if (raw->len) g_string_append_c(raw, '\n');
        if (!g_ascii_strncasecmp(lines[i], "Status:", 7)) {
            g_string_append_printf(raw, "Status: %s %s %s", selection, words[1], words[2]);
            skip_continuations = TRUE;
        } else {
            if (!continuation) skip_continuations = FALSE;
            g_string_append(raw, lines[i]);
        }
    }
    if (pending && *pending) g_string_append_printf(raw, "\nTriggers-Pending: %s", pending);
    if (awaited && *awaited) g_string_append_printf(raw, "\nTriggers-Awaited: %s", awaited);
    Record *result = record(raw->str, "generated selection override", 1, FALSE);
    g_strfreev(lines); g_string_free(raw, TRUE);
    return result;
}
/* TRUE also covers formatting-only Status differences, and selection changes
 * dropped because the package no longer exists in the mounted module set. */
static gboolean merge_selection(Record *current, Record *previous, Record *next, gboolean info, Record **result) {
    *result = NULL;
    char **cur = status_words(current), **old = status_words(previous);
    /* dpkg --set-selections may have created just a selection before the
     * first module supplying the package was mounted. */
    gboolean residual = next && !previous && cur && !strcmp(cur[1], "ok") &&
        !strcmp(cur[2], "not-installed") && !*field(current, "version");
    /* 12.0.0 could carry the entire obsolete module version for a hold.
     * Preserve its selection when replacing that stale metadata, but never
     * replace a local install evidenced by writable package files. */
    gboolean stale = cur && old && !info && strcmp(cur[0], old[0]) &&
        strcmp(field(current, "version"), field(previous, "version")) &&
        !strcmp(field(current, "triggers-awaited"), field(previous, "triggers-awaited")) &&
        !strcmp(field(current, "triggers-pending"), field(previous, "triggers-pending"));
    gboolean selection_only = residual || (cur && old &&
        !strcmp(cur[1], old[1]) && !strcmp(cur[2], old[2]) &&
        (stale || same_fields(current, previous, EXCEPT_STATUS)));
    if (selection_only && next && (residual || strcmp(cur[0], old[0]))) {
        char **base = status_words(next);
        if (base) *result = rewrite_state(next, cur[0], base, NULL, NULL);
        else selection_only = FALSE;
        g_strfreev(base);
    }
    g_strfreev(cur); g_strfreev(old);
    return selection_only;
}
/* Replay local additions/removals, retaining newly supplied module triggers. */
static char *trigger_queue(Record *current, Record *old, Record *next, const char *name) {
    char **c = g_strsplit_set(field(current,name), " \t\n", -1);
    char **o = g_strsplit_set(field(old,name), " \t\n", -1);
    char **n = g_strsplit_set(field(next,name), " \t\n", -1);
    GString *out = g_string_new(NULL);
    GHashTable *seen = table();
    for (int i = 0; i < 2; ++i) {
        for (char **p = i ? c : n; *p; ++p) {
            if (!**p || (g_strv_contains((const char *const *)o, *p) &&
                         (i || !g_strv_contains((const char *const *)c, *p)))) continue;
            if (g_hash_table_add(seen, *p)) {
                if (out->len) g_string_append_c(out, ' ');
                g_string_append(out, *p);
            }
        }
    }
    g_hash_table_destroy(seen);
    g_strfreev(c); g_strfreev(o); g_strfreev(n);
    return g_string_free(out, FALSE);
}
static gboolean installed_state(char **words) {
    return words && (!strcmp(words[2], "installed") || g_str_has_prefix(words[2], "triggers-"));
}
static gboolean merge_triggers(Record *r, Record *old, Record *next, gboolean info, Record **result) {
    if (!old || (!strcmp(field(r,"triggers-pending"), field(old,"triggers-pending")) &&
                 !strcmp(field(r,"triggers-awaited"), field(old,"triggers-awaited")))) return FALSE;
    /* An info file alone can be an unchanged copy-up. Preserve a full
     * writable override when package metadata also differs from baseline. */
    if (info && !same_fields(r, old, EXCEPT_TRIGGER_STATE)) return FALSE;
    char **cur = status_words(r), **prev = status_words(old), **base = status_words(next);
    gboolean handled = installed_state(cur) && installed_state(prev) && !strcmp(cur[1], prev[1]);
    if (handled && installed_state(base)) {
        char *p = trigger_queue(r,old,next,"triggers-pending");
        char *a = trigger_queue(r,old,next,"triggers-awaited");
        char *words[] = {base[0], base[1], *a ? "triggers-awaited" : *p ? "triggers-pending" : "installed"};
        *result = rewrite_state(next, strcmp(cur[0],prev[0]) ? cur[0] : base[0], words, p, a);
        g_free(p); g_free(a);
    }
    g_strfreev(cur); g_strfreev(prev); g_strfreev(base);
    return handled;
}
static void index_directory(GHashTable *index, const char *path, GPtrArray *dirs) {
    if (!input_exists(path, TRUE)) return;
    g_ptr_array_add(dirs, g_strdup(path));
    GError *error = NULL;
    GDir *dir = g_dir_open(path, 0, &error);
    if (!dir) {
        fprintf(stderr, "Cannot read directory %s: %s\n", path, error->message);
        exit(1);
    }
    const char *name;
    while ((name = g_dir_read_name(dir))) {
        if (g_str_has_prefix(name, ".wh.")) name += 4;
        /* Package names themselves may contain dots. Strip a recognized
         * terminal metadata suffix, never every dotted prefix of a filename. */
        static const char *suffixes[] = {
            ".list", ".md5sums", ".conffiles", ".preinst", ".postinst", ".prerm", ".postrm",
            ".triggers", ".shlibs", ".symbols", ".config", ".templates", ".extrafiles"
        };
        for (guint i = 0; i < G_N_ELEMENTS(suffixes); i++) {
            size_t suffix_len = strlen(suffixes[i]), name_len = strlen(name);
            if (name_len > suffix_len && g_str_has_suffix(name, suffixes[i])) {
                g_hash_table_add(index, g_strndup(name, name_len - suffix_len + 1));
                break;
            }
        }
    }
    g_dir_close(dir);
}
static GHashTable *info_index(const char *path, GPtrArray *dirs) {
    GHashTable *index = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
    if (input_exists(path, TRUE)) index_directory(index, path, dirs);
    else if (input_exists(path, FALSE)) {
        /* The frontend supplies NUL-delimited paths for writable plus restored
         * persistence layers. Package modules themselves never prove a local edit. */
        char *data; gsize size; GError *error = NULL;
        if (!g_file_get_contents(path, &data, &size, &error)) {
            fprintf(stderr, "Cannot read info directory inventory: %s\n", error->message); exit(1);
        }
        if (size && data[size - 1]) {
            fprintf(stderr, "Invalid info directory inventory\n"); exit(1);
        }
        for (gsize offset = 0; offset < size; offset += strlen(data + offset) + 1)
            index_directory(index, data + offset, dirs);
        g_free(data);
    }
    return index;
}
/* A selection and a copied-up .list alone do not own the module's files.
 * Reinstalling a .deb with payload leaves its md5sums and the corresponding
 * regular files together in the writable layer. Only probe on replacement. */
static gboolean local_payload(GPtrArray *dirs, Record *r, const char *merged_root) {
    const char *pkg = field(r, "package"), *arch = field(r, "architecture");
    if (strchr(pkg, '/') || strchr(arch, '/')) return FALSE;
    for (guint i = 0; i < dirs->len; i++) {
        const char *dir = g_ptr_array_index(dirs, i);
        const char *suffix = "/var/lib/dpkg/info";
        if (!g_str_has_suffix(dir, suffix)) continue;
        g_autofree char *root = g_strndup(dir, strlen(dir) - strlen(suffix));
        g_autofree char *name = !strcmp(field(r,"multi-arch"),"same")
            ? g_strdup_printf("%s:%s.md5sums", pkg, arch) : g_strdup_printf("%s.md5sums", pkg);
        g_autofree char *manifest = g_build_filename(dir, name, NULL);
        struct stat st;
        if (lstat(manifest, &st) || !S_ISREG(st.st_mode)) continue;
        g_autofree char *data = NULL;
        GError *error = NULL;
        if (!g_file_get_contents(manifest, &data, NULL, &error)) {
            fprintf(stderr, "Cannot read %s: %s\n", manifest, error->message); exit(1);
        }
        g_auto(GStrv) lines = g_strsplit(data, "\n", -1);
        gboolean found = FALSE;
        for (char **p = lines; *p; p++) {
            if (!**p) continue;
            const char *line = *p;
            size_t n = strspn(line, "0123456789abcdefABCDEF");
            if (n != 32 || strncmp(line+n, "  ", 2)) { found = FALSE; break; }
            const char *rel = line+n+2;
            if (!*rel || *rel == '/' || g_str_has_prefix(rel, "../") || strstr(rel, "/../")) {
                found = FALSE; break;
            }
            g_autofree char *file = g_build_filename(*root ? root : "/", rel, NULL);
            if (lstat(file, &st)) {
                if (errno == ENOENT) {
                    /* dpkg lists path-excluded files even in .list. Ignore
                     * absent payload, but not files provided by a lower. */
                    g_autofree char *visible = g_build_filename(merged_root, rel, NULL);
                    if (lstat(visible, &st) && errno == ENOENT) continue;
                }
                found = FALSE; break;
            }
            if (!S_ISREG(st.st_mode)) { found = FALSE; break; }
            found = TRUE;
        }
        if (found) return TRUE;
    }
    return FALSE;
}
static gboolean local_info(GHashTable *index, Record *r) {
    char *plain = g_strconcat(field(r, "package"), ".", NULL);
    char *arch = g_strconcat(field(r, "package"), ":", field(r, "architecture"), ".", NULL);
    gboolean found = g_hash_table_contains(index, plain)
        || (*field(r, "architecture") && g_hash_table_contains(index, arch));
    g_free(plain); g_free(arch);
    return found;
}
static void write_status(const char *path, GHashTable *records) {
    FILE *f = fopen(path, "w");
    if (!f) { perror(path); exit(1); }
    GList *keys = g_list_sort(g_hash_table_get_keys(records), (GCompareFunc)strcmp);
    for (GList *p = keys; p; p = p->next) {
        Record *r = g_hash_table_lookup(records, p->data);
        if (fprintf(f, "%s\n\n", r->raw) < 0) { perror(path); exit(1); }
    }
    if (fclose(f)) { perror(path); exit(1); }
    g_list_free(keys);
}
int main(int argc, char **argv) {
    if (argc != 7 && argc != 8) {
        fprintf(stderr, "Usage: %s MODULE_STATUS CURRENT_STATUS PREVIOUS_BASE CHANGES_INFO BASE_OUT FINAL_OUT [MERGED_ROOT]\n", argv[0]);
        return 1;
    }
    GHashTable *base = parse(argv[1], TRUE), *current = parse(argv[2], FALSE);
    gboolean has_previous = input_exists(argv[3], FALSE);
    GPtrArray *dirs = g_ptr_array_new_with_free_func(g_free);
    GHashTable *previous = parse(argv[3], FALSE), *info = info_index(argv[4], dirs);
    GHashTable *final = table();
    GPtrArray *selections = g_ptr_array_new_with_free_func(record_free);
    GHashTableIter it; gpointer key, value;
    g_hash_table_iter_init(&it, base);
    while (g_hash_table_iter_next(&it, &key, &value)) g_hash_table_insert(final, key, value);
    /* A writable status may itself be yesterday's merged output. Compare
     * against yesterday's module-only baseline to distinguish local changes
     * from stale records left by a detached module. Only an absent baseline
     * (including /dev/null) selects bootstrap rules. A regular empty file is
     * an authoritative previous state with no module packages. */
    GHashTable *reference = has_previous ? previous : base;
    g_hash_table_iter_init(&it, current);
    while (g_hash_table_iter_next(&it, &key, &value)) {
        Record *r = value, *old = g_hash_table_lookup(reference, key);
        Record *selected = NULL;
        gboolean info_present = local_info(info, r);
        Record *next = g_hash_table_lookup(base, key);
        if (info_present && old && !same(old, next) && local_payload(dirs, r, argc == 8 ? argv[7] : "/")) {
            g_hash_table_insert(final, key, r);
            continue;
        }
        if (same(r, old)) continue;
        if (merge_triggers(r, old, next, info_present, &selected) ||
            merge_selection(r, old, next, info_present, &selected)) {
            if (selected) {
                g_ptr_array_add(selections, selected);
                g_hash_table_insert(final, selected->key, selected);
            }
            continue;
        }
        /* Selections for absent packages and outstanding trigger work can
         * exist entirely in status, without a writable info file. */
        char **words = has_previous && !old ? status_words(r) : NULL;
        gboolean status_only = words && (strcmp(words[2], "installed") || strcmp(words[1], "ok"));
        g_strfreev(words);
        if (info_present || status_only ||
            (old && (actual_state_changed(r, old) ||
                strcmp(field(r, "triggers-pending"), field(old, "triggers-pending")) ||
                strcmp(field(r, "triggers-awaited"), field(old, "triggers-awaited")))) ||
            (old && !strcmp(field(r, "version"), field(old, "version")) && same_fields(r, old, EXCEPT_STATUS)))
            g_hash_table_insert(final, key, r);
    }
    g_hash_table_iter_init(&it, reference);
    while (g_hash_table_iter_next(&it, &key, &value))
        if (!g_hash_table_contains(current, key) && (has_previous || local_info(info, value)))
            g_hash_table_remove(final, key);
    write_status(argv[5], base);
    write_status(argv[6], final);
    g_hash_table_destroy(final); /* Borrowed keys and records. */
    g_ptr_array_free(selections, TRUE);
    g_hash_table_destroy(info);
    g_ptr_array_free(dirs, TRUE);
    g_hash_table_destroy(previous);
    g_hash_table_destroy(current);
    g_hash_table_destroy(base);
    return 0;
}

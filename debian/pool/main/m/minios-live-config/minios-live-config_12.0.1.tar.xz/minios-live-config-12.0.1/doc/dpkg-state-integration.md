# Module status integration contract

| Producer / consumer | Responsibility |
| --- | --- |
| minios-live build-live | Export core through a private overlay against an empty baseline; preserve mutable core status |
| minios-live build-modules | Prepare full build status from selected lower modules, retain initial baseline, pack unmounted upper before compression |
| Kernel runtime module | No /var/lib/dpkg; installer metadata under usr/share/minios/kernel-dpkg is a separate format |
| apt2sb / script2sb / chroot2sb | Prepare selected lower chain before package operations; savechanges exports private stage |
| savechanges module export | Pack captured status against its captured build/module baseline |
| Persistence changes.sb | Preserve complete status and runtime baseline; never pack |
| dir2sb | Require already prepared module metadata; refuse raw status without an explicit preceding pack operation |
| Store / Module Manager | Delegate to minios-tools, with no separate status implementation |
| Image Builder | Delegates captures to savechanges; raw customization overlays must not contain monolithic status |
| live-config | Compose before package-aware boot components, then reconcile against writable status and previous baseline |
| Installer BundleOverlay | Materialize a clean status from the selected module roots before native-install preflight and copy, including the copy fallback |
| sb activation | Refresh full runtime status after branch changes |

Existing modules must be rebuilt; there is no compatibility loader. The
minios-dpkg-state package built by minios-live-config must be available on build hosts and in the core image
before rebuilding a complete module chain. Publishing old producers together
with the new consumer is not supported. Kernel installer records remain
independent and must not be converted into this format. Native installation
from module roots materializes its own clean full status, without session changes.

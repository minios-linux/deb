import subprocess
from pathlib import Path

import pytest


COMPONENT = Path(__file__).parents[1] / "components" / "0045-user-media"


def run_function(function, setup="", args=""):
    source = COMPONENT.read_text(encoding="utf-8")
    source = source.replace(". /usr/lib/live/config.sh\n", "")
    source = source.rsplit("\nCmdline\nInit\nConfig\n", 1)[0]
    script = "{}\n{}\n{} {}\n".format(source, setup, function, args)
    return subprocess.run(
        ["sh"], input=script, text=True, capture_output=True, check=False
    )


@pytest.mark.parametrize("value", ["/minios/userdata", "minios/userdata", "userdata"])
def test_normalize_path_accepts_media_relative_paths(value):
    result = run_function("normalize_path", args="'{}'".format(value))
    assert result.returncode == 0
    assert result.stdout.strip() == value.lstrip("/")


@pytest.mark.parametrize("value", ["/", "../data", "/minios/../data", "/minios//data", "/minios/./data"])
def test_normalize_path_rejects_escaping_or_ambiguous_paths(value):
    result = run_function("normalize_path", args="'{}'".format(value))
    assert result.returncode != 0


@pytest.mark.parametrize("token", ["toram", "toram=full", "toram=trim"])
def test_cmdline_recognizes_every_supported_toram_mode(token):
    result = run_function(
        "Cmdline; printf '%s' \"$TORAM\"",
        setup="LIVE_CONFIG_CMDLINE='{}'".format(token),
    )
    assert result.returncode == 0
    assert result.stdout == "true"


def test_cmdline_does_not_accept_a_toram_prefix_lookalike():
    result = run_function(
        "Cmdline; printf '%s' \"$TORAM\"",
        setup="LIVE_CONFIG_CMDLINE='torambo'",
    )
    assert result.returncode == 0
    assert result.stdout == "false"


def test_cmdline_reads_user_dirs_path_value():
    result = run_function(
        "Cmdline; printf '%s' \"$LIVE_USER_DIRS_PATH\"",
        setup="LIVE_CONFIG_CMDLINE='user-dirs-path=/minios/private'",
    )
    assert result.returncode == 0
    assert result.stdout == "/minios/private"

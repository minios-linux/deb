import subprocess
from pathlib import Path


ROOT = Path(__file__).parents[1]


def test_config_cmdline_is_loaded_and_exported(tmp_path):
    config = tmp_path / "config.conf"
    config.write_text("LIVE_CONFIG_CMDLINE='components noautologin'\n", encoding="utf-8")
    script = (ROOT / "frontend" / "init-config.sh").read_text(encoding="utf-8")
    script = script.replace(
        "/etc/live/config.conf /etc/live/config.conf.d/*.conf",
        str(config),
    )
    script += "\nprintf '%s' \"$LIVE_CONFIG_CMDLINE\"\n"
    result = subprocess.run(
        ["sh"], input=script, text=True, capture_output=True, check=False
    )
    assert result.returncode == 0
    assert result.stdout == "components noautologin"


def test_every_autologin_component_accepts_config_cmdline_token():
    components = (
        "0080-gdm3",
        "0085-sddm",
        "0090-kdm",
        "0100-lightdm",
        "0110-lxdm",
        "0120-nodm",
        "0130-slim",
        "0140-xinit",
        "0160-sysvinit",
    )
    for name in components:
        source = (ROOT / "components" / name).read_text(encoding="utf-8")
        assert "live-config.noautologin|noautologin)" in source
        assert 'LIVE_CONFIG_NOAUTOLOGIN="true"' in source

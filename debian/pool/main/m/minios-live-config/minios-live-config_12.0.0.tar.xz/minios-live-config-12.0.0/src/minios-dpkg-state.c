/* SPDX-License-Identifier: GPL-3.0-or-later
 * MiniOS Live Config module-only dpkg state. Runtime status is a normal file.
 */
#define _GNU_SOURCE
#define _FILE_OFFSET_BITS 64
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

#define FORMAT "minios-dpkg-state 1\n"
#define DB "var/lib/dpkg"
typedef struct { char *text, *key; GHashTable *fields; } Record;

static void die(const char *format, ...) G_GNUC_NORETURN G_GNUC_PRINTF(1, 2);
static void die(const char *format, ...) {
    va_list ap;
    va_start(ap, format);
    fputs("minios-dpkg-state: ", stderr);
    vfprintf(stderr, format, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}
static gboolean space(unsigned char c) { return c == ' ' || (c >= '\t' && c <= '\r'); }
static const char *get(Record *r, const char *key) {
    const char *v = g_hash_table_lookup(r->fields, key);
    return v ? v : "";
}
static void free_record(gpointer p) {
    Record *r = p;
    g_free(r->text); g_free(r->key); g_hash_table_destroy(r->fields); g_free(r);
}
static GHashTable *records(void) {
    return g_hash_table_new_full(g_str_hash, g_str_equal, NULL, free_record);
}
static int kind(const char *path) {
    struct stat st;
    if (lstat(path, &st)) {
        if (errno == ENOENT) return 0;
        die("cannot stat %s: %s", path, strerror(errno));
    }
    if (S_ISREG(st.st_mode)) return 1;
    if (S_ISDIR(st.st_mode)) return 2;
    die("not a regular file or directory: %s", path);
}
static void check_db_path(const char *root) {
    struct stat st;
    if (stat(root, &st) || !S_ISDIR(st.st_mode)) die("module/build root is not a directory: %s", root);
    const char *parts[] = {"var", "var/lib", DB};
    for (size_t i = 0; i < G_N_ELEMENTS(parts); i++) {
        char *p = g_build_filename(root, parts[i], NULL);
        int type = kind(p);
        if (type && type != 2) die("not a directory: %s", p);
        g_free(p);
        if (!type) break;
    }
}
static char *read_file(const char *path) {
    int fd = open(path, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) die("cannot read %s: %s", path, strerror(errno));
    struct stat st;
    if (fstat(fd, &st) || !S_ISREG(st.st_mode)) die("not a regular file: %s", path);
    GString *s = g_string_new(NULL);
    char buf[16384];
    ssize_t n;
    while ((n = read(fd, buf, sizeof(buf))) != 0) {
        if (n < 0) {
            if (errno == EINTR) continue;
            die("cannot read %s: %s", path, strerror(errno));
        }
        if (memchr(buf, 0, (size_t)n)) die("NUL byte in %s", path);
        g_string_append_len(s, buf, n);
    }
    if (close(fd)) die("cannot close %s", path);
    return g_string_free(s, FALSE);
}
static void field_finish(Record *r, char *name, GString *value) {
    if (name) g_hash_table_insert(r->fields, name, g_string_free(value, FALSE));
}
static Record *parse_record(const char *text, const char *path) {
    Record *r = g_new0(Record, 1);
    size_t len = strlen(text);
    while (len && space(text[len - 1])) len--;
    r->text = g_strndup(text, len);
    r->fields = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);
    char **lines = g_strsplit(r->text, "\n", -1), *name = NULL;
    GString *value = NULL;
    for (size_t i = 0; lines[i]; i++) {
        char *line = lines[i], *colon = strchr(line, ':');
        if (*line == ' ' || *line == '\t') {
            if (!name) die("continuation before field in %s", path);
            g_string_append_c(value, '\n'); g_string_append(value, line + 1);
            continue;
        }
        if (!colon || colon == line) die("invalid field in %s", path);
        for (char *p = line; p < colon; p++)
            if (!g_ascii_isalnum(*p) && *p != '-') die("invalid field name in %s", path);
        field_finish(r, name, value);
        name = g_ascii_strdown(line, colon - line);
        if (g_hash_table_contains(r->fields, name)) die("duplicate field %s in %s", name, path);
        char *start = colon + 1;
        if (space(*start)) start++;
        value = g_string_new(start);
    }
    field_finish(r, name, value);
    g_strfreev(lines);
    const char *pkg = get(r, "package"), *arch = get(r, "architecture");
    if (!*pkg || !(g_ascii_islower(*pkg) || g_ascii_isdigit(*pkg))) die("invalid Package in %s", path);
    for (const char *p = pkg; *p; p++)
        if (!g_ascii_islower(*p) && !g_ascii_isdigit(*p) && !strchr("+.-", *p)) die("invalid Package in %s", path);
    for (const char *p = arch; *p; p++)
        if (!g_ascii_islower(*p) && !g_ascii_isdigit(*p) && *p != '-') die("invalid Architecture in %s", path);
    /* Empty architecture is retained for legitimate residual dpkg records. */
    r->key = g_strconcat(pkg, ":", arch, NULL);
    return r;
}
static GHashTable *parse_text(char *text, const char *path) {
    GHashTable *table = records();
    char *paragraph = text;
    while (paragraph) {
        char *next = NULL;
        for (char *p = paragraph; *p;) {
            if (*p != '\n') { p++; continue; }
            char *end = p + 1, *last = p;
            while (space(*end)) { if (*end == '\n') last = end; end++; }
            if (last != p) { *p = 0; next = last + 1; break; }
            p = end;
        }
        char *p = paragraph;
        while (space(*p)) p++;
        if (*p) {
            Record *r = parse_record(paragraph, path);
            if (g_hash_table_contains(table, r->key)) die("duplicate package %s in %s", r->key, path);
            g_hash_table_insert(table, r->key, r);
        }
        paragraph = next;
    }
    return table;
}
static GHashTable *load(const char *path) {
    if (!strcmp(path, "/dev/null")) return records();
    char *text = read_file(path);
    GHashTable *table = parse_text(text, path);
    g_free(text);
    return table;
}
static gboolean equal(Record *a, Record *b) {
    if (!a || !b || g_hash_table_size(a->fields) != g_hash_table_size(b->fields)) return FALSE;
    GHashTableIter iter; gpointer key, value;
    g_hash_table_iter_init(&iter, a->fields);
    while (g_hash_table_iter_next(&iter, &key, &value))
        if (g_strcmp0(value, g_hash_table_lookup(b->fields, key))) return FALSE;
    return TRUE;
}
static void sync_dir(const char *path) {
    int fd = open(path, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (fd < 0 || fsync(fd)) die("cannot sync directory %s: %s", path, strerror(errno));
    close(fd);
}
static void write_atomic(const char *path, const char *data) {
    char *tmp = g_strconcat(path, ".tmp.XXXXXX", NULL);
    int fd = g_mkstemp_full(tmp, O_RDWR | O_CLOEXEC, 0644);
    if (fd < 0) die("cannot create %s: %s", tmp, strerror(errno));
    FILE *out = fdopen(fd, "w");
    if (!out || fputs(data, out) == EOF || fflush(out) || fsync(fd) || fclose(out)) {
        unlink(tmp); die("cannot write %s: %s", path, strerror(errno));
    }
    if (rename(tmp, path)) { unlink(tmp); die("cannot publish %s: %s", path, strerror(errno)); }
    char *parent = g_path_get_dirname(path);
    sync_dir(parent); g_free(parent); g_free(tmp);
}
static void output(const char *path, GHashTable *table) {
    GString *text = g_string_new(NULL);
    GList *keys = g_list_sort(g_hash_table_get_keys(table), (GCompareFunc)strcmp);
    for (GList *p = keys; p; p = p->next) {
        Record *r = g_hash_table_lookup(table, p->data);
        g_string_append(text, r->text); g_string_append(text, "\n\n");
    }
    write_atomic(path, text->str);
    g_list_free(keys); g_string_free(text, TRUE);
}
static char *filename(Record *r) {
    return g_compute_checksum_for_string(G_CHECKSUM_SHA256, r->key, -1);
}
static void put_record(const char *dir, const char *subdir, Record *r) {
    char *name = filename(r), *path = g_build_filename(dir, subdir, name, NULL);
    char *text = g_strconcat(r->text, "\n\n", NULL);
    write_atomic(path, text);
    g_free(text); g_free(path); g_free(name);
}
static void split(const char *before_path, const char *after_path, const char *dir) {
    GHashTable *before = load(before_path), *after = load(after_path);
    /* Never overwrite an existing format directory; callers own private staging. */
    if (mkdir(dir, 0755)) die("cannot create new directory %s: %s", dir, strerror(errno));
    char *record_dir = g_build_filename(dir, "records", NULL), *removed_dir = g_build_filename(dir, "removed", NULL);
    if (mkdir(record_dir, 0755) || mkdir(removed_dir, 0755)) die("cannot create record directories in %s", dir);
    GHashTableIter it; gpointer key, value;
    g_hash_table_iter_init(&it, after);
    while (g_hash_table_iter_next(&it, &key, &value))
        if (!equal(value, g_hash_table_lookup(before, key))) put_record(dir, "records", value);
    g_hash_table_iter_init(&it, before);
    while (g_hash_table_iter_next(&it, &key, &value))
        if (!g_hash_table_contains(after, key)) put_record(dir, "removed", value);
    char *format = g_build_filename(dir, "format", NULL);
    write_atomic(format, FORMAT); /* Last: incomplete directories are not valid modules. */
    g_free(format); g_free(record_dir); g_free(removed_dir);
    g_hash_table_destroy(before); g_hash_table_destroy(after);
}
static GHashTable *load_records_dir(const char *path) {
    if (kind(path) != 2) die("missing record directory %s", path);
    GError *error = NULL;
    GDir *dir = g_dir_open(path, 0, &error);
    if (!dir) die("cannot open %s: %s", path, error->message);
    GHashTable *result = records();
    const char *name;
    while ((name = g_dir_read_name(dir))) {
        char *file = g_build_filename(path, name, NULL);
        GHashTable *one = load(file);
        if (g_hash_table_size(one) != 1) die("expected exactly one record in %s", file);
        GHashTableIter it; gpointer key, value;
        g_hash_table_iter_init(&it, one); g_hash_table_iter_next(&it, &key, &value);
        char *expected = filename(value);
        if (strcmp(name, expected)) die("record filename does not match identity in %s", file);
        g_hash_table_iter_steal(&it);
        g_hash_table_insert(result, key, value);
        g_free(expected); g_hash_table_destroy(one); g_free(file);
    }
    g_dir_close(dir);
    return result;
}
static void apply_module(GHashTable *state, const char *root) {
    check_db_path(root);
    char *db = g_build_filename(root, DB, NULL), *legacy = g_build_filename(db, "status", NULL);
    if (kind(legacy)) die("legacy module status is forbidden: %s; rebuild the module", legacy);
    const char *reserved[] = {"status-old", ".wh.status", ".wh.status-old", ".minios-build", ".minios-merge"};
    for (size_t i = 0; i < G_N_ELEMENTS(reserved); i++) {
        char *path = g_build_filename(db, reserved[i], NULL);
        if (kind(path)) die("runtime/build dpkg state must not be shipped in a module: %s", path);
        g_free(path);
    }
    char *dir = g_build_filename(db, "status.d", NULL);
    if (!kind(dir)) { g_free(db); g_free(legacy); g_free(dir); return; }
    if (kind(dir) != 2) die("invalid status.d: %s", dir);
    GDir *entries = g_dir_open(dir, 0, NULL);
    if (!entries) die("cannot open %s", dir);
    const char *entry;
    while ((entry = g_dir_read_name(entries)))
        if (strcmp(entry, "format") && strcmp(entry, "records") && strcmp(entry, "removed"))
            die("unknown status.d entry %s/%s", dir, entry);
    g_dir_close(entries);
    char *format_path = g_build_filename(dir, "format", NULL), *format = read_file(format_path);
    if (strcmp(format, FORMAT)) die("unsupported module status format in %s", dir);
    char *rp = g_build_filename(dir, "records", NULL), *dp = g_build_filename(dir, "removed", NULL);
    GHashTable *set = load_records_dir(rp), *removed = load_records_dir(dp);
    GHashTableIter it; gpointer key, value;
    g_hash_table_iter_init(&it, removed);
    while (g_hash_table_iter_next(&it, &key, &value)) {
        if (g_hash_table_contains(set, key)) die("record both replaced and removed: %s", (char *)key);
        g_hash_table_remove(state, key);
    }
    g_hash_table_iter_init(&it, set);
    while (g_hash_table_iter_next(&it, &key, &value)) {
        g_hash_table_iter_steal(&it);
        g_hash_table_replace(state, key, value);
    }
    g_hash_table_destroy(set); g_hash_table_destroy(removed);
    g_free(db); g_free(legacy); g_free(dir); g_free(format_path); g_free(format); g_free(rp); g_free(dp);
}
static GHashTable *compose(int count, char **roots) {
    GHashTable *state = records();
    for (int i = 0; i < count; i++) apply_module(state, roots[i]);
    return state;
}
static void remove_tree(const char *path) {
    int type = kind(path);
    if (!type) return;
    if (type == 1) { if (unlink(path)) die("cannot remove %s", path); return; }
    GDir *dir = g_dir_open(path, 0, NULL);
    if (!dir) die("cannot open %s", path);
    const char *name;
    while ((name = g_dir_read_name(dir))) {
        char *child = g_build_filename(path, name, NULL);
        remove_tree(child); g_free(child);
    }
    g_dir_close(dir);
    if (rmdir(path)) die("cannot remove %s", path);
}
static void prepare(const char *root, int count, char **roots) {
    check_db_path(root);
    char *db = g_build_filename(root, DB, NULL), *status = g_build_filename(db, "status", NULL);
    char *build = g_build_filename(db, ".minios-build", NULL), *base = g_build_filename(build, "status.base", NULL);
    if (kind(build) && kind(build) != 2) die("invalid build baseline directory %s", build);
    if (kind(base)) { /* Resuming the same build keeps its original baseline. */
        if (kind(base) != 1 || kind(status) != 1) die("incomplete build state in %s", root);
        g_free(db); g_free(status); g_free(build); g_free(base);
        return;
    }
    if (g_mkdir_with_parents(build, 0755)) die("cannot create %s", build);
    if (!kind(status) && !count) die("no build status or lower modules for %s", root);
    GHashTable *state = kind(status) ? load(status) : compose(count, roots);
    output(status, state); output(base, state);
    g_hash_table_destroy(state); g_free(db); g_free(status); g_free(build); g_free(base);
}
static void prepare_lowers(const char *root, const char *list) {
    char **parts = g_strsplit(list, ":", -1);
    GPtrArray *roots = g_ptr_array_new();
    for (int i = (int)g_strv_length(parts) - 1; i >= 0; i--) {
        if (g_str_has_suffix(parts[i], "=ro")) parts[i][strlen(parts[i]) - 3] = 0;
        if (!*parts[i]) die("empty lower module path");
        g_ptr_array_add(roots, parts[i]);
    }
    prepare(root, (int)roots->len, (char **)roots->pdata);
    g_ptr_array_free(roots, TRUE); g_strfreev(parts);
}
static void pack(const char *root, const char *explicit_base) {
    check_db_path(root);
    char *db = g_build_filename(root, DB, NULL), *status = g_build_filename(db, "status", NULL);
    if (!kind(status)) {
        GHashTable *state = records(); apply_module(state, root); g_hash_table_destroy(state);
        g_free(db); g_free(status); return;
    }
    char *updates = g_build_filename(db, "updates", NULL);
    if (kind(updates)) {
        if (kind(updates) != 2) die("invalid dpkg updates directory: %s", updates);
        GDir *dir = g_dir_open(updates, 0, NULL);
        if (!dir) die("cannot open %s", updates);
        const char *name;
        while ((name = g_dir_read_name(dir)))
            if (g_ascii_isdigit(*name)) die("pending dpkg updates in %s; complete the transaction before exporting", updates);
        g_dir_close(dir);
    }
    g_free(updates);
    char *build = g_build_filename(db, ".minios-build", NULL), *base = g_build_filename(build, "status.base", NULL);
    char *merge = g_build_filename(db, ".minios-merge", NULL), *merge_base = g_build_filename(merge, "status.base", NULL);
    if (kind(build) && kind(build) != 2) die("invalid build baseline directory %s", build);
    if (kind(merge) && kind(merge) != 2) die("invalid module baseline directory %s", merge);
    const char *before = explicit_base ? explicit_base : kind(base) ? base : kind(merge_base) ? merge_base : NULL;
    if (!before) die("missing build baseline for %s; supply BEFORE explicitly", root);
    char *target = g_build_filename(db, "status.d", NULL), *tmp = g_strconcat(target, ".new.XXXXXX", NULL);
    /* Reserve a unique name, then split creates the directory itself. */
    int fd = g_mkstemp(tmp);
    if (fd < 0) die("cannot reserve %s", tmp);
    close(fd); unlink(tmp);
    split(before, status, tmp);
    remove_tree(target);
    if (rename(tmp, target)) die("cannot publish %s", target);
    if (unlink(status)) die("cannot remove packaged monolithic status %s", status);
    char *old = g_build_filename(db, "status-old", NULL);
    remove_tree(old); remove_tree(build); remove_tree(merge); sync_dir(db);
    g_free(old); g_free(target); g_free(tmp); g_free(db); g_free(status);
    g_free(build); g_free(base); g_free(merge); g_free(merge_base);
}
static void locked(const char *root, char **command) {
    check_db_path(root);
    const char *names[] = {"lock-frontend", "lock"};
    for (size_t i = 0; i < G_N_ELEMENTS(names); i++) {
        char *path = g_build_filename(root, DB, names[i], NULL);
        int fd = open(path, O_RDWR | O_CREAT | O_NOFOLLOW, 0660);
        if (fd < 0) die("cannot open lock %s: %s", path, strerror(errno));
        struct flock lock = {.l_type = F_WRLCK, .l_whence = SEEK_SET};
        /* Linux OFD locks conflict with dpkg's POSIX locks and survive exec.
         * Keep descriptors high so the frontend's own fd 9 cannot replace one. */
        int held = fcntl(fd, F_DUPFD, 64);
        close(fd);
        if (held < 0) die("cannot retain lock %s: %s", path, strerror(errno));
        if (fcntl(held, F_OFD_SETLK, &lock)) {
            if (errno == EAGAIN || errno == EACCES) die("dpkg database is busy: %s", path);
            die("cannot acquire lock %s: %s", path, strerror(errno));
        }
        g_free(path);
    }
    execvp(command[0], command);
    die("cannot execute %s: %s", command[0], strerror(errno));
}
int main(int argc, char **argv) {
    if (argc == 5 && !strcmp(argv[1], "split")) split(argv[2], argv[3], argv[4]);
    else if (argc >= 3 && !strcmp(argv[1], "compose")) {
        GHashTable *state = compose(argc - 3, argv + 3); output(argv[2], state); g_hash_table_destroy(state);
    } else if (argc >= 3 && !strcmp(argv[1], "prepare")) prepare(argv[2], argc - 3, argv + 3);
    else if (argc == 4 && !strcmp(argv[1], "prepare-lowers")) prepare_lowers(argv[2], argv[3]);
    else if ((argc == 3 || argc == 4) && !strcmp(argv[1], "pack")) pack(argv[2], argc == 4 ? argv[3] : NULL);
    else if (argc == 3 && !strcmp(argv[1], "validate")) {
        GHashTable *state = records(); apply_module(state, argv[2]); g_hash_table_destroy(state);
    } else if (argc >= 4 && !strcmp(argv[1], "locked")) locked(argv[2], argv + 3);
    else {
        fputs("Usage: minios-dpkg-state split BEFORE AFTER NEW_STATUS_D\n"
              "       minios-dpkg-state compose OUTPUT [MODULE_ROOT ...] (bottom to top)\n"
              "       minios-dpkg-state prepare BUILD_ROOT [MODULE_ROOT ...]\n"
              "       minios-dpkg-state prepare-lowers BUILD_ROOT TOP_TO_BOTTOM_LOWERDIR_LIST\n"
              "       minios-dpkg-state pack PRIVATE_ROOT [BEFORE]\n"
              "       minios-dpkg-state validate MODULE_ROOT\n"
              "       minios-dpkg-state locked ROOT COMMAND...\n", stderr);
        return 2;
    }
    return 0;
}

# MiniOS dpkg state

Module-only decomposition of dpkg status. Live systems and build chroots use a
normal writable status file. No FUSE, kernel module, daemon, interpreter, or
patched dpkg is required. GLib is the only non-libc runtime dependency.

## Format 1

Each package-bearing module contains `var/lib/dpkg/status.d/`:

- `format`: exactly `minios-dpkg-state 1` followed by LF;
- `records/`: complete deb822 status records added or semantically changed;
- `removed/`: old records for identities explicitly removed by this module.

Each record filename is the lowercase SHA-256 of `Package:Architecture` (the
literal colon separates the two field values). Empty architecture is permitted
for residual dpkg records. Contents, not names alone, determine identity; loaders
check both. Each file contains exactly one complete record. State fields,
multi-line values and unknown dpkg fields are retained. There are no md5sums in
status.d. A missing status.d means the module has no package-state changes.
Legacy monolithic module status files are rejected, even alongside status.d.

Apply module directories in actual bottom-to-top order. Later explicit records
replace earlier records, including downgrades; a missing record is not a removal.
Removals affect only their package/architecture. There is no highest-version
selection and no inference of package ownership from info/*.list. Dependencies
between modules remain the responsibility of their producer/loader.

## Commands

```
minios-dpkg-state split BEFORE AFTER NEW_STATUS_D
minios-dpkg-state compose OUTPUT MODULE_ROOT...
minios-dpkg-state prepare BUILD_ROOT MODULE_ROOT...
minios-dpkg-state prepare-lowers BUILD_ROOT TOP_TO_BOTTOM_LOWERDIR_LIST
minios-dpkg-state pack PRIVATE_ROOT [BEFORE]
minios-dpkg-state validate MODULE_ROOT
minios-dpkg-state locked ROOT COMMAND...
```

`split` compares full pre/post-build snapshots; `/dev/null` is the explicit empty
baseline used for core. Output must not exist. `compose` creates a full status,
never decomposes writable runtime state. `prepare` materializes a build root's
status when absent, saving its original snapshot in `.minios-build/status.base`;
an existing ordinary status (e.g. a resumed session) is retained as the baseline.
`pack` operates ONLY on a private staging tree or unmounted build upper, turns
its status into records, and removes status/status-old and build/runtime baseline
directories from that tree. It uses an explicit BEFORE, then a build baseline,
then a saved module baseline. Missing baselines fail; they never imply an empty
base. `validate` also accepts data-only trees without package state.

Callers must serialize against package operations, capture consistent snapshots,
and publish the module only after success. `pack` is not an operation on a mounted
live upper. Persistence checkpoints (changes.sb) retain ordinary status and are
not decomposed. Raw folder converters require already prepared metadata or an
explicit build baseline; they must not guess one from the host's current state.

## Writable status reconciliation

`minios-update-dpkg-merge` combines the composed module status with the writable
status and the preceding module-only baseline. A regular empty baseline means
that the previous module set had no packages; it is not a missing baseline.
The existing `/dev/null` sentinel selects first-run/bootstrap behavior.

A change solely to the desired selection (the first word of `Status`, such as
`install` to `hold`) is applied to the new module record. Its new version,
dependencies, conffile metadata and actual package state remain intact. This does
not prevent replacement of module files: the selection controls future dpkg/APT
operations. A selection alone does not retain a package after its module is
removed. Selection history is not separately stored once that record disappears.

Genuine changes to the actual state or error flag remain complete local records.
Other metadata overrides require evidence in writable/restored persistence info;
matching versions alone are not evidence of a local metadata change. Info names
are matched by a recognized terminal suffix, so `foo.bar.list` belongs to
`foo.bar`, not `foo`. Architecture qualifiers and `.wh.` whiteouts are respected;
unknown suffixes and opacity markers do not count as package metadata. Both a
single info directory and the frontend's NUL-delimited directory inventory are
supported. Residual `not-installed` records may omit Version or Architecture.

Built by minios-live-config: `make`; regression tests: `make test` (the state
tests use POSIX shell and standard utilities). Packaged separately as
minios-dpkg-state for build hosts, without live-config's init backend dependency.
See `dpkg-state-integration.md` for producer and consumer integration points.

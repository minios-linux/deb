#!/bin/sh
# Reconciliation regressions: the module's files and its status must agree.
set -eu
export LC_ALL=C
export UBSAN_OPTIONS="${UBSAN_OPTIONS:+$UBSAN_OPTIONS:}halt_on_error=1"
MERGER=${MERGE_C_BINARY:-"$PWD/build/minios-update-dpkg-merge"}
WORK=$(mktemp -d "${TMPDIR:-/tmp}/minios-dpkg-regressions.XXXXXXXX")
trap 'rm -rf "$WORK"' 0
trap 'exit 1' HUP INT TERM

record() {
    printf 'Package: %s\nStatus: %s\nArchitecture: %s\n' "$1" "$3" "${5:-amd64}"
    [ "$2" = '-' ] || printf 'Version: %s\n' "$2"
    printf 'Description: fixture\n continuation\n .\n more\n'
    [ -z "${4:-}" ] || printf '%s\n' "$4"
    printf '\n'
}
reset_case() {
    rm -rf "$WORK/info"
    mkdir "$WORK/info"
    for name in modules current previous expected; do : >"$WORK/$name"; done
    PREVIOUS="$WORK/previous"
    INFO="$WORK/info"
}
merge() {
    # The production frontend supplies precreated mktemp files.
    : >"$WORK/base"
    : >"$WORK/final"
    "$MERGER" "$WORK/modules" "$WORK/current" "$PREVIOUS" "$INFO" \
        "$WORK/base" "$WORK/final"
    cmp "$WORK/modules" "$WORK/base"
    cmp "$WORK/expected" "$WORK/final"
}
repeat_merge() {
    cp "$WORK/base" "$WORK/previous"
    cp "$WORK/final" "$WORK/current"
    merge
}

# A desired selection is not a pin on the old module's complete metadata.
for selection in hold deinstall purge unknown; do
    for marker in absent present; do
        reset_case
        record sample 1 'install ok installed' 'Depends: old-dep' >"$WORK/previous"
        record sample 1 "$selection ok installed" 'Depends: old-dep' >"$WORK/current"
        record sample 2 'install ok installed' 'Depends: new-dep' >"$WORK/modules"
        record sample 2 "$selection ok installed" 'Depends: new-dep' >"$WORK/expected"
        [ "$marker" = absent ] || touch "$WORK/info/sample.list"
        merge
        repeat_merge
    done
done
reset_case
record sample 1 'hold ok installed' >"$WORK/previous"
record sample 1 'install ok installed' >"$WORK/current"
record sample 2 'hold ok installed' >"$WORK/modules"
record sample 2 'install ok installed' >"$WORK/expected"
merge
printf 'Selection transfer across module replacement and idempotence: passed\n'

reset_case
record sample 1 'install ok installed' >"$WORK/previous"
record sample 1 ' install  ok installed ' >"$WORK/current"
record sample 2 'install ok installed' >"$WORK/modules"
cp "$WORK/modules" "$WORK/expected"
merge

# A selection alone must not resurrect an unmounted package, even when info
# happens to have been copied up without a semantic change to that package.
for marker in absent present; do
    reset_case
    record sample 1 'install ok installed' >"$WORK/previous"
    record sample 1 'hold ok installed' >"$WORK/current"
    [ "$marker" = absent ] || touch "$WORK/info/sample.list"
    merge
    cp "$WORK/base" "$WORK/previous"
    cp "$WORK/final" "$WORK/current"
    record sample 2 'install ok installed' >"$WORK/modules"
    cp "$WORK/modules" "$WORK/expected"
    merge
done
printf 'Selection-only detach and reattach: passed\n'

# Local version/content/state changes remain full-record overrides.
for status in 'deinstall ok config-files' 'install reinstreq half-installed'; do
    reset_case
    record sample 1 'install ok installed' >"$WORK/previous"
    record sample 1 "$status" >"$WORK/current"
    record sample 2 'install ok installed' >"$WORK/modules"
    cp "$WORK/current" "$WORK/expected"
    merge
    repeat_merge
done
reset_case
record sample 1 'install ok installed' 'Conffiles:
 /etc/sample old-hash' >"$WORK/previous"
record sample 3 'hold ok installed' 'Conffiles:
 /etc/sample local-hash' >"$WORK/current"
record sample 2 'install ok installed' 'Conffiles:
 /etc/sample new-hash' >"$WORK/modules"
touch "$WORK/info/sample.conffiles"
cp "$WORK/current" "$WORK/expected"
merge
repeat_merge
printf 'Genuine local state, version and conffile overrides: passed\n'

# foo.bar.list does not prove anything about foo; architecture-qualified info
# belongs only to that architecture. Exercise the persistence inventory too.
for marker in foo.bar.list .wh.foo.bar:amd64.md5sums foo.bar:i386.postinst foo.bar.unknown .wh..wh..opq; do
    reset_case
    record foo 1 'install ok installed' 'X-State: old' >"$WORK/previous"
    record foo.bar 1 'install ok installed' 'X-State: old' >>"$WORK/previous"
    record foo.bar 1 'install ok installed' 'X-State: old' i386 >>"$WORK/previous"
    record foo 1 'install ok installed' 'X-State: local' >"$WORK/current"
    record foo.bar 1 'install ok installed' 'X-State: local' >>"$WORK/current"
    record foo.bar 1 'install ok installed' 'X-State: local' i386 >>"$WORK/current"
    record foo 2 'install ok installed' 'X-State: new' >"$WORK/modules"
    record foo.bar 2 'install ok installed' 'X-State: new' >>"$WORK/modules"
    record foo.bar 2 'install ok installed' 'X-State: new' i386 >>"$WORK/modules"
    touch "$WORK/info/$marker"
    record foo 2 'install ok installed' 'X-State: new' >"$WORK/expected"
    for arch in amd64 i386; do
        if [ "$marker" = foo.bar.list ] ||
           [ "$marker" = ".wh.foo.bar:$arch.md5sums" ] ||
           [ "$marker" = "foo.bar:$arch.postinst" ]; then
            record foo.bar 1 'install ok installed' 'X-State: local' "$arch"
        else
            record foo.bar 2 'install ok installed' 'X-State: new' "$arch"
        fi
    done >>"$WORK/expected"
    merge
    printf '%s\0' "$WORK/info" >"$WORK/info-inventory"
    INFO="$WORK/info-inventory"
    merge
done
printf 'Exact dotted-name, suffix and multiarch info matching: passed\n'

# An empty regular baseline is an actual previous state, not bootstrap mode.
for marker in sample.list .wh.sample.list; do
    reset_case
    record sample 1 'install ok installed' >"$WORK/modules"
    touch "$WORK/info/$marker"
    cp "$WORK/modules" "$WORK/expected"
    merge
    PREVIOUS=/dev/null
    : >"$WORK/expected"
    merge
    PREVIOUS="$WORK/missing-baseline"
    merge
done
printf 'Absent versus known-empty baseline: passed\n'

# Residual records from dpkg --set-selections need not have a Version or an
# Architecture. Preserve that existing contract instead of enforcing the
# archive's narrower installed-record schema.
reset_case
record sample - 'hold ok not-installed' >"$WORK/modules"
cp "$WORK/modules" "$WORK/expected"
merge
reset_case
printf 'Package: sample\nStatus: hold ok not-installed\n\n' >"$WORK/modules"
cp "$WORK/modules" "$WORK/expected"
merge

# Preserve unrelated multiline fields and handle a folded/case-varied Status.
reset_case
record sample 1 'install ok installed' >"$WORK/previous"
record sample 1 'hold ok installed' >"$WORK/current"
printf 'Package: sample\nsTaTuS: install\n ok installed\nArchitecture: amd64\nVersion: 2\nDescription: changed\n continued\nConffiles:\n /etc/sample new-hash\n\n' >"$WORK/modules"
printf 'Package: sample\nStatus: hold ok installed\nArchitecture: amd64\nVersion: 2\nDescription: changed\n continued\nConffiles:\n /etc/sample new-hash\n\n' >"$WORK/expected"
merge
printf 'Residual records and multiline selection rewriting: passed\n'

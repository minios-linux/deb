#!/bin/sh
set -eu
export LC_ALL=C
TOOL=${1:-"$PWD/build/minios-dpkg-state"}
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' 0
trap 'exit 1' HUP INT TERM
rec() {
    printf 'Package: %s\nStatus: install ok installed\nArchitecture: %s\nVersion: %s\nDescription: fixture\n continued\n\n' "$1" "$2" "$3"
}
mkdir -p "$WORK/core/var/lib/dpkg" "$WORK/extra/var/lib/dpkg" "$WORK/empty"
rec alpha amd64 2 >"$WORK/base"
rec alpha i386 2 >>"$WORK/base"
rec gone amd64 1 >>"$WORK/base"
rec alpha amd64 1 >"$WORK/after" # explicit downgrade
rec alpha i386 2 >>"$WORK/after"
rec local.pkg amd64 3 >>"$WORK/after"
"$TOOL" split /dev/null "$WORK/base" "$WORK/core/var/lib/dpkg/status.d"
"$TOOL" split "$WORK/base" "$WORK/after" "$WORK/extra/var/lib/dpkg/status.d"
"$TOOL" compose "$WORK/result" "$WORK/core" "$WORK/extra" "$WORK/empty"
cmp "$WORK/after" "$WORK/result"
"$TOOL" compose "$WORK/result" "$WORK/core"
cmp "$WORK/base" "$WORK/result"
test "$(find "$WORK/extra/var/lib/dpkg/status.d/records" -type f | wc -l)" -eq 2
test "$(find "$WORK/extra/var/lib/dpkg/status.d/removed" -type f | wc -l)" -eq 1
printf 'Layer composition, removal, downgrade and multiarch: passed\n'

mkdir -p "$WORK/buildroot"
"$TOOL" prepare-lowers "$WORK/buildroot" "$WORK/extra=ro:$WORK/core=ro"
cmp "$WORK/after" "$WORK/buildroot/var/lib/dpkg/status"
cmp "$WORK/after" "$WORK/buildroot/var/lib/dpkg/.minios-build/status.base"
rec session amd64 4 >>"$WORK/buildroot/var/lib/dpkg/status"
cp "$WORK/buildroot/var/lib/dpkg/status" "$WORK/session"
"$TOOL" prepare-lowers "$WORK/buildroot" "$WORK/extra:$WORK/core"
cmp "$WORK/session" "$WORK/buildroot/var/lib/dpkg/status"
cmp "$WORK/after" "$WORK/buildroot/var/lib/dpkg/.minios-build/status.base"
"$TOOL" pack "$WORK/buildroot"
test ! -e "$WORK/buildroot/var/lib/dpkg/status"
test ! -e "$WORK/buildroot/var/lib/dpkg/.minios-build"
"$TOOL" validate "$WORK/buildroot"
"$TOOL" compose "$WORK/result" "$WORK/core" "$WORK/extra" "$WORK/buildroot"
cmp "$WORK/session" "$WORK/result"
printf 'Build preparation, resume and private export round trip: passed\n'

# Field ordering alone is not a changed record.
mkdir -p "$WORK/reordered/var/lib/dpkg"
printf 'Version: 1\nArchitecture: amd64\nPackage: order\nStatus: install ok installed\n\n' >"$WORK/old"
printf 'Package: order\nStatus: install ok installed\nArchitecture: amd64\nVersion: 1\n\n' >"$WORK/new"
"$TOOL" split "$WORK/old" "$WORK/new" "$WORK/reordered/var/lib/dpkg/status.d"
test "$(find "$WORK/reordered/var/lib/dpkg/status.d/records" -type f | wc -l)" -eq 0

# Reject legacy modules before replacing an existing cached status.
mkdir -p "$WORK/legacy/var/lib/dpkg"
cp "$WORK/base" "$WORK/legacy/var/lib/dpkg/status"
cp "$WORK/session" "$WORK/result"
if "$TOOL" compose "$WORK/result" "$WORK/core" "$WORK/legacy" 2>"$WORK/error"; then exit 1; fi
grep -q 'legacy module status' "$WORK/error"
cmp "$WORK/session" "$WORK/result"
if "$TOOL" pack "$WORK/legacy" 2>"$WORK/error"; then exit 1; fi
grep -q 'missing build baseline' "$WORK/error"
cmp "$WORK/base" "$WORK/legacy/var/lib/dpkg/status"
"$TOOL" pack "$WORK/legacy" /dev/null
"$TOOL" compose "$WORK/result" "$WORK/legacy"
cmp "$WORK/base" "$WORK/result"

# Strict format, path and record validation.
printf 'future-format\n' >"$WORK/extra/var/lib/dpkg/status.d/format"
if "$TOOL" validate "$WORK/extra" 2>"$WORK/error"; then exit 1; fi
grep -q 'unsupported' "$WORK/error"
printf 'minios-dpkg-state 1\n' >"$WORK/extra/var/lib/dpkg/status.d/format"
touch "$WORK/extra/var/lib/dpkg/status.d/extra"
if "$TOOL" validate "$WORK/extra" 2>"$WORK/error"; then exit 1; fi
grep -q 'unknown status.d' "$WORK/error"
rm "$WORK/extra/var/lib/dpkg/status.d/extra"
touch "$WORK/extra/var/lib/dpkg/status.d/records/wrong"
if "$TOOL" validate "$WORK/extra" 2>"$WORK/error"; then exit 1; fi
rm "$WORK/extra/var/lib/dpkg/status.d/records/wrong"
ln -s "$WORK/base" "$WORK/extra/var/lib/dpkg/status.d/records/link"
if "$TOOL" validate "$WORK/extra" 2>"$WORK/error"; then exit 1; fi
rm "$WORK/extra/var/lib/dpkg/status.d/records/link"
printf 'Package: invalid/escape\nVersion: 1\n\n' >"$WORK/bad"
if "$TOOL" split /dev/null "$WORK/bad" "$WORK/rejected" 2>"$WORK/error"; then exit 1; fi
test ! -e "$WORK/rejected"
cat "$WORK/base" "$WORK/base" >"$WORK/bad"
if "$TOOL" split /dev/null "$WORK/bad" "$WORK/rejected" 2>"$WORK/error"; then exit 1; fi
test ! -e "$WORK/rejected"
printf 'Strict validation and failure-before-publication: passed\n'

mkdir -p "$WORK/pending/var/lib/dpkg/updates"
cp "$WORK/base" "$WORK/pending/var/lib/dpkg/status"
touch "$WORK/pending/var/lib/dpkg/updates/0000"
if "$TOOL" pack "$WORK/pending" /dev/null 2>"$WORK/error"; then exit 1; fi
grep -q 'pending dpkg updates' "$WORK/error"
cmp "$WORK/base" "$WORK/pending/var/lib/dpkg/status"
test ! -e "$WORK/pending/var/lib/dpkg/status.d"
printf 'Incomplete dpkg transaction export rejected: passed\n'

mkdir -p "$WORK/locked/var/lib/dpkg"
"$TOOL" locked "$WORK/locked" sh -c '
    if "$1" locked "$2" sh -c : 2>"$3"; then exit 1; fi
    grep -q "dpkg database is busy" "$3"
' sh "$TOOL" "$WORK/locked" "$WORK/error"
"$TOOL" locked "$WORK/locked" sh -c :
printf 'Lock lifetime across exec: passed\n'

import sys
import threading
import time
import unittest
from unittest import mock

from gi.repository import Gtk

from minios_gui.command import (
    CommandRunner, LogView, _FrameDecoder, format_command, format_log_line,
)


class CommandRunnerTests(unittest.TestCase):
    def test_format_log_line_uses_shared_metadata_order(self):
        self.assertEqual(
            format_log_line("message\n", timestamp="12:34:56", level="warn"),
            "[12:34:56] WARN message\n")

    def test_cancel_requested_before_popen_is_applied_after_start(self):
        results = []
        process = mock.Mock()
        process.pid = 1234
        process.poll.return_value = None
        process.stdout.fileno.return_value = 10
        process.wait.return_value = -15
        process.returncode = -15

        def idle_add(callback, *args):
            callback(*args)
            return 1

        runner = CommandRunner(
            ['/bin/true'], lambda _line: None,
            lambda returncode, cancelled: results.append((returncode, cancelled)))
        runner.cancel()
        selector = mock.Mock()
        selector.get_map.return_value = {}
        with mock.patch('minios_gui.command.subprocess.Popen', return_value=process), \
                mock.patch('minios_gui.command.selectors.DefaultSelector',
                           return_value=selector), \
                mock.patch.object(CommandRunner, '_signal_process') as terminate, \
                mock.patch('minios_gui.command.GLib.idle_add', side_effect=idle_add):
            runner._worker()

        terminate.assert_called_once_with(process, process.pid, 15)
        self.assertEqual(results, [(-15, True)])

    def test_cancel_kills_descendant_after_process_group_leader_exits(self):
        ready = threading.Event()
        results = []
        script = """\
import os
import signal
import time

if os.fork():
    os._exit(0)
signal.signal(signal.SIGTERM, signal.SIG_IGN)
os.write(1, b"ready\\n")
time.sleep(30)
"""

        def idle_add(callback, *args):
            callback(*args)
            return 1

        def output(line):
            if line == "ready\n":
                ready.set()

        runner = CommandRunner(
            [sys.executable, "-c", script], output,
            lambda code, cancelled: results.append((code, cancelled)),
            cancel_grace=0.1)
        with mock.patch(
                "minios_gui.command.GLib.idle_add", side_effect=idle_add):
            runner.start()
            try:
                self.assertTrue(ready.wait(2.0))
                with runner._lock:
                    process = runner._process
                deadline = time.monotonic() + 2.0
                while process.poll() is None and time.monotonic() < deadline:
                    time.sleep(0.01)
                self.assertIsNotNone(process.poll())
                self.assertTrue(runner.cancel())
                self.assertTrue(runner.wait(2.0))
            finally:
                if not runner.wait(0):
                    runner.cancel()
                    runner.wait(2.0)

        self.assertEqual(results, [(0, True)])
        self.assertEqual(runner.state, "cancelled")
        self.assertIsNone(runner._pgid)
        with mock.patch("minios_gui.command.os.killpg") as killpg:
            self.assertFalse(runner.cancel())
        killpg.assert_not_called()

    def test_frame_decoder_preserves_crlf_across_chunks(self):
        decoder = _FrameDecoder(1024)
        self.assertEqual(decoder.feed(b"line\r"), [])
        self.assertEqual(decoder.feed(b"\nnext\rother"),
                         [b"line\r\n", b"next\r"])
        self.assertEqual(decoder.flush(), [b"other"])

        decoder = _FrameDecoder(1024)
        self.assertEqual(decoder.feed(b"solitary\r"), [])
        self.assertEqual(decoder.flush(), [b"solitary\r"])

    def test_frame_decoder_does_not_split_utf8_sequence_at_buffer_limit(self):
        decoder = _FrameDecoder(2)
        frames = decoder.feed("a€b".encode("utf-8"))
        frames.extend(decoder.flush())
        self.assertEqual([frame.decode("utf-8") for frame in frames],
                         ["a", "€", "b"])

    def test_runner_streams_output_and_reports_success(self):
        lines = []
        results = []

        def idle_add(callback, *args):
            callback(*args)
            return 1

        runner = CommandRunner(
            ["/bin/sh", "-c", "printf 'hello\\n'"],
            lines.append,
            lambda returncode, cancelled: results.append(
                (returncode, cancelled)),
        )
        with mock.patch(
                "minios_gui.command.GLib.idle_add", side_effect=idle_add):
            runner._worker()

        self.assertEqual(lines, ["hello\n"])
        self.assertEqual(results, [(0, False)])

    def test_runner_frames_carriage_returns_and_separates_stderr(self):
        stdout = []
        stderr = []
        results = []

        def idle_add(callback, *args):
            callback(*args)
            return 1

        runner = CommandRunner(
            ["/bin/sh", "-c", "printf 'one\\rtwo\\n'; printf 'bad\\n' >&2"],
            stdout.append, lambda code, cancelled: results.append((code, cancelled)),
            stderr_callback=stderr.append)
        with mock.patch(
                "minios_gui.command.GLib.idle_add", side_effect=idle_add):
            runner._worker()

        self.assertEqual(stdout, ["one\r", "two\n"])
        self.assertEqual(stderr, ["bad\n"])
        self.assertEqual(results, [(0, False)])

    def test_lifecycle_safe_argv_and_display_command(self):
        with self.assertRaises(TypeError):
            CommandRunner("true", lambda line: None, lambda code, cancel: None)
        runner = CommandRunner(
            ["printf", "%s", "secret"], lambda line: None,
            lambda code, cancel: None, display_argv=["printf", "%s", "***"])
        self.assertEqual(runner.state, "idle")
        self.assertFalse(runner.running)
        self.assertEqual(runner.formatted_command, "printf %s '***'")
        self.assertEqual(format_command(["a b", "c"]), "'a b' c")
        with runner._lock:
            runner._state = "starting"
        with self.assertRaises(RuntimeError):
            runner.start()

    def test_output_is_bounded_and_reports_truncation_once(self):
        lines = []

        def idle_add(callback, *args):
            callback(*args)
            return 1

        runner = CommandRunner(
            ["true"], lines.append, lambda code, cancel: None,
            maximum_output_bytes=4)
        with mock.patch(
                "minios_gui.command.GLib.idle_add", side_effect=idle_add):
            runner._emit(lines.append, "1234")
            runner._emit(lines.append, "5")
            runner._emit(lines.append, "6")
        self.assertEqual(lines[0], "1234")
        self.assertEqual(len(lines), 2)
        self.assertIn("limit reached", lines[1])

    def test_output_limit_preserves_configured_critical_frames(self):
        lines = []

        def idle_add(callback, *args):
            callback(*args)
            return 1

        runner = CommandRunner(
            ["true"], lines.append, lambda code, cancel: None,
            maximum_output_bytes=4, preserve_output_prefixes=("P:", "E:"))
        with mock.patch(
                "minios_gui.command.GLib.idle_add", side_effect=idle_add):
            runner._emit(lines.append, "1234")
            runner._emit(lines.append, "ignored")
            runner._emit(lines.append, "  E: critical\n")
        self.assertIn("limit reached", lines[1])
        self.assertEqual(lines[2], "  E: critical\n")

    def test_preserved_output_prefixes_are_validated(self):
        callbacks = (lambda line: None, lambda code, cancel: None)
        with self.assertRaises(TypeError):
            CommandRunner(["true"], callbacks[0], callbacks[1],
                          preserve_output_prefixes=["E:"])
        with self.assertRaises(ValueError):
            CommandRunner(["true"], callbacks[0], callbacks[1],
                          preserve_output_prefixes=("",))

    def test_log_view_applies_semantic_level_tag(self):
        view = LogView()
        provider = Gtk.CssProvider()
        provider.load_from_data(b"@define-color minios_red #cc0000;")
        view.text_view.get_style_context().add_provider(
            provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        view.append_line("broken", level="error")
        tag = view.text_buffer.get_tag_table().lookup("log-level-error")
        self.assertIsNotNone(tag)
        self.assertIn(tag, view.text_buffer.get_start_iter().get_tags())
        self.assertTrue(tag.props.foreground_set)
        self.assertAlmostEqual(tag.props.foreground_rgba.red, 0.8, places=2)
        updated_provider = Gtk.CssProvider()
        updated_provider.load_from_data(b"@define-color minios_red #00cc00;")
        view.text_view.get_style_context().add_provider(
            updated_provider, Gtk.STYLE_PROVIDER_PRIORITY_USER)
        view._update_level_tags()
        self.assertAlmostEqual(tag.props.foreground_rgba.green, 0.8, places=2)

    def test_log_view_unknown_level_has_theme_safe_fallback(self):
        view = LogView()
        view.append_line("trace", level="custom")
        tag = view.text_buffer.get_tag_table().lookup("log-level-custom")
        self.assertFalse(tag.props.foreground_set)


if __name__ == "__main__":
    unittest.main()

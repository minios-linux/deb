import unittest
from unittest import mock

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from minios_gui import (
    choose_folder, choose_open_file, choose_open_files, choose_save_file,
)


class ChooserTests(unittest.TestCase):
    def chooser(self, response=Gtk.ResponseType.ACCEPT):
        dialog = mock.Mock()
        dialog.run.return_value = response
        dialog.get_filename.return_value = "/tmp/file.txt"
        dialog.get_filenames.return_value = ["/tmp/a", "/tmp/b"]
        dialog.get_uri.return_value = "smb://server/share/file.txt"
        dialog.get_uris.return_value = [
            "smb://server/share/a", "smb://server/share/b"]
        return dialog

    def test_open_file_configures_filter_and_always_destroys(self):
        dialog = self.chooser()
        with mock.patch("minios_gui.chooser.Gtk.FileChooserDialog",
                        return_value=dialog), \
                mock.patch("minios_gui.chooser.Gtk.FileFilter") as filter_type:
            result = choose_open_file(
                title="Open", filters=[("Text", ("*.txt",), ("text/plain",))],
                current_folder="/tmp", accept_label="Choose", local_only=False)
        self.assertEqual(result, "smb://server/share/file.txt")
        dialog.get_uri.assert_called_once_with()
        dialog.get_filename.assert_not_called()
        dialog.set_current_folder.assert_called_once_with("/tmp")
        dialog.set_local_only.assert_called_once_with(False)
        filter_type.return_value.add_pattern.assert_called_once_with("*.txt")
        filter_type.return_value.add_mime_type.assert_called_once_with("text/plain")
        dialog.destroy.assert_called_once_with()

    def test_open_files_returns_list(self):
        dialog = self.chooser()
        with mock.patch("minios_gui.chooser.Gtk.FileChooserDialog",
                        return_value=dialog):
            self.assertEqual(choose_open_files(), ["/tmp/a", "/tmp/b"])
        dialog.set_select_multiple.assert_called_once_with(True)

    def test_open_files_returns_uris_when_not_local_only(self):
        dialog = self.chooser()
        with mock.patch("minios_gui.chooser.Gtk.FileChooserDialog",
                        return_value=dialog):
            self.assertEqual(choose_open_files(local_only=False), [
                "smb://server/share/a", "smb://server/share/b"])
        dialog.get_uris.assert_called_once_with()
        dialog.get_filenames.assert_not_called()

    def test_cancel_returns_none_and_destroys(self):
        dialog = self.chooser(Gtk.ResponseType.CANCEL)
        with mock.patch("minios_gui.chooser.Gtk.FileChooserDialog",
                        return_value=dialog):
            self.assertIsNone(choose_folder(create_folders=False))
        dialog.set_create_folders.assert_called_once_with(False)
        dialog.destroy.assert_called_once_with()

    def test_save_options(self):
        dialog = self.chooser()
        with mock.patch("minios_gui.chooser.Gtk.FileChooserDialog",
                        return_value=dialog):
            result = choose_save_file(
                current_name="image.iso", overwrite_confirmation=False)
        self.assertEqual(result, "/tmp/file.txt")
        dialog.set_current_name.assert_called_once_with("image.iso")
        dialog.set_do_overwrite_confirmation.assert_called_once_with(False)


if __name__ == "__main__":
    unittest.main()

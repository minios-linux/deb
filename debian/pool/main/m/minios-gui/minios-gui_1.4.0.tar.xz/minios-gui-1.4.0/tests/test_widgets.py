import unittest

from gi.repository import Gtk

from minios_gui import (
    HelpPopoverButton, IconTextRow, OperationView, PasswordEntry,
    ProgressDialog, StatePlaceholder, StatusBanner, new_header_bar,
    new_header_icon_button,
)


class WidgetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        initialized, _argv = Gtk.init_check([])
        if not initialized:
            raise unittest.SkipTest("GTK display is unavailable")

    def test_header_bar_uses_canonical_style(self):
        header = new_header_bar("MiniOS Test")
        self.assertEqual(header.props.title, "MiniOS Test")
        self.assertFalse(header.get_has_subtitle())
        self.assertTrue(
            header.get_style_context().has_class("minios-headerbar"))

    def test_header_icon_button_uses_canonical_square_action_class(self):
        button = new_header_icon_button(
            "go-previous-symbolic", "Back", "Go back")

        self.assertIsNotNone(button.get_image())
        self.assertEqual(button.get_tooltip_text(), "Go back")
        self.assertFalse(button.get_focus_on_click())
        self.assertEqual(button.get_valign(), Gtk.Align.CENTER)
        self.assertTrue(button.get_style_context().has_class(
            "minios-header-action"))
        self.assertEqual(button.get_accessible().get_name(), "Back")

    def test_status_banner_updates_intent_and_text(self):
        banner = StatusBanner("Initial", intent="warning")
        self.assertEqual(banner.intent, "warning")
        self.assertEqual(banner.label.get_text(), "Initial")
        self.assertTrue(
            banner.get_style_context().has_class("warning-banner"))

        banner.set_text("Ready")
        banner.set_intent("success")
        self.assertEqual(banner.label.get_text(), "Ready")
        self.assertEqual(banner.intent, "success")
        self.assertFalse(
            banner.get_style_context().has_class("warning-banner"))
        self.assertTrue(
            banner.get_style_context().has_class("success-banner"))

    def test_status_banner_rejects_unknown_intent(self):
        with self.assertRaises(ValueError):
            StatusBanner("Broken", intent="unknown")

    def test_help_popover_builds_structured_content(self):
        window = Gtk.Window()
        button = HelpPopoverButton(
            "Packages", "Build from packages.",
            (("Use this when", "APT should resolve dependencies."),),
            label="Help")
        window.add(button)
        window.show_all()
        button.clicked()
        while Gtk.events_pending():
            Gtk.main_iteration_do(False)
        self.assertIsInstance(button, Gtk.Button)
        self.assertTrue(button.help_popover.get_visible())
        minimum, _natural = button.help_popover.get_preferred_width()
        self.assertGreaterEqual(minimum, 600)
        self.assertTrue(
            button.get_style_context().has_class("minios-help-button"))
        self.assertTrue(button.help_heading.get_style_context().has_class(
            "minios-help-title"))
        self.assertEqual(button.get_tooltip_text(), "Packages")
        window.destroy()

    def test_compact_help_popover_accepts_markup(self):
        button = HelpPopoverButton(
            "Filesystem", "<b>ext4</b> is recommended.",
            compact=True, markup=True)
        self.assertIsNotNone(button.help_popover)

    def test_help_popover_accepts_compiled_document(self):
        document = {
            "product_kind": "minios-markup-document",
            "schema_version": 1,
            "nodes": [
                ["heading", 1, "filesystem", [["text", "Filesystem"]]],
                ["block", "paragraph", [
                    ["text", "Use "],
                    ["span", "strong", [["text", "ext4"]]],
                    ["text", " or "],
                    ["span", "code", [["text", "perchmode=squashfs"]]],
                    ["text", "."],
                ]],
            ],
        }
        button = HelpPopoverButton("Filesystem", compact=True, document=document)
        self.assertIsNotNone(button.help_popover)
        self.assertIsNotNone(button.document_view)
        self.assertFalse(hasattr(button, "help_heading"))
        self.assertIs(button.document_view.get_parent(), button.help_scrolled)
        tags = button.document_view.get_buffer().get_tag_table()
        self.assertGreater(tags.lookup("heading1").props.scale,
                           tags.lookup("heading2").props.scale)

    def test_document_scroll_range_ends_with_document(self):
        window = Gtk.Window()
        nodes = [["heading", 1, "help", [["text", "Help"]]]]
        nodes.extend([
            ["block", "paragraph", [["text",
                "Paragraph {} with enough text to wrap onto another line.".format(i)]]]
            for i in range(40)
        ])
        document = {
            "product_kind": "minios-markup-document",
            "schema_version": 1,
            "nodes": nodes,
        }
        button = HelpPopoverButton("Help", document=document)
        window.add(button)
        window.show_all()
        button.clicked()
        while Gtk.events_pending():
            Gtk.main_iteration_do(False)

        view = button.document_view
        end_rect = view.get_iter_location(view.get_buffer().get_end_iter())
        upper = button.help_scrolled.get_vadjustment().get_upper()
        self.assertLessEqual(upper - end_rect.y - end_rect.height, 32)
        window.destroy()

    def test_operation_view_presents_state_progress_log_and_cancel(self):
        view = OperationView("Starting", show_log=True)
        cancelled = []
        view.connect("cancel-requested", lambda widget: cancelled.append(True))
        view.set_state("running", "Working")
        view.set_progress(0.5)
        view.append_line("step", level="info")
        view.cancel_button.clicked()
        self.assertEqual(view.state, "running")
        self.assertEqual(view.status_label.get_text(), "Working")
        self.assertEqual(view.progress_bar.get_fraction(), 0.5)
        self.assertEqual(view.log_view.get_text(), "INFO step\n")
        self.assertEqual(cancelled, [True])
        view.set_state("success")
        self.assertFalse(view.cancel_button.get_sensitive())

    def test_running_reveals_status_after_hidden_initial_show(self):
        window = Gtk.Window()
        view = OperationView("Creating session", cancellable=False)
        view.set_no_show_all(True)
        view.hide()
        window.add(view)
        window.show_all()

        self.assertFalse(view.get_visible())
        view.show()
        view.set_state("running")

        self.assertTrue(view.status_row.get_visible())
        self.assertTrue(view.status_label.get_visible())
        self.assertTrue(view.spinner.get_visible())
        self.assertFalse(view.cancel_button.get_visible())
        window.destroy()

    def test_progress_dialog_wraps_operation_view(self):
        dialog = ProgressDialog(title="Work", status="Waiting")
        responses = []
        dialog.connect("response", lambda widget, response: responses.append(response))
        dialog.operation_view.cancel_button.clicked()
        self.assertEqual(responses, [Gtk.ResponseType.CANCEL])
        dialog.destroy()

    def test_state_placeholder_action(self):
        placeholder = StatePlaceholder(
            "Nothing here", "Add an item.", action_label="Add")
        activated = []
        placeholder.connect(
            "action-activated", lambda widget: activated.append(True))
        placeholder.action_button.clicked()
        self.assertEqual(placeholder.title_label.get_text(), "Nothing here")
        self.assertEqual(activated, [True])

    def test_password_entry_toggle_mode_and_translated_labels(self):
        password = PasswordEntry(
            "toggle", placeholder_text="Password",
            show_label="Afficher", hide_label="Masquer")
        self.assertIsInstance(password.reveal_button, Gtk.ToggleButton)
        self.assertEqual(password.reveal_button.get_tooltip_text(), "Afficher")
        password.set_text("secret")
        password.reveal_button.set_active(True)
        self.assertEqual(password.get_text(), "secret")
        self.assertTrue(password.entry.get_visibility())
        self.assertEqual(password.reveal_button.get_tooltip_text(), "Masquer")
        self.assertEqual(
            password.reveal_button.get_accessible().get_name(), "Masquer")
        password.reveal_button.set_active(False)
        self.assertFalse(password.entry.get_visibility())
        self.assertEqual(password.reveal_button.get_tooltip_text(), "Afficher")

    def test_password_entry_hold_mode_uses_momentary_button_activation(self):
        held = PasswordEntry("hold")
        self.assertIsInstance(held.reveal_button, Gtk.Button)
        self.assertNotIsInstance(held.reveal_button, Gtk.ToggleButton)

        held.reveal_button.emit("pressed")
        self.assertTrue(held.entry.get_visibility())
        held.reveal_button.emit("released")
        self.assertFalse(held.entry.get_visibility())

        # Keyboard and programmatic activation end in "clicked" without
        # creating persistent reveal state in hold mode.
        held.reveal_button.clicked()
        self.assertFalse(held.entry.get_visibility())

    def test_password_entry_rejects_invalid_reveal_mode(self):
        with self.assertRaises(ValueError):
            PasswordEntry("invalid")

    def test_icon_text_row_accepts_composable_edges(self):
        leading = Gtk.CheckButton()
        trailing = Gtk.Switch()
        row = IconTextRow(
            "Network", "Connected", leading=leading, trailing=trailing)
        self.assertIs(row.leading, leading)
        self.assertIs(row.trailing, trailing)
        self.assertEqual(row.title_label.get_text(), "Network")


if __name__ == "__main__":
    unittest.main()

import threading
import unittest
from collections import namedtuple

from minios_gui import BackgroundTask, CancellationToken, TaskCancelled, TaskOutcome


def immediate(callback, *args):
    callback(*args)
    return 1


class Owner(object):
    def connect(self, signal, callback):
        self.destroy_callback = callback


class TaskTests(unittest.TestCase):
    def test_token_raises_after_cancellation(self):
        token = CancellationToken()
        self.assertFalse(token.cancelled)
        self.assertTrue(token.cancel())
        self.assertFalse(token.cancel())
        with self.assertRaises(TaskCancelled):
            token.checkpoint()
        with self.assertRaises(TaskCancelled):
            token.raise_if_cancelled()

    def test_token_callbacks_can_be_removed_or_registered_after_cancel(self):
        token = CancellationToken()
        calls = []
        remove = token.add_cancel_callback(lambda: calls.append("removed"))
        token.add_cancel_callback(lambda: calls.append("called"))
        remove()
        self.assertTrue(token.cancel())
        self.assertEqual(calls, ["called"])
        token.add_cancel_callback(lambda: calls.append("late"))
        self.assertEqual(calls, ["called", "late"])
        with self.assertRaises(TypeError):
            CancellationToken().add_cancel_callback(None)

    def test_success_has_one_deterministic_outcome_and_start_once(self):
        outcomes = []
        states = []
        task = BackgroundTask(
            lambda token: 42, outcomes.append, states.append,
            dispatcher=immediate)
        task.start()
        self.assertTrue(task.wait(2))
        self.assertEqual(task.state, "success")
        self.assertTrue(task.outcome.succeeded)
        self.assertEqual(task.outcome.value, 42)
        self.assertEqual(task.outcome.result, 42)
        self.assertEqual(outcomes, [task.outcome])
        self.assertEqual(states[0], "starting")
        self.assertEqual(states[-1], "success")
        with self.assertRaises(RuntimeError):
            task.start()

    def test_cooperative_cancel_and_owner_destroy_suppresses_callback(self):
        entered = threading.Event()
        outcomes = []
        owner = Owner()

        def worker(token):
            entered.set()
            token.wait(2)
            token.raise_if_cancelled()

        task = BackgroundTask(
            worker, outcomes.append, dispatcher=immediate, owner=owner)
        task.start()
        self.assertTrue(entered.wait(1))
        owner.destroy_callback(owner)
        self.assertTrue(task.wait(2))
        self.assertEqual(task.state, "cancelled")
        self.assertEqual(outcomes, [])

    def test_outcome_rejects_non_terminal_state(self):
        with self.assertRaises(ValueError):
            TaskOutcome("running")

    def test_worker_error_is_captured(self):
        def fail(_token):
            raise RuntimeError("broken")

        task = BackgroundTask(fail, dispatcher=immediate).start()
        self.assertTrue(task.wait(2))
        self.assertEqual(task.state, "error")
        self.assertIsInstance(task.outcome.error, RuntimeError)

    def test_external_token_links_cancellation(self):
        token = CancellationToken()
        entered = threading.Event()

        def worker(worker_token):
            self.assertIs(worker_token, token)
            entered.set()
            worker_token.wait(2)
            worker_token.checkpoint()

        task = BackgroundTask(
            worker, dispatcher=immediate, token=token).start()
        self.assertTrue(entered.wait(1))
        self.assertTrue(task.cancel())
        self.assertFalse(task.cancel())
        self.assertTrue(task.wait(2))
        self.assertEqual(task.state, "cancelled")

    def test_legacy_outcome_adapter_preserves_result_error_and_cancelled(self):
        LegacyOutcome = namedtuple(
            "LegacyOutcome", ("result", "error", "cancelled"))
        error = TaskCancelled("stopped")
        outcome = TaskOutcome.from_outcome(
            LegacyOutcome("partial", error, True))
        self.assertEqual(outcome.state, "cancelled")
        self.assertEqual(outcome.result, "partial")
        self.assertIs(outcome.error, error)
        self.assertTrue(outcome.cancelled)
        self.assertIs(TaskOutcome.from_outcome(outcome), outcome)


if __name__ == "__main__":
    unittest.main()

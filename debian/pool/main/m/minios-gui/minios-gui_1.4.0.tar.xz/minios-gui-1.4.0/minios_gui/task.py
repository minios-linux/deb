"""Generic cancellable background work for GTK 3 applications."""

import threading
import weakref

from gi.repository import GLib


class TaskCancelled(Exception):
    """Raised by cooperative work when cancellation is observed."""


class CancellationToken(object):
    """Thread-safe cooperative token with cancellation callbacks."""

    def __init__(self):
        self._event = threading.Event()
        self._lock = threading.Lock()
        self._callbacks = []

    @property
    def cancelled(self):
        return self._event.is_set()

    def cancel(self):
        with self._lock:
            if self._event.is_set():
                return False
            self._event.set()
            callbacks = list(self._callbacks)
            self._callbacks = []
        for callback in callbacks:
            try:
                callback()
            except Exception:
                pass
        return True

    def raise_if_cancelled(self):
        self.checkpoint()

    def checkpoint(self):
        if self.cancelled:
            raise TaskCancelled("operation was cancelled")

    def wait(self, timeout=None):
        return self._event.wait(timeout)

    def add_cancel_callback(self, callback):
        if not callable(callback):
            raise TypeError("cancel callback must be callable")
        call_now = False
        with self._lock:
            if self._event.is_set():
                call_now = True
            else:
                self._callbacks.append(callback)
        if call_now:
            callback()

        def remove():
            with self._lock:
                try:
                    self._callbacks.remove(callback)
                except ValueError:
                    pass

        return remove


class TaskOutcome(object):
    """Terminal result of a BackgroundTask."""

    def __init__(self, state, value=None, error=None):
        if state not in ("success", "error", "cancelled"):
            raise ValueError("invalid terminal task state: {}".format(state))
        self.state = state
        self.value = value
        self.error = error

    @property
    def result(self):
        return self.value

    @property
    def succeeded(self):
        return self.state == "success"

    @property
    def cancelled(self):
        return self.state == "cancelled"

    @classmethod
    def from_outcome(cls, outcome):
        """Adapt this or a legacy ``result/error/cancelled`` outcome."""
        if isinstance(outcome, cls):
            return outcome
        error = getattr(outcome, "error", None)
        cancelled = bool(getattr(outcome, "cancelled", False))
        state = getattr(outcome, "state", None)
        if state == "cancelled" or cancelled:
            state = "cancelled"
        elif state in ("finished", "success"):
            state = "success"
        elif state in ("failed", "error"):
            state = "error"
        elif error is not None:
            state = "error"
        else:
            state = "success"
        value = getattr(outcome, "value", getattr(outcome, "result", None))
        return cls(state, value=value, error=error)


class BackgroundTask(object):
    """Run ``worker(token)`` once and dispatch one terminal outcome."""

    def __init__(self, worker, finished_callback=None, state_callback=None,
                 dispatcher=None, owner=None, token=None):
        self.worker = worker
        self.finished_callback = finished_callback
        self.state_callback = state_callback
        self.dispatcher = dispatcher or GLib.idle_add
        self.token = token if token is not None else CancellationToken()
        self._owner_ref = weakref.ref(owner) if owner is not None else None
        self._owner_destroyed = False
        self._state = "idle"
        self._outcome = None
        self._thread = None
        self._finished_event = threading.Event()
        self._lock = threading.Lock()
        if owner is not None and hasattr(owner, "connect"):
            owner.connect("destroy", self._on_owner_destroy)

    @property
    def state(self):
        with self._lock:
            return self._state

    @property
    def running(self):
        return self.state in ("starting", "running", "cancelling")

    @property
    def outcome(self):
        with self._lock:
            return self._outcome

    def start(self):
        with self._lock:
            if self._state != "idle":
                raise RuntimeError("BackgroundTask can only be started once")
            self._state = "starting"
        self._dispatch(self.state_callback, "starting")
        self._thread = threading.Thread(target=self._run)
        self._thread.daemon = True
        self._thread.start()
        return self

    def cancel(self):
        with self._lock:
            if self._state not in ("starting", "running", "cancelling"):
                return False
            if self.token.cancelled:
                return False
            self._state = "cancelling"
        if not self.token.cancel():
            return False
        self._dispatch(self.state_callback, "cancelling")
        return True

    def wait(self, timeout=None):
        return self._finished_event.wait(timeout)

    def _run(self):
        with self._lock:
            cancelling = self._state == "cancelling"
            if not cancelling:
                self._state = "running"
        if not cancelling:
            self._dispatch(self.state_callback, "running")
        try:
            self.token.raise_if_cancelled()
            value = self.worker(self.token)
            self.token.raise_if_cancelled()
            outcome = TaskOutcome("success", value=value)
        except TaskCancelled as error:
            outcome = TaskOutcome("cancelled", error=error)
        except Exception as error:
            outcome = TaskOutcome("error", error=error)
        with self._lock:
            if outcome.succeeded and self.token.cancelled:
                outcome = TaskOutcome("cancelled", error=TaskCancelled())
            self._outcome = outcome
            self._state = outcome.state
        self._finished_event.set()
        self._dispatch(self.state_callback, outcome.state)
        self._dispatch(self.finished_callback, outcome)

    def _on_owner_destroy(self, *_args):
        self._owner_destroyed = True
        self.cancel()

    def _owner_alive(self):
        return (not self._owner_destroyed and
                (self._owner_ref is None or self._owner_ref() is not None))

    def _dispatch(self, callback, *args):
        if callback is None or not self._owner_alive():
            return
        self.dispatcher(self._deliver, callback, args)

    def _deliver(self, callback, args):
        if self._owner_alive():
            callback(*args)
        return False

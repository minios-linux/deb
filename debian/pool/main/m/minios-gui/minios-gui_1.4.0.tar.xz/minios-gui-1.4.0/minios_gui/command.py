"""Responsive command execution and streamed output widgets for GTK 3."""

import gettext
import os
import re
import selectors
import signal
import shlex
import subprocess
import threading

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk


_ = gettext.gettext


_ANSI_RE = re.compile(
    r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b[@-Z\\-_]|[\x00\x07\x08]")

_LEVEL_COLORS = {
    "debug": "minios_blue",
    "info": "minios_blue",
    "warning": "minios_amber",
    "warn": "minios_amber",
    "error": "minios_red",
    "critical": "minios_red",
    "success": "minios_green",
}


def format_log_line(message, timestamp=None, level=None):
    """Return one normalized log record with optional metadata prefix."""
    prefix = []
    if timestamp:
        prefix.append("[{}]".format(timestamp))
    if level:
        prefix.append(str(level).upper())
    text = str(message).rstrip("\r\n")
    if prefix:
        text = "{} {}".format(" ".join(prefix), text)
    return text + "\n"


def format_command(argv):
    """Format an argv sequence for display without changing its execution."""
    return " ".join(shlex.quote(str(argument)) for argument in argv)


class _FrameDecoder(object):
    """Split bytes on CR or newline while bounding unterminated frames."""

    def __init__(self, maximum_buffer):
        self.maximum_buffer = maximum_buffer
        self.buffer = bytearray()

    def feed(self, chunk):
        self.buffer.extend(chunk)
        frames = []
        while self.buffer:
            positions = [position for position in (
                self.buffer.find(b"\r"), self.buffer.find(b"\n"))
                if position >= 0]
            if positions:
                end = min(positions) + 1
                if self.buffer[end - 1:end] == b"\r":
                    if end == len(self.buffer):
                        break
                    if self.buffer[end:end + 1] == b"\n":
                        end += 1
                frames.append(bytes(self.buffer[:end]))
                del self.buffer[:end]
            elif len(self.buffer) > self.maximum_buffer:
                end = self._bounded_end()
                if end is None:
                    break
                frames.append(bytes(self.buffer[:end]))
                del self.buffer[:end]
            else:
                break
        return frames

    def _bounded_end(self):
        end = self.maximum_buffer
        if end >= len(self.buffer) or not self._is_utf8_continuation(
                self.buffer[end]):
            return end
        while end > 0 and self._is_utf8_continuation(self.buffer[end]):
            end -= 1
        if end:
            return end
        length = self._utf8_sequence_length(self.buffer[0])
        if length is None:
            return self.maximum_buffer
        return length if len(self.buffer) >= length else None

    @staticmethod
    def _is_utf8_continuation(value):
        return value & 0xc0 == 0x80

    @staticmethod
    def _utf8_sequence_length(value):
        if value < 0x80:
            return 1
        if 0xc2 <= value <= 0xdf:
            return 2
        if 0xe0 <= value <= 0xef:
            return 3
        if 0xf0 <= value <= 0xf4:
            return 4
        return None

    def flush(self):
        if not self.buffer:
            return []
        frame = bytes(self.buffer)
        self.buffer.clear()
        return [frame]


class LogView(Gtk.ScrolledWindow):
    """Read-only monospace output with terminal-style carriage returns."""

    def __init__(self, maximum_characters=None):
        Gtk.ScrolledWindow.__init__(self)
        self.maximum_characters = maximum_characters
        self.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.set_hexpand(True)
        self.set_vexpand(True)
        self._textview = Gtk.TextView()
        self._textview.set_editable(False)
        self._textview.set_cursor_visible(False)
        self._textview.set_monospace(True)
        self._textview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self._textview.set_left_margin(6)
        self._textview.set_right_margin(6)
        self._textview.get_style_context().add_class("log-view")
        self._buffer = self._textview.get_buffer()
        self._line_start = self._buffer.create_mark(
            "line-start", self._buffer.get_end_iter(), True)
        self._textview.connect("style-updated", self._update_level_tags)
        self.add(self._textview)

    @property
    def text_view(self):
        return self._textview

    @property
    def text_buffer(self):
        return self._buffer

    def clear(self):
        self._buffer.set_text("")
        self._buffer.move_mark(self._line_start, self._buffer.get_end_iter())

    def feed(self, text, level=None):
        text = _ANSI_RE.sub("", text)
        if not text:
            return False
        for part in re.split(r"(\r\n|\r|\n)", text):
            if not part:
                continue
            if part in ("\n", "\r\n"):
                self._insert("\n", level)
                self._buffer.move_mark(
                    self._line_start, self._buffer.get_end_iter())
            elif part == "\r":
                start = self._buffer.get_iter_at_mark(self._line_start)
                self._buffer.delete(start, self._buffer.get_end_iter())
            else:
                self._insert(part, level)
        self._textview.scroll_to_iter(
            self._buffer.get_end_iter(), 0.0, False, 0.0, 0.0)
        self._trim_history()
        return False

    def append_line(self, message, timestamp=None, level=None):
        """Append one record using the shared metadata layout."""
        return self.feed(format_log_line(message, timestamp, level), level=level)

    def _insert(self, text, level):
        if level:
            tag_name = "log-level-{}".format(str(level).lower())
            tag = self._buffer.get_tag_table().lookup(tag_name)
            if tag is None:
                tag = self._buffer.create_tag(tag_name)
            self._style_level_tag(tag, str(level).lower())
            self._buffer.insert_with_tags(
                self._buffer.get_end_iter(), text, tag)
        else:
            self._buffer.insert(self._buffer.get_end_iter(), text)

    def _style_level_tag(self, tag, level):
        color_name = _LEVEL_COLORS.get(level)
        found = False
        color = None
        if color_name:
            found, color = self._textview.get_style_context().lookup_color(
                color_name)
        if found:
            tag.set_property("foreground-rgba", color)
        else:
            tag.set_property("foreground-set", False)

    def _update_level_tags(self, *_args):
        table = self._buffer.get_tag_table()
        for level in _LEVEL_COLORS:
            tag = table.lookup("log-level-{}".format(level))
            if tag is not None:
                self._style_level_tag(tag, level)

    def _trim_history(self):
        if not self.maximum_characters:
            return
        overflow = self._buffer.get_char_count() - self.maximum_characters
        if overflow <= 0:
            return
        start = self._buffer.get_start_iter()
        end = self._buffer.get_iter_at_offset(overflow)
        self._buffer.delete(start, end)

    def get_text(self):
        return self._buffer.get_text(
            self._buffer.get_start_iter(), self._buffer.get_end_iter(), False)


class CommandRunner(object):
    """Run a subprocess off the GTK main loop and stream combined output."""

    def __init__(self, argv, line_callback, finished_callback, cwd=None,
                 env=None, state_callback=None, cancel_grace=3.0,
                 maximum_output_buffer=64 * 1024,
                 maximum_output_bytes=8 * 1024 * 1024,
                 display_argv=None, stderr_callback=None,
                 preserve_output_prefixes=()):
        if isinstance(argv, (str, bytes)):
            raise TypeError("argv must be a sequence, not a command string")
        self.argv = tuple(str(argument) for argument in argv)
        if not self.argv:
            raise ValueError("argv must not be empty")
        if isinstance(display_argv, (str, bytes)):
            raise TypeError("display_argv must be a sequence")
        self.display_argv = tuple(str(argument) for argument in (
            display_argv if display_argv is not None else self.argv))
        self.line_callback = line_callback
        self.finished_callback = finished_callback
        self.cwd = cwd
        self.env = env
        self.state_callback = state_callback
        self.cancel_grace = max(0.0, float(cancel_grace))
        self.maximum_output_buffer = max(1, int(maximum_output_buffer))
        self.maximum_output_bytes = max(1, int(maximum_output_bytes))
        self.stderr_callback = stderr_callback
        if not isinstance(preserve_output_prefixes, tuple):
            raise TypeError("preserve_output_prefixes must be a tuple")
        if any(not isinstance(prefix, str) or not prefix
               for prefix in preserve_output_prefixes):
            raise ValueError(
                "preserve_output_prefixes must contain non-empty strings")
        self.preserve_output_prefixes = preserve_output_prefixes
        self._process = None
        self._pgid = None
        self._cancelled = False
        self._state = "idle"
        self._returncode = None
        self._thread = None
        self._finished_event = threading.Event()
        self._output_bytes = 0
        self._output_truncated = False
        self._escalation_started = False
        self._lock = threading.Lock()

    @property
    def state(self):
        with self._lock:
            return self._state

    @property
    def running(self):
        return self.state in ("starting", "running", "cancelling", "killing")

    @property
    def is_running(self):
        return self.running

    @property
    def returncode(self):
        with self._lock:
            return self._returncode

    @property
    def cancelled(self):
        with self._lock:
            return self._cancelled

    @property
    def formatted_command(self):
        return format_command(self.display_argv)

    def wait(self, timeout=None):
        return self._finished_event.wait(timeout)

    def start(self):
        with self._lock:
            if self._state != "idle":
                raise RuntimeError("CommandRunner can only be started once")
            self._state = "starting"
        self._notify_state("starting")
        self._thread = threading.Thread(target=self._worker)
        self._thread.daemon = True
        self._thread.start()
        return self

    def _signal_process(self, process, pgid, process_signal):
        with self._lock:
            if self._process is not process or self._pgid != pgid:
                return False
            try:
                os.killpg(pgid, process_signal)
            except (OSError, ProcessLookupError):
                if process.poll() is None:
                    try:
                        process.send_signal(process_signal)
                    except OSError:
                        pass
            return True

    def cancel(self):
        with self._lock:
            if self._state in ("finished", "cancelled", "failed-to-start"):
                return False
            self._cancelled = True
            process = self._process
            pgid = self._pgid
            if self._state == "idle":
                return True
            self._state = "cancelling"
        self._notify_state("cancelling")
        if process is not None:
            self._signal_process(process, pgid, signal.SIGTERM)
            self._start_escalation(process, pgid)
        return True

    def _start_escalation(self, process, pgid):
        with self._lock:
            if self._escalation_started:
                return
            self._escalation_started = True
        thread = threading.Thread(target=self._escalate, args=(process, pgid))
        thread.daemon = True
        thread.start()

    def _escalate(self, process, pgid):
        self._finished_event.wait(self.cancel_grace)
        with self._lock:
            should_kill = self._process is process and self._pgid == pgid
            if should_kill:
                self._state = "killing"
        if should_kill:
            self._notify_state("killing")
            self._signal_process(process, pgid, signal.SIGKILL)

    def _notify_state(self, state):
        if self.state_callback is not None:
            GLib.idle_add(self._deliver, self.state_callback, state)

    @staticmethod
    def _deliver(callback, *args):
        callback(*args)
        return False

    def _emit(self, callback, text):
        size = len(text.encode("utf-8", "replace"))
        preserve = (bool(self.preserve_output_prefixes) and
                    text.lstrip().startswith(self.preserve_output_prefixes))
        if (self._output_bytes + size > self.maximum_output_bytes and
                not preserve):
            if not self._output_truncated:
                self._output_truncated = True
                GLib.idle_add(
                    self._deliver, self.line_callback,
                    _("Output display limit reached; further output omitted.\n"))
            return
        self._output_bytes += size
        GLib.idle_add(self._deliver, callback, text)

    def _worker(self):
        env = self.env.copy() if self.env is not None else os.environ.copy()
        env.setdefault("TERM", "xterm")
        try:
            process = subprocess.Popen(
                self.argv,
                stdout=subprocess.PIPE,
                stderr=(subprocess.PIPE if self.stderr_callback is not None
                        else subprocess.STDOUT),
                stdin=subprocess.DEVNULL,
                cwd=self.cwd,
                env=env,
                close_fds=True,
                shell=False,
                start_new_session=True,
            )
        except Exception as error:
            self._emit(self.line_callback,
                       _("Failed to start: {}\n").format(error))
            with self._lock:
                self._returncode = 127
                self._state = "failed-to-start"
            self._finished_event.set()
            self._notify_state("failed-to-start")
            GLib.idle_add(self._deliver, self.finished_callback,
                          127, self.cancelled)
            return

        with self._lock:
            self._process = process
            self._pgid = process.pid
            cancelled = self._cancelled
            self._state = "cancelling" if cancelled else "running"
        self._notify_state("cancelling" if cancelled else "running")
        if cancelled:
            self._signal_process(process, process.pid, signal.SIGTERM)
            self._start_escalation(process, process.pid)

        streams = [(process.stdout, self.line_callback)]
        if self.stderr_callback is not None:
            streams.append((process.stderr, self.stderr_callback))
        selector = selectors.DefaultSelector()
        decoders = {}
        for stream, callback in streams:
            selector.register(stream, selectors.EVENT_READ, callback)
            decoders[stream] = _FrameDecoder(self.maximum_output_buffer)
        while selector.get_map():
            for key, _mask in selector.select():
                chunk = os.read(key.fileobj.fileno(), 4096)
                if chunk:
                    for frame in decoders[key.fileobj].feed(chunk):
                        self._emit(key.data, frame.decode("utf-8", "replace"))
                else:
                    selector.unregister(key.fileobj)
                    for frame in decoders[key.fileobj].flush():
                        self._emit(key.data, frame.decode("utf-8", "replace"))
                    key.fileobj.close()
        selector.close()
        process.wait()
        with self._lock:
            self._process = None
            self._pgid = None
            self._returncode = process.returncode
            self._state = "cancelled" if self._cancelled else "finished"
            state = self._state
            cancelled = self._cancelled
        self._finished_event.set()
        self._notify_state(state)
        GLib.idle_add(self._deliver, self.finished_callback,
                      process.returncode, cancelled)


class CommandDialog(Gtk.Dialog):
    """Modal progress dialog with streamed output and safe cancellation."""

    def __init__(self, parent, title, argv, description=None,
                 finished_callback=None, cwd=None, env=None):
        Gtk.Dialog.__init__(
            self, title=title, transient_for=parent, modal=True,
            destroy_with_parent=True)
        self.set_default_size(700, 480)
        self._argv = argv
        self._cwd = cwd
        self._env = env
        self._finished_callback = finished_callback
        self._finished = False
        self._runner = None

        content = self.get_content_area()
        content.set_spacing(8)
        content.set_margin_top(12)
        content.set_margin_bottom(12)
        content.set_margin_start(12)
        content.set_margin_end(12)

        if description:
            label = Gtk.Label(label=description, xalign=0)
            label.set_line_wrap(True)
            content.pack_start(label, False, False, 0)

        command = Gtk.Label(label="$ " + format_command(argv), xalign=0)
        command.set_selectable(True)
        command.set_line_wrap(True)
        command.get_style_context().add_class("command-line")
        content.pack_start(command, False, False, 0)

        status = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._spinner = Gtk.Spinner()
        status.pack_start(self._spinner, False, False, 0)
        self._status_label = Gtk.Label(label=_("Working..."), xalign=0)
        status.pack_start(self._status_label, True, True, 0)
        content.pack_start(status, False, False, 0)

        self.log_view = LogView()
        content.pack_start(self.log_view, True, True, 0)
        self._cancel_button = self.add_button(
            _("Cancel"), Gtk.ResponseType.CANCEL)
        self._close_button = self.add_button(_("Close"), Gtk.ResponseType.CLOSE)
        self._close_button.set_sensitive(False)
        self.connect("response", self._on_response)
        self.connect("delete-event", self._on_delete_event)

    def start(self):
        self.show_all()
        self._spinner.start()
        self._runner = CommandRunner(
            self._argv, self.log_view.feed, self._on_finished,
            cwd=self._cwd, env=self._env)
        self._runner.start()

    def _on_finished(self, returncode, cancelled):
        self._finished = True
        succeeded = returncode == 0 and not cancelled
        self._spinner.stop()
        self._cancel_button.set_sensitive(False)
        self._close_button.set_sensitive(True)
        self._close_button.grab_focus()
        if cancelled:
            self._status_label.set_text(_("Cancelled."))
        elif succeeded:
            self._status_label.set_text(_("Completed successfully."))
        else:
            self._status_label.set_text(
                _("Failed (exit code {}).").format(returncode))
        if self._finished_callback is not None:
            self._finished_callback(succeeded)
        return False

    def _on_response(self, _dialog, response):
        if response == Gtk.ResponseType.CLOSE or self._finished:
            self.destroy()
        elif response == Gtk.ResponseType.CANCEL and self._runner is not None:
            self._status_label.set_text(_("Cancelling..."))
            self._cancel_button.set_sensitive(False)
            self._runner.cancel()

    def _on_delete_event(self, _widget, _event):
        if self._finished:
            return False
        if self._runner is not None:
            self._runner.cancel()
        return True

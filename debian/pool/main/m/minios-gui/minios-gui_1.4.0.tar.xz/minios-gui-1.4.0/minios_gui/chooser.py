"""Synchronous GTK 3 file chooser helpers."""

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk


def _add_filters(dialog, filters):
    for spec in filters or ():
        file_filter = Gtk.FileFilter()
        if isinstance(spec, dict):
            name = spec.get("name")
            patterns = spec.get("patterns", ())
            mime_types = spec.get("mime_types", ())
        else:
            name, patterns = spec[:2]
            mime_types = spec[2] if len(spec) > 2 else ()
        if isinstance(patterns, str):
            patterns = (patterns,)
        if isinstance(mime_types, str):
            mime_types = (mime_types,)
        if name:
            file_filter.set_name(name)
        for pattern in patterns:
            file_filter.add_pattern(pattern)
        for mime_type in mime_types:
            file_filter.add_mime_type(mime_type)
        dialog.add_filter(file_filter)


def _choose(action, parent=None, title=None, filters=None,
            current_folder=None, current_name=None, accept_label=None,
            local_only=True, create_folders=True, overwrite_confirmation=False,
            multiple=False):
    dialog = Gtk.FileChooserDialog(
        title=title, transient_for=parent, action=action)
    try:
        dialog.add_button(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL)
        dialog.add_button(accept_label or (
            Gtk.STOCK_SAVE if action == Gtk.FileChooserAction.SAVE
            else Gtk.STOCK_OPEN), Gtk.ResponseType.ACCEPT)
        dialog.set_select_multiple(multiple)
        dialog.set_local_only(local_only)
        dialog.set_create_folders(create_folders)
        dialog.set_do_overwrite_confirmation(overwrite_confirmation)
        if current_folder:
            dialog.set_current_folder(current_folder)
        if current_name:
            dialog.set_current_name(current_name)
        _add_filters(dialog, filters)
        if dialog.run() != Gtk.ResponseType.ACCEPT:
            return None
        if local_only:
            return (dialog.get_filenames() if multiple
                    else dialog.get_filename())
        return dialog.get_uris() if multiple else dialog.get_uri()
    finally:
        dialog.destroy()


def choose_open_file(parent=None, title=None, filters=None,
                     current_folder=None, accept_label=None, local_only=True):
    """Return a filename, or a URI when local_only is false."""
    return _choose(Gtk.FileChooserAction.OPEN, parent, title, filters,
                   current_folder, accept_label=accept_label,
                   local_only=local_only)


def choose_open_files(parent=None, title=None, filters=None,
                      current_folder=None, accept_label=None, local_only=True):
    """Return filenames, or URIs when local_only is false."""
    result = _choose(Gtk.FileChooserAction.OPEN, parent, title, filters,
                     current_folder, accept_label=accept_label,
                     local_only=local_only, multiple=True)
    return result if result is not None else None


def choose_folder(parent=None, title=None, current_folder=None,
                   accept_label=None, local_only=True, create_folders=True):
    """Return a folder filename, or a URI when local_only is false."""
    return _choose(Gtk.FileChooserAction.SELECT_FOLDER, parent, title,
                   current_folder=current_folder, accept_label=accept_label,
                   local_only=local_only, create_folders=create_folders)


def choose_save_file(parent=None, title=None, filters=None,
                     current_folder=None, current_name=None, accept_label=None,
                     local_only=True, create_folders=True,
                      overwrite_confirmation=True):
    """Return a filename, or a URI when local_only is false."""
    return _choose(Gtk.FileChooserAction.SAVE, parent, title, filters,
                   current_folder, current_name, accept_label, local_only,
                   create_folders, overwrite_confirmation)

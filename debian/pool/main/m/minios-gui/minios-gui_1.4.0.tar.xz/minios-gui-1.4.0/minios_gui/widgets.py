"""Reusable semantic GTK 3 widgets for MiniOS applications."""

import gettext
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import GObject, Gtk

from .command import LogView
from .document import DocumentTextView
from .style import new_icon, resolve_icon


_ = gettext.gettext

_BANNER_CLASSES = {
    "info": "info-banner",
    "warning": "warning-banner",
    "error": "error-banner",
    "success": "success-banner",
}

_BANNER_ICONS = {
    "info": "dialog-information-symbolic",
    "warning": "dialog-warning-symbolic",
    "error": "dialog-error-symbolic",
    "success": "emblem-default-symbolic",
}


def new_header_bar(title):
    """Return the canonical MiniOS workspace header bar."""
    header = Gtk.HeaderBar(show_close_button=True)
    header.set_has_subtitle(False)
    header.get_style_context().add_class("minios-headerbar")
    header.props.title = title
    return header


def new_header_icon_button(icon_name, accessible_name, tooltip=None):
    """Return a canonical square icon action for a MiniOS header bar."""
    button = Gtk.Button()
    button.set_image(new_icon(
        icon_name, Gtk.IconSize.BUTTON, accessible_name=accessible_name))
    button.set_tooltip_text(tooltip or accessible_name)
    button.set_focus_on_click(False)
    button.set_valign(Gtk.Align.CENTER)
    button.get_style_context().add_class("minios-header-action")
    accessible = button.get_accessible()
    if accessible is not None:
        accessible.set_name(accessible_name)
    return button


class StatusBanner(Gtk.Box):
    """Theme-aware status banner with a semantic intent, icon and message."""

    def __init__(self, text="", intent="info", icon=None):
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._intent = None
        self._icon = new_icon("dialog-information-symbolic",
                              Gtk.IconSize.LARGE_TOOLBAR)
        self._label = Gtk.Label(xalign=0)
        self._label.set_line_wrap(True)
        self._label.set_hexpand(True)
        self.pack_start(self._icon, False, False, 0)
        self.pack_start(self._label, True, True, 0)
        self.set_intent(intent, icon=icon)
        self.set_text(text)

    @property
    def label(self):
        return self._label

    @property
    def icon(self):
        return self._icon

    @property
    def intent(self):
        return self._intent

    def set_text(self, text):
        self._label.set_text(text or "")

    def set_intent(self, intent, icon=None):
        if intent not in _BANNER_CLASSES:
            raise ValueError("unknown status banner intent: {}".format(intent))
        context = self.get_style_context()
        for style_class in _BANNER_CLASSES.values():
            context.remove_class(style_class)
        context.add_class(_BANNER_CLASSES[intent])
        icon_name = resolve_icon(icon or _BANNER_ICONS[intent])
        self._icon.set_from_icon_name(icon_name, Gtk.IconSize.LARGE_TOOLBAR)
        self._intent = intent


class HelpPopoverButton(Gtk.Button):
    """Context-help button with structured, keyboard-accessible popover text."""

    def __init__(self, title, summary="", sections=(), label=None,
                 tooltip=None, compact=False, markup=False, width=None,
                 document=None, asset_resolver=None):
        Gtk.Button.__init__(self)
        self.set_focus_on_click(False)
        self.get_style_context().add_class("minios-help-button")
        if compact:
            self.set_relief(Gtk.ReliefStyle.NONE)
        icon = new_icon("dialog-information-symbolic", Gtk.IconSize.MENU,
                        accessible_name=label or title)
        if label:
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            box.pack_start(icon, False, False, 0)
            box.pack_start(Gtk.Label(label=label), False, False, 0)
            self.add(box)
            self.get_style_context().add_class("minios-text-button")
        else:
            self.add(icon)
            icon.get_style_context().add_class("field-help-icon")
        self.set_tooltip_text(tooltip or title)
        accessible = self.get_accessible()
        if accessible is not None:
            accessible.set_name(label or title)

        popover = Gtk.Popover.new(self)
        popover.set_position(Gtk.PositionType.BOTTOM)
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        content_width = int(width or (420 if compact else 600))
        scrolled.set_min_content_width(content_width)
        scrolled.set_size_request(content_width, -1)
        if hasattr(scrolled, "set_propagate_natural_width"):
            scrolled.set_propagate_natural_width(True)
        if hasattr(scrolled, "set_max_content_height"):
            scrolled.set_max_content_height(420)
        if hasattr(scrolled, "set_propagate_natural_height"):
            scrolled.set_propagate_natural_height(True)
        if document is not None:
            document_view = DocumentTextView(
                document, asset_resolver=asset_resolver)
            document_view.set_left_margin(16)
            document_view.set_right_margin(16)
            document_view.set_top_margin(12)
            document_view.set_bottom_margin(12)
            document_view.set_hexpand(True)
            document_view.set_vexpand(True)
            scrolled.add(document_view)
            self.document_view = document_view
        else:
            body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            body.set_margin_top(12)
            body.set_margin_bottom(12)
            body.set_margin_start(12)
            body.set_margin_end(12)
            heading = Gtk.Label(label=title, xalign=0)
            heading.get_style_context().add_class("minios-help-title")
            body.pack_start(heading, False, False, 0)
            self.help_heading = heading
            if summary:
                body.pack_start(
                    self._help_label(summary, markup=markup), False, False, 0)
            for section_title, section_text in sections:
                section_heading = Gtk.Label(label=section_title, xalign=0)
                section_heading.get_style_context().add_class("row-title")
                body.pack_start(section_heading, False, False, 2)
                body.pack_start(
                    self._help_label(section_text, markup=markup), False, False, 0)
            scrolled.add(body)
        popover.add(scrolled)
        self.help_scrolled = scrolled
        self.help_popover = popover
        self.connect("clicked", self._toggle_help)

    def _toggle_help(self, _button):
        if self.help_popover.get_visible():
            self.help_popover.popdown()
        else:
            self.help_popover.show_all()
            self.help_popover.popup()

    @staticmethod
    def _help_label(text, markup=False):
        label = Gtk.Label(xalign=0)
        if markup:
            label.set_markup(text)
        else:
            label.set_text(text)
        label.set_line_wrap(True)
        label.set_max_width_chars(58)
        label.set_selectable(False)
        return label


class OperationView(Gtk.Box):
    """Composable status, progress, log and cancellation presentation."""

    __gsignals__ = {
        "cancel-requested": (GObject.SignalFlags.RUN_LAST, None, ()),
    }
    _STATES = ("idle", "running", "success", "error", "cancelled")

    def __init__(self, status="", show_log=False, cancellable=True):
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.get_style_context().add_class("operation-view")
        self._state = "idle"

        self.status_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.spinner = Gtk.Spinner()
        self.status_label = Gtk.Label(label=status, xalign=0)
        self.status_label.get_style_context().add_class("operation-status")
        self.status_label.set_line_wrap(True)
        self.status_label.set_hexpand(True)
        self.cancel_button = Gtk.Button(label=_("Cancel"))
        self.cancel_button.get_style_context().add_class("destructive-action")
        self.cancel_button.set_no_show_all(not cancellable)
        self.cancel_button.set_visible(cancellable)
        self.cancel_button.connect("clicked", self._on_cancel_clicked)
        self.status_row.pack_start(self.spinner, False, False, 0)
        self.status_row.pack_start(self.status_label, True, True, 0)
        self.status_row.pack_end(self.cancel_button, False, False, 0)
        self.pack_start(self.status_row, False, False, 0)

        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_no_show_all(True)
        self.pack_start(self.progress_bar, False, False, 0)
        self.log_view = LogView()
        self.log_expander = Gtk.Expander(label=_("Details"))
        self.log_expander.add(self.log_view)
        self.log_expander.set_no_show_all(not show_log)
        self.log_expander.set_visible(show_log)
        self.pack_start(self.log_expander, True, True, 0)
        self.set_state("idle")

    @property
    def state(self):
        return self._state

    def set_status(self, status):
        self.status_label.set_text(status or "")

    def set_state(self, state, status=None):
        if state not in self._STATES:
            raise ValueError("invalid operation state: {}".format(state))
        context = self.get_style_context()
        for current in self._STATES:
            context.remove_class("operation-{}".format(current))
        context.add_class("operation-{}".format(state))
        self._state = state
        if status is not None:
            self.set_status(status)
        if state == "running":
            # Hidden overlays can be excluded from the toplevel's initial
            # show_all(). Reveal their status children when work actually starts.
            self.status_row.show_all()
            self.spinner.start()
        else:
            self.spinner.stop()
        self.cancel_button.set_sensitive(state == "running")

    def set_progress(self, fraction=None):
        if fraction is None:
            self.progress_bar.hide()
            return
        self.progress_bar.set_fraction(max(0.0, min(1.0, float(fraction))))
        self.progress_bar.show()

    def set_log_visible(self, visible):
        self.log_expander.set_no_show_all(not visible)
        self.log_expander.set_visible(bool(visible))

    def feed(self, text, level=None):
        return self.log_view.feed(text, level=level)

    def append_line(self, message, timestamp=None, level=None):
        return self.log_view.append_line(message, timestamp, level)

    def _on_cancel_clicked(self, _button):
        self.cancel_button.set_sensitive(False)
        self.emit("cancel-requested")


class ProgressDialog(Gtk.Dialog):
    """Thin dialog wrapper around OperationView."""

    def __init__(self, parent=None, title="", status="", show_log=False,
                 cancellable=True):
        Gtk.Dialog.__init__(
            self, title=title, transient_for=parent, modal=True,
            destroy_with_parent=True)
        self.operation_view = OperationView(
            status=status, show_log=show_log, cancellable=cancellable)
        content = self.get_content_area()
        content.set_border_width(12)
        content.add(self.operation_view)
        self.operation_view.connect("cancel-requested", self._on_cancel)

    def _on_cancel(self, _view):
        self.response(Gtk.ResponseType.CANCEL)


class StatePlaceholder(Gtk.Box):
    """Generic icon, title, description and optional action placeholder."""

    __gsignals__ = {
        "action-activated": (GObject.SignalFlags.RUN_LAST, None, ()),
    }

    def __init__(self, title="", description="", icon_name=None,
                 action_label=None):
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.get_style_context().add_class("state-placeholder")
        self.set_halign(Gtk.Align.CENTER)
        self.set_valign(Gtk.Align.CENTER)
        self.icon = new_icon(icon_name or "dialog-information-symbolic",
                             Gtk.IconSize.DIALOG)
        self.title_label = Gtk.Label(label=title)
        self.title_label.get_style_context().add_class(
            "state-placeholder-title")
        self.description_label = Gtk.Label(label=description)
        self.description_label.set_line_wrap(True)
        self.description_label.set_justify(Gtk.Justification.CENTER)
        self.action_button = Gtk.Button(label=action_label or "")
        self.action_button.set_no_show_all(action_label is None)
        self.action_button.set_visible(action_label is not None)
        self.action_button.connect(
            "clicked", lambda _button: self.emit("action-activated"))
        self.pack_start(self.icon, False, False, 0)
        self.pack_start(self.title_label, False, False, 0)
        self.pack_start(self.description_label, False, False, 0)
        self.pack_start(self.action_button, False, False, 4)


class PasswordEntry(Gtk.Box):
    """Password entry with hold-to-reveal or persistent toggle reveal."""

    def __init__(self, reveal_mode="hold", placeholder_text=None,
                 show_label=None, hide_label=None):
        if reveal_mode not in ("hold", "toggle"):
            raise ValueError("reveal_mode must be 'hold' or 'toggle'")
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.reveal_mode = reveal_mode
        self.show_label = (_("Show password") if show_label is None
                           else show_label)
        self.hide_label = (_("Hide password") if hide_label is None
                           else hide_label)
        self.entry = Gtk.Entry()
        self.entry.set_visibility(False)
        if placeholder_text is not None:
            self.entry.set_placeholder_text(placeholder_text)
        if reveal_mode == "toggle":
            self.reveal_button = Gtk.ToggleButton()
        else:
            self.reveal_button = Gtk.Button()
        self.reveal_button.set_focus_on_click(False)
        self.reveal_icon = new_icon(
            "view-reveal-symbolic", Gtk.IconSize.BUTTON,
            accessible_name=self.show_label)
        self.reveal_button.add(self.reveal_icon)
        self.entry.set_hexpand(True)
        self.pack_start(self.entry, True, True, 0)
        self.pack_start(self.reveal_button, False, False, 0)
        if reveal_mode == "toggle":
            self.reveal_button.connect("toggled", self._on_toggled)
        else:
            self.reveal_button.connect("pressed", self._on_pressed)
            self.reveal_button.connect("released", self._on_released)
            self.reveal_button.connect("leave-notify-event", self._on_hold_lost)
            self.reveal_button.connect("focus-out-event", self._on_hold_lost)
            self.entry.connect("focus-out-event", self._on_hold_lost)
        self._update_reveal_semantics(False)

    def get_text(self):
        return self.entry.get_text()

    def set_text(self, text):
        self.entry.set_text(text)

    def _on_toggled(self, button):
        revealed = button.get_active()
        self.entry.set_visibility(revealed)
        self._update_reveal_semantics(revealed)

    def _on_pressed(self, _button):
        self.entry.set_visibility(True)
        self._update_reveal_semantics(True)

    def _on_released(self, _button):
        self._hide_held_password()

    def _on_hold_lost(self, _widget, _event):
        self._hide_held_password()
        return False

    def _hide_held_password(self):
        self.entry.set_visibility(False)
        self._update_reveal_semantics(False)

    def _update_reveal_semantics(self, revealed):
        if revealed:
            icon_name = "view-conceal-symbolic"
            label = self.hide_label
        else:
            icon_name = "view-reveal-symbolic"
            label = self.show_label
        self.reveal_icon.set_from_icon_name(
            resolve_icon(icon_name), Gtk.IconSize.BUTTON)
        self.reveal_button.set_tooltip_text(label)
        accessible = self.reveal_button.get_accessible()
        if accessible is not None:
            accessible.set_name(label)


class IconTextRow(Gtk.Box):
    """Horizontal row combining optional widgets with title and subtitle."""

    def __init__(self, title, subtitle=None, icon_name=None, leading=None,
                 trailing=None):
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.get_style_context().add_class("icon-text-row")
        self.leading = leading
        if self.leading is None and icon_name:
            self.leading = new_icon(icon_name, Gtk.IconSize.DND)
        if self.leading is not None:
            self.pack_start(self.leading, False, False, 0)
        labels = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.title_label = Gtk.Label(label=title, xalign=0)
        self.title_label.get_style_context().add_class("row-title")
        self.subtitle_label = Gtk.Label(label=subtitle or "", xalign=0)
        self.subtitle_label.get_style_context().add_class("row-subtitle")
        self.subtitle_label.set_no_show_all(subtitle is None)
        self.subtitle_label.set_visible(subtitle is not None)
        self.subtitle_label.set_line_wrap(True)
        labels.pack_start(self.title_label, False, False, 0)
        labels.pack_start(self.subtitle_label, False, False, 0)
        self.pack_start(labels, True, True, 0)
        self.trailing = trailing
        if trailing is not None:
            self.pack_end(trailing, False, False, 0)

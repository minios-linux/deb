"""Shared GTK 3 helpers for MiniOS graphical applications.

The public API intentionally uses syntax available in Python 3.6 and GTK 3.22.
"""

from .chooser import (
    choose_folder, choose_open_file, choose_open_files, choose_save_file,
)
from .command import (
    CommandDialog, CommandRunner, LogView, format_command, format_log_line,
)
from .completion import TokenCompletionPopover
from .dialogs import ask_confirmation, show_error_dialog, show_info_dialog
from .document import (
    DocumentFormatError, DocumentTextView, document_asset_path,
    load_localized_document, validate_document,
)
from .module_display import classify_module, format_bytes
from .style import (
    SHARED_CSS_PATH,
    apply_css,
    apply_minios_css,
    new_icon,
    resolve_icon,
)
from .task import (
    BackgroundTask, CancellationToken, TaskCancelled, TaskOutcome,
)
from .widgets import (
    HelpPopoverButton, IconTextRow, OperationView, PasswordEntry,
    ProgressDialog, StatePlaceholder, StatusBanner, new_header_bar,
    new_header_icon_button,
)

__version__ = "1.4.1"

__all__ = (
    "BackgroundTask",
    "CancellationToken",
    "SHARED_CSS_PATH",
    "CommandDialog",
    "CommandRunner",
    "DocumentFormatError",
    "DocumentTextView",
    "HelpPopoverButton",
    "IconTextRow",
    "LogView",
    "OperationView",
    "PasswordEntry",
    "ProgressDialog",
    "StatePlaceholder",
    "StatusBanner",
    "TokenCompletionPopover",
    "TaskCancelled",
    "TaskOutcome",
    "apply_css",
    "classify_module",
    "apply_minios_css",
    "ask_confirmation",
    "choose_folder",
    "choose_open_file",
    "choose_open_files",
    "choose_save_file",
    "document_asset_path",
    "format_bytes",
    "format_command",
    "format_log_line",
    "load_localized_document",
    "new_header_bar",
    "new_header_icon_button",
    "new_icon",
    "resolve_icon",
    "show_error_dialog",
    "show_info_dialog",
    "validate_document",
)

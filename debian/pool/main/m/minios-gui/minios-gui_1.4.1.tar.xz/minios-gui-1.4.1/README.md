# MiniOS GUI

## Overview

Shared GUI resources for MiniOS graphical applications.

This source repository builds two architecture-independent Debian packages:

- **`minios-gui`** — the canonical GTK 3 application stylesheet;
- **`python3-minios-gui`** — Python 3.6-compatible GTK helpers.

The stylesheet is installed to:

```
/usr/share/minios/minios.css
```

## Components

`minios.css` is a GTK 3 stylesheet organized into 15 sections: brand tokens, header bar, sidebar, sidebar steps, typography, content cards, status banners, buttons, badge pills, lists, entries/validation, progress, footer/action bar, log view, and drop-zone/empty-state helpers.

Design rules encoded by the sheet:

- **Theme-aware.** Surfaces derive from the running GTK theme (`@theme_bg_color`, `@theme_base_color`, `@borders`, `@theme_fg_color`, `@theme_selected_bg_color`), so light and dark desktops both work.
- **Brand accent.** Only the primary action (`suggested-action`) and small brand accents use the fixed MiniOS blue; destructive actions use the MiniOS red.
- **One vocabulary.** Canonical class names (`minios-headerbar`, `minios-sidebar`, `content-card`, `info/warning/error/success-banner`, `badge*`, `minios-list`, `minios-footer`, …) replace the per-app variants.
- **Consistent content buttons.** Label-only GTK buttons receive the compact Installer height and shared 12 px horizontal padding automatically; icon+text buttons use `minios-text-button`. Emphasized/footer actions use 14 px horizontally. HeaderBar icon buttons retain native theme metrics.

Only the eight semantic brand colors are hard-coded (via `@define-color`); everything else follows the theme. Action/status icons come from the existing `elementary-minios-icon-theme`, whose source is maintained in the `elementary-xfce-minios` repository.

The `minios_gui` Python package provides:

- `apply_minios_css()` / `apply_css()` for deterministic base + app CSS loading;
- `resolve_icon()` / `new_icon()` for safe icon-theme lookup;
- standard informational, error and irreversible-action confirmation dialogs;
- `new_header_bar()` and `new_header_icon_button()` for canonical MiniOS workspace headers and square icon actions;
- `StatusBanner` for reusable info/warning/error/success banners with semantic styling and icon handling;
- `classify_module()` / `format_bytes()` for consistent compact module presentation across MiniOS graphical tools;
- `TokenCompletionPopover` for token-aware static or asynchronous entry completion, anchored visually to the word being completed; arrows choose a result and Tab/Enter accept it while Shift+Tab keeps normal focus navigation;
- `HelpPopoverButton` for keyboard-accessible contextual help, from compact field explanations to structured page-level guidance or a precompiled document;
- `DocumentTextView` for parser-free rendering of precompiled MiniOS markup documents, including native tables, links, anchors and SVG/image assets;
- `LogView`, `CommandRunner` and `CommandDialog` for responsive, cancellable, streamed command execution outside the GTK main loop;
- `BackgroundTask`, `CancellationToken`, `TaskOutcome` and `TaskCancelled` for cooperative non-blocking work with owner-lifetime-safe completion callbacks;
- synchronous `choose_open_file()`, `choose_open_files()`, `choose_folder()` and `choose_save_file()` helpers with GTK filters and guaranteed dialog cleanup;
- `OperationView` / `ProgressDialog`, `StatePlaceholder`, `PasswordEntry` and `IconTextRow` for composable, domain-neutral operation presentation.

### Generic API signatures

```python
CommandRunner(argv, line_callback, finished_callback, cwd=None, env=None,
              state_callback=None, cancel_grace=3.0,
              maximum_output_buffer=64 * 1024,
              maximum_output_bytes=8 * 1024 * 1024,
              display_argv=None, stderr_callback=None,
              preserve_output_prefixes=())
LogView(maximum_characters=None)
LogView.feed(text, level=None)
LogView.append_line(message, timestamp=None, level=None)

CancellationToken()
TaskOutcome(state, value=None, error=None)
BackgroundTask(worker, finished_callback=None, state_callback=None,
               dispatcher=None, owner=None, token=None)

choose_open_file(parent=None, title=None, filters=None, current_folder=None,
                 accept_label=None, local_only=True)
choose_open_files(parent=None, title=None, filters=None, current_folder=None,
                  accept_label=None, local_only=True)
choose_folder(parent=None, title=None, current_folder=None, accept_label=None,
              local_only=True, create_folders=True)
choose_save_file(parent=None, title=None, filters=None, current_folder=None,
                 current_name=None, accept_label=None, local_only=True,
                 create_folders=True, overwrite_confirmation=True)

OperationView(status="", show_log=False, cancellable=True)
ProgressDialog(parent=None, title="", status="", show_log=False,
               cancellable=True)
StatePlaceholder(title="", description="", icon_name=None, action_label=None)
PasswordEntry(reveal_mode="hold", placeholder_text=None,
              show_label=None, hide_label=None)
IconTextRow(title, subtitle=None, icon_name=None, leading=None, trailing=None)
```

Chooser filter specs may be `(name, patterns[, mime_types])` tuples or mappings with `name`, `patterns` and `mime_types` keys. Chooser helpers return local filename(s) when `local_only=True` and URI(s) when `local_only=False`. Commands always execute an argv sequence with `shell=False`; `display_argv` only controls the safely quoted `formatted_command` presentation. Unless `stderr_callback` is supplied, stderr remains combined with stdout. Runner and task callbacks are dispatched through the GTK main loop by default. `preserve_output_prefixes` keeps matching critical frames after the normal output limit. Cancellation tokens provide idempotent `cancel()`, `checkpoint()` / `raise_if_cancelled()` and removable callbacks; `TaskOutcome.from_outcome()` adapts legacy `result/error/cancelled` outcomes.

## Usage

The source repository **does not modify any application**. An app opts in by depending on the relevant binary package and loading shared resources first:

```python
from minios_gui import apply_minios_css

apply_minios_css("/usr/share/minios-installer/style.css")
```

Load order matters: the shared base first, the app sheet second so an app can still override or add genuinely app-specific widgets.

An application that only loads the stylesheet depends on `minios-gui`. An app that imports `minios_gui` depends on `python3-minios-gui` (which in turn depends on the matching `minios-gui` binary version). Markdown is an authoring/build format, not a runtime API. Applications that ship Markdown help compile it to the MiniOS document format before packaging and render it with `DocumentTextView` or pass the compiled object to `HelpPopoverButton(document=...)`. Mermaid blocks are likewise rendered to static SVG during that build step.

Example runtime use:

```python
import json
from minios_gui import HelpPopoverButton

with open("/usr/share/example-app/help/storage.json", encoding="utf-8") as stream:
    document = json.load(stream)
help_button = HelpPopoverButton("Storage", document=document, compact=True)
```

## Compatibility

- Python 3.6 and later;
- GTK 3.22 and later;
- Debian 10–13 and later, equivalent Devuan releases, Ubuntu 18.04–26.04 and later.

No dataclasses, assignment expressions, structural matching or GTK 4 APIs are used by the shared Python package.

## Scope

This is **not** a GTK system theme. It is an application-level stylesheet and helper library loaded on top of the active GTK theme. The shared MiniOS icon theme is `elementary-minios-icon-theme`, maintained in the `elementary-xfce-minios` source repository.

## Development

Standard Debian packaging (`debhelper` compat 11):

```sh
dpkg-buildpackage -us -uc -b
```

Or install both resource groups into a staging tree:

```sh
make install DESTDIR=/path/to/root
```

The build produces `minios-gui_<version>_all.deb` and `python3-minios-gui_<version>_all.deb`.

### Shared documentation compiler

Applications that author help in Markdown use the shared build-only compiler in `tools/`. Install its pinned npm dependencies locally with:

```sh
tools/npm-ci.sh
```

`tools/markdown-compiler.mjs` converts Markdown batches into the parser-free MiniOS document format. Fenced code is tokenized at build time by Shiki 2.5.0 with the same `github-light` / `github-dark` themes used by the current VitePress documentation, and Mermaid fences are rendered to sanitized static SVG. The Node/npm/Puppeteer toolchain is not installed by the Debian binary packages; applications commit their generated JSON/SVG bundles and only need `DocumentTextView` at runtime.

## License

Distributed under the GNU General Public License v2 or later.

"""Password actions use the eye icons shipped by Elementary, with fallbacks."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from gi.repository import Gtk
from minios_gui import PasswordEntry


class PasswordIcons(unittest.TestCase):
    def test_elementary_eye_names_and_reveal_state(self):
        icons = {'eye-open-negative-filled-symbolic', 'eye-not-looking-symbolic'}
        theme = SimpleNamespace(has_icon=lambda name: name in icons)
        with patch('minios_gui.style.Gtk.IconTheme.get_default', return_value=theme):
            entry = PasswordEntry('toggle')
            self.assertEqual(entry.reveal_icon.get_icon_name()[0], 'eye-open-negative-filled-symbolic')
            entry.reveal_button.set_active(True)
            self.assertTrue(entry.entry.get_visibility())
            self.assertEqual(entry.reveal_icon.get_icon_name()[0], 'eye-not-looking-symbolic')
            entry.reveal_button.set_active(False)
            self.assertFalse(entry.entry.get_visibility())
            self.assertEqual(entry.reveal_icon.get_icon_name()[0], 'eye-open-negative-filled-symbolic')

    def test_minimal_theme_has_password_fallback(self):
        theme = SimpleNamespace(has_icon=lambda name: name == 'dialog-password')
        with patch('minios_gui.style.Gtk.IconTheme.get_default', return_value=theme):
            entry = PasswordEntry('toggle')
            self.assertEqual(entry.reveal_icon.get_icon_name()[0], 'dialog-password')
            entry.reveal_button.set_active(True)
            self.assertEqual(entry.reveal_icon.get_icon_name()[0], 'dialog-password')

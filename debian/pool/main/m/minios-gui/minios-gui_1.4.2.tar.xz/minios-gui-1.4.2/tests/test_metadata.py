"""Keep maintained release metadata synchronized."""
import re
from pathlib import Path

from minios_gui import __version__


def test_python_version_matches_debian_changelog():
    root = Path(__file__).resolve().parents[1]
    first_line = (root / "debian/changelog").read_text(encoding="utf-8").splitlines()[0]
    match = re.fullmatch(r"minios-gui \(([^)]+)\) unstable; urgency=\w+", first_line)
    assert match is not None
    assert __version__ == match.group(1)

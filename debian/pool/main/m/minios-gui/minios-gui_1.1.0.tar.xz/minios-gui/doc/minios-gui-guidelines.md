# MiniOS GUI guidelines

| Field | Value |
|-------|-------|
| **Date** | 2026-08-04 |
| **Status** | Draft 2 — researched design standard |
| **Applies to** | All GTK GUI apps shipped in MiniOS (`minios-*`, `driveutility`) |
| **Reference implementations** | `minios-installer`, `minios-configurator`, `driveutility` |
| **Canonical stylesheet** | `submodules/minios-gui/share/minios.css` |
| **Platform baseline** | Python 3.6+, GTK 3.22+, Debian 10–13+, Devuan equivalents, Ubuntu 18.04–26.04+ |

---

## 1. Purpose & scope

MiniOS ships a family of desktop tools — installer, configurator, module manager,
kernel manager, session manager, image builder and drive utility. They are built
by the same team on the same toolkit, but each grew its own stylesheet, its own
class names and its own layout habits. The result is a set of programs that are
*individually* fine but look like they came from different projects.

This document defines **one** visual language and **one** set of building blocks
so that any MiniOS GUI feels like part of the same product. It covers:

- the toolkit and foundations every app must share;
- design tokens (color, spacing, radius, type, sizing);
- the window, navigation, layout and component rules;
- behavioral conventions (primary actions, destructive confirmation, privilege,
  streamed command output);
- desktop-integration and `.desktop` conventions;
- a **canonical `minios.css`** that encodes all of the above.

It does **not** cover the two non-GTK outliers except to place them:

- **`minios-store`** — a React/Tailwind web UI rendered in a webview;
- **`minios-welcome`** — an HTML slideshow.

Those follow web conventions and are out of scope here; they should still reuse
the **palette** in §4 for brand consistency.

### 1.1 How the references were chosen

`minios-installer`, `minios-configurator` and `driveutility` are the most
finished interfaces and are treated as authoritative. The other GTK apps
(`minios-module-manager`, `minios-kernel-manager`, `minios-session-manager`,
`minios-image-builder`) are less complete — `minios-image-builder` most of all —
and where they diverge from this guideline, **they are the ones that change**,
not the guideline. §13 lists what each app needs to align.

### 1.2 External design basis

This standard was cross-checked against current primary guidance from GNOME,
KDE, Microsoft, Apple and W3C. MiniOS does not copy a single platform language:
it adopts principles that transfer to a GTK 3 desktop while preserving native
theme behavior and compatibility with older distributions.

| Source | What MiniOS adopts | What is not copied literally |
|--------|--------------------|------------------------------|
| [GNOME HIG](https://developer.gnome.org/hig/) | Focused windows, shallow navigation, header-bar discipline, symbolic action icons, inline feedback, adaptive sizing, accessible keyboard flow | Libadwaita/GTK 4 widgets and phone-first layouts unavailable on GTK 3 |
| [KDE HIG](https://develop.kde.org/hig/) | “Simple by default, powerful when needed”, consistent spacing units, visible core actions, actionable empty/error states | Kirigami/KXMLGui components and KDE-specific menu structure |
| [Windows App Design](https://learn.microsoft.com/en-us/windows/apps/design/) | Responsive layout, command prioritization, explicit action labels, undo for reversible actions, accessible input | WinUI control dimensions and Windows-specific dialog ordering |
| [Apple HIG](https://developer.apple.com/design/human-interface-guidelines/) | Clear visual hierarchy, restrained prominence, standard symbols, one or two prominent actions, platform-native metrics | SF Symbols/AppKit-only components and macOS-specific command placement |
| [WCAG 2.2](https://www.w3.org/TR/WCAG22/) and [ARIA APG](https://www.w3.org/WAI/ARIA/apg/) | Contrast targets, keyboard operability, visible focus, target size, error identification, status announcement principles | ARIA/DOM implementation details do not apply directly to native GTK/ATK |

Where sources disagree, MiniOS follows these precedence rules:

1. Preserve native GTK behavior when it is accessible and visually sound.
2. Prefer the pattern that best supports the task, not the one that looks newest.
3. Use progressive disclosure: common actions visible, advanced power available.
4. Prefer prevention and undo over confirmation; confirm only irreversible risk.
5. Treat measurable accessibility requirements as release criteria, not advice.

---

## 2. Reference applications & the two archetypes

Every MiniOS GUI is one of two shapes. Pick the smallest one that fits.

### 2.1 Workspace (multi-section / multi-step)

Used by **`minios-installer`** (wizard) and **`minios-configurator`** (categories).

```
┌───────────────────────────────────────────────┐
│ ⟨HeaderBar: title, window controls⟩            │  ← .minios-headerbar
├──────────┬────────────────────────────────────┤
│          │  Page title                         │
│ Sidebar  │  Page subtitle                      │
│ (nav)    │  ┌──────────────────────────────┐   │
│          │  │ content-card                 │   │
│ • Step 1 │  │  label : control             │   │
│ • Step 2 │  │  label : control             │   │
│ • Step 3 │  └──────────────────────────────┘   │
│          │                                     │
│          │  ──────────────────────────────     │  ← nav-separator
│          │  [Back]                    [Next]    │  ← primary bottom-right
└──────────┴────────────────────────────────────┘
```

- Left **rail** (`minios-sidebar`, ~180 px) for navigation.
- Scrollable content area with a **page title** + optional subtitle.
- Related fields grouped in **content-cards**.
- A **footer / in-page nav** with the primary action at the bottom-right.
- Window sized as a fraction of the monitor work area (see §4.5).

### 2.2 Utility (single task, compact)

Used by **`driveutility`**.

```
┌───────────────────────────────────────────────┐
│ ⟨HeaderBar:  ⟨Write │ Create │ Format │ Wipe⟩ ⟩ │  ← centered StackSwitcher
├───────────────────────────────────────────────┤
│   To disk:     [ combo ▾ ]                      │
│   Image file:  [ file chooser        ]          │  ← Gtk.Grid, 12px gutters
│                [███████ progress ███████]       │
│   ☐ Show mounted disks                          │  ← safety toggle
├───────────────────────────────────────────────┤
│                                      [ _Write ] │  ← GtkActionBar, primary end
└───────────────────────────────────────────────┘
```

- HeaderBar hosts a centered **`GtkStackSwitcher`** for the 2–5 modes.
- Each mode is a **`Gtk.Grid`** form: left-aligned label column, expanding control.
- A **`GtkActionBar`** holds the primary action, packed to the end.
- Compact, fixed / non-resizable window.

> If a tool has more than ~5 top-level sections, or its sections have their own
> multi-field forms, use the **workspace** archetype instead.

---

## 3. Foundations

Non-negotiable, shared by every GTK app.

| Foundation | Rule |
|-----------|------|
| **Toolkit** | GTK **3** via PyGObject (`gi.require_version('Gtk', '3.0')`). Do not mix GTK 4 into the family yet. |
| **Theme awareness** | Never hard-code window/background/text colors. Use `@theme_bg_color`, `@theme_base_color`, `@theme_fg_color`, `@theme_text_color`, `@theme_selected_bg_color`, `@borders`. The UI must look correct on both light and dark desktops. |
| **Brand accent** | Only the **primary action** and small brand accents use the fixed MiniOS blue (§4.1). Everything else derives from the theme. |
| **Stylesheet** | Load `minios.css` at `GTK_STYLE_PROVIDER_PRIORITY_APPLICATION`, then optionally an app-specific sheet for widgets unique to that app. |
| **Icons** | Symbolic icons from the theme for in-app actions (`view-refresh-symbolic`, `list-add-symbolic`, …); resolve with a fallback so a missing icon never crashes the UI. |
| **i18n** | All user-facing strings through `gettext` (`_()`), with a bound text domain. |
| **Privilege** | Escalate with `pkexec` from the `.desktop` entry — not `sudo` in a terminal (see §9.4). |

### 3.1 Product quality principles

Consistency is a baseline, not the design goal. A MiniOS app must also be:

- **Clear:** the primary task and next action are obvious without reading every label.
- **Calm:** use one accent, restrained borders and whitespace instead of decoration.
- **Efficient:** compact enough for utility work, but never cramped; align repeated
  controls and preserve predictable scan paths.
- **Native where native is better:** do not override GTK chrome, menus or composite
  controls merely to make them different. Shared styling is for semantic components.
- **Purposeful:** visual differences are retained when they communicate different
  roles (for example a large empty-state illustration versus a small field-help icon).
- **Accessible:** do not encode state by color alone; preserve theme contrast,
  keyboard navigation, mnemonics, tooltips and readable disabled states.

### 3.2 Loading the stylesheet

The reference apps already ship an `apply_css_if_exists()` helper
(e.g. `minios-module-manager/lib/ui_utils.py:63`). Standardize on this shape and
load `minios.css` **before** any app-specific sheet:

```python
def apply_css(*css_paths):
    screen = Gdk.Screen.get_default()
    for path in css_paths:
        if path and os.path.exists(path):
            provider = Gtk.CssProvider()
            provider.load_from_path(path)
            Gtk.StyleContext.add_provider_for_screen(
                screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

# order matters: shared base first, app overrides second
apply_css("/usr/share/minios/minios.css",
          "/usr/share/minios-installer/style.css")
```

---

## 4. Design tokens

### 4.1 Color palette

The eight brand tokens (defined via `@define-color` in `minios.css`). Surfaces
and neutrals come from the theme; these are the only hard-coded colors.

| Token | Hex | Use |
|-------|-----|-----|
| `@minios_blue` | `#4a90d9` | Primary accent, gradient bottom |
| `@minios_blue_light` | `#6bb5ff` | Primary gradient top / hover |
| `@minios_blue_dark` | `#3875c4` | Primary border / pressed |
| `@minios_red` | `#c6262e` | Destructive |
| `@minios_red_light` | `#ed5353` | Destructive gradient top |
| `@minios_red_dark` | `#c01c28` | Destructive border |
| `@minios_amber` | `#e5a50a` | Warning |
| `@minios_green` | `#26a269` | Success |

**Semantic intents** (used by banners, badges, list-row accents):

| Intent | Color | Wash (bg) | Border |
|--------|-------|-----------|--------|
| Info / accent | `@minios_blue` | `alpha(…, 0.12)` | `alpha(…, 0.45)` |
| Success | `@minios_green` | `alpha(…, 0.14)` | `alpha(…, 0.48)` |
| Warning | `@minios_amber` | `alpha(…, 0.18)` | `alpha(…, 0.55)` |
| Error | `@minios_red` | `alpha(…, 0.14)` | `alpha(…, 0.50)` |

> The palette maps to the elementary/Adwaita family used by the existing
> `elementary-minios-icon-theme` (source: `elementary-xfce-minios`), so icons and
> application chrome agree.

### 4.2 Spacing

Use an **even, 2-based** scale. No arbitrary values.

| Step | px | Typical use |
|------|----|-------------|
| xs | 2 | Row internal, tight stacks |
| s | 4 | Title↔subtitle, icon↔label |
| m | 6 | Sidebar padding, card padding (compact) |
| l | 8 | Card padding, banner padding, grid gutters |
| xl | 10–12 | Content margins, form gutters, dialog margins |
| 2xl | 16–24 | Result / hero pages only |

`Gtk.Grid` forms use **12 px** row/column spacing and a **12 px** container
border (as in `driveutility.ui`).

### 4.3 Corner radius

| Element | Radius |
|---------|--------|
| Buttons, entries, banners, list rows, sidebar items | **4 px** |
| Content cards, list containers, scrolled windows, progress bars | **6 px** |
| Badges (pills) | **9 px** (pill) |
| Drop zones | 8 px |

> This resolves the current 4/5/6/8 px card inconsistency: **cards are 6 px**,
> **small controls are 4 px**.

### 4.4 Typography scale

Keep it tight. The theme's default font is the body size.

| Class | Size | Weight |
|-------|------|--------|
| `.page-title` | 18–20 px | bold |
| `.section-title` | 14–15 px | bold |
| body / controls | default (theme) | normal |
| `.page-subtitle`, `.dim-label`, `.field-description` | default / `smaller` | normal, 72% opacity |
| `.badge`, `.row-meta` | 10 px / `smaller` | 700 / normal |

Page titles establish hierarchy but must not dominate a utility window. Avoid
decorative eyebrows, negative tracking and multiple competing title sizes.

### 4.5 Window sizing

| Archetype | Rule |
|-----------|------|
| Utility | Prefer resizable with a compact default. A fixed window is allowed only when all modes, translations and 200% text scaling fit without clipping (e.g. a carefully tested Drive Utility). |
| Workspace | Resizable. `set_default_size` to a fraction of the monitor **work area**, clamped to sane min/max, then `set_size_request` a floor so core controls never collapse. Must fit a 1024×600 work area. |

Reference (`minios-configurator/lib/main_configurator.py:240`):

```python
workarea = screen.get_monitor_workarea(screen.get_primary_monitor())
width  = min(900, max(700, int(workarea.width  * 0.76)))
height = min(600, max(480, int(workarea.height * 0.76)))
self.set_default_size(width, height)
```

Always `set_icon_name(...)` and center the first launch with
`Gtk.WindowPosition.CENTER`. Preserve user-resized geometry when practical.

---

## 5. Window & header bar

Every window uses a header bar — including utilities. Keep native GTK sizing;
never force a compact height that squashes a `GtkStackSwitcher`. Workspace apps
add `minios-headerbar` for light shared spacing. Compact utilities such as
Drive Utility may retain the theme-native header unchanged when it is visually
better.

```python
header = Gtk.HeaderBar(show_close_button=True)
header.set_has_subtitle(False)
header.get_style_context().add_class("minios-headerbar")
header.props.title = _("MiniOS Installer")
self.set_titlebar(header)
```

Rules:

- **Class** `minios-headerbar` on workspace header bars for shared horizontal spacing.
- **Title** = the application name; **no subtitle** (`set_has_subtitle(False)`).
- **Window controls** follow the active GTK theme; do not force their dimensions.
- Header **actions** are icon-only, flat (`relief=NONE`), symbolic icons, with a
  tooltip *and* an accessible name (see `minios-image-builder`'s
  `_header_button`, `main_image_builder.py:438`, for the pattern — the pattern is
  good even though that app is otherwise non-canonical).
- Utility archetype: a centered **`GtkStackSwitcher`** may be the header's custom
  title widget (`driveutility.ui:1268`).

Reference header bars: `minios-installer/lib/main_installer.py:1011`,
`minios-configurator/lib/main_configurator.py:295`.

---

## 6. Navigation

### 6.1 Left rail — `minios-sidebar`

One surface class for the nav rail in the workspace archetype: **`minios-sidebar`**
(replaces today's `config-sidebar` / `installer-sidebar` / `app-sidebar` /
`minios-sidebar` / `manager-*` sprawl). Width **180 px**.

Two contents are allowed inside it:

**a) Category list** — a `Gtk.ListBox`, `SelectionMode.SINGLE`
(`minios-configurator/lib/main_configurator.py:308`):

```python
self.sidebar = Gtk.ListBox()
self.sidebar.set_selection_mode(Gtk.SelectionMode.SINGLE)
self.sidebar.set_size_request(180, -1)
self.sidebar.get_style_context().add_class("minios-sidebar")
```

**b) Wizard steps** — flat `Gtk.Button`s with `sidebar-step`
(`minios-installer/lib/main_installer.py:1362`). Each step carries a state class
and a leading marker:

| State | Class | Marker |
|-------|-------|--------|
| Current | `sidebar-step-active` | `●` + **bold** label + accent left border |
| Visited | `sidebar-step-done` | `✓`, 85% opacity |
| Not yet reached | `sidebar-step-todo` | step number, 55% opacity |

Content switches through a `Gtk.Stack` (`CROSSFADE` for categories;
show/rebuild per step for wizards).

### 6.2 Header StackSwitcher (utility)

For 3–5 peer modes with no ordering, put a centered `GtkStackSwitcher` bound to
the content `Gtk.Stack` in the header bar. Give each stack child a translatable
`title` and an `icon_name` (`driveutility.ui`).

For more than five independent destinations use a sidebar. For a hierarchical
workflow use Back/Next or browsing navigation rather than peer tabs. Keep the
navigation hierarchy to one level whenever possible.

### 6.3 Notebook tabs — discouraged

`Gtk.Notebook` tabs (as in `minios-kernel-manager`) are acceptable only for a
genuinely tabbed **secondary** area. Do not use tabs as the top-level navigation;
prefer a rail or a header switcher for product consistency.

---

## 7. Content layout

### 7.1 Page header

Start each page/section with a `page-title` and, if it needs a sentence of
explanation, a `page-subtitle` (`main_installer.py:1417`):

```python
title = Gtk.Label(xalign=0)
title.get_style_context().add_class("page-title")
title.set_text(_("Select destination"))
```

### 7.2 Content cards

Group related controls in a **`content-card`** — a transparent, 1 px-bordered,
6 px-radius container on the window background. Never fill a card with the
entry-white `@theme_base_color` (white-on-gray looks broken); the border defines
it.

### 7.3 Forms

- Layout with `Gtk.Grid`: **left-aligned** label (`halign=start`, `xalign=0`,
  `use_underline=True`, `mnemonic_widget=<control>`) in column 0, an
  **expanding** control (`hexpand=True`) in column 1.
- Labels in one form share a common leading edge; controls share another.
- Help icons sit directly after the label, never after the control.
- 12 px row/column spacing, 12 px container border.
- Controls are **32 px** tall (`setting-control` / the entry/combobox/spinbutton
  min-height rule).
- Put a `dialog-information`-icon with an explanatory tooltip next to fields that
  need it (`driveutility.ui` filesystem help).

### 7.4 Status banners

One family, four intents: `info-banner`, `success-banner`, `warning-banner`,
`error-banner`. Compose as `[icon] [wrapping label]`. A workspace app typically
pins a `warning-banner` at the top when an action is risky
(`main_configurator.py:321`).

Do not introduce app-specific status-banner families; use these four classes.

---

## 8. Components

### 8.1 Buttons

- Ordinary buttons remain theme-native in height, colors and borders. Label-only
  buttons use the GTK `.text-button` class and receive 12 px horizontal padding
  from `minios.css`; icon+text buttons use `.minios-text-button` for the same
  padding. HeaderBar icon-only, ComboBox and SpinButton buttons keep their native
  compact metrics.
- **Primary** action → `suggested-action`; **destructive** action →
  `destructive-action`. These are **semantic hints only**: the active GTK theme
  renders its own native primary/destructive appearance. MiniOS does **not**
  force a branded blue/red gradient or fixed button sizes, so buttons look like
  classic desktop (XFCE/Greybird) controls.
- Everything else = the theme's default button.
- One primary action per view. Its resting place is **bottom-right** (footer or
  action bar).
- Labels use short, specific verbs (`Save`, `Create`, `Format`, `Retry`), never
  generic `OK`, `Yes` or `Submit` when a precise action is known.
- Prefer one or two prominent actions per view. Disable unavailable actions and
  explain why through adjacent status/help text when the reason is not obvious.
- In forms and dialogs use text-only buttons by default. Add a symbolic icon
  when it materially improves scanning and then keep icon usage consistent
  across the whole peer action group.

`suggested-action`/`destructive-action` are semantic classes rendered by the
GTK theme's own primary/destructive styling; `minios.css` no longer overrides
their colors or sizes. Header, combo, spin and ordinary buttons remain
theme-native.

### 8.2 Badges

Use theme-aware **pills**: `badge` plus an intent
(`badge-accent`/`badge-success`/`badge-warning`/`badge-error`). Do **not** hand-
roll gradient label badges (as `minios-kernel-manager` /
`minios-session-manager` do today).

### 8.3 Lists

Use `minios-list` for a bordered list container and rows that follow the **theme
selection color** on `:selected` (legible text on any theme). Do not paint
selected rows with a hard-coded blue gradient and forced white text. Status is
shown with a left-edge accent (`row-status-active` / `-running` / `-available`),
not by recoloring the whole row.

Row anatomy: `row-title` (600 weight) + `row-subtitle` / `row-meta`
(60% opacity, smaller).

### 8.4 Entries & validation

- Invalid field → `entry.error` (2 px red border).
- Field changed from its saved value → `changed`.
- Inline messages → `inline-error` / `inline-warning`.
- Password fields pair with a flat show/hide toggle using
  `eye-open-negative-filled-symbolic` / `eye-not-looking-symbolic`.
- Tokenized text fields use shared `TokenCompletionPopover` rather than local
  `Gtk.EntryCompletion` wrappers. The popover points to the token under the
  cursor and replaces only that token. Up/Down chooses a result without moving
  focus out of the entry; Tab or Enter accepts it, Escape closes the list, and
  Shift+Tab keeps normal backward focus navigation. Static lists are filtered
  locally; dynamic providers run outside the GTK main loop and must not perform
  a network request for each keystroke.

### 8.5 Icon roles

- **Field help:** use shared `HelpPopoverButton` in compact mode with
  `dialog-information-symbolic` at `Gtk.IconSize.MENU`. Place it beside the
  field label. The tooltip may repeat the short explanation, but the help must
  also be keyboard-accessible through the popover rather than hover-only.
- **Page help:** use the same `HelpPopoverButton` with a visible Help label when
  a workflow needs more than one sentence. Keep a one-line purpose statement
  visible on the page; structure the popover into short titled sections such as
  when to use the workflow, required input, and its effects or safety limits.
- **Button action:** symbolic icon at `Gtk.IconSize.BUTTON`, before the label.
  Use the same icon name for the same action (`document-open-symbolic`,
  `document-save-symbolic`, `user-trash-symbolic`).
- **Status banner:** semantic full-color icon at `Gtk.IconSize.LARGE_TOOLBAR`.
- **Empty state:** a larger illustration may deliberately differ from field-help
  icons; it explains the whole page rather than one control.
- Do not mix symbolic and full-color icons within one role.

### 8.6 Progress

Choose feedback by perceived duration:

- **<1 second:** no indicator; avoid flicker.
- **1–3 seconds:** usually no indicator unless the interface otherwise appears frozen.
- **3–30 seconds:** inline spinner with a specific status label.
- **>30 seconds or measurable work:** determinate `Gtk.ProgressBar`, explanatory
  text and Cancel/Pause when cancellation is safe.

Use determinate progress whenever possible and switch from indeterminate once
measurement becomes available. Keep progress beside the affected content, not
in a separate window. Use a 12 px trough/progress and 6 px radius; show text for
long-running raw operations (`driveutility`).

### 8.7 Footer / action bar

- Workspace: a `minios-footer` bar, or an in-page nav row preceded by a
  `nav-separator`, with `[Back] … [Primary]` (`main_installer.py:1446`).
- Utility: a `GtkActionBar` with the primary action `pack_type=end`
  (`driveutility.ui:148`).

### 8.8 Menus

- Use menus for commands, not primary navigation. Core functionality must also
  be visible or reachable without a context menu.
- Prefer 3–12 items, grouped by separators; one submenu level maximum. A submenu
  with fewer than three or more than about six items usually needs redesign.
- Use theme-native `Gtk.Menu` styling. Do not recolor hover states per command.
- Use specific command labels and append an ellipsis only when more input is
  required before the command runs.
- Do not include Quit/Close in a header hamburger menu; window controls and
  `Ctrl+W` already provide it.
- Within one menu group use action icons for every item or none. Every command
  has a mnemonic and an accessible name.

### 8.9 Dialogs & streamed commands

- Simple messaging → shared `show_error_dialog`, `show_info_dialog`, and
  `ask_confirmation` from `minios_gui.dialogs`. Always set `transient_for` and
  `modal=True` through the shared helper rather than rebuilding dialogs per app.
- Use a modal only when the user must decide before work can continue. Prefer
  inline validation, banners and non-modal feedback for page-local conditions.
- Never stack dialogs. `Escape` cancels/closes; restore focus to the invoking
  control. Enter activates a default only when that default is non-destructive.
- Dialog buttons use specific verbs. Cancel precedes the affirmative action in
  the MiniOS/GTK layout; destructive actions are never the surprising default.
- Long generic command operations → the shared **`LogView` + `CommandRunner` +
  `CommandDialog`** stack from `minios_gui.command`: a modal dialog that streams
  live output into a monospace `log-view`, with a spinner, a `$ command` echo,
  and Cancel→Close. Typed JSON/NDJSON protocols and interactive PTY workflows
  keep specialized workers when merging stdout/stderr would break their contract.

These helpers are part of `python3-minios-gui`; applications should import them
instead of copying local variants. See §13.1.

---

## 9. Behavior & interaction

1. **Primary action placement.** Exactly one primary (`suggested-action`) per
   view, bottom-right. Back/secondary to its left.
2. **Recovery before confirmation.** Prefer Undo/Trash for reversible removal.
   Confirm uncommon, irreversible, costly or high-impact actions. The dialog
   names the target and consequence. Never make a surprising destructive action
   the default focus.
3. **Safety reveals.** Dangerous-but-sometimes-needed options stay hidden behind
   an explicit toggle (`driveutility`'s "Show mounted disks" checkbutton).
4. **Privilege.** Request root via `pkexec` from the `.desktop` `Exec=` line
   (`Exec=pkexec /usr/bin/minios-installer`). Don't run the whole GUI as root
   when only one operation needs it if that can be avoided; when it can't, the
   `pkexec` desktop entry is the norm.
5. **Long work stays responsive.** Run shell tools in a worker thread
   (`CommandRunner`) and marshal UI updates with `GLib.idle_add`; never block the
   GTK main loop. Offer **Cancel** (terminate the process group).
6. **Non-reflowing states.** Selection/validation highlights must not change a
   widget's box size (use fixed-width borders, e.g. `choice-card` uses a 2 px
   border in both states) so the layout doesn't jump.
7. **Immediate, local feedback.** Change the affected row/control first; use a
   transient in-app message for completion and a persistent banner for a state
   that still needs attention. System notifications are only for useful
   background events and never the sole record of an error.
8. **Keyboard model.** `Tab` moves between components; arrows move within a
   list/radio/menu group; Space activates toggles/buttons; Enter confirms a safe
   default; Escape dismisses menus and dialogs. Common actions use conventional
   shortcuts and advertise them in tooltips or menus.

---

## 10. Iconography & desktop integration

Today the `.desktop` files disagree on naming, categories, icons and flags.
Standardize:

| Field | Rule |
|-------|------|
| `Name` | **Noun** product name: `MiniOS <Thing> Manager` / `MiniOS Image Builder`. Task-style verbs (`Install MiniOS`, `Configure MiniOS`) are allowed only for the two first-run flows (installer, configurator) that already use them. |
| `Comment` | One sentence, imperative, describing what it does. |
| `Categories` | Use exactly one freedesktop main category to avoid duplicate menu placement: `System;` for system managers, `Settings;` for configuration tools, or `Utility;` for general utilities. Drop the ad-hoc `GTK;`. |
| `Keywords` | `;`-terminated, lowercase. |
| `Icon` | Use an icon from `elementary-minios-icon-theme`. Add missing dedicated `minios-<app>` icons to its `elementary-xfce-minios` source repository rather than creating another icon theme. Fall back to a stable stock icon only until the shared theme gains one. |
| `Terminal` | `false`. |
| `StartupNotify` | `true`. |
| `Exec` | `pkexec /usr/bin/<app>` when the tool needs root; otherwise the plain binary. |

Provide **translations** for `Name`/`Comment`/`GenericName` (the installer's
`.desktop` is the gold standard for coverage).

> Iconography is the biggest remaining branding gap: apps currently borrow
> unrelated stock icons (`usb-creator-gtk`, `office-database`, `isomaster`,
> `media-floppy`, …). Add coherent application icons to the existing
> `elementary-xfce-minios` theme so the family reads as one product without
> introducing a parallel icon theme.

---

## 11. Accessibility & internationalization

Accessibility is a release gate. WCAG values are used as measurable proxies for
native GTK where the platform does not provide a stricter metric.

| Requirement | MiniOS acceptance criterion |
|-------------|-----------------------------|
| Keyboard | Every action works without a pointer; focus order follows visual/reading order; no keyboard traps. |
| Focus | Focus is always visible and not obscured by overlays, footers or dialogs. Selection and focus remain distinguishable. |
| Text contrast | At least **4.5:1** for normal text and **3:1** for large/bold text. |
| UI/icon contrast | Meaningful controls, focus indicators and graphics reach **3:1** against adjacent colors. |
| Target size | At least **24×24 px** including invisible hit area; aim for **28×28 px** on desktop and 32 px for primary controls. |
| Text scaling | No clipping or lost controls at **200%** font scaling and with the longest shipped translation. |
| Status | Success/error/progress changes are exposed through GTK/ATK semantics or focus-safe text, not color alone. |

Implementation rules:

- **Mnemonics** on every label that targets a control (`use_underline=True` +
  `mnemonic_widget`). The visible label text must match the accessible name.
- **Tooltips** on icon-only buttons and non-obvious controls; tooltips never
  contain essential information unavailable elsewhere.
- **Accessible names** on icon-only buttons
  (`button.get_accessible().set_name(...)`) and descriptions where the name is
  insufficient.
- **Theme and high contrast:** do not replace focus outlines; never encode state
  by color alone; verify light, dark and high-contrast themes.
- **Wrap, don't clip.** Long labels use `set_line_wrap(True)` with a sane
  `max_width_chars`; layouts survive 200% text and German/Russian/Portuguese.
- **Translate everything** with `gettext`; keep `.desktop`, tooltips, accessible
  names and status strings translatable. Check right-to-left reading order even
  if full RTL localization is not yet shipped.
- Test keyboard-only navigation, Orca output, large text, high contrast,
  disabled animation and no-audio operation before release.

---

## 12. The canonical stylesheet

The canonical stylesheet is maintained at `submodules/minios-gui/share/minios.css`
and shipped by the **`minios-gui`** binary package, which installs it to
`/usr/share/minios/minios.css`. It is organized into 15 sections: tokens, header
bar, sidebar, sidebar steps, typography, cards, banners, buttons, badges, lists,
entries/validation, progress, footer/action bar, log view, drop zone/empty state.

**Adoption:**

1. Install the `minios-gui` package (ships `/usr/share/minios/minios.css`) and
   add it to the app's `Depends:`.
2. Load it first, then your app sheet (see §3.2).
3. Delete rules from the app sheet that now duplicate `minios.css`; keep only
   genuinely app-specific widgets (e.g. the installer's partition-bar segments).
4. Rename app-local classes to the canonical names (`*-sidebar` →
   `minios-sidebar`, `*-footer` → `minios-footer`, status banners → the four
   `*-banner` classes, gradient badges → `badge*`).

GTK 3 CSS constraints to remember while editing it: **no** `var()` / custom
properties, **no** `calc()`; use the `@define-color` tokens and the theme's
`alpha()` / `shade()` / `mix()` functions.

---

## 13. Per-app conformance & migration

Snapshot of where each GTK app stands against this guideline and what to change.
"✔" = already conforms, "→" = change needed.

| Area | installer | configurator | driveutility | module-mgr | kernel-mgr | session-mgr | image-builder |
|------|:--------:|:------------:|:------------:|:----------:|:----------:|:-----------:|:-------------:|
| Header bar | ✔ shared | ✔ shared | ✔ native (intentional) | ✔ shared | ✔ shared | ✔ shared | ✔ shared |
| Loads shared CSS | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | → |
| Uses `python3-minios-gui` API | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | → |
| Sidebar class name | ✔ | ✔ | n/a | → | n/a | n/a | ✔ |
| Card/frame radius = 6 px | ✔ | ✔ | n/a | ✔ | ✔ | ✔ | ✔ |
| Primary button = canonical | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ |
| Status banners = 4 classes | ✔ | ✔ | n/a | ✔ | ✔ | ✔ | → |
| Badges = pill | n/a | n/a | n/a | n/a | ✔ | ✔ | ✔ |
| List selection = theme color | ✔ | ✔ | n/a | ✔ | ✔ | ✔ | ✔ |
| Type hierarchy = target 18–20 px page title | ✔ | n/a | n/a | ✔ | n/a | n/a | → (23/eyebrow) |
| Desktop entry conventions | → icon | → icon | → icon | → icon | → cat | → icon | → icon |

Highest-value moves, in order:

1. **Adopt `minios-gui` in the remaining app**: image builder. Module Manager
   now uses the shared stylesheet, HeaderBar, semantic status banners, icons and
   standard dialogs while keeping its typed NDJSON/VTE workers local.
2. **Rework `minios-image-builder` hierarchy**: remove decorative eyebrow and
   letter spacing, reduce the oversized page title, standardize progress,
   banners, footer and empty states. It remains the largest visual outlier.
3. **Accessibility audit all five adopted apps** against §11: keyboard path,
   ATK names, focus, 200% text, high contrast, 1024×600 and long translations.
4. **Interaction audit**: replace avoidable modal success/error dialogs with
   inline messages; add Undo where deletion is reversible; standardize progress.
5. **Desktop entries + icons**: apply §10 and extend `elementary-xfce-minios`
   with the missing MiniOS application icons.
6. **Automate conformance**: CSS parser, forbidden-style grep, Python 3.6 syntax
   check, screenshot matrix and keyboard smoke tests in CI.

### 13.1 Shared code, not copied code

The `minios-gui` source repository builds both `minios-gui` and
`python3-minios-gui`. The latter installs the Python 3.6-compatible `minios_gui`
module with stylesheet loading, icon resolution, standard dialogs, canonical
`new_header_bar()` / `StatusBanner` widgets, and the `LogView` /
`CommandRunner` / `CommandDialog` stack. Apps should migrate from their duplicated
`ui_utils.py` implementations to this API incrementally; do not remove a local
helper until its caller is covered by tests.

Current adopters: Drive Utility, Configurator, Installer, Session Manager,
Kernel Manager and Module Manager. Their specialized progress parsers, typed JSON
subprocess protocols, passphrase input and backend-function workers remain local
because the generic `CommandRunner` is not behaviorally equivalent. Image Builder
is the remaining adopter.

---

## 14. Do / Don't quick reference

**Do**

- Use `Gtk.HeaderBar`; use `minios-headerbar` on workspaces and preserve a
  high-quality native header where the shared class would regress it.
- Derive surfaces from theme colors; reserve MiniOS blue for the primary action.
- Load `minios.css` first, app CSS second.
- Group fields in 6 px `content-card`s; 12 px grid gutters; 32 px controls.
- One primary (`suggested-action`) per view, bottom-right.
- Prefer Undo; confirm irreversible destructive actions and name the target.
- Stream long commands through `CommandDialog`; keep the main loop free.
- Give icon-only buttons a tooltip **and** an accessible name.

**Don't**

- Hard-code window/text/background colors or force white text on light fills.
- Invent a new sidebar/footer/banner class — reuse the canonical names.
- Paint selected list rows with a fixed blue gradient.
- Hand-roll gradient badge labels — use `badge*` pills.
- Use oversized/decorative titles, letter-spaced eyebrows, or per-app radius values.
- Block the GTK main loop on a subprocess.
- Ship a `.desktop` file with ad-hoc categories or an unrelated stock icon.

---

## 15. Implementation roadmap

Work in measured phases. Each phase must be visually reviewed on the LiveCD VM
and pass on the oldest supported stack (Python 3.6 + GTK 3.22) before moving on.

### Phase 0 — freeze the baseline (1–2 days)

- Capture every page/dialog/menu in the five adopted apps at 1280×800.
- Add light, dark, high-contrast, 1024×600 and 200% font screenshots.
- Record keyboard paths for each primary workflow.
- Create a component inventory: buttons, menus, frames, banners, icons, empty
  states, dialogs and progress treatments.

**Exit:** a versioned screenshot matrix and issue list; no design change is
accepted without a before/after comparison.

### Phase 1 — accessibility and interaction correctness (3–5 days)

- Fix tab/focus order, mnemonics and missing accessible names.
- Verify 24×24 minimum targets, contrast and visible focus.
- Test longest translations and 200% text without clipping.
- Replace generic dialog verbs; prevent destructive defaults; restore focus
  after modal close.
- Add standard shortcuts (`Ctrl+W`, refresh, open/save where relevant).

**Exit:** all §11 acceptance criteria pass on the five apps; keyboard-only
completion of each primary workflow.

### Phase 2 — remaining apps and visual hierarchy (4–7 days)

- Adopt `minios-gui` in `minios-image-builder`; Module Manager is already on the
  shared stylesheet and Python helper API.
- Redesign `minios-image-builder` against the workspace archetype rather than
  mechanically replacing CSS classes.
- Standardize page title (18–20 px), section title (14–15 px), content width,
  sidebar behavior, forms, footer and empty states.
- Keep domain visualizations (partition maps, logs, module metadata) distinct
  where they improve comprehension.

**Exit:** all seven GTK apps pass the component inventory with documented,
purposeful exceptions.

### Phase 3 — feedback and long operations (3–5 days)

- Migrate all apps to the command/progress API already shipped by
  `python3-minios-gui`; remove duplicated helpers only after parity tests.
- Apply the <1 s / 1–3 s / 3–30 s / >30 s feedback thresholds.
- Use determinate progress where data exists; add Cancel/Pause where safe.
- Replace page-local modal errors with inline banners and actionable retry.
- Add Undo for reversible deletion/deactivation; retain confirmation for disk
  erase, formatting, overwrite and irreversible installation.

**Exit:** no blocked GTK main loop; every long task has state text, progress and
a defined cancellation/recovery policy.

### Phase 4 — identity, CI and release gate (3–5 days)

- Add a coherent `minios-<app>` application-icon family to the existing
  `elementary-xfce-minios` source repository.
- Normalize `.desktop` metadata, categories, keywords and translations.
- Add CI checks: GTK CSS parse, `git diff --check`, Python 3.6 compile (or
  `ast.parse(feature_version=(3, 6))`), package build, lintian and unit tests.
- Add VM screenshot comparison with tolerances plus scripted keyboard smoke tests.
- Publish a reviewer checklist and require it for every GUI pull request.

**Exit:** repeatable release evidence for Debian 10–13, a representative Devuan
release, Ubuntu 18.04 and the newest supported Ubuntu; no known critical visual,
keyboard or accessibility regression.

### Prioritization

| Priority | Work | Reason |
|----------|------|--------|
| P0 | Keyboard/focus, clipping, destructive safety, blocked main loop | Functional or data-loss risk |
| P1 | Image Builder hierarchy, remaining shared-style adoption, progress/error behavior | Largest quality and consistency gain |
| P2 | Extend `elementary-xfce-minios`, desktop metadata, responsive polish | Product identity and discoverability |
| P3 | Animation and decorative refinements | Only after correctness and accessibility |

---

## Appendix A — canonical `minios.css` (excerpt)

Full file: `submodules/minios-gui/share/minios.css`. Key pieces:

```css
/* Brand tokens — the only hard-coded colors */
@define-color minios_blue        #4a90d9;
@define-color minios_blue_light  #6bb5ff;
@define-color minios_blue_dark   #3875c4;
@define-color minios_red         #c6262e;
@define-color minios_red_light   #ed5353;
@define-color minios_red_dark    #c01c28;
@define-color minios_amber       #e5a50a;
@define-color minios_green       #26a269;

/* Header bar — preserve native vertical metrics */
headerbar.minios-headerbar { padding-left: 6px; padding-right: 6px; }

/* Nav rail (one class for both category lists and wizard steps) */
.minios-sidebar {
    background-color: shade(@theme_bg_color, 0.97);
    border-right: 1px solid alpha(@borders, 0.7);
    padding: 4px 6px 4px 4px;
}
.sidebar-step { border-radius: 4px; border-left: 3px solid transparent; }
.sidebar-step-active {
    background-color: alpha(@theme_selected_bg_color, 0.18);
    border-left: 3px solid @theme_selected_bg_color;
    font-weight: bold;
}

/* Content card — transparent, border-defined, 6 px */
.content-card {
    border: 1px solid alpha(@borders, 0.65);
    border-radius: 6px;
    background-color: transparent;
    padding: 8px; margin: 10px;
}

/* Ordinary buttons stay theme-native. Primary action uses shared metrics. */
button.suggested-action {
    min-height: 32px; min-width: 110px; padding: 0 14px;
    border-radius: 4px; font-size: 13px; color: #ffffff;
    background-image: linear-gradient(to bottom, @minios_blue_light, @minios_blue);
    border: 1px solid @minios_blue_dark;
}

/* Status banners — one family, four intents */
.warning-banner {
    background-color: alpha(@minios_amber, 0.18);
    border: 1px solid alpha(@minios_amber, 0.55);
    border-radius: 4px; padding: 8px 10px;
}

/* Badge pill — theme-aware, replaces gradient labels */
.badge {
    padding: 1px 8px; border-radius: 9px;
    border: 1px solid alpha(@theme_fg_color, 0.18);
    background-color: alpha(@theme_fg_color, 0.06);
    color: alpha(@theme_fg_color, 0.78);
    font-size: 10px; font-weight: 700;
}
```

## Appendix B — primary references

Guidance reviewed on 2026-08-04:

- GNOME: [Design principles](https://developer.gnome.org/hig/principles.html),
  [header bars](https://developer.gnome.org/hig/patterns/containers/header-bars.html),
  [navigation](https://developer.gnome.org/hig/guidelines/navigation.html),
  [buttons](https://developer.gnome.org/hig/patterns/controls/buttons.html),
  [menus](https://developer.gnome.org/hig/patterns/controls/menus.html),
  [dialogs](https://developer.gnome.org/hig/patterns/feedback/dialogs.html),
  [progress](https://developer.gnome.org/hig/patterns/feedback/progress-bars.html),
  [accessibility](https://developer.gnome.org/hig/guidelines/accessibility.html).
- KDE: [Simple by default](https://develop.kde.org/hig/simple_by_default/),
  [Powerful when needed](https://develop.kde.org/hig/powerful_when_needed/),
  [layout and navigation](https://develop.kde.org/hig/layout_and_nav/),
  [status changes](https://develop.kde.org/hig/status_changes/),
  [icons](https://develop.kde.org/hig/icons/),
  [accessibility](https://develop.kde.org/hig/accessibility/).
- Microsoft: [Windows app design](https://learn.microsoft.com/en-us/windows/apps/design/),
  [commanding](https://learn.microsoft.com/en-us/windows/apps/design/basics/commanding-basics),
  [dialogs](https://learn.microsoft.com/en-us/windows/apps/develop/ui/controls/dialogs-and-flyouts/dialogs),
  [progress](https://learn.microsoft.com/en-us/windows/apps/develop/ui/controls/progress-controls),
  [accessibility](https://learn.microsoft.com/en-us/windows/apps/design/accessibility/accessibility-overview).
- Apple: [Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines/),
  [layout](https://developer.apple.com/design/human-interface-guidelines/layout),
  [buttons](https://developer.apple.com/design/human-interface-guidelines/buttons),
  [alerts](https://developer.apple.com/design/human-interface-guidelines/alerts),
  [menus](https://developer.apple.com/design/human-interface-guidelines/menus),
  [accessibility](https://developer.apple.com/design/human-interface-guidelines/accessibility).
- W3C: [WCAG 2.2](https://www.w3.org/TR/WCAG22/),
  [contrast minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html),
  [non-text contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html),
  [target size](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html),
  [focus visible](https://www.w3.org/WAI/WCAG22/Understanding/focus-visible.html),
  [keyboard practice](https://www.w3.org/WAI/ARIA/apg/practices/keyboard-interface/).

import unittest
from unittest import mock

from minios_gui.command import CommandRunner, format_log_line


class CommandRunnerTests(unittest.TestCase):
    def test_format_log_line_uses_shared_metadata_order(self):
        self.assertEqual(
            format_log_line("message\n", timestamp="12:34:56", level="warn"),
            "[12:34:56] WARN message\n")

    def test_runner_streams_output_and_reports_success(self):
        lines = []
        results = []

        def idle_add(callback, *args):
            callback(*args)
            return 1

        runner = CommandRunner(
            ["/bin/sh", "-c", "printf 'hello\\n'"],
            lines.append,
            lambda returncode, cancelled: results.append(
                (returncode, cancelled)),
        )
        with mock.patch(
                "minios_gui.command.GLib.idle_add", side_effect=idle_add):
            runner._worker()

        self.assertEqual(lines, ["hello\n"])
        self.assertEqual(results, [(0, False)])


if __name__ == "__main__":
    unittest.main()

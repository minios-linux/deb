/* SPDX-License-Identifier: MIT */
/*
 * Copyright © 2024 Intel Corporation
 */

#ifndef __INTEL_GT_CCS_MODE_H__
#define __INTEL_GT_CCS_MODE_H__

struct intel_gt;

unsigned int intel_gt_apply_ccs_mode(struct intel_gt *gt);

#endif /* __INTEL_GT_CCS_MODE_H__ */

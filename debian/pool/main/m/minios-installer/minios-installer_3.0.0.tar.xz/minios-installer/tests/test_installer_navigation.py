#!/usr/bin/env python3

from main_installer import can_navigate_to_viewed_step


def test_only_viewed_non_current_steps_are_clickable():
    viewed = {0, 1, 3}
    assert can_navigate_to_viewed_step(0, 1, viewed)
    assert not can_navigate_to_viewed_step(1, 1, viewed)
    assert not can_navigate_to_viewed_step(2, 1, viewed)
    assert can_navigate_to_viewed_step(3, 1, viewed)


def test_install_running_blocks_all_sidebar_navigation():
    assert not can_navigate_to_viewed_step(0, 2, {0, 1, 2}, install_running=True)

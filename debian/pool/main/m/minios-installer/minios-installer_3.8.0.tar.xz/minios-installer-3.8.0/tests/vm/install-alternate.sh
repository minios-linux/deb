#!/bin/bash
set -euo pipefail
media=/run/initramfs/memory/data/qa
[[ $(systemd-detect-virt) =~ ^(kvm|qemu)$ && -d /sys/firmware/efi ]]
test -s "$media/alternate.iso"
dpkg -i "$media"/*.deb
disks=$(minios-deploy list-disks --json | python3 -c '
import json,subprocess,sys
disks=json.load(sys.stdin); assert len(disks)==2; by_size={}
for disk in disks:
 p=disk["by_id"]; assert p.startswith("/dev/disk/by-id/")
 by_size[int(subprocess.check_output(["blockdev","--getsize64",p]))]=p
print(by_size[2*1024**3], by_size[10*1024**3])')
read -r source_disk target <<<"$disks"
for disk in "$source_disk" "$target"; do test -z "$(wipefs --noheadings -o TYPE "$disk")"; done
mkfs.ext4 -q -L QAISOS "$source_disk"
source_mount=$(mktemp -d)
mount "$source_disk" "$source_mount"
cp "$media/alternate.iso" "$source_mount/flux.iso"
opts=(--mode live --boot-layout uefi_gpt --source "$source_mount/flux.iso")
if minios-deploy plan "$source_disk" "${opts[@]}"; then exit 1; fi
minios-deploy plan "$target" "${opts[@]}" --json >/tmp/iso-plan.json
python3 -c 'import json; p=json.load(open("/tmp/iso-plan.json")); assert any("flux-desktop" in n for n in p["modules"]) and p["source_iso"].endswith("/flux.iso")'
minios-deploy install "$target" "${opts[@]}" --dry-run
minios-deploy install "$target" "${opts[@]}" --yes
umount "$source_mount"
sync

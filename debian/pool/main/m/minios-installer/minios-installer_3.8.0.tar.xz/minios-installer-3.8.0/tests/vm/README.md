# Dual-boot acceptance fixtures

These Testo 15 scenarios run only in fresh Testo-owned guests. The guest scripts
require virtualization, identify their blank disks via `minios-deploy list-disks
--json` and check their size and existing signatures. Never run a seed script
on the host or on a disk image containing user data.

The fixture DVD is a local Trixie Standard amd64 MiniOS ISO with an additional
`/qa` directory. Preserve the original boot images (e.g. `xorriso -boot_image any
replay`). Do not replace the kernel or any live modules. Include the candidate
`minios-installer`, `minios-deploy`, `minios-native-dracut` and matching
`minios-dpkg-state` debs. This tests the installed package, not a checkout.
The seed scripts use a second copy of the same Linux payload with a distinct
label, data tree and kernel command line as the pre-existing operating system.

- **`bios-alongside.testo`:** add `seed-bios.sh`, `bios-fixture/boot.img` from
  `grub-pc-bin` and a contiguous `bios-fixture/core.img`. Generate it with
  `grub-mkimage -O i386-pc -p '(hd0,msdos1)/boot/grub' -o core.img biosdisk
  part_msdos ext2 normal linux configfile search search_fs_uuid echo test sleep`.
  The diskboot sector's single extent starts at sector 2, loads at segment
  `0x820` and has `(len(core.img) - 1) // 512` sectors. Store that count as a
  little-endian 16-bit integer at offset 508 before seeding the blank disk.
  The test checks original MBR boot code, embedding area and active flags,
  then ejects the ISO and boots each system through the existing GRUB.
- **`linux-directory.testo`:** use the same BIOS fixture and pass
  `--param SHOT_DIR /absolute/path/to/screenshots`. The existing ext4 partition
  hosts both payloads. The seed checks that installation preserves the partition
  table, boot code, filesystem UUID and label, and sample user data. Testo ejects
  the DVD and boots both entries through the existing GRUB, checking that MiniOS
  uses `/minios/system-<filesystem UUID>` rather than the previous Linux tree.
- **`uefi-alongside.testo`:** add `seed-efi.sh`, Trixie's `efibootmgr`,
  `libefiboot1t64`, `libefivar1t64` and `libpopt0` debs and `previous.efi`.
  Generate `previous.efi` with `grub-mkstandalone -O x86_64-efi` and an embedded
  GRUB config that searches for `PREVLINUX`, boots the ISO kernel/initrd from
  `/previous/boot` and passes `from=/dev/disk/by-label/PREVLINUX/previous
  dualqa.previous`. The seed installs both an independent EFI loader and a
  fallback. Both hashes, the original BootOrder and separately identified OS
  boots are checked. This requires writable **persistent** firmware variables.
  An ordinary OVMF run does not establish Secure Boot or BitLocker compatibility.
- **`alternate-source.testo`:** add `install-alternate.sh` and the alternate
  workspace ISO as `/qa/alternate.iso`. The pinned acceptance pair uses
  `minios-trixie-xfce-standard-amd64-20261024_0049.iso` for the host and
  `minios-trixie-flux-minimum-amd64-20261121_2030.iso` for the source. Check
  source rejection on the 2 GiB source disk, JSON module inventory, installation
  on the 10 GiB target, DVD ejection and the installed Flux kernel/module.

Run each scenario first with `--dry`, then with a fresh prefix, `--user
--param ISO /absolute/path/to/qa.iso --allowed-sharing-directory DIR
--report-folder REPORT --junit-report RESULT.xml --record-tests --assume-yes`.
Clean only the prefix used by that run. Windows/WinRE and enrolled Secure Boot
require separate real fixtures; a Linux fixture or a copied Microsoft filename
is not evidence for them.

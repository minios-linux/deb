#!/bin/bash
# Only for the disposable 24 GiB Windows 10 + WinRE reference clone.
set -euo pipefail
trap 'echo "Windows test stopped at line $LINENO (status $?)"' ERR
export LC_ALL=C
qa=/run/initramfs/memory/data/qa
[[ $(systemd-detect-virt) =~ ^(kvm|qemu)$ && -d /sys/firmware/efi ]]
dpkg -i "$qa"/*.deb
disk=$(minios-deploy list-disks --json | python3 -c '
import json,sys
d=json.load(sys.stdin); assert len(d)==1
p=d[0]["by_id"]; assert p.startswith("/dev/disk/by-id/"); print(p)')
test "$(blockdev --getsize64 "$disk")" = 25769803776
sfdisk --json "$disk" >/tmp/windows-before.json
python3 - <<'PY'
import json
p=json.load(open('/tmp/windows-before.json'))['partitiontable']['partitions']
assert len(p)==4 and [x['start'] for x in p]==[2048,206848,239616,48799744]
assert p[0]['type'].lower().startswith('c12a7328-')
assert p[2]['type'].lower().startswith('ebd0a0a2-')
assert p[3]['type'].lower().startswith('de94bba4-')
PY
esp="${disk}-part1"; win="${disk}-part3"; recovery="${disk}-part4"
test "$(blkid -s TYPE -o value "$win")" = ntfs
ntfs-3g.probe --readwrite "$win"
root=$(mktemp -d)
mount -o ro "$esp" "$root"
test -s "$root/EFI/Microsoft/Boot/bootmgfw.efi"
(cd "$root" && find EFI -type f -print0 | sort -z | xargs -0 sha256sum) >/tmp/windows-efi.sha256
umount "$root"
sha256sum "$recovery" >/tmp/windows-recovery.sha256
# Imported disk, fresh Testo firmware: establish the original boot option
# from the actual Microsoft loader before invoking the installer.
efibootmgr --create --disk "$(readlink -f "$disk")" --part 1 --label "Windows Boot Manager" --loader '\EFI\Microsoft\Boot\bootmgfw.efi'
before=$(efibootmgr | sed -n 's/^BootOrder: //p')
opts=(--mode live --placement alongside_os --alongside-size 2048)
if [[ ${1:-} == directory ]]; then
    opts=(--mode live --placement directory --data-partuuid "$(blkid -s PARTUUID -o value "$win")")
    mount -t ntfs-3g -o norecover "$win" "$root"
    test -s "$root/Windows/System32/ntoskrnl.exe"
    test ! -e "$root/minios"
    mkdir -p "$root/minios/changes"
    printf 'old session\n' > "$root/minios/changes/old"
    (cd "$root" && sha256sum Windows/System32/ntoskrnl.exe) >/tmp/windows-kernel.sha256
    umount "$root"
    if minios-deploy plan "$disk" "${opts[@]}"; then exit 1; fi
    opts+=(--replace-directory)
fi
minios-deploy plan "$disk" "${opts[@]}" --json >/tmp/windows-plan.json
python3 - <<'PY'
import json
p=json.load(open('/tmp/windows-plan.json'))
assert p['boot_action']=='append_efi' and p['reuse_esp'] and not p['wipe_disk']
if p.get('directory_partuuid'):
    assert not p['resize'] and p['replace_existing_directory'] and all(x['action']=='reuse' for x in p['partitions'])
else:
    assert p['resize']['partition_number']==3 and len([x for x in p['partitions'] if x['action']=='create'])==1
PY
minios-deploy install "$disk" "${opts[@]}" --dry-run
minios-deploy install "$disk" "${opts[@]}" --yes
if [[ ${1:-} == directory ]]; then
    # Replace an actual prior MiniOS installation with an owned loader and
    # existing NVRAM entry, in addition to the initial data-only collision.
    order_after_first=$(efibootmgr | sed -n 's/^BootOrder: //p')
    mount -t ntfs-3g -o norecover "$win" "$root"
    printf 'prior installation\n' >"$root/minios/replace-me"
    umount "$root"
    minios-deploy install "$disk" "${opts[@]}" --yes
    test "$(efibootmgr | sed -n 's/^BootOrder: //p')" = "$order_after_first"
fi
sfdisk --json "$disk" >/tmp/windows-after.json
python3 - <<'PY'
import json
def parts(name):
    return json.load(open('/tmp/windows-'+name+'.json'))['partitiontable']['partitions']
old,new=parts('before'),parts('after')
p=json.load(open('/tmp/windows-plan.json'))
if p.get('directory_partuuid'):
    assert new==old
else:
    assert len(new)==5 and all(new[i]==old[i] for i in (0,1,3))
    assert new[2]['start']==old[2]['start'] and new[2]['uuid']==old[2]['uuid']
    assert new[2]['size']==p['resize']['new_size_sectors']
PY
if [[ ${1:-} == directory ]]; then
    mount -t ntfs-3g -o ro "$win" "$root"
    (cd "$root" && sha256sum -c /tmp/windows-kernel.sha256)
    test ! -e "$root/minios/changes/old"
    test ! -e "$root/minios/replace-me"
    test -s "$root/minios/system-$(blkid -s UUID -o value "$win")/00-core-amd64.sb"
    umount "$root"
fi
mount -o ro "$esp" "$root"
(cd "$root" && sha256sum --quiet -c /tmp/windows-efi.sha256 && test -s EFI/minios/bootx64.efi)
umount "$root"
sha256sum --quiet -c /tmp/windows-recovery.sha256
new=$(efibootmgr | sed -nE 's/^Boot([0-9A-Fa-f]{4})\* MiniOS([[:space:]].*)?$/\1/p')
test -n "$new" && test "$(efibootmgr | sed -n 's/^BootOrder: //p')" = "$before,$new"
sync

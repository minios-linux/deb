import contextlib
import errno
import os
import signal
import stat
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest

import directory_install
from directory_install import destination, existing, mounted, plan_directory
from partition_models import PartitionPlan, PlannedPartition
from partition_executor import execute_plan
from copy_utils import bind_live_data


@pytest.mark.parametrize("persistent", [False, True])
def test_directory_mount_retries_without_detaching_busy_filesystem(tmp_path, persistent):
    commands = []

    def run(command, check=False, **kwargs):
        commands.append(command)
        if command[0] == "findmnt":
            result = subprocess.CompletedProcess(command, 1)
        elif command[0] == "umount":
            attempts = sum(cmd[0] == "umount" for cmd in commands)
            result = subprocess.CompletedProcess(command, 32 if persistent or attempts == 1 else 0)
        else:
            result = subprocess.CompletedProcess(command, 0)
        if check:
            result.check_returncode()
        return result

    def use_mount():
        with mounted("/dev/test", "ext4", write=True) as root:
            work = Path(root).parent
            assert stat.S_IMODE(work.stat().st_mode) == 0o700
            assert work.parent == tmp_path

    with patch("directory_install.tempfile.tempdir", str(tmp_path)), \
         patch("directory_install.subprocess.run", side_effect=run), patch("directory_install.time.sleep"):
        if persistent:
            with pytest.raises(subprocess.CalledProcessError):
                use_mount()
            # Do not remove the path of a filesystem that failed to unmount.
            assert Path(commands[-1][1]).is_dir()
        else:
            use_mount()
            assert not list(tmp_path.iterdir())

    attempts = [cmd for cmd in commands if cmd[0] == "umount"]
    assert len(attempts) == (6 if persistent else 2)
    assert all(cmd == ["umount", commands[1][-1]] for cmd in attempts)


@pytest.fixture
def private_mount(monkeypatch, tmp_path):
    root = tmp_path / "data"
    root.mkdir()

    @contextlib.contextmanager
    def mount(*args, **kwargs):
        yield str(root)

    def getxattr(path, name, **kwargs):
        if name == "system.ntfs_attrib":
            return b"\x30\x00\x00\x00"
        assert name == "system.ntfs_times"
        return os.lstat(path).st_ino.to_bytes(8, "little") + bytes(24)

    monkeypatch.setattr(directory_install, "mounted", mount)
    monkeypatch.setattr(directory_install, "_NTFS_RUNTIME", str(tmp_path / "runtime"))
    monkeypatch.setattr(directory_install.os, "getxattr", getxattr)
    monkeypatch.setattr("partition_executor._verify_existing_partition", Mock())
    monkeypatch.setattr("partition_executor._revalidate_preserve_plan", Mock())
    monkeypatch.setattr("native_deploy._blkid_value", Mock(return_value="part"))
    monkeypatch.setattr("native_deploy._unique_fs_uuid", Mock(return_value="1234"))
    return root


def directory_plan(root, fs="ext4"):
    plan = PartitionPlan("/disk", True, False, directory_partuuid="part", directory_uuid="1234",
                         replace_directory=True, previous_directory=existing(str(root), fs))
    plan.partitions = [PlannedPartition("reuse", "minios_root", 0, 100, fs, "/disk3")]
    return plan


def stage(work):
    fresh = Path(work) / "new"
    fresh.mkdir()
    (fresh / "new-module").write_bytes(b"new")
    return fresh


@pytest.mark.parametrize("phase", ["boot-fails", "uncommitted", "committed", "after-commit-fails"])
def test_replace_is_whole_directory_and_boot_commit_is_irreversible(private_mount, phase):
    tmp_path = private_mount
    old = tmp_path / "minios" / "changes"
    old.mkdir(parents=True)
    (old / "installed-packages").write_bytes(b"old")
    outside = tmp_path / "Documents"
    outside.mkdir()
    (outside / "user").write_bytes(b"keep")
    (old / "link").symlink_to(outside)
    orphan = tmp_path / ".minios-install-untrusted"
    orphan.mkdir()
    (orphan / "previous").symlink_to(outside)
    (orphan / "new").write_bytes(b"untrusted data")
    plan = directory_plan(tmp_path)

    def install():
        with destination(plan) as (work, publish, commit):
            fresh = stage(work)
            publish()
            assert (fresh / "changes/installed-packages").read_bytes() == b"old"
            if phase == "boot-fails":
                raise RuntimeError("activation failed")
            if phase != "uncommitted":
                commit()
            if phase == "after-commit-fails":
                raise RuntimeError("final progress failed")

    message = {"boot-fails": "activation failed", "uncommitted": "was not committed",
               "after-commit-fails": "final progress failed"}.get(phase)
    if message:
        with pytest.raises(RuntimeError, match=message):
            install()
    else:
        install()
    if phase in ("boot-fails", "uncommitted"):
        assert (old / "installed-packages").read_bytes() == b"old"
    else:
        assert not old.exists() and (tmp_path / "minios/new-module").is_file()
    assert (outside / "user").read_bytes() == b"keep"
    assert set(tmp_path.glob(".minios-install-*")) == {orphan}
    assert (orphan / "previous").is_symlink() and (orphan / "new").read_bytes() == b"untrusted data"


@pytest.mark.parametrize("after_exchange", [False, True])
def test_publish_error_before_or_after_kernel_exchange_restores_old(private_mount, monkeypatch, after_exchange):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    (target / "old").touch()
    rename = directory_install._rename

    def broken(src, dst, flags):
        if Path(dst) == target:
            if after_exchange:
                rename(src, dst, flags)
            raise OSError(errno.EIO, "exchange fault")
        rename(src, dst, flags)

    monkeypatch.setattr(directory_install, "_rename", broken)
    with pytest.raises(OSError, match="exchange fault"):
        with destination(directory_plan(root)) as (work, publish, _commit):
            stage(work)
            publish()
    assert (target / "old").is_file()
    assert sorted(root.iterdir()) == [target]


@pytest.mark.parametrize("after_exchange", [False, True])
def test_sigkill_at_exchange_leaves_complete_canonical_tree_and_retains_other(private_mount, after_exchange):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    (target / "old").write_bytes(b"original")
    plan = directory_plan(root)
    pid = os.fork()
    if pid == 0:
        rename = directory_install._rename

        def interrupted(src, dst, flags):
            if Path(dst) != target:
                rename(src, dst, flags)
                return
            if after_exchange:
                rename(src, dst, flags)
            os.kill(os.getpid(), signal.SIGKILL)

        directory_install._rename = interrupted
        try:
            with destination(plan) as (work, publish, _commit):
                stage(work)
                publish()
        finally:
            os._exit(70)

    _, status = os.waitpid(pid, 0)
    assert os.WIFSIGNALED(status) and os.WTERMSIG(status) == signal.SIGKILL
    orphan, = root.glob(".minios-install-*")
    published, retained = (("new-module", "old") if after_exchange else ("old", "new-module"))
    assert [entry.name for entry in target.iterdir()] == [published]
    path = orphan / "new" / retained
    kept = path.read_bytes()
    # A later successful installation must not infer ownership from a prefix
    # or interpret the leftovers of the killed process as a recovery journal.
    with destination(directory_plan(root)) as (work, publish, commit):
        stage(work)
        publish()
        commit()
    assert (target / "new-module").read_bytes() == b"new"
    assert path.read_bytes() == kept


def test_ambiguous_exchange_preserves_all_trees(private_mount):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    (target / "old").touch()
    with pytest.raises(RuntimeError, match="state is ambiguous"):
        with destination(directory_plan(root)) as (work, publish, _commit):
            retained = stage(work)
            publish()
            target.rename(root / "displaced")
            target.mkdir()
            (target / "foreign").touch()
            raise RuntimeError("activation failed")
    assert (target / "foreign").is_file()
    assert (root / "displaced/new-module").is_file()
    assert (retained / "old").is_file()


def test_failed_reverse_exchange_retains_old_tree_and_canonical_new_tree(private_mount, monkeypatch):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    (target / "old").touch()
    rename = directory_install._rename

    def broken(src, dst, flags):
        if Path(src) == target:
            raise OSError(errno.EIO, "rollback fault")
        rename(src, dst, flags)

    monkeypatch.setattr(directory_install, "_rename", broken)
    with pytest.raises(OSError, match="rollback fault"):
        with destination(directory_plan(root)) as (work, publish, _commit):
            retained = stage(work)
            publish()
            raise RuntimeError("activation failed")
    assert (target / "new-module").is_file()
    assert (retained / "old").is_file()


def test_precommit_sync_error_after_exchange_rolls_back_and_retains_old_tree(private_mount, monkeypatch):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    (target / "old").touch()
    real_sync = directory_install._sync_filesystem

    def broken(fd):
        if (target / "new-module").exists():
            raise OSError(errno.EIO, "sync fault")
        real_sync(fd)

    monkeypatch.setattr(directory_install, "_sync_filesystem", broken)
    with pytest.raises(OSError, match="sync fault"):
        with destination(directory_plan(root)) as (work, publish, _commit):
            stage(work)
            publish()
    assert (target / "old").is_file()
    assert sorted(root.iterdir()) == [target]


def test_failed_exchange_probe_refuses_before_copying(private_mount, monkeypatch):
    root = private_mount
    (root / "minios").mkdir()
    (root / "minios" / "keep").touch()
    monkeypatch.setattr(directory_install, "_rename", Mock(side_effect=OSError(errno.EINVAL, "unsupported")))
    with pytest.raises(RuntimeError, match="Cannot verify atomic replacement"):
        with destination(directory_plan(root)):
            pytest.fail("copying must not start without a successful probe")
    assert (root / "minios/keep").is_file()
    assert sorted(root.iterdir()) == [root / "minios"]


def directory_layout(fs):
    partition = SimpleNamespace(partuuid="part", has_children=False, mountpoint=None, role="data",
                                fstype=fs, path="/disk3", parttype=directory_install.DATA_GUID,
                                partition_number=3, start_sector=2048, size_sectors=200000,
                                start_mib=1, end_mib=98)
    return SimpleNamespace(partitions=[partition], device="/disk", partition_table="gpt",
                           logical_sector_size=512, has_mapped_layout=False, has_nested_layout=False)


@pytest.mark.parametrize("fs", ["ext2", "vfat"])
def test_create_only_filesystems_refuse_replacement_but_can_create(private_mount, monkeypatch, fs):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    monkeypatch.setattr("partition_planner._existing_esp", Mock(return_value=None))
    monkeypatch.setattr("partition_planner._use_efi_for_layout", Mock(return_value=False))
    with pytest.raises(ValueError, match="does not support atomic replacement"):
        plan_directory(directory_layout(fs), "part", True, 0, "live", "auto")
    with pytest.raises(ValueError, match="does not support atomic replacement"):
        with destination(directory_plan(root, fs)):
            pytest.fail("unsupported replacement must fail closed")
    assert sorted(root.iterdir()) == [target]
    target.rmdir()
    plan = plan_directory(directory_layout(fs), "part", False, 0, "live", "auto")
    with destination(plan) as (work, publish, commit):
        stage(work)
        publish()
        commit()
    assert (target / "new-module").is_file()


@pytest.mark.parametrize("failure", [False, True])
def test_ntfs_plan_accepts_replacement_and_only_committed_activation_removes_old(private_mount, monkeypatch, failure):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    (target / "old").touch()
    monkeypatch.setattr("partition_planner._existing_esp", Mock(return_value=None))
    monkeypatch.setattr("partition_planner._use_efi_for_layout", Mock(return_value=False))
    plan = plan_directory(directory_layout("ntfs"), "part", True, 0, "live", "auto")

    def install():
        with destination(plan) as (work, publish, commit):
            stage(work)
            publish()
            assert (Path(work) / "previous" / "old").is_file()
            if failure:
                raise RuntimeError("boot failed")
            commit()

    if failure:
        with pytest.raises(RuntimeError, match="boot failed"):
            install()
        assert (target / "old").is_file()
    else:
        install()
        assert (target / "new-module").is_file()
    assert sorted(root.iterdir()) == [target]
    assert not list((root.parent / "runtime").glob("*/intent.json"))


@pytest.mark.parametrize("kill", ["before-move", "after-old-move", "after-new-move", "after-commit"])
def test_ntfs_sigkill_recovers_prior_to_new_plan(private_mount, monkeypatch, kill):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    (target / "old").write_bytes(b"original")
    (root / "outside").write_bytes(b"foreign")
    plan = directory_plan(root, "ntfs")
    monkeypatch.setattr("partition_planner._existing_esp", Mock(return_value=None))
    monkeypatch.setattr("partition_planner._use_efi_for_layout", Mock(return_value=False))
    child = os.fork()
    if child == 0:
        real = directory_install._ntfs_move

        def interrupted(src, dst):
            if kill == "before-move" and Path(src) == target:
                os.kill(os.getpid(), signal.SIGKILL)
            real(src, dst)
            if ((kill == "after-old-move" and Path(src) == target)
                    or (kill == "after-new-move" and Path(dst) == target)):
                os.kill(os.getpid(), signal.SIGKILL)

        directory_install._ntfs_move = interrupted
        try:
            with destination(plan) as (work, publish, commit):
                stage(work)
                publish()
                commit()
                os.kill(os.getpid(), signal.SIGKILL)
        finally:
            os._exit(70)

    _, status = os.waitpid(child, 0)
    assert os.WIFSIGNALED(status) and os.WTERMSIG(status) == signal.SIGKILL
    work, = root.glob(".minios-ntfs-*")
    if kill == "after-old-move":
        assert not target.exists()
    next_plan = plan_directory(directory_layout("ntfs"), "part", True, 0, "live", "auto")
    assert next_plan.previous_directory == existing(str(root), "ntfs")
    if kill in ("after-new-move", "after-commit"):
        assert (target / "new-module").read_bytes() == b"new"
        assert (work / "previous" / "old").read_bytes() == b"original"
    else:
        assert (target / "old").read_bytes() == b"original"
        assert (work / "new" / "new-module").read_bytes() == b"new"
    assert (root / "outside").read_bytes() == b"foreign"
    assert not list((root.parent / "runtime").glob("*/intent.json"))


def test_ntfs_untrusted_record_cannot_move_or_remove_files(private_mount):
    root = private_mount
    target = root / "minios"
    work = root / (".minios-ntfs-" + "a" * 32)
    outside = root / "Documents"
    outside.mkdir()
    (outside / "data").write_bytes(b"foreign")
    work.mkdir()
    (work / "intent.json").write_text('{"work": "Documents", "previous": "Documents"}')
    (work / "previous").symlink_to(outside)
    with pytest.raises(RuntimeError, match="unverified replacement staging"):
        with destination(directory_plan(root, "ntfs")):
            pytest.fail("untrusted staging must not be interpreted as an intent")
    assert not target.exists()
    assert (work / "previous").is_symlink()
    assert (outside / "data").read_bytes() == b"foreign"


def test_ntfs_verified_intent_does_not_overwrite_an_ambiguous_target(private_mount, monkeypatch):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    (target / "old").write_bytes(b"old")
    plan = directory_plan(root, "ntfs")
    real = directory_install._ntfs_move

    def conflict(src, dst):
        real(src, dst)
        if Path(src) == target:
            target.mkdir()
            (target / "foreign").write_bytes(b"keep")

    with patch("directory_install._ntfs_move", conflict):
        with pytest.raises(RuntimeError, match="state is ambiguous"):
            with destination(plan) as (work, publish, _commit):
                staged = stage(work)
                publish()
    assert (target / "foreign").read_bytes() == b"keep"
    assert (staged / "new-module").read_bytes() == b"new"
    assert (staged.parent / "previous" / "old").read_bytes() == b"old"
    monkeypatch.setattr("partition_planner._existing_esp", Mock(return_value=None))
    monkeypatch.setattr("partition_planner._use_efi_for_layout", Mock(return_value=False))
    with pytest.raises(RuntimeError, match="state is ambiguous"):
        plan_directory(directory_layout("ntfs"), "part", True, 0, "live", "auto")
    assert (target / "foreign").read_bytes() == b"keep"
    assert (staged.parent / "previous" / "old").read_bytes() == b"old"
    assert list((root.parent / "runtime").glob("*/intent.json"))


def test_new_install_does_not_touch_foreign_target(private_mount):
    root = private_mount
    target = root / "minios"
    plan = directory_plan(root)
    with pytest.raises(RuntimeError, match="destination changed"):
        with destination(plan) as (work, publish, _commit):
            stage(work)
            target.mkdir()
            (target / "foreign").touch()
            publish()
    assert (target / "foreign").is_file()
    assert sorted(root.iterdir()) == [target]


@pytest.mark.parametrize("fs", ["ext4", "ntfs"])
def test_failed_first_install_removes_only_its_own_publication(private_mount, fs):
    root = private_mount
    (root / "private-file").write_bytes(b"keep")
    with pytest.raises(RuntimeError, match="activation failed"):
        with destination(directory_plan(root, fs)) as (work, publish, _commit):
            stage(work)
            publish()
            assert (root / "minios/new-module").is_file()
            raise RuntimeError("activation failed")
    assert [entry.name for entry in root.iterdir()] == ["private-file"]
    assert (root / "private-file").read_bytes() == b"keep"


def test_existing_rejects_vfat_alias_without_canonical_entry(private_mount, monkeypatch):
    root = private_mount
    unrelated = root / "unrelated-directory"
    unrelated.mkdir()
    real_lstat = os.lstat

    def alias_lstat(path, *args, **kwargs):
        return real_lstat(unrelated if path == str(root / "minios") else path, *args, **kwargs)

    monkeypatch.setattr(directory_install.os, "lstat", alias_lstat)
    with pytest.raises(RuntimeError, match="conflicting name or alias"):
        existing(str(root), "vfat")
    assert sorted(root.iterdir()) == [unrelated]


def test_vfat_rejects_legacy_replacement_plan_before_writable_mount(private_mount):
    root = private_mount
    target = root / "minios"
    target.mkdir()
    (target / "old").write_bytes(b"old")
    plan = directory_plan(root, "vfat")
    old = target.stat()
    plan.previous_directory = (old.st_size, old.st_mtime_ns, old.st_ctime_ns)
    saved = root / "saved"
    target.rename(saved)
    target.mkdir()
    (target / "foreign").write_bytes(b"keep")

    with patch("directory_install.mounted", side_effect=AssertionError("must not try to mount")) as mount:
        with pytest.raises(ValueError, match="does not support atomic replacement"):
            with destination(plan):
                pytest.fail("a VFAT replacement plan must not run")
        mount.assert_not_called()
    assert (target / "foreign").read_bytes() == b"keep"
    assert (saved / "old").read_bytes() == b"old"


def test_vfat_rejects_a_new_tree_that_appeared_after_a_create_plan(private_mount):
    root = private_mount
    plan = directory_plan(root, "vfat")
    target = root / "minios"
    target.mkdir()
    (target / "foreign").write_bytes(b"keep")

    with pytest.raises(RuntimeError, match="existing minios directory changed"):
        with destination(plan):
            pytest.fail("a new installation must not stage over a foreign tree")
    assert (target / "foreign").read_bytes() == b"keep"
    assert sorted(root.iterdir()) == [target]


def test_directory_plan_never_reaches_partition_executor():
    plan = PartitionPlan("/disk", True, False, directory_partuuid="part")
    with patch("partition_executor._apply_partition_table") as apply, pytest.raises(RuntimeError):
        execute_plan(plan, Mock())
    apply.assert_not_called()


def test_directory_kernel_and_grub_paths_are_pinned_without_relabelling(tmp_path):
    grub = tmp_path / "minios/boot/grub"
    grub.mkdir(parents=True)
    (grub / "grub.cfg").write_text("source /minios/boot/grub/main.cfg\n")
    menu = grub / "main.cfg"
    menu.write_text(" linux /minios/boot/vmlinuz-test boot=live\n initrd /minios/boot/initrfs.img\n")
    bind_live_data(str(tmp_path), "", subdir="system-1234")
    assert (grub / "grub.cfg").read_text() == "source /minios/system-1234/boot/grub/main.cfg\n"
    assert menu.read_text() == (" linux /minios/system-1234/boot/vmlinuz-test boot=live from=/minios/system-1234\n"
                                " initrd /minios/system-1234/boot/initrfs.img\n")

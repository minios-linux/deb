#!/bin/bash
# Fixture launcher for a disposable Testo UEFI guest. No Windows emulation.
set -euo pipefail
media=/run/initramfs/memory/data
qa=$media/qa
[[ $(systemd-detect-virt) =~ ^(kvm|qemu)$ && -d /sys/firmware/efi ]]
test -f "$qa/previous.efi"
dpkg -i "$qa"/*.deb
disk=$(minios-deploy list-disks --json | python3 -c '
import json,sys
d=json.load(sys.stdin); assert len(d)==1
p=d[0]["by_id"]; assert p.startswith("/dev/disk/by-id/"); print(p)')
test "$(blockdev --getsize64 "$disk")" = 10737418240
test -z "$(wipefs --noheadings -o TYPE "$disk")"
layout='label: gpt\nsize=260MiB, type=U\nsize=3072MiB, type=L\n'
if [[ ${1:-live} == native ]]; then
    test -f "$qa/native-separate-boot.py"
    layout+='size=768MiB, type=L\ntype=L\n'
fi
printf '%b' "$layout" | sfdisk "$disk"
udevadm settle
esp="${disk}-part1"
rootpart="${disk}-part2"
mkfs.vfat -F 32 "$esp"
mkfs.ext4 -q -L PREVLINUX "$rootpart"
root=$(mktemp -d)
mount "$rootpart" "$root"
cp -a "$media/minios" "$root/previous"
mkdir -p "$root/boot/grub"
printf 'echo WRONG_BOOT_FILESYSTEM\n' > "$root/boot/grub/grub.cfg"
mkdir "$root/previous/qa"
cp "$qa"/{efibootmgr,libefiboot*,libefivar*,libpopt*}_*.deb "$root/previous/qa/"
umount "$root"
mount "$esp" "$root"
mkdir -p "$root/EFI/previous" "$root/EFI/BOOT"
cp "$qa/previous.efi" "$root/EFI/previous/linux.efi"
cp "$qa/previous.efi" "$root/EFI/BOOT/BOOTX64.EFI"
(cd "$root" && sha256sum EFI/previous/linux.efi EFI/BOOT/BOOTX64.EFI) >/tmp/dual-old.sha256
umount "$root"
efibootmgr --create --disk "$(readlink -f "$disk")" --part 1 --label QA-previous --loader '\EFI\previous\linux.efi'
before=$(efibootmgr | sed -n 's/^BootOrder: //p')
[[ -n $before ]]
if [[ ${1:-live} == native ]]; then
    mkfs.ext4 -q -L QABOOT "${disk}-part3"
    mkfs.ext4 -q -L QAROOT "${disk}-part4"
    python3 "$qa/native-separate-boot.py"
else
    minios-deploy plan "$disk" --mode live --placement free_space --json >/tmp/dual-plan.json
    python3 -c 'import json; p=json.load(open("/tmp/dual-plan.json")); assert p["boot_action"]=="append_efi" and p["reuse_esp"] and not p["wipe_disk"]'
    minios-deploy install "$disk" --mode live --placement free_space --dry-run
    minios-deploy install "$disk" --mode live --placement free_space --yes
fi
mount -o ro "$esp" "$root"
(cd "$root" && sha256sum -c /tmp/dual-old.sha256 && test -s EFI/minios/bootx64.efi)
umount "$root"
new=$(efibootmgr | sed -nE 's/^Boot([0-9A-Fa-f]{4})\* MiniOS([[:space:]].*)?$/\1/p')
test "$(efibootmgr | sed -n 's/^BootOrder: //p')" = "$before,$new"
sync

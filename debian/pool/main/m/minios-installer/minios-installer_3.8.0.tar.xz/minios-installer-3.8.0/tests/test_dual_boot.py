import copy
from unittest.mock import patch

import pytest

from partition_models import DiskLayout, PartitionInfo, PartitionPlan, PlannedPartition
from partition_planner import _existing_esp, _use_gpt_for_preserve
from native_deploy import _matching_minios_efi_entries, _mounted_grub_wrapper
from copy_utils import bind_live_data, verify_efi_payload
from grub_hook import _facts


def test_mbr_native_under_uefi_preserves_primary_table():
    with patch("partition_planner.is_uefi_system", return_value=True):
        assert not _use_gpt_for_preserve(DiskLayout("/disk", 16000, partition_table="dos"),
                                         install_mode="native")


def test_multiple_esps_are_not_selected_by_list_order():
    parts = [PartitionInfo(str(n), "/disk{}".format(n), 200, role="esp") for n in (1, 2)]
    with patch("subprocess.check_output", return_value="BootOrder: 0003\n"), pytest.raises(ValueError, match="ambiguous"):
        _existing_esp(DiskLayout("/disk", 16000, partitions=parts), True)


def test_esp_with_windows_entry_is_selected_by_partuuid():
    guid = "c12a7328-f81f-11d2-ba4b-00a0c93ec93b"
    layout = DiskLayout("/disk", 16000, partition_table="gpt", partitions=[
        PartitionInfo(str(n), "/disk{}".format(n), 200, role="esp", fstype="vfat", parttype=guid, partuuid=uuid)
        for n, uuid in ((1, "aaaa"), (2, "bbbb"))])
    listing = "BootOrder: 0003\nBoot0003* Windows Boot Manager HD(2,GPT,bbbb,0x800,0x100)/File(\\EFI\\Microsoft\\Boot\\bootmgfw.efi)"
    with patch("subprocess.check_output", return_value=listing):
        assert _existing_esp(layout, True).path == "/disk2"


@pytest.mark.parametrize("change", ["range", "order", "module", "esp", "sector"])
def test_confirmation_rejects_substituted_action(change):
    plan = PartitionPlan("/disk", True, False,
                         [PlannedPartition("create", "minios_root", 101, 4096, "ext4")],
                         use_efi=True, boot_action="append_efi", firmware_order=("0005", "0002"))
    fresh = copy.deepcopy(plan)
    if change == "range":
        fresh.partitions[0].start_mib += 1
    elif change == "order":
        fresh.firmware_order = tuple(reversed(plan.firmware_order))
    elif change == "module":
        fresh.modules = ("kernel.sb",)
    elif change == "esp":
        fresh.esp_partuuid = "different"
    else:
        fresh.sector_size = 4096
    with pytest.raises(RuntimeError, match="plan changed"):
        fresh.require_approved(plan)


def test_shared_efi_refuses_same_length_corruption(tmp_path):
    src, dst = tmp_path / "src", tmp_path / "dst"
    (src / "boot/EFI/BOOT").mkdir(parents=True)
    (dst / "EFI/BOOT").mkdir(parents=True)
    (src / "boot/EFI/BOOT/BOOTX64.EFI").write_bytes(b"source")
    (dst / "EFI/BOOT/BOOTX64.EFI").write_bytes(b"broken")
    with pytest.raises(RuntimeError, match="verification failed"):
        verify_efi_payload(str(src), str(dst))


def test_mounted_separate_boot_selects_its_filesystem(tmp_path):
    with patch("native_deploy.subprocess.check_output", return_value="/dev/test2\n"), \
         patch("native_deploy.os.path.ismount", return_value=True), \
         patch("native_deploy._unique_fs_uuid", return_value="UUID-of-boot") as identity:
        wrapper = _mounted_grub_wrapper(str(tmp_path))
    identity.assert_called_once_with("/dev/test2")
    assert "UUID-of-boot" in wrapper and "($root)/grub\n" in wrapper and "--file" not in wrapper


def test_matching_efi_mbr_signature_and_partition():
    loader = r"\EFI\minios\bootx64.efi"
    listing = "BootOrder: 0005\nBoot0005* MiniOS HD(2,MBR,0x12345678,0x800,0x60000)/File({})".format(loader)
    assert _matching_minios_efi_entries(listing, loader, "12345678-02") == {"0005"}
    assert not _matching_minios_efi_entries(listing, loader, "12345678-01")


def test_live_data_location_changes_only_kernel_commands(tmp_path):
    directory = tmp_path / "minios/boot/grub"
    directory.mkdir(parents=True)
    menu = directory / "main.cfg"
    (directory / "grub.cfg").write_text("source $prefix/main.cfg\n")
    menu.write_bytes(b"  linux /minios/boot/vmlinuz-1 boot=live\r\n  initrd /minios/boot/initrfs.img\r\n")
    bind_live_data(str(tmp_path), "MOS01234567")
    assert menu.read_bytes() == (b"  linux /minios/boot/vmlinuz-1 boot=live from=/dev/disk/by-label/MOS01234567/minios\r\n"
                                 b"  initrd /minios/boot/initrfs.img\r\n")


def test_grub_hook_rejects_foreign_core_even_with_grub_mbr(tmp_path):
    import struct
    directory = tmp_path / "boot/grub/i386-pc"
    directory.mkdir(parents=True)
    (directory.parent / "grub.cfg").write_bytes(b"source ${config_directory}/custom.cfg\n")
    boot = bytearray(512)
    boot[150:154] = b"GRUB"
    boot[510:] = b"\x55\xaa"
    struct.pack_into("<Q", boot, 0x5c, 1)
    (directory / "boot.img").write_bytes(boot)
    core = bytearray(1024)
    struct.pack_into("<QHH", core, 500, 2, 1, 0x820)
    (directory / "core.img").write_bytes(core)
    disk = tmp_path / "disk"
    disk.write_bytes(boot + core)
    assert _facts(str(tmp_path), str(disk), 2048)
    core[700] ^= 1
    disk.write_bytes(boot + core)
    with pytest.raises(ValueError, match="does not match"):
        _facts(str(tmp_path), str(disk), 2048)

"""Testo guest only: exercise the manual GUI's actual planner and executor."""
import json
import os
import subprocess
import sys

sys.path.insert(0, "/usr/lib/minios-installer")
from disk_utils import get_device_identity
from install_state import InstallState, UserConfig
from manual_partitioning import ManualAction, ManualPlanner, MountAssignment, scan_manual_layout
from module_selection import list_live_module_names
from native_deploy import run_native_install
from partition_scanner import scan_disk

if __name__ == "__main__":
    assert os.geteuid() == 0 and os.path.exists("/sys/firmware/efi")
    assert subprocess.check_output(["systemd-detect-virt"]).strip() in (b"kvm", b"qemu")
    disks = json.loads(subprocess.check_output(["minios-deploy", "list-disks", "--json"]))
    assert len(disks) == 1 and disks[0]["by_id"].startswith("/dev/disk/by-id/")
    disk = disks[0]["by_id"]
    assert int(subprocess.check_output(["blockdev", "--getsize64", disk])) == 10 * 1024**3
    snapshot = scan_manual_layout(scan_disk(os.path.realpath(disk)))
    esp, previous, boot, root = snapshot.partitions
    for part, label in ((previous, "PREVLINUX"), (boot, "QABOOT"), (root, "QAROOT")):
        dev = disk + "-part" + str(part.number)
        assert subprocess.check_output(["blkid", "-s", "LABEL", "-o", "value", dev]).strip() == label.encode()
    assignments = [MountAssignment(root, "root", "/", "ext4", True),
                   MountAssignment(boot, "data", "/boot", "ext4", True),
                   MountAssignment(esp, "esp", "/boot/efi", "vfat", False)]
    actions = [ManualAction("format", p, fstype="ext4") for p in (root, boot)]
    plan = ManualPlanner().stage(snapshot, actions, assignments, use_efi=True)
    # The old Linux has its own /boot/grub/grub.cfg and must not win a global
    # GRUB search once the new native entry is selected.
    state = InstallState(install_mode="native", placement="manual", target_device=disk,
                         target_device_identity=get_device_identity(disk), manual_partition_plan=plan,
                         selected_modules=[n for n in list_live_module_names() if n.startswith(("00-", "01-"))],
                         download_missing_packages=True,
                         user_config=UserConfig(username="qa", password="qa", hostname="dual-native",
                                                default_target="multi-user"))
    run_native_install(state, lambda p, m: print(p, m, flush=True), lambda m: print(m, flush=True))

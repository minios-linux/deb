#!/bin/bash
# Only run from a purpose-built Testo DVD, with a single blank disposable disk.
set -euo pipefail
media=/run/initramfs/memory/data
qa=$media/qa
[[ $(systemd-detect-virt) =~ ^(kvm|qemu)$ && ! -d /sys/firmware/efi ]]
test -f "$qa/bios-fixture/core.img"
dpkg -i "$qa"/*.deb
disk=$(minios-deploy list-disks --json | python3 -c '
import json,sys
d=json.load(sys.stdin); assert len(d)==1
p=d[0]["by_id"]; assert p.startswith("/dev/disk/by-id/"); print(p)')
test "$(blockdev --getsize64 "$disk")" = 10737418240
signatures=$(wipefs --noheadings --output TYPE "$disk")
test -z "$signatures"
printf 'label: dos\nstart=2048, size=6291456, type=83, bootable\n' | sfdisk "$disk"
udevadm settle
part="${disk}-part1"
mkfs.ext4 -q -L PREVLINUX "$part"
root=$(mktemp -d)
mount "$part" "$root"
mkdir -p "$root/boot/grub/i386-pc"
cp -a "$media/minios" "$root/previous"
cp "$qa"/bios-fixture/{core.img,boot.img} "$root/boot/grub/i386-pc/"
if [[ ${1:-} == directory ]]; then
    mkdir "$root/Documents"
    printf 'keep existing ext4 data\n' >"$root/Documents/keep.txt"
fi
kernel=$(basename "$(find "$root/previous/boot" -type f -name 'vmlinuz-*' -print -quit)")
initrd=$(basename "$(find "$root/previous/boot" -type f -name 'initrfs-*.img' -print -quit)")
cat >"$root/boot/grub/grub.cfg" <<EOF
set default=0
set timeout=15
menuentry 'Previous Linux' {
 linux /previous/boot/$kernel boot=live quiet from=/dev/disk/by-label/PREVLINUX/previous dualqa.previous
 initrd /previous/boot/$initrd
}
if [ -f \$prefix/custom.cfg ]; then
 source \$prefix/custom.cfg
fi
EOF
umount "$root"
core=$qa/bios-fixture/core.img
test "$(stat -c%s "$core")" -lt 1048064
dd if="$core" of="$disk" bs=512 seek=1 conv=notrunc,fsync status=none
dd if="$qa/bios-fixture/boot.img" of="$disk" bs=440 count=1 conv=notrunc,fsync status=none
before=$(dd if="$disk" bs=440 count=1 status=none | sha256sum)
gap=$(dd if="$disk" bs=512 skip=1 count=2047 status=none | sha256sum)
# lsblk reads filesystem metadata from udev. Finish publishing the fixture
# before testing the planner, especially after mkfs and raw MBR writes.
udevadm trigger --action=change --sysname-match="$(basename "$(readlink -f "$part")")"
udevadm settle
test "$(lsblk -dnro FSTYPE "$part")" = ext4
test -n "$(blkid -s PARTUUID -o value "$part")"
opts=(--mode live --placement free_space)
if [[ ${1:-} == directory ]]; then
    partuuid=$(blkid -s PARTUUID -o value "$part")
    opts=(--mode live --placement directory --data-partuuid "$partuuid")
    fs_uuid=$(blkid -s UUID -o value "$part")
    printf 'Directory target: %s (ext4, UUID=%s, PARTUUID=%s)\n' "$part" "$fs_uuid" "$partuuid"
    sfdisk --dump "$disk" >/tmp/orig-layout
fi
echo "Checking install plan"
minios-deploy plan "$disk" "${opts[@]}" --json >/tmp/dual-plan.json
python3 -c 'import json; p=json.load(open("/tmp/dual-plan.json")); assert p["boot_action"]=="existing_grub" and not p["wipe_disk"]'
if [[ ${1:-} == directory ]]; then
    python3 - "$partuuid" <<'PY'
import json, sys
plan = json.load(open("/tmp/dual-plan.json"))
part, = plan["partitions"]
assert plan["directory_partuuid"] == sys.argv[1] and plan["resize"] is None
assert (part["action"], part["role"], part["fstype"]) == ("reuse", "minios_root", "ext4")
PY
fi
echo "Checking dry run"
minios-deploy install "$disk" "${opts[@]}" --dry-run
echo "Running installation"
minios-deploy install "$disk" "${opts[@]}" --yes
if [[ ${1:-} == directory ]]; then
    sfdisk --dump "$disk" | cmp - /tmp/orig-layout
    test "$(blkid -s UUID -o value "$part")" = "$fs_uuid"
    test "$(blkid -s LABEL -o value "$part")" = PREVLINUX
    mount -o ro "$part" "$root"
    test -s "$root/minios/system-$fs_uuid/00-core-amd64.sb"
    test -s "$root/previous/00-core-amd64.sb"
    grep -Fxq 'keep existing ext4 data' "$root/Documents/keep.txt"
    umount "$root"
    echo "Verified ext4 UUID, label, both payloads and existing user data"
fi
test "$before" = "$(dd if="$disk" bs=440 count=1 status=none | sha256sum)"
test "$gap" = "$(dd if="$disk" bs=512 skip=1 count=2047 status=none | sha256sum)"
sfdisk --json "$disk" | python3 -c 'import sys,json; p=json.load(sys.stdin)["partitiontable"]["partitions"]; assert p[0]["bootable"] and not any(x.get("bootable") for x in p[1:])'
sync

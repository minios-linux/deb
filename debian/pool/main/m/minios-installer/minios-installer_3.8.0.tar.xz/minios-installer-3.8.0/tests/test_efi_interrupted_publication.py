import os
import signal
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))

import native_deploy


@pytest.mark.parametrize("kill_after", ["old", "new"])
def test_sigkill_leaves_recoverable_old_loader_and_blocks_retry(tmp_path, kill_after):
    source = tmp_path / "source"
    boot = source / "boot"
    boot.mkdir(parents=True)
    (boot / "bootx64.efi").write_bytes(b"new-loader")
    (boot / "grubx64.efi").write_bytes(b"prefix=/EFI/debian")
    (boot / "grubia32.efi").write_bytes(b"prefix=/EFI/debian")
    esp = tmp_path / "esp"
    target = esp / "EFI"
    (target / "minios").mkdir(parents=True)
    (target / "minios" / "grub.cfg").write_text("old-wrapper")
    (target / "minios" / "bootx64.efi").write_bytes(b"old-loader")
    windows = target / "Microsoft" / "Boot" / "bootmgfw.efi"
    windows.parent.mkdir(parents=True)
    windows.write_bytes(b"windows")
    foreign = target / "ubuntu" / "grub.cfg"
    foreign.parent.mkdir()
    foreign.write_text("foreign")

    pid = os.fork()
    if pid == 0:
        real_replace = os.replace

        def replace(src, dst):
            real_replace(src, dst)
            if ((kill_after == "old" and os.path.basename(dst) == "minios"
                 and os.path.basename(os.path.dirname(dst)) == "EFI.original")
                    or (kill_after == "new" and dst == str(target / "minios"))):
                os.kill(os.getpid(), signal.SIGKILL)

        native_deploy.os.replace = replace
        try:
            native_deploy._publish_native_efi(
                str(source), str(target), "new-wrapper", lambda: None,
                reuse_esp=True, owned_wrapper="old-wrapper")
        finally:
            os._exit(90)

    _, status = os.waitpid(pid, 0)
    assert os.WIFSIGNALED(status) and os.WTERMSIG(status) == signal.SIGKILL
    stages = list(esp.glob(".minios-native-efi-*"))
    assert len(stages) == 1
    backup = stages[0] / "EFI.original" / "minios"
    assert (backup / "bootx64.efi").read_bytes() == b"old-loader"
    if kill_after == "old":
        assert not (target / "minios").exists()
    else:
        assert (target / "minios" / "bootx64.efi").read_bytes() == b"new-loader"

    with pytest.raises(RuntimeError, match="interrupted EFI update") as error:
        native_deploy._publish_native_efi(
            str(source), str(target), "new-wrapper", lambda: None,
            reuse_esp=True, owned_wrapper="old-wrapper")
    assert stages[0].name + "/EFI.original/minios" in str(error.value)
    assert "EFI/minios is missing" in str(error.value)
    assert windows.read_bytes() == b"windows"
    assert foreign.read_text() == "foreign"


def test_preflight_rejects_interrupted_backup_before_minios_check(tmp_path, monkeypatch):
    esp = tmp_path / "esp"
    backup = esp / ".minios-native-efi-stale" / "EFI.original" / "minios"
    backup.mkdir(parents=True)
    (backup / "grub.cfg").write_text("old")
    monkeypatch.setattr(native_deploy, "_validate_regular_efi_tree", lambda *_: None)
    monkeypatch.setattr(native_deploy, "_efi_grub_vendors", lambda *_: set())
    monkeypatch.setattr(native_deploy.tempfile, "mkdtemp", lambda **_: str(esp))
    monkeypatch.setattr(native_deploy.subprocess, "run",
                        lambda *args, **kwargs: type("Result", (), {"returncode": 0})())
    monkeypatch.setattr(native_deploy.shutil, "rmtree", lambda *_args, **_kwargs: None)
    with pytest.raises(RuntimeError, match="interrupted EFI update"):
        native_deploy._preflight_reused_efi_payload_path("/dev/esp", "/source")


def test_exception_after_backup_rename_restores_original(tmp_path, monkeypatch):
    source = tmp_path / "source"
    boot = source / "boot"
    boot.mkdir(parents=True)
    (boot / "bootx64.efi").write_bytes(b"new")
    (boot / "grubx64.efi").write_bytes(b"prefix=/EFI/debian")
    (boot / "grubia32.efi").write_bytes(b"prefix=/EFI/debian")
    target = tmp_path / "esp" / "EFI"
    (target / "minios").mkdir(parents=True)
    (target / "minios" / "grub.cfg").write_text("old")
    real_replace = os.replace

    def replace(src, dst):
        real_replace(src, dst)
        if os.path.basename(os.path.dirname(dst)) == "EFI.original":
            raise OSError("interrupted after rename")

    monkeypatch.setattr(native_deploy.os, "replace", replace)
    with pytest.raises(OSError, match="interrupted after rename"):
        native_deploy._publish_native_efi(
            str(source), str(target), "new", lambda: None,
            reuse_esp=True, owned_wrapper="old")
    assert (target / "minios" / "grub.cfg").read_text() == "old"


def test_untrusted_staging_symlink_blocks_without_following(tmp_path):
    esp = tmp_path / "esp"
    esp.mkdir()
    foreign = tmp_path / "foreign"
    foreign.mkdir()
    (foreign / "keep").write_text("untouched")
    (esp / ".minios-native-efi-untrusted").symlink_to(foreign, target_is_directory=True)
    with pytest.raises(RuntimeError, match="interrupted EFI update"):
        native_deploy._check_interrupted_efi_publication(str(esp))
    assert (foreign / "keep").read_text() == "untouched"

import contextlib
import os
import sys
from unittest.mock import Mock

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))

import directory_install
import live_deploy
from install_state import InstallCanceled, InstallState


@pytest.mark.parametrize("boot", ["grub", "efi"])
@pytest.mark.parametrize("failure", ["none", "early_cancel", "late_cancel", "activation",
                                     "boot_cleanup", "esp_unmount", "data_cleanup", "progress"])
def test_directory_activation_commit_boundary(tmp_path, monkeypatch, boot, failure):
    root = tmp_path / "data"
    root.mkdir()
    (root / "minios").mkdir()
    (root / "minios" / "old").write_text("old")
    esp = tmp_path / "esp"
    esp.mkdir()
    state = InstallState(install_mode="live", placement="directory",
                         target_device="/dev/disk", filesystem="ext4",
                         directory_partuuid="part", replace_directory=True)
    plan = Mock()
    plan.directory_uuid = "1234"
    plan.directory_partuuid = "part"
    plan.previous_directory = directory_install.existing(str(root), "ext4")
    plan.replace_directory = True
    plan.root_partition.return_value = Mock(path="/dev/data", fstype="ext4")
    plan.esp_path = "/dev/esp"
    plan.reuse_esp = boot == "efi"
    plan.boot_action = "existing_grub" if boot == "grub" else "efi"
    plan.grub_hook = ("/dev/data",)
    plan.live_label = ""
    plan.use_gpt = True
    plan.wipe_disk = False
    events = []

    @contextlib.contextmanager
    def mounted(path, fs, write=False):
        try:
            yield str(esp if path == "/dev/esp" else root)
        finally:
            events.append("esp exit" if path == "/dev/esp" else "data exit")
            if path == "/dev/esp" and failure == "esp_unmount":
                raise RuntimeError("esp unmount")

    def copy(_src, dest, *_args, **_kwargs):
        os.mkdir(os.path.join(dest, "minios"))
        with open(os.path.join(dest, "minios", "fresh"), "w") as stream:
            stream.write("new")

    def activate(*_args, **kwargs):
        events.append("activated")
        if failure == "activation":
            raise RuntimeError("activation")
        if failure == "late_cancel":
            state.cancel_requested = True
        kwargs["on_published"]()
        if failure == "boot_cleanup":
            raise RuntimeError("boot cleanup")

    def progress(percent, _message):
        if percent == 99 and failure == "progress":
            raise RuntimeError("progress")

    real_rmtree = directory_install.shutil.rmtree

    def rmtree(path, *args, **kwargs):
        if failure == "data_cleanup":
            raise RuntimeError("data cleanup")
        return real_rmtree(path, *args, **kwargs)

    monkeypatch.setattr(directory_install, "mounted", mounted)
    monkeypatch.setattr(directory_install.shutil, "rmtree", rmtree)
    real_destination = directory_install.destination

    @contextlib.contextmanager
    def destination(plan):
        with real_destination(plan) as (work, publish, commit):
            def publish_with_cancel():
                publish()
                if failure == "early_cancel":
                    state.cancel_requested = True
            yield work, publish_with_cancel, commit

    monkeypatch.setattr(directory_install, "destination", destination)
    monkeypatch.setattr("partition_executor._revalidate_preserve_plan", Mock())
    monkeypatch.setattr("partition_executor._verify_existing_partition", Mock())
    monkeypatch.setattr("partition_executor._revalidate_reused_esp", Mock())
    monkeypatch.setattr("native_deploy._blkid_value", Mock(return_value="part"))
    monkeypatch.setattr("native_deploy._unique_fs_uuid", Mock(return_value="1234"))
    monkeypatch.setattr("native_deploy._preflight_efi_payload_contract", Mock())
    monkeypatch.setattr("native_deploy._preflight_reused_efi_payload_path", Mock())
    monkeypatch.setattr("native_deploy._publish_native_efi", activate)
    monkeypatch.setattr("grub_hook.publish", activate)
    monkeypatch.setattr("copy_utils.bind_live_data", Mock())
    monkeypatch.setattr(live_deploy, "resolve_install_device", Mock(return_value="/dev/disk"))
    monkeypatch.setattr(live_deploy, "find_minios_source", Mock(return_value="/source/minios"))
    monkeypatch.setattr(live_deploy, "scan_disk", Mock())
    monkeypatch.setattr(live_deploy, "build_plan", Mock(return_value=plan))
    monkeypatch.setattr(live_deploy, "copy_minios_files", copy)
    monkeypatch.setattr(live_deploy, "create_live_session", Mock())

    should_raise = failure in ("early_cancel", "activation", "boot_cleanup", "data_cleanup", "progress") or (
        boot == "efi" and failure == "esp_unmount")
    if should_raise:
        with pytest.raises(InstallCanceled if failure == "early_cancel" else RuntimeError):
            live_deploy.run_live_install(state, progress, lambda *_: None)
    else:
        live_deploy.run_live_install(state, progress, lambda *_: None)

    if failure in ("activation", "early_cancel"):
        assert (root / "minios" / "old").read_text() == "old"
        assert not (root / "minios" / "system-1234" / "fresh").exists()
        if failure == "early_cancel":
            assert "activated" not in events
    else:
        assert (root / "minios" / "system-1234" / "fresh").read_text() == "new"
        assert not (root / "minios" / "old").exists()
    if boot == "efi" and "esp exit" in events:
        assert events.index("esp exit") < events.index("data exit")


def test_grub_callback_precedes_own_unmount_error(tmp_path, monkeypatch):
    import grub_hook
    import native_deploy

    grub = tmp_path / "boot" / "grub"
    grub.mkdir(parents=True)
    plan = Mock(device="/dev/disk", install_mode="live", directory_partuuid="part")
    plan.grub_hook = ("/dev/grub", "part", 2048, "approved")
    events = []

    @contextlib.contextmanager
    def mount(*_args, **_kwargs):
        yield str(tmp_path)
        raise RuntimeError("grub unmount")

    monkeypatch.setattr(grub_hook, "_mount", mount)
    monkeypatch.setattr(grub_hook, "_facts", Mock(return_value=("approved",)))
    monkeypatch.setattr(native_deploy, "_blkid_value", Mock(return_value="part"))
    with pytest.raises(RuntimeError, match="grub unmount"):
        grub_hook.publish(plan, "1234", on_published=lambda: events.append("commit"))
    assert events == ["commit"]
    assert "system-1234" in (grub / "custom.cfg").read_text()


def test_efi_callback_precedes_cleanup_error(tmp_path, monkeypatch):
    import native_deploy

    source = tmp_path / "source"
    (source / "boot").mkdir(parents=True)
    (source / "boot" / "loader.efi").write_text("loader")
    target = tmp_path / "esp" / "EFI"
    events = []
    monkeypatch.setattr(native_deploy, "_efi_grub_vendors", Mock(return_value=[]))

    def cleanup(_path, **_kwargs):
        raise RuntimeError("efi cleanup")

    monkeypatch.setattr(native_deploy.shutil, "rmtree", cleanup)
    with pytest.raises(RuntimeError, match="efi cleanup"):
        native_deploy._publish_native_efi(
            str(source), str(target), "wrapper", register_reused=lambda: None,
            reuse_esp=True, on_published=lambda: events.append("commit"))
    assert events == ["commit"]
    assert (target / "minios" / "loader.efi").read_text() == "loader"


def test_efi_commit_error_does_not_rollback_loader(tmp_path, monkeypatch):
    import native_deploy

    source = tmp_path / "source"
    (source / "boot").mkdir(parents=True)
    (source / "boot" / "loader.efi").write_text("loader")
    target = tmp_path / "esp" / "EFI"
    monkeypatch.setattr(native_deploy, "_efi_grub_vendors", Mock(return_value=[]))

    def fail():
        raise RuntimeError("commit failed")

    with pytest.raises(RuntimeError, match="commit failed"):
        native_deploy._publish_native_efi(
            str(source), str(target), "wrapper", register_reused=lambda: None,
            reuse_esp=True, on_published=fail)
    assert (target / "minios" / "loader.efi").read_text() == "loader"

"""Narrow BIOS preserve path: a single recognized ext-based GRUB installation."""
import contextlib
import gettext
import hashlib
import os
import stat
import struct
import subprocess
import tempfile

_ = gettext.gettext
MAX_CONFIG = 4 * 1024 * 1024
def _standard_hook(cfg):
    # Do not infer that an arbitrary conditional, commented example or
    # menuentry body will actually source the file. Recognize a final,
    # unconditional source or the standard distro-generated 41_custom block.
    lines = [b" ".join(line.split()) for line in cfg.splitlines()
             if line.strip() and not line.lstrip().startswith(b"#")]
    lines = [line.replace(b"${prefix}", b"$prefix").replace(b"${config_directory}", b"$config_directory")
             for line in lines]
    simple = [b"if [ -f $prefix/custom.cfg ]; then", b"source $prefix/custom.cfg", b"fi"]
    standard = [b"if [ -f $config_directory/custom.cfg ]; then", b"source $config_directory/custom.cfg",
                b'elif [ -z "$config_directory" -a -f $prefix/custom.cfg ]; then', b"source $prefix/custom.cfg", b"fi"]
    return lines[-3:] == simple or lines[-5:] == standard or lines[-1:] in (
        [b"source $prefix/custom.cfg"], [b"source $config_directory/custom.cfg"])


def _read(root, relative, limit=MAX_CONFIG, optional=False):
    path = os.path.join(root, relative)
    if os.path.realpath(path) != path:
        raise ValueError(_("GRUB paths containing symbolic links cannot be modified safely."))
    if optional and not os.path.lexists(path):
        return b""
    if not stat.S_ISREG(os.lstat(path).st_mode) or os.path.getsize(path) > limit:
        raise ValueError(_("Unsupported GRUB file: ") + relative)
    with open(path, "rb") as stream:
        return stream.read(limit + 1)


@contextlib.contextmanager
def _mount(partition, writable=False):
    if subprocess.run(["findmnt", "-rn", "-S", partition], stdout=subprocess.DEVNULL).returncode != 1:
        raise ValueError(_("The existing GRUB partition must be unmounted."))
    root = tempfile.mkdtemp(prefix="minios-existing-grub-")
    mounted = False
    try:
        opts = "rw" if writable else "ro,noload"
        subprocess.run(["mount", "-t", "ext4", "-o", opts + ",nodev,nosuid,noexec", partition, root], check=True)
        mounted = True
        yield root
    finally:
        if mounted:
            subprocess.run(["umount", root], check=True)
        os.rmdir(root)


def _facts(root, disk, first):
    cfg = _read(root, "boot/grub/grub.cfg")
    if not _standard_hook(cfg):
        raise ValueError(_("The existing GRUB configuration does not load custom.cfg."))
    core = _read(root, "boot/grub/i386-pc/core.img")
    boot = _read(root, "boot/grub/i386-pc/boot.img", 512)
    custom = _read(root, "boot/grub/custom.cfg", optional=True)
    with open(disk, "rb", buffering=0) as stream:
        mbr = stream.read(512)
        if (len(boot) != 512 or len(mbr) != 512 or mbr[510:] != b"\x55\xaa"
                or b"GRUB" not in mbr[:440] or mbr[128:440] != boot[128:440]):
            raise ValueError(_("The disk does not boot the recognized GRUB MBR."))
        start = struct.unpack_from("<Q", mbr, 0x5c)[0]
        if len(core) <= 512 or start != 1 or start * 512 + len(core) > first * 512:
            raise ValueError(_("Cannot verify the existing GRUB embedding area."))
        stream.seek(start * 512)
        embedded = stream.read(len(core))
        # diskboot.img contains the patched block list; only accept a contiguous
        # second stage with matching content, never merely the GRUB MBR string.
        if (embedded[512:] != core[512:] or len(embedded) < 512
                or struct.unpack_from("<QHH", embedded, 500) !=
                (start + 1, (len(core) - 1) // 512, 0x820)):
            raise ValueError(_("The embedded GRUB image does not match the selected Linux installation."))
    return tuple(hashlib.sha256(data).hexdigest() for data in (mbr[:440], embedded, cfg, custom))


def inspect(plan):
    from partition_scanner import scan_disk
    layout = scan_disk(plan.device)
    if (layout.logical_sector_size != 512 or not layout.geometry_complete or
            layout.has_nested_layout or layout.has_mapped_layout):
        raise ValueError(_("Unsupported BIOS disk geometry for existing GRUB integration."))
    roots = [p for p in layout.partitions if p.fstype != "swap"]
    if len(roots) != 1 or roots[0].fstype not in ("ext2", "ext3", "ext4") or not roots[0].partuuid:
        raise ValueError(_("Cannot uniquely identify an existing Linux BIOS GRUB installation."))
    part = roots[0]
    first = min([p.start_sector for p in layout.partitions] +
                [p.start_mib * 2048 for p in plan.partitions if p.action == "create"])
    try:
        with _mount(part.path) as root:
            return (part.path, part.partuuid, first) + _facts(root, plan.device, first)
    except (OSError, subprocess.CalledProcessError) as exc:
        raise ValueError(_("Cannot verify the existing BIOS GRUB configuration.")) from exc


def publish(plan, uuid, mounted_root=None, on_published=None):
    from native_deploy import _blkid_value, _grub_wrapper
    part, identity, first = plan.grub_hook[:3]
    if _blkid_value(part, "PARTUUID") != identity:
        raise RuntimeError(_("The GRUB partition changed after confirmation."))
    with contextlib.ExitStack() as stack:
        root = mounted_root or stack.enter_context(_mount(part, writable=True))
        if _facts(root, plan.device, first) != plan.grub_hook[3:]:
            raise RuntimeError(_("Existing boot configuration changed. The GRUB menu was not replaced."))
        original = _read(root, "boot/grub/custom.cfg", optional=True)
        live = plan.install_mode == "live"
        entry = ("\nmenuentry '{0}' --id minios-{1} {{\n{2}}}\n".format(
            "MiniOS Live" if live else "MiniOS", uuid,
            _grub_wrapper(uuid, "/minios/system-{}/boot/grub".format(uuid) if plan.directory_partuuid
                          else "/minios/boot/grub" if live else "/boot/grub"))).encode("ascii")
        if entry in original:
            if on_published:
                on_published()
            return
        path = os.path.join(root, "boot/grub/custom.cfg")
        fd, staged = tempfile.mkstemp(prefix=".minios-", dir=os.path.dirname(path))
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(original + entry)
                os.fchmod(stream.fileno(), os.stat(path).st_mode & 0o777 if os.path.exists(path) else 0o644)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(staged, path)
            if on_published:
                on_published()
        finally:
            if os.path.exists(staged):
                os.unlink(staged)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from dataclasses import dataclass, field

from typing import List, Optional


PLACEMENT_ERASE_ALL = "erase_all"
PLACEMENT_FREE_SPACE = "free_space"
PLACEMENT_ALONGSIDE_WINDOWS = "alongside_windows"
PLACEMENT_ALONGSIDE_OS = "alongside_os"
PLACEMENT_MANUAL = "manual"


@dataclass
class FreeExtent:
    start_mib: int
    end_mib: int

    @property
    def size_mib(self) -> int:
        return max(0, self.end_mib - self.start_mib)


@dataclass
class PartitionInfo:
    name: str
    path: str
    size_mib: int
    start_mib: int = 0
    end_mib: int = 0
    fstype: str = ""
    label: str = ""
    mountpoint: str = ""
    role: str = "unknown"
    flags: List[str] = field(default_factory=list)
    start_sector: int = 0
    size_sectors: int = 0
    partition_number: int = 0
    has_children: bool = False
    parttype: str = ""
    partuuid: str = ""


@dataclass
class DiskLayout:
    device: str
    size_mib: int
    model: str = ""
    serial: str = ""
    transport: str = ""
    partition_table: str = ""
    partitions: List[PartitionInfo] = field(default_factory=list)
    free_extents: List[FreeExtent] = field(default_factory=list)
    has_efi: bool = False
    has_windows: bool = False
    has_linux: bool = False
    logical_sector_size: int = 512
    size_sectors: int = 0
    geometry_complete: bool = True
    has_nested_layout: bool = False
    has_mapped_layout: bool = False


@dataclass
class PlannedPartition:
    action: str
    role: str
    start_mib: int
    end_mib: int
    fstype: str
    path: str = ""
    mountpoint: str = ""
    label: str = ""

    @property
    def size_mib(self) -> int:
        return max(0, self.end_mib - self.start_mib)


@dataclass
class ResizeOperation:
    path: str
    partition_number: int
    fstype: str
    start_sector: int
    old_size_sectors: int
    new_size_sectors: int
    sector_size: int


@dataclass
class PartitionPlan:
    device: str
    use_gpt: bool
    wipe_disk: bool
    partitions: List[PlannedPartition] = field(default_factory=list)
    reuse_esp: bool = False
    esp_path: str = ""
    resize: Optional[ResizeOperation] = None
    use_efi: bool = False
    # Immutable preserve-layout facts captured while planning and checked before
    # the first write, so a rescanned /dev node cannot redirect a plan.
    expected_partition_table: str = ""
    expected_partitions: List[tuple] = field(default_factory=list)
    expected_free_extent: Optional[tuple] = None
    esp_min_mib: int = 0
    esp_partuuid: str = ""
    boot_action: str = ""
    install_mode: str = ""
    firmware_order: tuple = ()
    grub_hook: tuple = ()
    live_label: str = ""
    sector_size: int = 512
    source_iso: str = ""
    source_identity: tuple = ()
    source_root: str = ""
    modules: tuple = ()
    directory_partuuid: str = ""
    directory_uuid: str = ""
    replace_directory: bool = False
    previous_directory: tuple = ()
    write_phase: str = field(default="none", compare=False, repr=False)

    def failure_note(self):
        from gettext import gettext as _
        if self.write_phase == "none":
            return _("Installation stopped before partition or boot changes.")
        if self.write_phase == "disk":
            return _("Partition or filesystem changes may already be present. The new boot entry was not activated.")
        return _("Boot setup started. Inspect the installation log before retrying; disk changes were not undone.")

    def bind_source(self, iso, modules):
        self.modules = tuple(modules or ())
        if iso:
            iso.check_target(self.device)
            self.source_iso = iso.path
            self.source_identity = iso.identity
            self.source_root = iso.mount

    def prepare_boot(self, mode):
        import gettext
        import subprocess
        from native_deploy import _efi_boot_order, _preflight_writable_efi_variables
        _ = gettext.gettext
        self.install_mode = mode
        if self.wipe_disk:
            self.boot_action = "initialize"
        elif not self.use_efi and not self.use_gpt:
            from grub_hook import inspect
            self.grub_hook = inspect(self)
            self.boot_action = "existing_grub"
        elif not self.use_efi or (mode == "live" and not self.use_gpt):
            raise RuntimeError(_("No verified path to preserve the existing BIOS loader. Select another disk or boot under UEFI."))
        elif self.reuse_esp:
            import re
            _preflight_writable_efi_variables()
            try:
                listing = subprocess.check_output(["efibootmgr", "-v"], universal_newlines=True)
            except (OSError, subprocess.CalledProcessError) as exc:
                raise RuntimeError(_("Cannot inspect the existing UEFI boot entries.")) from exc
            self.firmware_order = tuple(_efi_boot_order(listing))
            if (not self.firmware_order or len(set(self.firmware_order)) != len(self.firmware_order)
                    or any(not re.fullmatch(r"[0-9A-F]{4}", n) for n in self.firmware_order)):
                raise RuntimeError(_("Cannot identify the existing UEFI boot order."))
            self.boot_action = "append_efi"
        else:
            raise RuntimeError(_("Automatic installation alongside another OS requires an existing, unambiguous EFI system partition."))
        if mode == "live" and not self.wipe_disk and not self.directory_partuuid:
            import hashlib
            identity = repr((self.expected_partitions, self.root_partition())).encode("utf-8")
            self.live_label = "MOS" + hashlib.sha256(identity).hexdigest()[:8].upper()
            label_probe = subprocess.run(["blkid", "-c", "/dev/null", "-t", "LABEL=" + self.live_label, "-o", "device"],
                                         stdout=subprocess.PIPE)
            if label_probe.returncode != 2 or label_probe.stdout:
                raise RuntimeError(_("Cannot allocate a unique label for Live boot."))

    def require_approved(self, approved):
        if approved is not None and self != approved:
            import gettext
            raise RuntimeError(gettext.gettext("The installation plan changed. Review the disk and boot changes again."))

    def root_partition(self) -> Optional[PlannedPartition]:
        return next((p for p in self.partitions if p.role == "minios_root"), None)

    def esp_partition(self) -> Optional[PlannedPartition]:
        return next((p for p in self.partitions if p.role == "esp"), None)

    def summary_lines(self) -> List[str]:
        import gettext

        gettext.bindtextdomain("minios-installer", "/usr/share/locale")
        gettext.textdomain("minios-installer")
        _ = gettext.gettext

        lines = []
        table = "GPT" if self.use_gpt else "MBR"
        if self.wipe_disk:
            lines.append(
                _("Erase {device} and create a new {table} partition table").format(
                    device=self.device, table=table
                )
            )
        else:
            lines.append(
                _("Preserve existing partition table on {device}").format(device=self.device)
            )
        if self.resize:
            old_mib = self.resize.old_size_sectors * self.resize.sector_size // (1024 * 1024)
            new_mib = self.resize.new_size_sectors * self.resize.sector_size // (1024 * 1024)
            lines.append(
                _("Shrink {path} ({fstype}) from {old} MiB to {new} MiB").format(
                    path=self.resize.path,
                    fstype=self.resize.fstype,
                    old=old_mib,
                    new=new_mib,
                )
            )
        for part in self.partitions:
            if self.directory_partuuid and part.role == "minios_root":
                lines.append((_("Completely replace {part}:/minios, deleting all old sessions, modules and personal files.")
                              if self.previous_directory else _("Create {part}:/minios without formatting or resizing.")).format(part=part.path))
                continue
            if part.action == "reuse":
                lines.append(
                    _("Reuse {path} as {role}").format(path=part.path, role=part.role)
                )
            else:
                lines.append(
                    _(
                        "Create {role} {fstype} partition: {start}MiB-{end}MiB ({size}MiB)"
                    ).format(
                        role=part.role,
                        fstype=part.fstype,
                        start=part.start_mib,
                        end=part.end_mib,
                        size=part.size_mib,
                    )
                )
        if self.boot_action == "append_efi":
            lines.append(_("Boot: add MiniOS to the firmware menu on {esp}; preserve EFI/BOOT and the existing default (Boot{first}).").format(
                esp=self.esp_path, first=self.firmware_order[0]))
        elif self.boot_action == "existing_grub":
            lines.append(_("Boot: append MiniOS to the existing GRUB menu on {part}; preserve its default, MBR and active partition.").format(part=self.grub_hook[0]))
        return lines

"""Install a Live payload into an existing filesystem without partitioning it."""
import contextlib
import ctypes
import fcntl
import functools
import gettext
import json
import os
import re
import secrets
import shutil
import stat
import subprocess
import sysconfig
import tempfile
import time

from partition_models import PartitionPlan, PlannedPartition

_ = gettext.gettext
DATA_GUID = "ebd0a0a2-b9e5-4433-87c0-68b6b72699c7"
LINUX_GUID = "0fc63daf-8483-4772-8e79-3d69d8477de4"
_NOREPLACE_FILESYSTEMS = ("ext2", "ext3", "ext4", "vfat")
# Native ext2 and ntfs-3g lack exchange. VFAT may support exchange, but has
# no stable directory identity for revalidating approval after a remount.
_EXCHANGE_FILESYSTEMS = ("ext3", "ext4")
_AT_FDCWD = -100
_RENAME_NOREPLACE = 1
_RENAME_EXCHANGE = 2
_LIBC = ctypes.CDLL(None, use_errno=True)
_NTFS_RUNTIME = "/run/minios-installer-directory"
_NTFS_WORK = ".minios-ntfs-"
_NTFS_TOKEN = re.compile(r"[0-9a-f]{32}")


def _renameat2_function():
    if hasattr(_LIBC, "renameat2"):
        return _LIBC.renameat2
    # Ubuntu 18.04's glibc predates this wrapper; its Linux kernel still
    # implements the syscall. Select the userspace ABI, not uname's ISA.
    number = {"x86_64-linux-gnu": 316, "i386-linux-gnu": 353,
              "i686-linux-gnu": 353}.get(sysconfig.get_config_var("MULTIARCH"))
    return functools.partial(_LIBC.syscall, ctypes.c_long(number)) if number is not None else None


_RENAMEAT2 = _renameat2_function()


def candidates(layout):
    def unmounted_or_ntfs_recovery(p):
        # Only the recovery code, under the volume lock, may actually reuse
        # this private mount location. A desktop/Windows mount is not eligible.
        return not p.mountpoint or (p.fstype == "ntfs" and re.fullmatch(
            re.escape(_NTFS_RUNTIME) + r"/" + re.escape(p.partuuid.lower()) + r"_[0-9a-f-]+/data",
            p.mountpoint))

    return [p for p in layout.partitions if p.partuuid and not p.has_children and unmounted_or_ntfs_recovery(p)
            and p.role != "esp" and p.fstype in ("ntfs", "ext2", "ext3", "ext4", "vfat")
            and (layout.partition_table != "gpt" or p.parttype.lower() in (DATA_GUID, LINUX_GUID))]


def _unmount(root):
    # A desktop or device probe can briefly hold a newly mounted filesystem.
    # Wait for a regular unmount; a lazy detach would not finish a writable mount.
    command = ["umount", root]
    for delay in (0.1, 0.25, 0.5, 1.0, 2.0):
        result = subprocess.run(command, stderr=subprocess.PIPE)
        if result.returncode == 0:
            return
        if result.returncode != 32:  # umount(8): mount/unmount failure
            result.check_returncode()
        time.sleep(delay)
    subprocess.run(command, check=True)


@contextlib.contextmanager
def mounted(path, fs, write=False, private_parent=None):
    if subprocess.run(["findmnt", "-rn", "-S", path], stdout=subprocess.DEVNULL).returncode != 1:
        raise RuntimeError(_("The selected partition must be unmounted."))
    options = ["rw" if write else "ro", "nodev", "nosuid", "noexec"]
    if fs == "ntfs":
        subprocess.run(["ntfs-3g.probe", "--readwrite", path], check=True)
        fs = "ntfs-3g"
        options.extend(["norecover", "windows_names"])
    elif not write and fs in ("ext3", "ext4"):
        options.append("noload")
    work = private_parent or tempfile.mkdtemp(prefix="minios-directory-")
    # The mounted filesystem hides the permissions of the mountpoint itself.
    # Keep it under a private parent, out of reach of desktop processes.
    root = os.path.join(work, "data")
    active = False
    try:
        os.mkdir(root)
        subprocess.run(["mount", "-t", fs, "-o", ",".join(options), path, root], check=True)
        active = True
        yield root
    finally:
        if active:
            _unmount(root)
        if os.path.isdir(root):
            os.rmdir(root)
        if private_parent is None:
            os.rmdir(work)


def _directory_stamp(st):
    return (st.st_ino, st.st_mtime_ns, st.st_ctime_ns)


def existing(root, fs):
    path = os.path.join(root, "minios")
    matches = [name for name in os.listdir(root) if name.casefold() == "minios"]
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        if not matches:
            return ()
        st = None
    if matches != ["minios"]:
        raise RuntimeError(_("A conflicting name or alias for minios exists."))
    if st is None or not stat.S_ISDIR(st.st_mode) or os.path.ismount(path):
        raise RuntimeError(_("The existing minios path is not a regular directory."))
    # On VFAT only presence matters: neither synthetic inodes nor FAT times
    # establish that the tree still matches the one seen at approval.
    return (True,) if fs == "vfat" else _directory_stamp(st)


def supports_directory_replacement(fs):
    return fs == "ntfs" or (fs in _EXCHANGE_FILESYSTEMS and _RENAMEAT2 is not None)


def _require_replacement(fs):
    if not supports_directory_replacement(fs):
        raise ValueError(_("This filesystem does not support atomic replacement of minios. A new directory installation requires minios to be absent."))


def _rename(source, target, flags):
    if _RENAMEAT2(_AT_FDCWD, os.fsencode(source), _AT_FDCWD, os.fsencode(target), flags):
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error), source, None, target)


def _probe_exchange(root, work):
    # Probe nonempty directories in the actual source and destination parents
    # (notably the special root directory on FAT12/16), without touching minios.
    with contextlib.ExitStack() as probes:
        left = probes.enter_context(tempfile.TemporaryDirectory(prefix=".minios-exchange-", dir=root))
        right = probes.enter_context(tempfile.TemporaryDirectory(prefix=".exchange-", dir=work))
        os.mkdir(os.path.join(left, "first"))
        os.mkdir(os.path.join(right, "second"))
        try:
            _rename(left, right, _RENAME_EXCHANGE)
        except OSError as exc:
            raise RuntimeError(_("Cannot verify atomic replacement of minios on the selected filesystem.")) from exc
        if os.listdir(left) != ["second"] or os.listdir(right) != ["first"]:
            raise RuntimeError(_("Cannot verify atomic replacement of minios on the selected filesystem."))


def _sync_filesystem(fd):
    if _LIBC.syncfs(fd):
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))


def _inode(st):
    return (st.st_dev, st.st_ino)


def _directory_inode(path):
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return None
    return _inode(st) if stat.S_ISDIR(st.st_mode) else ()


def _private_directory(path):
    try:
        os.mkdir(path, 0o700)
    except FileExistsError:
        pass
    st = os.lstat(path)
    if not stat.S_ISDIR(st.st_mode) or st.st_uid != os.geteuid() or stat.S_IMODE(st.st_mode) != 0o700:
        raise RuntimeError(_("The installer recovery directory is not private."))


def _clear_ntfs_mount(runtime, device):
    root = os.path.join(runtime, "data")
    result = subprocess.run(["findmnt", "-rn", "-M", root, "-o", "FSTYPE,SOURCE"],
                            stdout=subprocess.PIPE, check=False, universal_newlines=True)
    if result.returncode not in (0, 1):
        result.check_returncode()
    if result.returncode == 0:
        info = result.stdout.split()
        if len(info) != 2 or info[0] != "fuseblk" or os.path.realpath(info[1]) != os.path.realpath(device):
            raise RuntimeError(_("The installer recovery mount does not match the selected NTFS partition."))
        _unmount(root)
    if os.path.lexists(root):
        # The only valid unmounted mountpoint is an empty installer directory.
        if not stat.S_ISDIR(os.lstat(root).st_mode):
            raise RuntimeError(_("The installer recovery mountpoint is not a directory."))
        os.rmdir(root)


def _ntfs_name(path):
    """Reject aliases, reparse points and case collisions at protocol names."""
    parent, name = os.path.split(path)
    matches = [entry for entry in os.listdir(parent) if entry.casefold() == name.casefold()]
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        if not matches:
            return None
        raise
    if matches != [name] or not stat.S_ISDIR(st.st_mode) or os.path.ismount(path):
        raise RuntimeError(_("A conflicting or non-directory entry exists at an NTFS recovery path."))
    attributes = os.getxattr(path, "system.ntfs_attrib", follow_symlinks=False)
    if len(attributes) != 4 or int.from_bytes(attributes, "little") & 0x400:  # FILE_ATTRIBUTE_REPARSE_POINT
        raise RuntimeError(_("A conflicting or non-directory entry exists at an NTFS recovery path."))
    return st


def _ntfs_identity(path, contents=True):
    st = _ntfs_name(path)
    if st is None:
        return None
    times = os.getxattr(path, "system.ntfs_times", follow_symlinks=False)
    if len(times) != 32:
        raise RuntimeError(_("Cannot determine the identity of the NTFS directory."))
    # A rename changes ctime, and ntfs-3g can report a different size after
    # remounting. The MFT record number and creation time survive both.
    return [st.st_ino, times[:8].hex()] + ([st.st_mtime_ns] if contents else [])


def _read_ntfs_intent(journal):
    try:
        with open(journal, encoding="ascii") as handle:
            intent = json.loads(handle.read(4096))
    except FileNotFoundError:
        return None
    except ValueError as exc:
        raise RuntimeError(_("The NTFS recovery record is invalid. No data was changed.")) from exc

    def identity(value, size):
        return (isinstance(value, list) and len(value) == size and type(value[0]) is int and value[0] > 0
                and isinstance(value[1], str) and re.fullmatch(r"[0-9a-f]{16}", value[1])
                and (size == 2 or type(value[2]) is int))

    if (not isinstance(intent, dict) or set(intent) != {"token", "work", "old", "new"}
            or not isinstance(intent["token"], str) or not _NTFS_TOKEN.fullmatch(intent["token"])
            or not identity(intent["work"], 2) or not identity(intent["old"], 3)
            or not identity(intent["new"], 3)
            or len({intent[key][0] for key in ("work", "old", "new")}) != 3):
        raise RuntimeError(_("The NTFS recovery record is invalid. No data was changed."))
    return intent


def _save_ntfs_intent(journal, intent):
    fd, pending = tempfile.mkstemp(prefix="intent-", dir=os.path.dirname(journal))
    try:
        with os.fdopen(fd, "w", encoding="ascii") as handle:
            json.dump(intent, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(pending, journal)
    finally:
        if os.path.lexists(pending):
            os.unlink(pending)


def _ntfs_move(source, dest):
    if _ntfs_name(dest) is not None:
        raise RuntimeError(_("An NTFS recovery path is already occupied. No existing entry was overwritten."))
    # FUSE has no RENAME_NOREPLACE. This is run under the volume lock with the
    # filesystem mounted only in a root-private directory. Never replace a name.
    os.rename(source, dest)


def _ntfs_state(root, intent):
    work = os.path.join(root, _NTFS_WORK + intent["token"])
    if _ntfs_identity(work, contents=False) != intent["work"]:
        raise RuntimeError(_("The NTFS staging directory does not match the recovery record."))
    return (_ntfs_identity(os.path.join(root, "minios")),
            _ntfs_identity(os.path.join(work, "previous")),
            _ntfs_identity(os.path.join(work, "new")))


def _ntfs_states(intent):
    return ((intent["old"], None, intent["new"]),
            (None, intent["old"], intent["new"]),
            (intent["new"], intent["old"], None))


def _finish_ntfs(root, root_fd, intent, rollback):
    before, gap, after = _ntfs_states(intent)
    work = os.path.join(root, _NTFS_WORK + intent["token"])
    target, backup, staged = (os.path.join(root, "minios"), os.path.join(work, "previous"),
                              os.path.join(work, "new"))
    state = _ntfs_state(root, intent)
    if rollback and state == after:
        _ntfs_move(target, staged)
        _sync_filesystem(root_fd)
        state = _ntfs_state(root, intent)
    if rollback is not False and state == gap:
        _ntfs_move(backup, target)
        _sync_filesystem(root_fd)
        state = _ntfs_state(root, intent)
    # Recovery (rollback=None) never withdraws a canonical new tree: the
    # process may have died just after publishing the external bootloader.
    allowed = (before, after) if rollback is None else ((before,) if rollback else (after,))
    if state not in allowed:
        raise RuntimeError(_("The NTFS replacement state is ambiguous. Inspect {directory}; no staging data was removed.")
                           .format(directory=os.path.basename(work)))
    _sync_filesystem(root_fd)


@contextlib.contextmanager
def _directory_mount(device, fs, fs_uuid, partuuid, write=False):
    if fs != "ntfs":
        with mounted(device, fs, write=write) as root:
            yield root, None
        return

    def directory_id(value):
        if not re.fullmatch(r"[0-9A-Za-z-]{1,128}", value):
            raise RuntimeError(_("Unsupported partition identifier for NTFS recovery."))
        return value.lower()

    _private_directory(_NTFS_RUNTIME)
    runtime = os.path.join(_NTFS_RUNTIME, directory_id(partuuid) + "_" + directory_id(fs_uuid))
    _private_directory(runtime)
    journal = os.path.join(runtime, "intent.json")
    fd = os.open(os.path.join(runtime, "lock"), os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "rb") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError(_("Another installer is using the selected NTFS partition.")) from exc
        _clear_ntfs_mount(runtime, device)
        intent = _read_ntfs_intent(journal)
        if intent is not None:
            from native_deploy import _blkid_value, _unique_fs_uuid
            if _blkid_value(device, "PARTUUID") != partuuid or _unique_fs_uuid(device) != fs_uuid:
                raise RuntimeError(_("The selected partition changed before NTFS recovery."))
            with mounted(device, fs, write=True, private_parent=runtime) as root:
                root_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                try:
                    _finish_ntfs(root, root_fd, intent, rollback=None)
                finally:
                    os.close(root_fd)
            os.unlink(journal)
        with mounted(device, fs, write=write, private_parent=runtime) as root:
            if not existing(root, fs) and any(
                    name.casefold().startswith(_NTFS_WORK) and _NTFS_TOKEN.fullmatch(name[len(_NTFS_WORK):].casefold())
                    for name in os.listdir(root)):
                raise RuntimeError(_("NTFS is missing minios and has unverified replacement staging. No data was changed; inspect it manually."))
            yield root, journal


def plan_directory(layout, partition, replace, required_mib, mode, boot_layout):
    from native_deploy import _unique_fs_uuid
    from partition_planner import _existing_esp, _use_efi_for_layout
    if mode != "live" or not partition or layout.has_mapped_layout or layout.has_nested_layout:
        raise ValueError(_("Select a direct data partition for Live directory installation."))
    targets = [p for p in candidates(layout) if p.partuuid.lower() == partition.lower()]
    if len(targets) != 1:
        raise ValueError(_("The specified data PARTUUID does not uniquely identify a supported partition on this disk."))
    data = targets[0]
    efi = _use_efi_for_layout(boot_layout)
    esp = _existing_esp(layout, efi)
    plan = PartitionPlan(layout.device, layout.partition_table == "gpt", False,
                         use_efi=efi, sector_size=layout.logical_sector_size)
    plan.directory_partuuid = data.partuuid
    plan.replace_directory = replace
    plan.directory_uuid = _unique_fs_uuid(data.path)
    if not re.fullmatch(r"[0-9a-fA-F-]+", plan.directory_uuid):
        raise ValueError(_("Unsupported filesystem UUID."))
    plan.expected_partition_table = layout.partition_table
    plan.expected_partitions = [(p.partition_number, p.start_sector, p.size_sectors, p.parttype, p.partuuid)
                                for p in layout.partitions]
    plan.partitions.append(PlannedPartition("reuse", "minios_root", data.start_mib, data.end_mib, data.fstype, data.path))
    if esp:
        plan.reuse_esp, plan.esp_path, plan.esp_partuuid = True, esp.path, esp.partuuid
        plan.partitions.append(PlannedPartition("reuse", "esp", esp.start_mib, esp.end_mib, esp.fstype, esp.path))
    with _directory_mount(data.path, data.fstype, plan.directory_uuid, plan.directory_partuuid) as (root, _journal):
        plan.previous_directory = existing(root, data.fstype)
        if plan.previous_directory and not replace:
            raise ValueError(_("The minios directory already exists. Full replacement deletes its sessions, modules and personal files."))
        if plan.previous_directory:
            _require_replacement(data.fstype)
        if shutil.disk_usage(root).free < required_mib * 1024**2:
            raise ValueError(_("Not enough free space to stage the new installation while retaining the old directory."))
    return plan


@contextlib.contextmanager
def destination(plan):
    """Yield staging path, payload publication, and boot-commit callbacks.

    Call commit immediately after successful boot-loader publication. Until
    then, a handled failure restores the old tree. On process death, an
    exchange retains both trees, or the trusted NTFS intent repairs the gap
    before the next plan. Recovery never deletes staging and this is not an
    atomic transaction with the bootloader or a power-loss guarantee.
    """
    from native_deploy import _blkid_value, _unique_fs_uuid
    from partition_executor import _revalidate_preserve_plan, _verify_existing_partition
    data = plan.root_partition()
    _revalidate_preserve_plan(plan)
    _verify_existing_partition(plan, data.path, data.fstype)
    if _blkid_value(data.path, "PARTUUID") != plan.directory_partuuid or _unique_fs_uuid(data.path) != plan.directory_uuid:
        raise RuntimeError(_("The selected data partition changed."))
    fs = data.fstype
    if fs == "vfat" and plan.previous_directory and plan.replace_directory:
        # Also reject a stale/constructed replacement plan before a RW mount.
        _require_replacement(fs)
    with _directory_mount(data.path, fs, plan.directory_uuid, plan.directory_partuuid, write=True) as location, \
         contextlib.ExitStack() as fds:
        root, journal = location
        old = existing(root, fs)
        if old != plan.previous_directory or (old and not plan.replace_directory):
            raise RuntimeError(_("The existing minios directory changed. Review the plan again."))
        if old:
            _require_replacement(fs)

        def pin(path):
            fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            fds.callback(os.close, fd)
            return fd

        target = os.path.join(root, "minios")
        root_fd = pin(root)
        old_st = os.fstat(pin(target)) if old else None
        if old_st is not None and _directory_stamp(old_st) != old:
            raise RuntimeError(_("The existing minios directory changed. Review the plan again."))
        old_inode = _inode(old_st) if old_st is not None else None
        ntfs_replace = bool(journal and old)
        if ntfs_replace:
            token = secrets.token_hex(16)
            work = os.path.join(root, _NTFS_WORK + token)
            os.mkdir(work, 0o700)
        else:
            work = tempfile.mkdtemp(prefix=".minios-install-", dir=root)
        work_inode = _inode(os.fstat(pin(work)))
        staged = os.path.join(work, "new")
        backup = os.path.join(work, "previous")
        intent = None
        new_inode = None
        attempted = False
        published = False
        committed = False

        def names():
            return (_directory_inode(target), _directory_inode(staged))

        def move(source, dest):
            if old:
                _rename(source, dest, _RENAME_EXCHANGE)
            elif fs in _NOREPLACE_FILESYSTEMS and _RENAMEAT2 is not None:
                _rename(source, dest, _RENAME_NOREPLACE)
            else:
                # ntfs-3g lacks renameat2 flags. On a private mount a plain
                # rename to a checked missing name suffices for creation only.
                if _directory_inode(dest) is not None:
                    raise RuntimeError(_("The destination changed during copying."))
                os.rename(source, dest)

        def require_owned_work():
            if _directory_inode(work) != work_inode:
                raise RuntimeError(_("The installation staging directory changed. No staging data was removed."))

        def publish():
            nonlocal new_inode, attempted, published, intent
            if new_inode is not None:
                raise RuntimeError(_("The directory publication was already attempted."))
            require_owned_work()
            new_inode = _inode(os.fstat(pin(staged)))
            _sync_filesystem(root_fd)
            if existing(root, fs) != old or names() != (old_inode, new_inode):
                raise RuntimeError(_("The destination changed during copying."))
            if ntfs_replace:
                intent = {"token": token, "work": _ntfs_identity(work, contents=False),
                          "old": _ntfs_identity(target), "new": _ntfs_identity(staged)}
                before, gap, after = _ntfs_states(intent)
                if _ntfs_state(root, intent) != before:
                    raise RuntimeError(_("The destination changed during copying."))
                # Commit the trusted intent before making the canonical name
                # temporarily absent. No on-volume record authorizes replay.
                _save_ntfs_intent(journal, intent)
                _ntfs_move(target, backup)
                if _ntfs_state(root, intent) != gap:
                    raise RuntimeError(_("Cannot verify the retained minios directory."))
                _sync_filesystem(root_fd)
                _ntfs_move(staged, target)
                if _ntfs_state(root, intent) != after:
                    raise RuntimeError(_("Cannot verify the published minios directory."))
            else:
                attempted = True
                move(staged, target)
                if names() != (new_inode, old_inode):
                    raise RuntimeError(_("Cannot verify the published minios directory."))
            _sync_filesystem(root_fd)
            published = True

        def commit():
            nonlocal committed
            if not published:
                raise RuntimeError(_("The minios directory was not published."))
            committed = True

        try:
            if old and not ntfs_replace:
                _probe_exchange(root, work)
            yield work, publish, commit
            if not committed:
                raise RuntimeError(_("The directory installation was not committed."))
        finally:
            require_owned_work()
            if intent is not None:
                _finish_ntfs(root, root_fd, intent, rollback=not committed)
                # Retire when the canonical tree is safe, before deleting
                # anything. A kill during cleanup cannot leave a stale intent.
                with contextlib.suppress(FileNotFoundError):
                    os.unlink(journal)
            elif attempted:
                before, after = (old_inode, new_inode), (new_inode, old_inode)
                # Check the actual result in case an exception arrived between
                # the rename syscall and its return to the caller.
                if not committed and names() == after:
                    move(target, staged)
                    _sync_filesystem(root_fd)
                if names() != (after if committed else before):
                    raise RuntimeError(_("The minios directory state is ambiguous. No staging data was removed from {directory}.")
                                       .format(directory=os.path.basename(work)))
            # Only this invocation's staging area can be cleaned. Before boot
            # commit the old tree must be back in place; afterwards the newly
            # published tree must still be at the canonical path.
            shutil.rmtree(work)

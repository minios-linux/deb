"""Read-only, pinned ISO source for Live installation."""
import gettext
import os
import stat
import subprocess
import tempfile

from module_selection import list_live_module_names

_ = gettext.gettext


class LiveISO:
    def __init__(self, filename):
        self.path = os.path.realpath(filename)
        self.stream = open(self.path, "rb")
        self.mount = None
        self.mounted = False
        try:
            if not stat.S_ISREG(os.fstat(self.stream.fileno()).st_mode):
                raise ValueError(_("Choose a regular ISO image."))
            self.mount = tempfile.mkdtemp(prefix="minios-iso-")
            fd = self.stream.fileno()
            subprocess.run(["mount", "-t", "iso9660", "-o", "loop,ro,nodev,nosuid,noexec",
                            "/proc/self/fd/{}".format(fd), self.mount],
                           pass_fds=(fd,), check=True)
            self.mounted = True
            self.source = os.path.join(self.mount, "minios")
            for root, dirs, files in os.walk(self.mount):
                for name in dirs + files:
                    path = os.path.join(root, name)
                    if (os.path.commonpath((self.mount, os.path.realpath(path))) != self.mount
                            or not (os.path.isdir(path) or os.path.isfile(path))):
                        raise ValueError(_("The ISO contains an unsupported link or special file."))
            if not list_live_module_names(self.source) or not os.path.isdir(os.path.join(self.source, "boot")):
                raise ValueError(_("The ISO does not contain a MiniOS Live system."))
            boot = os.listdir(os.path.join(self.source, "boot"))
            if not any(n.startswith("vmlinuz") for n in boot) or not any(n.startswith(("initrfs", "initrd")) for n in boot):
                raise ValueError(_("The ISO has no MiniOS kernel or initramfs."))
            self.identity = self._identity()
        except BaseException:
            self.close()
            raise

    def _identity(self):
        st = os.fstat(self.stream.fileno())
        return st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns

    def check_target(self, disk):
        if self._identity() != self.identity:
            raise ValueError(_("The selected ISO changed. Select it again."))
        dev = self.identity[0]
        backing = "/dev/block/{}:{}".format(os.major(dev), os.minor(dev))
        if not os.path.exists(backing):
            raise ValueError(_("Cannot identify the disk containing the ISO. Use an ISO on a separate local disk."))
        rows = subprocess.check_output(["lsblk", "-snrpo", "NAME,TYPE", os.path.realpath(backing)],
                                       universal_newlines=True).splitlines()
        disks = [row.split()[0] for row in rows if row.endswith(" disk")]
        if not disks or os.path.realpath(disk) in map(os.path.realpath, disks):
            raise ValueError(_("The ISO must be on a different identifiable physical disk."))

    def close(self):
        if self.mounted:
            subprocess.run(["umount", self.mount], check=True)
            self.mounted = False
        if self.mount:
            os.rmdir(self.mount)
            self.mount = None
        self.stream.close()

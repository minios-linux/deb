#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Post-install chroot configuration for native installations.
"""

import os
import subprocess
from typing import Callable, List, Optional

from install_state import InstallState, UserConfig


LIVE_ONLY_PACKAGES: List[str] = [
    "minios-live-config",
    "minios-live-config-systemd",
    "minios-live-config-doc",
    "minios-live-config-sysvinit",
    "minios-installer",
    "minios-configurator",
    "minios-session-manager",
    "minios-kernel-manager",
    "minios-tools",
]

LIVE_ARTIFACT_PATHS = [
    "/etc/live",
    "/etc/live/config.conf",
    "/usr/share/polkit-1/actions/org.minios.installer.policy",
    "/usr/share/polkit-1/actions/org.minios.configurator.policy",
]


def _chroot_run(target: str, *args: str, check: bool = True) -> subprocess.CompletedProcess:
    cmd = ["chroot", target] + list(args)
    return subprocess.run(cmd, check=check, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)


def write_fstab(target: str, root_uuid: str, esp_uuid: Optional[str] = None) -> None:
    lines = [
        f"UUID={root_uuid}  /  ext4  defaults  0  1\n",
        "proc  /proc  proc  defaults  0  0\n",
    ]
    if esp_uuid:
        lines.insert(1, f"UUID={esp_uuid}  /boot/efi  vfat  umask=0077  0  1\n")
    with open(os.path.join(target, "etc/fstab"), "w", encoding="utf-8") as fh:
        fh.writelines(lines)


def write_user_config(target: str, user: UserConfig, log_cb: Callable[[str], None]) -> None:
    if user.hostname:
        with open(os.path.join(target, "etc/hostname"), "w", encoding="utf-8") as fh:
            fh.write(user.hostname + "\n")
    if user.locale:
        locale_path = os.path.join(target, "etc/default/locale")
        os.makedirs(os.path.dirname(locale_path), exist_ok=True)
        with open(locale_path, "w", encoding="utf-8") as fh:
            fh.write(f'LANG="{user.locale}"\n')
    if user.timezone and os.path.isdir(os.path.join(target, "usr/share/zoneinfo")):
        tz_link = os.path.join(target, "etc/localtime")
        if os.path.lexists(tz_link):
            os.remove(tz_link)
        zone_src = os.path.join(target, "usr/share/zoneinfo", user.timezone)
        if os.path.exists(zone_src):
            os.symlink(f"/usr/share/zoneinfo/{user.timezone}", tz_link)
    if user.username and user.password:
        log_cb(f"Creating user {user.username}...")
        _chroot_run(target, "useradd", "-m", "-s", "/bin/bash", user.username, check=False)
        proc = subprocess.run(
            ["chroot", target, "bash", "-c", f"echo '{user.username}:{user.password}' | chpasswd"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
        )
        if proc.returncode != 0:
            log_cb(f"Warning: could not set password for {user.username}")


def install_kernel_offline(target: str, log_cb: Callable[[str], None]) -> None:
    """Copy kernel to /boot and register in dpkg without network."""
    boot_dir = os.path.join(target, "boot")
    os.makedirs(boot_dir, exist_ok=True)

    kernel_candidates = []
    for search in (
        os.path.join(target, "minios", "boot"),
        "/run/initramfs/memory/data/minios/boot",
        "/lib/live/mount/medium/minios/boot",
    ):
        if os.path.isdir(search):
            for name in os.listdir(search):
                if name.startswith("vmlinuz-"):
                    kernel_candidates.append(os.path.join(search, name))

    if not kernel_candidates:
        log_cb("Warning: no kernel found for native install.")
        return

    src_vmlinuz = kernel_candidates[0]
    version = os.path.basename(src_vmlinuz).replace("vmlinuz-", "")
    dst_vmlinuz = os.path.join(boot_dir, os.path.basename(src_vmlinuz))
    if src_vmlinuz != dst_vmlinuz:
        subprocess.run(["cp", "-a", src_vmlinuz, dst_vmlinuz], check=True)

    initrd_names = [f"initrfs-{version}.img", f"initrd.img-{version}"]
    for base in (os.path.dirname(src_vmlinuz),):
        for initrd_name in initrd_names:
            src_initrd = os.path.join(base, initrd_name)
            if os.path.exists(src_initrd):
                subprocess.run(["cp", "-a", src_initrd, os.path.join(boot_dir, initrd_name)], check=True)
                break

    deb_dirs = [
        "/usr/share/minios-installer/kernel",
        os.path.join(target, "usr/share/minios-installer/kernel"),
    ]
    for deb_dir in deb_dirs:
        if not os.path.isdir(deb_dir):
            continue
        for name in os.listdir(deb_dir):
            if name.endswith(".deb") and "linux-image" in name:
                host_deb = os.path.join(deb_dir, name)
                target_deb = os.path.join(target, "tmp", name)
                os.makedirs(os.path.dirname(target_deb), exist_ok=True)
                subprocess.run(["cp", host_deb, target_deb], check=True)
                log_cb(f"Installing kernel package offline: {name}")
                _chroot_run(target, "dpkg", "-i", f"/tmp/{name}")
                return

    log_cb("No offline kernel .deb found; kernel files copied to /boot only.")


def purge_live_packages(target: str, log_cb: Callable[[str], None]) -> None:
    log_cb("Removing live-only packages...")
    pkg_list = " ".join(LIVE_ONLY_PACKAGES)
    _chroot_run(
        target,
        "bash", "-c",
        f"DEBIAN_FRONTEND=noninteractive apt-get purge -y {pkg_list} || true; "
        f"DEBIAN_FRONTEND=noninteractive apt-get autoremove -y || true",
        check=False,
    )
    for rel_path in LIVE_ARTIFACT_PATHS:
        full = os.path.join(target, rel_path.lstrip("/"))
        if os.path.isdir(full):
            subprocess.run(["rm", "-rf", full], check=False)
        elif os.path.isfile(full):
            os.remove(full)

    minios_dir = os.path.join(target, "minios")
    if os.path.isdir(minios_dir):
        log_cb("Removing live minios/ directory from native root...")
        subprocess.run(["rm", "-rf", minios_dir], check=False)


def setup_grub(target: str, device: str, efi_mount: Optional[str], log_cb: Callable[[str], None]) -> None:
    log_cb("Installing GRUB...")
    if efi_mount and os.path.isdir(os.path.join(target, "boot/efi")):
        _chroot_run(target, "grub-install", "--target=x86_64-efi", "--efi-directory=/boot/efi", "--bootloader-id=MiniOS", check=False)
    else:
        _chroot_run(target, "grub-install", device, check=False)
    _chroot_run(target, "update-grub", check=False)


def run_chroot_setup(
    target_mount: str,
    state: InstallState,
    device: str,
    esp_mount: Optional[str],
    log_cb: Callable[[str], None],
) -> None:
    proc = subprocess.run(
        ["findmnt", "-n", "-o", "SOURCE", target_mount],
        stdout=subprocess.PIPE,
        universal_newlines=True,
        check=True,
    )
    root_part = proc.stdout.strip()
    root_uuid = subprocess.check_output(
        ["blkid", "-s", "UUID", "-o", "value", root_part],
        universal_newlines=True,
    ).strip()

    esp_uuid = None
    if esp_mount:
        esp_src = subprocess.check_output(
            ["findmnt", "-n", "-o", "SOURCE", esp_mount],
            stdout=subprocess.PIPE,
            universal_newlines=True,
        ).strip()
        esp_uuid = subprocess.check_output(
            ["blkid", "-s", "UUID", "-o", "value", esp_src],
            universal_newlines=True,
        ).strip()

    write_fstab(target_mount, root_uuid, esp_uuid)
    write_user_config(target_mount, state.user_config, log_cb)
    install_kernel_offline(target_mount, log_cb)
    purge_live_packages(target_mount, log_cb)
    _chroot_run(target_mount, "update-initramfs", "-u", "-k", "all", check=False)
    setup_grub(target_mount, state.target_device or device, esp_mount, log_cb)
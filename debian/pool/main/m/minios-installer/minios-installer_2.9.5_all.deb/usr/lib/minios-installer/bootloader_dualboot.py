#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bootloader installation for live and native installs with dual-boot support.
"""

import os
import subprocess
from typing import Callable, Optional

from bootloader_utils import install_bootloader
from install_state import InstallState
from partition_models import PartitionPlan


def install_bootloader_for_plan(
    state: InstallState,
    plan: PartitionPlan,
    root_part: str,
    esp_part: Optional[str],
    root_mount: str,
    esp_mount: Optional[str],
    progress_cb: Callable[[int, str], None],
    log_cb: Callable[[str], None],
) -> None:
    device = state.target_device
    fs = state.filesystem

    if state.is_native():
        _install_native_grub(device, esp_mount, root_mount, log_cb)
        return

    if plan.reuse_esp and esp_mount:
        log_cb("Dual-boot UEFI: reusing existing ESP...")
        _install_grub_efi_chroot(root_mount, esp_mount, log_cb)
        return

    if not plan.use_gpt and fs != "exfat":
        install_bootloader(device, root_part, esp_part, progress_cb, log_cb)
    elif plan.use_gpt and esp_mount:
        _install_grub_efi_chroot(root_mount, esp_mount, log_cb)


def _install_grub_efi_chroot(root_mount: str, esp_mount: str, log_cb: Callable[[str], None]) -> None:
    efi_target = os.path.join(root_mount, "boot/efi")
    os.makedirs(efi_target, exist_ok=True)
    subprocess.run(["mount", "--bind", esp_mount, efi_target], check=True)
    try:
        subprocess.run(
            ["chroot", root_mount, "grub-install", "--target=x86_64-efi", "--efi-directory=/boot/efi", "--bootloader-id=MiniOS", "--recheck"],
            check=False,
        )
        subprocess.run(["chroot", root_mount, "update-grub"], check=False)
        log_cb("GRUB EFI installed on shared ESP.")
    finally:
        subprocess.run(["umount", efi_target], check=False)


def _install_native_grub(device: str, esp_mount: Optional[str], root_mount: str, log_cb: Callable[[str], None]) -> None:
    if esp_mount:
        _install_grub_efi_chroot(root_mount, esp_mount, log_cb)
    else:
        subprocess.run(["chroot", root_mount, "grub-install", device], check=False)
        subprocess.run(["chroot", root_mount, "update-grub"], check=False)
        log_cb("GRUB BIOS installed.")
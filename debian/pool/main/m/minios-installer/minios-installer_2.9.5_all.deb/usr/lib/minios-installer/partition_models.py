#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Data models for disk layout and partition plans.
"""

from dataclasses import dataclass, field
from typing import List, Optional


PARTITION_ROLES = (
    "minios_root",
    "esp",
    "swap",
    "windows",
    "linux_other",
    "free",
    "data",
    "unknown",
)

PLACEMENT_ERASE_ALL = "erase_all"
PLACEMENT_ALONGSIDE_WINDOWS = "alongside_windows"
PLACEMENT_ALONGSIDE_OS = "alongside_os"
PLACEMENT_FREE_SPACE = "free_space"
PLACEMENT_MANUAL = "manual"


@dataclass
class PartitionInfo:
    name: str
    path: str
    size_bytes: int
    fstype: str = ""
    label: str = ""
    mountpoint: str = ""
    role: str = "unknown"
    os_name: str = ""
    start_bytes: int = 0
    end_bytes: int = 0
    number: int = 0
    flags: List[str] = field(default_factory=list)
    preserve: bool = False

    @property
    def size_mib(self) -> int:
        return max(1, self.size_bytes // (1024 * 1024))


@dataclass
class DiskLayout:
    device: str
    size_bytes: int
    model: str = ""
    serial: str = ""
    transport: str = ""
    partition_table: str = ""
    partitions: List[PartitionInfo] = field(default_factory=list)
    has_efi: bool = False
    has_windows: bool = False
    has_linux: bool = False
    free_bytes: int = 0

    @property
    def size_mib(self) -> int:
        return max(1, self.size_bytes // (1024 * 1024))


@dataclass
class PlannedPartition:
    role: str
    size_mib: int
    fstype: str
    mountpoint: str = ""
    preserve: bool = False
    source_path: str = ""
    label: str = ""


@dataclass
class PartitionPlan:
    device: str
    use_gpt: bool
    wipe_disk: bool
    reuse_esp: bool = False
    esp_path: str = ""
    partitions: List[PlannedPartition] = field(default_factory=list)
    shrink_paths: List[str] = field(default_factory=list)
    shrink_mib: int = 0

    def root_partition(self) -> Optional[PlannedPartition]:
        for part in self.partitions:
            if part.role == "minios_root":
                return part
        return None

    def esp_partition(self) -> Optional[PlannedPartition]:
        for part in self.partitions:
            if part.role == "esp":
                return part
        return None
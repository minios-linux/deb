#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Disk and partition discovery via lsblk.
"""

import json
import os
import subprocess
from typing import Dict, List, Optional

from partition_models import DiskLayout, PartitionInfo


def is_uefi_system() -> bool:
    return os.path.isdir("/sys/firmware/efi")


def _run_lsblk(device: Optional[str] = None) -> List[Dict]:
    cmd = [
        "lsblk", "-J", "-b", "-o",
        "NAME,SIZE,TYPE,FSTYPE,LABEL,MOUNTPOINT,PKNAME,MODEL,SERIAL,TRAN,PTTYPE,START",
    ]
    if device:
        cmd.append(device)
    output = subprocess.check_output(cmd, universal_newlines=True)
    data = json.loads(output)
    return data.get("blockdevices", [])


def _detect_role(part: Dict, mountpoint: str, fstype: str, label: str) -> str:
    mp = (mountpoint or "").lower()
    fs = (fstype or "").lower()
    lbl = (label or "").lower()

    if part.get("type") == "part":
        if fs == "vfat" or "efi" in lbl or mp == "/boot/efi":
            return "esp"
        if fs in ("ntfs", "exfat") or "windows" in lbl:
            return "windows"
        if fs in ("ext4", "ext3", "ext2", "btrfs", "xfs") and (
            mp == "/" or "linux" in lbl or fs == "btrfs"
        ):
            return "linux_other"
        if fs == "swap":
            return "swap"
    return "unknown"


def _os_name_for_role(role: str, fstype: str, label: str) -> str:
    if role == "windows":
        return "Windows"
    if role == "linux_other":
        return label or "Linux"
    if role == "esp":
        return "EFI System"
    if role == "swap":
        return "Swap"
    return ""


def scan_disk(device: str) -> DiskLayout:
    if not device.startswith("/dev/"):
        device = f"/dev/{device}"

    disks = _run_lsblk(device)
    if not disks:
        raise RuntimeError(f"Device not found: {device}")

    disk = disks[0]
    children = disk.get("children") or []

    partitions: List[PartitionInfo] = []
    has_efi = False
    has_windows = False
    has_linux = False
    allocated = 0

    for child in children:
        if child.get("type") != "part":
            continue
        path = f"/dev/{child['name']}"
        size = int(child.get("size") or 0)
        fstype = child.get("fstype") or ""
        label = child.get("label") or ""
        mountpoint = child.get("mountpoint") or ""
        role = _detect_role(child, mountpoint, fstype, label)
        if role == "esp":
            has_efi = True
        if role == "windows":
            has_windows = True
        if role == "linux_other":
            has_linux = True
        allocated += size
        partitions.append(
            PartitionInfo(
                name=child["name"],
                path=path,
                size_bytes=size,
                fstype=fstype,
                label=label,
                mountpoint=mountpoint,
                role=role,
                os_name=_os_name_for_role(role, fstype, label),
                start_bytes=int(child.get("start") or 0) * 512,
                preserve=role in ("windows", "linux_other", "esp"),
            )
        )

    disk_size = int(disk.get("size") or 0)
    free_bytes = max(0, disk_size - allocated)

    return DiskLayout(
        device=device,
        size_bytes=disk_size,
        model=(disk.get("model") or "").strip(),
        serial=(disk.get("serial") or "").strip(),
        transport=(disk.get("tran") or "").strip(),
        partition_table=(disk.get("pttype") or "").lower(),
        partitions=partitions,
        has_efi=has_efi or is_uefi_system(),
        has_windows=has_windows,
        has_linux=has_linux,
        free_bytes=free_bytes,
    )
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Apply partition plans to disks.
"""

import os
import subprocess
from typing import Callable, Optional, Tuple

from command_utils import run_command
from disk_utils import zero_fill_disk
from format_utils import format_partitions
from mount_utils import mount_partition
from partition_models import PartitionPlan


def _part_name(device: str, index: int) -> str:
    if device.startswith("/dev/nvme") or device.startswith("/dev/mmcblk"):
        return f"{device}p{index}"
    return f"{device}{index}"


def _mkpart_commands(plan: PartitionPlan) -> None:
    device = plan.device
    if plan.wipe_disk:
        zero_fill_disk(device)
        label = "gpt" if plan.use_gpt else "msdos"
        run_command(["parted", "-s", device, "mklabel", label], "Failed to create partition table.")

    if not plan.wipe_disk and plan.shrink_paths:
        for path in plan.shrink_paths:
            _shrink_ntfs(path, plan.shrink_mib)

    start_mib = 1
    index = 1
    for part in plan.partitions:
        if part.preserve:
            continue
        end_mib = start_mib + part.size_mib
        fs_arg = "fat32" if part.fstype == "fat32" else part.fstype
        if part.role == "esp":
            run_command(
                ["parted", "-s", device, "mkpart", "ESP", "fat32", f"{start_mib}MiB", f"{end_mib}MiB"],
                "Failed to create EFI partition.",
            )
            if plan.use_gpt:
                run_command(
                    ["parted", "-s", device, "set", str(index), "esp", "on"],
                    "Failed to set ESP flag.",
                )
        elif part.fstype == "swap":
            run_command(
                ["parted", "-s", device, "mkpart", "primary", "linux-swap", f"{start_mib}MiB", f"{end_mib}MiB"],
                "Failed to create swap partition.",
            )
        else:
            run_command(
                ["parted", "-s", device, "mkpart", "primary", fs_arg, f"{start_mib}MiB", f"{end_mib}MiB"],
                "Failed to create partition.",
            )
            if index == 1 and not plan.use_gpt:
                run_command(["parted", "-s", device, "set", "1", "boot", "on"], "Failed to set boot flag.")
        start_mib = end_mib
        index += 1


def _format_swap(path: str, log_cb: Callable[[str], None]) -> None:
    proc = subprocess.run(
        ["mkswap", path],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        check=True,
    )
    output = (proc.stdout or "").strip()
    if output:
        for line in output.splitlines():
            if line.strip():
                log_cb(line.strip())
    log_cb(f"Formatted swap on {path}")


def _shrink_ntfs(path: str, shrink_mib: int) -> None:
    try:
        subprocess.run(
            ["ntfsresize", "--info", "--force", path],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
        )
        subprocess.run(
            ["ntfsresize", "--force", "--size", f"{shrink_mib}M", path],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        raise RuntimeError(f"Failed to resize {path}: {exc}") from exc


def execute_plan(
    plan: PartitionPlan,
    log_cb: Callable[[str], None],
) -> Tuple[str, Optional[str], str, Optional[str], Optional[str]]:
    """
    Apply a partition plan and mount target root (+ ESP if needed).
    Returns (root_part, esp_part, root_mount, esp_mount, reuse_esp_mount).
    """
    log_cb("Applying partition plan...")
    _mkpart_commands(plan)

    root_part = None
    esp_part = plan.esp_path or None
    root_mount = None
    esp_mount = None
    reuse_esp_mount = None

    idx = 1
    for part in plan.partitions:
        if part.preserve:
            continue
        path = _part_name(plan.device, idx)
        if part.role == "minios_root":
            root_part = path
            format_partitions(path, part.fstype, None)
            root_mount = f"/mnt/install/{os.path.basename(path)}"
            mount_partition(path, root_mount)
        elif part.role == "esp" and not plan.reuse_esp:
            esp_part = path
            format_partitions(path, "fat32", None)
            esp_mount = f"/mnt/install/{os.path.basename(path)}"
            mount_partition(path, esp_mount)
        elif part.role == "swap":
            _format_swap(path, log_cb)
        idx += 1

    if plan.reuse_esp and plan.esp_path:
        reuse_esp_mount = f"/mnt/install/{os.path.basename(plan.esp_path)}"
        mount_partition(plan.esp_path, reuse_esp_mount)

    if not root_part or not root_mount:
        raise RuntimeError("Partition plan does not contain a root partition.")

    return root_part, esp_part, root_mount, esp_mount or reuse_esp_mount, reuse_esp_mount
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Detect installed operating systems via os-prober and partition heuristics.
"""

import os
import subprocess
from typing import List, Dict

from partition_models import DiskLayout


def detect_os_entries(layout: DiskLayout) -> List[Dict[str, str]]:
    entries: List[Dict[str, str]] = []

    for part in layout.partitions:
        if part.role == "windows":
            entries.append({"name": "Windows", "partition": part.path, "type": "windows"})
        elif part.role == "linux_other":
            entries.append({"name": part.os_name or "Linux", "partition": part.path, "type": "linux"})

    if os.path.exists("/usr/sbin/os-prober"):
        try:
            output = subprocess.check_output(
                ["os-prober"],
                stderr=subprocess.DEVNULL,
                universal_newlines=True,
                timeout=120,
            )
            for line in output.splitlines():
                if ":" not in line:
                    continue
                partition, label = line.split(":", 1)[0], line.split(":", 1)[1].strip()
                if not any(e["partition"] == partition for e in entries):
                    entries.append({"name": label, "partition": partition, "type": "os-prober"})
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            pass

    return entries
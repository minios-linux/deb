#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Write live config.conf from wizard user settings.
"""

import os
import re
import tempfile
from typing import Optional

from install_state import UserConfig

_DEFAULT_TEMPLATE = """LIVE_USERNAME={username}
LIVE_USER_FULLNAME={full_name}
LIVE_HOSTNAME={hostname}
LIVE_TIMEZONE={timezone}
LIVE_LOCALES={locale}
LIVE_KEYBOARD_LAYOUTS={keyboard}
"""


def write_live_config(user: UserConfig, base_path: str = "/etc/live/config.conf") -> Optional[str]:
    if os.path.exists(base_path):
        with open(base_path, "r", encoding="utf-8") as fh:
            content = fh.read()
    else:
        content = _DEFAULT_TEMPLATE.format(
            username=user.username or "live",
            full_name=user.full_name or user.username or "live",
            hostname=user.hostname or "minios",
            timezone=user.timezone or "Etc/UTC",
            locale=user.locale or "en_US.UTF-8",
            keyboard=user.keyboard or "",
        )

    replacements = {
        "LIVE_USERNAME": user.username,
        "LIVE_USER_FULLNAME": user.full_name or user.username,
        "LIVE_HOSTNAME": user.hostname,
        "LIVE_TIMEZONE": user.timezone,
        "LIVE_LOCALES": user.locale,
        "LIVE_KEYBOARD_LAYOUTS": user.keyboard,
    }
    for key, value in replacements.items():
        if not value:
            continue
        pattern = rf"^({key}=)(.*)$"
        if re.search(pattern, content, re.MULTILINE):
            content = re.sub(pattern, rf"\g<1>{value}", content, flags=re.MULTILINE)
        else:
            content += f"\n{key}={value}\n"

    fd, temp_path = tempfile.mkstemp(prefix="minios-install-config-", suffix=".conf")
    os.close(fd)
    with open(temp_path, "w", encoding="utf-8") as fh:
        fh.write(content)
    return temp_path
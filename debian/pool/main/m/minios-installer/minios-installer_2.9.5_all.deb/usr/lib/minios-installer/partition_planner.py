#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Build partition plans for guided installation scenarios.
"""

from typing import Optional

from partition_models import (
    DiskLayout,
    PartitionPlan,
    PlannedPartition,
    PLACEMENT_ERASE_ALL,
    PLACEMENT_ALONGSIDE_WINDOWS,
    PLACEMENT_ALONGSIDE_OS,
    PLACEMENT_FREE_SPACE,
    PLACEMENT_MANUAL,
)
from acceptance_spec import (
    ACCEPTANCE_PARTITION_OVERHEAD_MIB,
    ACCEPTANCE_ROOT_MIN_MIB,
)
from partition_scanner import is_uefi_system


ESP_SIZE_MIB = 512
MIN_ROOT_MIB = 8192
MIN_SHRINK_MIB = 10240
SWAP_MIB = 2048
OVERHEAD_MIB = ACCEPTANCE_PARTITION_OVERHEAD_MIB


def _use_gpt(layout: DiskLayout) -> bool:
    if layout.partition_table == "gpt":
        return True
    return layout.size_mib > 2_097_152


def _swap_size_mib(layout: DiskLayout) -> int:
    if layout.size_mib < 4096:
        return 512
    if layout.size_mib < 16384:
        return SWAP_MIB
    max_swap = layout.size_mib - ACCEPTANCE_ROOT_MIN_MIB - OVERHEAD_MIB
    if max_swap <= 0:
        return 0
    preferred = 4096 if layout.size_mib >= 32768 else SWAP_MIB
    return min(preferred, max_swap)


def plan_erase_all(layout: DiskLayout, filesystem: str = "ext4") -> PartitionPlan:
    use_gpt = _use_gpt(layout)
    need_esp = filesystem != "fat32" and (use_gpt or is_uefi_system())
    swap_mib = _swap_size_mib(layout) if filesystem != "fat32" else 0
    esp_mib = ESP_SIZE_MIB if need_esp else 0
    root_mib = layout.size_mib - esp_mib - swap_mib - OVERHEAD_MIB

    if root_mib < MIN_ROOT_MIB:
        swap_mib = 0
        root_mib = layout.size_mib - esp_mib - OVERHEAD_MIB

    parts = [
        PlannedPartition(
            role="minios_root",
            size_mib=root_mib,
            fstype=filesystem,
            mountpoint="/",
        )
    ]
    if swap_mib > 0:
        parts.append(
            PlannedPartition(role="swap", size_mib=swap_mib, fstype="swap")
        )
    if need_esp:
        parts.append(
            PlannedPartition(
                role="esp",
                size_mib=esp_mib,
                fstype="fat32",
                mountpoint="/boot/efi",
            )
        )

    return PartitionPlan(
        device=layout.device,
        use_gpt=use_gpt,
        wipe_disk=True,
        reuse_esp=False,
        partitions=parts,
    )


def plan_alongside(
    layout: DiskLayout,
    filesystem: str = "ext4",
    target_mib: Optional[int] = None,
    prefer_windows: bool = True,
) -> PartitionPlan:
    if target_mib is None:
        target_mib = max(MIN_ROOT_MIB, min(layout.free_bytes // (1024 * 1024), layout.size_mib // 3))

    if target_mib < MIN_ROOT_MIB and layout.free_bytes < MIN_ROOT_MIB * 1024 * 1024:
        shrink_candidate = None
        for part in layout.partitions:
            if prefer_windows and part.role == "windows":
                shrink_candidate = part
                break
            if not prefer_windows and part.role == "linux_other":
                shrink_candidate = part
                break
        if shrink_candidate and shrink_candidate.size_mib > MIN_SHRINK_MIB + MIN_ROOT_MIB:
            target_mib = MIN_ROOT_MIB
            return PartitionPlan(
                device=layout.device,
                use_gpt=_use_gpt(layout),
                wipe_disk=False,
                reuse_esp=layout.has_efi,
                esp_path=next((p.path for p in layout.partitions if p.role == "esp"), ""),
                partitions=[
                    PlannedPartition(
                        role="minios_root",
                        size_mib=target_mib,
                        fstype=filesystem,
                        mountpoint="/",
                    ),
                    PlannedPartition(role="swap", size_mib=SWAP_MIB, fstype="swap"),
                ],
                shrink_paths=[shrink_candidate.path],
                shrink_mib=target_mib + SWAP_MIB + 64,
            )
        raise ValueError("Not enough free space for installation")

    parts = [
        PlannedPartition(
            role="minios_root",
            size_mib=target_mib,
            fstype=filesystem,
            mountpoint="/",
        )
    ]
    if layout.size_mib >= 4096:
        parts.append(PlannedPartition(role="swap", size_mib=SWAP_MIB, fstype="swap"))

    return PartitionPlan(
        device=layout.device,
        use_gpt=_use_gpt(layout),
        wipe_disk=False,
        reuse_esp=layout.has_efi,
        esp_path=next((p.path for p in layout.partitions if p.role == "esp"), ""),
        partitions=parts,
    )


def build_plan(
    layout: DiskLayout,
    placement: str,
    filesystem: str = "ext4",
    manual_partitions: Optional[list] = None,
) -> PartitionPlan:
    if placement == PLACEMENT_ERASE_ALL:
        return plan_erase_all(layout, filesystem)
    if placement == PLACEMENT_ALONGSIDE_WINDOWS:
        return plan_alongside(layout, filesystem, prefer_windows=True)
    if placement == PLACEMENT_ALONGSIDE_OS:
        return plan_alongside(layout, filesystem, prefer_windows=False)
    if placement == PLACEMENT_FREE_SPACE:
        if layout.free_bytes < MIN_ROOT_MIB * 1024 * 1024:
            raise ValueError("No unallocated space available")
        return plan_alongside(layout, filesystem)
    if placement == PLACEMENT_MANUAL and manual_partitions:
        return PartitionPlan(
            device=layout.device,
            use_gpt=_use_gpt(layout),
            wipe_disk=False,
            partitions=manual_partitions,
        )
    raise ValueError(f"Unsupported placement: {placement}")
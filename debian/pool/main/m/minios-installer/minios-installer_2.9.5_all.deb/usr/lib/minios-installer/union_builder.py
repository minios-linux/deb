#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Build a unified root filesystem from already-mounted live bundles.
"""

import os
import shutil
import subprocess
import tempfile
from typing import Callable, Optional, Tuple


def detect_live_paths() -> Tuple[str, str]:
    if os.path.isdir("/run/initramfs/memory/bundles"):
        return "/run/initramfs/memory/bundles", "/run/initramfs/memory/changes"
    if os.path.isdir("/lib/live/mount/bundles"):
        return "/lib/live/mount/bundles", "/lib/live/mount/changes"
    raise RuntimeError("Live bundles are not mounted. Run installer from a live session.")


def _aufs_supported() -> bool:
    try:
        with open("/proc/filesystems", "r", encoding="utf-8") as fh:
            return "aufs" in fh.read()
    except OSError:
        return False


def build_union_root(log_cb: Callable[[str], None]) -> Tuple[str, str]:
    """
    Merge mounted bundles into a unified read-only root.
    Returns (union_mount, tmp_base) — caller must call cleanup_union().
    """
    bundles, system_changes = detect_live_paths()
    log_cb(f"Using bundles from {bundles}")

    tmp_base = tempfile.mkdtemp(prefix="minios-install-union.", dir=os.path.join(system_changes, "tmp"))
    changes = os.path.join(tmp_base, "changes")
    work = os.path.join(tmp_base, "work")
    union = os.path.join(tmp_base, "union")
    os.makedirs(changes, exist_ok=True)
    os.makedirs(work, exist_ok=True)
    os.makedirs(union, exist_ok=True)

    bundle_dirs = sorted(
        [os.path.join(bundles, name) for name in os.listdir(bundles)],
        key=lambda p: os.path.basename(p),
        reverse=True,
    )
    if not bundle_dirs:
        raise RuntimeError("No module bundles found.")

    env = os.environ.copy()
    env["LIBMOUNT_FORCE_MOUNT2"] = "always"

    if _aufs_supported():
        lowers = ":".join(f"{path}=ro" for path in bundle_dirs)
        subprocess.run(
            ["mount", "-t", "aufs", "-o", f"br={changes}=rw:{lowers}", "none", union],
            check=True,
            env=env,
        )
    else:
        lowerdir = ":".join(bundle_dirs)
        subprocess.run(
            ["mount", "-t", "overlay", "-o", f"lowerdir={lowerdir},upperdir={changes},workdir={work}", "overlay", union],
            check=True,
            env=env,
        )

    log_cb(f"Unified root mounted at {union}")
    return union, tmp_base


def copy_union_to_target(
    union: str,
    target: str,
    log_cb: Callable[[str], None],
    progress_cb: Optional[Callable[[int, str], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
) -> None:
    excludes = [
        "--exclude=/dev/*",
        "--exclude=/proc/*",
        "--exclude=/sys/*",
        "--exclude=/run/*",
        "--exclude=/tmp/*",
        "--exclude=/mnt/*",
        "--exclude=/media/*",
    ]
    cmd = ["rsync", "-aAXH", "--info=progress2"] + excludes + [f"{union}/", f"{target}/"]
    log_cb("Copying unified root to target...")
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    assert proc.stdout is not None
    for line in proc.stdout:
        if cancel_check and cancel_check():
            proc.terminate()
            raise RuntimeError("Installation canceled.")
        line = line.strip()
        if line:
            log_cb(line)
    if proc.wait() != 0:
        raise RuntimeError("rsync failed while copying unified root.")


def cleanup_union(union: str, tmp_base: str) -> None:
    subprocess.run(["umount", "-l", union], check=False)
    shutil.rmtree(tmp_base, ignore_errors=True)
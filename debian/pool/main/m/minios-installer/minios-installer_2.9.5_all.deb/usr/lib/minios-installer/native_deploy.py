#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Native installation: merge bundles, copy unified root, chroot setup.
"""

from typing import Callable, Optional

from chroot_setup import run_chroot_setup
from install_state import InstallState
from mount_utils import unmount_partitions
from partition_executor import execute_plan
from partition_planner import build_plan
from partition_scanner import scan_disk
from union_builder import build_union_root, cleanup_union, copy_union_to_target


def run_native_install(
    state: InstallState,
    progress_cb: Callable[[int, str], None],
    log_cb: Callable[[str], None],
) -> None:
    if not state.target_device:
        raise RuntimeError("No target device selected.")

    layout = scan_disk(state.target_device)
    plan = state.partition_plan or build_plan(layout, state.placement, state.filesystem)
    state.partition_plan = plan

    progress_cb(4, "Preparing partitions...")
    root_part, esp_part, root_mount, esp_mount, _reuse = execute_plan(plan, log_cb)

    union = None
    tmp_base = None
    try:
        progress_cb(15, "Building unified root from modules...")
        union, tmp_base = build_union_root(log_cb)

        progress_cb(25, "Copying system files...")
        copy_union_to_target(
            union,
            root_mount,
            log_cb,
            progress_cb,
            cancel_check=lambda: state.cancel_requested,
        )

        progress_cb(85, "Configuring installed system...")
        run_chroot_setup(root_mount, state, state.target_device, esp_mount, log_cb)

        progress_cb(98, "Unmounting partitions...")
        unmount_partitions(root_part, esp_part, root_mount, esp_mount)
        progress_cb(100, "Installation complete!")
    finally:
        if union and tmp_base:
            cleanup_union(union, tmp_base)
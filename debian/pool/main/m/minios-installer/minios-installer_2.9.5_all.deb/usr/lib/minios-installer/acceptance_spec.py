#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Independent acceptance constants for plan.md criterion 3.

These values define the external spec; partition_planner must satisfy them
without tests importing planner-internal constants.
"""

# Blank 20 GB disk as reported by scan_disk/parted (20480 MiB).
ACCEPTANCE_DISK_20G_MIB = 20480

# Root partition on erase-all must occupy ~18–20 GiB (binary GiB → MiB).
ACCEPTANCE_ROOT_MIN_MIB = 18 * 1024  # 18432 MiB = 18 GiB
ACCEPTANCE_ROOT_MAX_MIB = ACCEPTANCE_DISK_20G_MIB

# Reserved for partition table alignment in erase-all plans.
ACCEPTANCE_PARTITION_OVERHEAD_MIB = 4
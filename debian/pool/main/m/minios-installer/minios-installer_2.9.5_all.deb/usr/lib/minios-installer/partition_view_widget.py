#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Visual partition bar and disk summary."""

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib  # noqa: E402

from partition_models import DiskLayout, PartitionInfo


ROLE_COLORS = {
    "windows": "#0078d4",
    "linux_other": "#4caf50",
    "esp": "#9c27b0",
    "swap": "#ff9800",
    "free": "#e0e0e0",
    "minios_root": "#2196f3",
    "unknown": "#9e9e9e",
}


class PartitionBar(Gtk.DrawingArea):
    def __init__(self, layout: DiskLayout):
        super().__init__()
        self.layout = layout
        self.set_size_request(-1, 36)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)

    def do_draw(self, cr):
        width = self.get_allocated_width()
        height = self.get_allocated_height()
        total = max(self.layout.size_bytes, 1)
        x = 0.0
        cr.set_line_width(1)

        parts = list(self.layout.partitions)
        if self.layout.free_bytes > 0:
            parts.append(
                PartitionInfo(
                    name="free",
                    path="",
                    size_bytes=self.layout.free_bytes,
                    role="free",
                    os_name="Free space",
                )
            )

        for part in parts:
            w = max(2.0, (part.size_bytes / total) * width)
            color = Gdk.RGBA()
            color.parse(ROLE_COLORS.get(part.role, ROLE_COLORS["unknown"]))
            cr.set_source_rgba(color.red, color.green, color.blue, 1.0)
            cr.rectangle(x, 0, w, height)
            cr.fill_preserve()
            cr.set_source_rgb(0.3, 0.3, 0.3)
            cr.stroke()
            x += w


class DiskSummaryBox(Gtk.Box):
    def __init__(self, layout: DiskLayout, gettext_func):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        _ = gettext_func
        title = Gtk.Label()
        title.set_markup(
            f"<b>{GLib.markup_escape_text(layout.device)}</b> "
            f"({layout.size_bytes // (1024 ** 3)} GB)"
        )
        title.set_halign(Gtk.Align.START)
        self.pack_start(title, False, False, 0)
        self.pack_start(PartitionBar(layout), False, False, 0)

        grid = Gtk.Grid(column_spacing=12, row_spacing=4)
        row = 0
        for part in layout.partitions:
            name = part.os_name or part.fstype or part.role
            grid.attach(Gtk.Label(label=name, xalign=0), 0, row, 1, 1)
            grid.attach(
                Gtk.Label(label=f"{part.size_bytes // (1024 ** 2)} MiB", xalign=1),
                1,
                row,
                1,
                1,
            )
            row += 1
        if layout.free_bytes:
            grid.attach(Gtk.Label(label=_("Free space"), xalign=0), 0, row, 1, 1)
            grid.attach(
                Gtk.Label(label=f"{layout.free_bytes // (1024 ** 2)} MiB", xalign=1),
                1,
                row,
                1,
                1,
            )
        self.pack_start(grid, False, False, 0)
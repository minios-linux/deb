#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Installation state shared across wizard steps and deploy backends.
"""

from dataclasses import dataclass, field
from typing import Optional, List

from partition_models import PartitionPlan


@dataclass
class UserConfig:
    full_name: str = ""
    username: str = ""
    password: str = ""
    hostname: str = "minios"
    locale: str = "en_US.UTF-8"
    timezone: str = "Etc/UTC"
    keyboard: str = ""


@dataclass
class InstallState:
    install_mode: str = "live"          # live | native
    placement: str = "erase_all"        # erase_all | alongside_windows | alongside_os | free_space | manual
    target_device: Optional[str] = None
    filesystem: str = "ext4"
    boot_config_type: str = "multilang"
    use_gpt: bool = False
    create_efi: bool = True
    partition_plan: Optional[PartitionPlan] = None
    user_config: UserConfig = field(default_factory=UserConfig)
    cancel_requested: bool = False
    disk_model: str = ""
    disk_size: str = ""

    def is_native(self) -> bool:
        return self.install_mode == "native"

    def is_live(self) -> bool:
        return self.install_mode == "live"

    def wipes_entire_disk(self) -> bool:
        return self.placement == "erase_all"
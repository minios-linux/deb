#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Live installation: copy minios/ tree to target disk.
"""

from typing import Callable, Optional

from bootloader_dualboot import install_bootloader_for_plan
from copy_utils import copy_efi_files, copy_minios_files, find_minios_source
from install_state import InstallState
from mount_utils import unmount_partitions
from partition_executor import execute_plan
from partition_planner import build_plan
from partition_scanner import scan_disk
from user_config_writer import write_live_config


def _config_override(state: InstallState) -> Optional[str]:
    return write_live_config(state.user_config)


def run_live_install(
    state: InstallState,
    progress_cb: Callable[[int, str], None],
    log_cb: Callable[[str], None],
) -> None:
    if not state.target_device:
        raise RuntimeError("No target device selected.")

    layout = scan_disk(state.target_device)
    plan = state.partition_plan or build_plan(layout, state.placement, state.filesystem)
    state.partition_plan = plan
    state.use_gpt = plan.use_gpt
    state.create_efi = any(p.role == "esp" for p in plan.partitions)

    progress_cb(0, "Preparing target disk...")
    root_part, esp_part, root_mount, esp_mount, reuse_esp = execute_plan(plan, log_cb)

    src = find_minios_source()
    if not src:
        raise RuntimeError("Cannot find MiniOS image.")

    config_override = _config_override(state)

    progress_cb(18, "Copying MiniOS files...")
    copy_minios_files(
        src,
        root_mount,
        progress_cb,
        log_cb,
        config_override,
        state.boot_config_type,
    )

    if esp_mount and state.create_efi:
        progress_cb(97, "Copying EFI files to ESP...")
        copy_efi_files(src, esp_mount, log_cb)
    elif not state.create_efi:
        progress_cb(97, "Copying EFI files to root...")
        copy_efi_files(src, root_mount, log_cb)

    progress_cb(98, "Setting up bootloader...")
    install_bootloader_for_plan(
        state,
        plan,
        root_part,
        esp_part,
        root_mount,
        esp_mount,
        progress_cb,
        log_cb,
    )

    progress_cb(99, "Unmounting disk...")
    unmount_partitions(root_part, esp_part, root_mount, esp_mount)
    progress_cb(100, "Installation complete!")
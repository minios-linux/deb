#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MiniOS Installer
A graphical tool for installing MiniOS onto a disk via GTK.

Usage:
    main_installer.py

Copyright (C) 2025 MiniOS Linux
Author: crims0n <crims0n@minios.dev>
Original idea: FershoUno <https://github.com/FershoUno>
"""

import os
import sys
import re
import gi
import gettext
import threading
import traceback

# Add lib directory to Python path
_LIB_DIR = os.path.dirname(os.path.abspath(__file__))
if _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)
# Development fallback
_DEV_LIB = os.path.join(os.path.dirname(_LIB_DIR), "lib")
if os.path.isdir(_DEV_LIB) and _DEV_LIB not in sys.path:
    sys.path.insert(0, _DEV_LIB)

from disk_utils import start_disk_monitoring, stop_disk_monitoring, pause_disk_monitoring, resume_disk_monitoring
from install_state import InstallState
from live_deploy import run_live_install
from native_deploy import run_native_install
from installer_wizard import InstallerWizard

gi.require_version('Gtk', '3.0')
gi.require_version('Gio', '2.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gtk, GLib, Gdk, Pango

APPLICATION_ID   = 'org.minios.installer'
APP_NAME         = 'minios-installer'
APP_TITLE        = 'MiniOS Installer'
LOCALE_DIRECTORY = '/usr/share/locale'
CSS_FILE_PATH    = '/usr/share/minios-installer/style.css'
ICON_WINDOW      = 'usb-creator-gtk'

gettext.bindtextdomain(APP_NAME, LOCALE_DIRECTORY)
gettext.textdomain(APP_NAME)
_ = gettext.gettext


def apply_css_if_exists():
    provider = Gtk.CssProvider()
    if os.path.exists(CSS_FILE_PATH):
        provider.load_from_path(CSS_FILE_PATH)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )


class InstallerWindow(Gtk.ApplicationWindow):
    def __init__(self, application: Gtk.Application):
        super().__init__(application=application, title=_(APP_TITLE))
        self.set_default_size(720, 520)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_icon_name(ICON_WINDOW)

        self.state = InstallState(boot_config_type=self._get_default_boot_config())
        self.cancel_requested = False

        self.main_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(self.main_vbox)

        apply_css_if_exists()
        self._build_header_bar()
        self._show_wizard()

        start_disk_monitoring(self._on_disks_changed)
        self.connect("destroy", self._on_destroy)

    def _get_default_boot_config(self):
        try:
            with open('/proc/cmdline', 'r', encoding='utf-8') as f:
                cmdline = f.read()
            match = re.search(r'locales=([^\s]+)', cmdline)
            if match:
                lang_code = match.group(1).split('.')[0]
                if lang_code != "en_US":
                    return lang_code
        except OSError:
            pass
        return "multilang"

    def _on_destroy(self, widget):
        stop_disk_monitoring(self._on_disks_changed)
        self.get_application().quit()

    def _on_disks_changed(self):
        if hasattr(self, 'wizard'):
            GLib.idle_add(self.wizard.refresh_disks)

    def _build_header_bar(self):
        header = Gtk.HeaderBar(show_close_button=True)
        header.props.title = _(APP_TITLE)
        self.set_titlebar(header)

    def _clear_main(self):
        for child in self.main_vbox.get_children():
            self.main_vbox.remove(child)

    def _show_wizard(self):
        self._clear_main()
        self.state.cancel_requested = False
        self.wizard = InstallerWizard(
            self.state,
            on_install=self._start_install,
            refresh_disks_cb=self._on_disks_changed,
        )
        self.main_vbox.pack_start(self.wizard, True, True, 0)
        self.wizard.show_all()

    def _start_install(self):
        pause_disk_monitoring()
        self._build_progress_ui()
        threading.Thread(target=self._run_install, daemon=True).start()

    def _build_progress_ui(self):
        self._clear_main()

        self.lbl_status = Gtk.Label(label=_("Preparing to install..."), xalign=0)
        self.lbl_status.set_line_wrap(True)
        self.lbl_status.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        self.lbl_status.set_margin_start(12)
        self.lbl_status.set_margin_end(12)
        self.lbl_status.set_margin_top(12)
        self.main_vbox.pack_start(self.lbl_status, False, False, 0)

        self.progress = Gtk.ProgressBar()
        self.progress.set_margin_start(12)
        self.progress.set_margin_end(12)
        self.main_vbox.pack_start(self.progress, False, False, 0)

        self.btn_toggle = Gtk.ToggleButton(label=_("Show Log"))
        self.btn_toggle.set_margin_start(12)
        self.btn_toggle.connect("toggled", self._on_toggle_log)
        self.main_vbox.pack_start(self.btn_toggle, False, False, 0)

        self.btn_cancel = Gtk.Button(label=_("Cancel"))
        self.btn_cancel.get_style_context().add_class('destructive-action')
        self.btn_cancel.set_margin_start(12)
        self.btn_cancel.set_margin_end(12)
        self.btn_cancel.set_margin_bottom(12)
        self.btn_cancel.connect("clicked", self._on_cancel)
        self.main_vbox.pack_end(self.btn_cancel, False, False, 0)

        self.log_buf = Gtk.TextBuffer()
        self.log_view = Gtk.TextView(buffer=self.log_buf)
        self.log_view.set_editable(False)
        self.log_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.log_view.set_monospace(True)
        self.log_sw = Gtk.ScrolledWindow()
        self.log_sw.set_min_content_height(200)
        self.log_sw.add(self.log_view)

        self.show_all()

    def _on_toggle_log(self, toggle):
        if toggle.get_active():
            toggle.set_label(_("Hide Log"))
            self.main_vbox.pack_start(self.log_sw, True, True, 0)
            self.log_sw.show_all()
        else:
            toggle.set_label(_("Show Log"))
            self.main_vbox.remove(self.log_sw)

    def _on_cancel(self, button):
        if not self.state.cancel_requested:
            self.state.cancel_requested = True
            GLib.idle_add(self.progress.set_fraction, 0.0)
            GLib.idle_add(self.lbl_status.set_text, _("Installation canceled."))
            GLib.idle_add(self._append_log, _("Installation canceled by user."))
            self._setup_restart_button()

    def _setup_restart_button(self):
        self.btn_cancel.set_label(_("Restart Installation"))
        self.btn_cancel.get_style_context().remove_class('destructive-action')
        self.btn_cancel.get_style_context().add_class('suggested-action')
        try:
            self.btn_cancel.disconnect_by_func(self._on_cancel)
        except TypeError:
            pass
        self.btn_cancel.connect("clicked", lambda b: self._show_wizard())
        self.btn_cancel.set_sensitive(True)

    def _report_progress(self, percent: int, message: str):
        GLib.idle_add(self.progress.set_fraction, percent / 100.0)
        GLib.idle_add(self.lbl_status.set_text, message)
        GLib.idle_add(self._append_log, message)

    def _append_log(self, message: str):
        timestamp = GLib.DateTime.new_now_local().format("%Y-%m-%d %H:%M:%S")
        self.log_buf.insert_at_cursor(f"[{timestamp}] {message}\n")

    def _log_async(self, message: str):
        GLib.idle_add(self._append_log, message)

    def _run_install(self):
        try:
            if self.state.is_native():
                run_native_install(self.state, self._report_progress, self._log_async)
            else:
                run_live_install(self.state, self._report_progress, self._log_async)
            if not self.state.cancel_requested:
                GLib.idle_add(self._setup_restart_button)
        except Exception as exc:
            if not self.state.cancel_requested:
                GLib.idle_add(self._append_log, traceback.format_exc())
                GLib.idle_add(self._show_error, _("Installation failed: ") + str(exc))
        finally:
            resume_disk_monitoring()

    def _show_error(self, message: str):
        dlg = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            destroy_with_parent=True,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=_("Installation Error"),
        )
        dlg.format_secondary_text(message)
        dlg.run()
        dlg.destroy()


class MiniOSInstallerApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APPLICATION_ID)
        self.window = None

    def do_activate(self):
        if self.window:
            self.window.present()
            return

        if os.geteuid() != 0:
            dlg = Gtk.MessageDialog(
                modal=True,
                destroy_with_parent=False,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.OK,
                text=_("Root Privileges Required"),
            )
            dlg.format_secondary_text(_("This installer must be run as root."))
            dlg.run()
            dlg.destroy()
            sys.exit(1)

        self.window = InstallerWindow(self)
        self.window.show_all()
        self.window.present()


def _print_help() -> None:
    print("Usage: minios-installer")
    print()
    print("Launch the MiniOS Installer graphical interface.")
    print()
    print("This command starts the GTK installer for copying MiniOS from the live")
    print("system to a target disk.")
    print()
    print("For the manual page, run: man minios-installer")


def main():
    if "--help" in sys.argv or "-h" in sys.argv:
        _print_help()
        return 0
    try:
        app = MiniOSInstallerApp()
        return app.run(sys.argv)
    except KeyboardInterrupt:
        return 130


if __name__ == '__main__':
    sys.exit(main())
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Installer wizard controller with Gtk.Stack navigation.
"""

import gettext
import gi
import sys
from typing import Callable, List, Optional

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib  # noqa: E402

from disk_utils import find_available_disks, get_disk_size_mib
from format_utils import detect_filesystem_tools
from install_state import InstallState
from partition_models import (
    PLACEMENT_ERASE_ALL,
    PLACEMENT_ALONGSIDE_WINDOWS,
    PLACEMENT_ALONGSIDE_OS,
    PLACEMENT_FREE_SPACE,
    PLACEMENT_MANUAL,
)
from partition_planner import build_plan
from partition_scanner import scan_disk
from partition_view_widget import DiskSummaryBox

_ = gettext.gettext

try:
    sys.path.insert(0, "/usr/lib/minios-configurator")
    from validation_utils import validate_hostname, validate_password, validate_username
except ImportError:
    def validate_hostname(value: str) -> bool:
        import re as _re
        return not value.strip() or bool(_re.match(r"^[a-zA-Z0-9-]+$", value))

    def validate_username(value: str) -> bool:
        return bool(value.strip())

    def validate_password(value: str, is_required: bool = False) -> bool:
        if " " in value:
            return False
        return bool(value) if is_required else True


class InstallerWizard(Gtk.Box):
    STEP_WELCOME = 0
    STEP_MODE = 1
    STEP_PLACEMENT = 2
    STEP_PARTITION = 3
    STEP_USER = 4
    STEP_SUMMARY = 5

    def __init__(self, state: InstallState, on_install: Callable[[], None], refresh_disks_cb: Callable[[], None]):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.state = state
        self.on_install = on_install
        self.refresh_disks_cb = refresh_disks_cb
        self.current_step = 0
        self._steps: List[Gtk.Widget] = []

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.stack.set_transition_duration(200)
        self.pack_start(self.stack, True, True, 0)

        self._build_steps()
        self._build_nav()
        self._show_step(0)

    def _build_nav(self):
        nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        nav.set_margin_top(12)
        nav.set_margin_bottom(12)
        nav.set_margin_start(12)
        nav.set_margin_end(12)
        nav.set_halign(Gtk.Align.END)

        self.btn_back = Gtk.Button(label=_("Back"))
        self.btn_back.connect("clicked", lambda *_: self._go_back())
        nav.pack_start(self.btn_back, False, False, 0)

        self.btn_next = Gtk.Button(label=_("Next"))
        self.btn_next.get_style_context().add_class("suggested-action")
        self.btn_next.connect("clicked", lambda *_: self._go_next())
        nav.pack_start(self.btn_next, False, False, 0)

        self.pack_start(nav, False, False, 0)

    def _build_steps(self):
        self._steps = [
            self._step_welcome(),
            self._step_mode(),
            self._step_placement(),
            self._step_partition(),
            self._step_user(),
            self._step_summary(),
        ]
        for idx, widget in enumerate(self._steps):
            self.stack.add_named(widget, str(idx))

    def _wrap_step(self, title: str, body: Gtk.Widget) -> Gtk.Box:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_margin_top(16)
        box.set_margin_bottom(16)
        box.set_margin_start(16)
        box.set_margin_end(16)
        lbl = Gtk.Label()
        lbl.set_markup(f"<span size='large' weight='bold'>{GLib.markup_escape_text(title)}</span>")
        lbl.set_halign(Gtk.Align.START)
        box.pack_start(lbl, False, False, 0)
        box.pack_start(body, True, True, 0)
        return box

    def _step_welcome(self) -> Gtk.Box:
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        body.pack_start(Gtk.Label(label=_("Welcome to MiniOS Installer."), xalign=0), False, False, 0)
        body.pack_start(
            Gtk.Label(
                label=_("This wizard will guide you through installing MiniOS on your computer."),
                xalign=0,
                wrap=True,
            ),
            False,
            False,
            0,
        )
        return self._wrap_step(_("Welcome"), body)

    def _step_mode(self) -> Gtk.Box:
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        live = Gtk.RadioButton.new_with_label_from_widget(None, _("Live Install (recommended)"))
        native = Gtk.RadioButton.new_with_label_from_widget(live, _("Native Install"))
        live.set_active(True)

        def _on_live(btn):
            if btn.get_active():
                self.state.install_mode = "live"

        def _on_native(btn):
            if btn.get_active():
                self.state.install_mode = "native"

        live.connect("toggled", _on_live)
        native.connect("toggled", _on_native)

        hint = Gtk.Label(
            label=_("Live Install keeps session management and easy rollback. "
                     "Native Install unpacks a full desktop system with apt upgrades."),
            xalign=0,
            wrap=True,
        )
        hint.set_margin_top(8)
        body.pack_start(live, False, False, 0)
        body.pack_start(native, False, False, 0)
        body.pack_start(hint, False, False, 0)
        return self._wrap_step(_("Installation mode"), body)

    def _step_placement(self) -> Gtk.Box:
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        options = [
            (PLACEMENT_ERASE_ALL, _("Erase disk and install MiniOS")),
            (PLACEMENT_ALONGSIDE_WINDOWS, _("Install alongside Windows")),
            (PLACEMENT_ALONGSIDE_OS, _("Install alongside another operating system")),
            (PLACEMENT_FREE_SPACE, _("Use largest free space")),
            (PLACEMENT_MANUAL, _("Manual partitioning")),
        ]
        first = None
        for value, label in options:
            btn = Gtk.RadioButton.new_with_label_from_widget(first, label)
            if first is None:
                first = btn
                btn.set_active(True)
            btn.connect("toggled", self._on_placement_toggled, value)
            body.pack_start(btn, False, False, 0)
        self.state.placement = PLACEMENT_ERASE_ALL
        return self._wrap_step(_("Installation type"), body)

    def _on_placement_toggled(self, button, value):
        if button.get_active():
            self.state.placement = value

    def _step_partition(self) -> Gtk.Box:
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        body.pack_start(Gtk.Label(label=_("Select target disk:"), xalign=0), False, False, 0)
        self.disk_combo = Gtk.ComboBoxText()
        self._populate_disk_combo()
        self.disk_combo.connect("changed", self._on_disk_changed)
        body.pack_start(self.disk_combo, False, False, 0)

        body.pack_start(Gtk.Label(label=_("Filesystem for MiniOS:"), xalign=0), False, False, 0)
        self.fs_combo = Gtk.ComboBoxText()
        for fs in detect_filesystem_tools():
            self.fs_combo.append_text(fs)
        self.fs_combo.set_active(0)
        self.fs_combo.connect("changed", self._on_fs_changed)
        body.pack_start(self.fs_combo, False, False, 0)

        self.disk_summary_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        body.pack_start(self.disk_summary_container, True, True, 0)

        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        lang_box.pack_start(Gtk.Label(label=_("Boot menu language:"), xalign=0), False, False, 0)
        self.lang_combo = Gtk.ComboBoxText()
        for code, name in [
            ("multilang", _("Multilingual menu")),
            ("en_US", "English"),
            ("ru_RU", "Русский"),
            ("de_DE", "Deutsch"),
        ]:
            self.lang_combo.append(code, name)
        self.lang_combo.set_active_id(self.state.boot_config_type)
        self.lang_combo.connect("changed", self._on_lang_changed)
        lang_box.pack_start(self.lang_combo, True, True, 0)
        body.pack_start(lang_box, False, False, 0)

        return self._wrap_step(_("Disk setup"), body)

    def _step_user(self) -> Gtk.Box:
        grid = Gtk.Grid(column_spacing=12, row_spacing=8)
        rows = [
            ("full_name", _("Full name:")),
            ("username", _("Username:")),
            ("password", _("Password:")),
            ("hostname", _("Computer name:")),
            ("locale", _("Locale (e.g. en_US.UTF-8):")),
            ("timezone", _("Timezone (e.g. Etc/UTC):")),
            ("keyboard", _("Keyboard layout:")),
        ]
        self._user_entries = {}
        for row_idx, (key, label) in enumerate(rows):
            grid.attach(Gtk.Label(label=label, xalign=0), 0, row_idx, 1, 1)
            entry = Gtk.Entry()
            if key == "password":
                entry.set_visibility(False)
            if key == "hostname":
                entry.set_text(self.state.user_config.hostname)
            if key == "locale":
                entry.set_text(self.state.user_config.locale)
            if key == "timezone":
                entry.set_text(self.state.user_config.timezone)
            entry.connect("changed", self._on_user_changed, key)
            grid.attach(entry, 1, row_idx, 1, 1)
            self._user_entries[key] = entry
        return self._wrap_step(_("User settings"), grid)

    def _step_summary(self) -> Gtk.Box:
        self.summary_label = Gtk.Label(xalign=0, yalign=0)
        self.summary_label.set_line_wrap(True)
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.add(self.summary_label)
        btn_install = Gtk.Button(label=_("Install"))
        btn_install.get_style_context().add_class("suggested-action")
        btn_install.connect("clicked", lambda *_: self.on_install())

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.pack_start(scrolled, True, True, 0)
        box.pack_start(btn_install, False, False, 0)
        return self._wrap_step(_("Summary"), box)

    def _populate_disk_combo(self):
        self.disk_combo.remove_all()
        for dev in find_available_disks():
            label = f"/dev/{dev['name']} — {dev.get('size', '')} {dev.get('model', '')}"
            self.disk_combo.append(dev["name"], label)
        if self.disk_combo.get_model().iter_n_children(None) > 0:
            self.disk_combo.set_active(0)

    def refresh_disks(self):
        active_id = self.disk_combo.get_active_id()
        self._populate_disk_combo()
        if active_id:
            self.disk_combo.set_active_id(active_id)

    def _on_disk_changed(self, combo):
        dev_name = combo.get_active_id()
        if not dev_name:
            return
        self.state.target_device = f"/dev/{dev_name}"
        try:
            self.state.use_gpt = get_disk_size_mib(self.state.target_device) > 2_097_152
        except Exception:
            self.state.use_gpt = False
        for child in self.disk_summary_container.get_children():
            self.disk_summary_container.remove(child)
        try:
            layout = scan_disk(self.state.target_device)
            self.disk_summary_container.pack_start(DiskSummaryBox(layout, _), False, False, 0)
            self.state.partition_plan = build_plan(layout, self.state.placement, self.state.filesystem)
            self.disk_summary_container.show_all()
        except Exception as exc:
            self.disk_summary_container.pack_start(Gtk.Label(label=str(exc)), False, False, 0)
            self.disk_summary_container.show_all()

    def _on_fs_changed(self, combo):
        text = combo.get_active_text()
        if text:
            self.state.filesystem = text
            self.state.create_efi = text != "fat32"
            self._on_disk_changed(self.disk_combo)

    def _on_lang_changed(self, combo):
        lang = combo.get_active_id()
        if lang:
            self.state.boot_config_type = lang

    def _on_user_changed(self, entry, key):
        setattr(self.state.user_config, key, entry.get_text())

    def _validate_step(self) -> Optional[str]:
        if self.current_step == self.STEP_PARTITION:
            if not self.state.target_device:
                return _("Please select a target disk.")
            if not self.state.filesystem:
                return _("Please select a filesystem.")
        if self.current_step == self.STEP_USER:
            uc = self.state.user_config
            if not validate_username(uc.username):
                return _("Please enter a valid username.")
            if not validate_password(uc.password, is_required=True):
                return _("Please enter a password without spaces.")
            if uc.hostname and not validate_hostname(uc.hostname):
                return _("Computer name contains invalid characters.")
        return None

    def _update_summary(self):
        uc = self.state.user_config
        mode = _("Live Install") if self.state.is_live() else _("Native Install")
        lines = [
            f"<b>{_('Mode')}:</b> {mode}",
            f"<b>{_('Device')}:</b> {GLib.markup_escape_text(self.state.target_device or '?')}",
            f"<b>{_('Filesystem')}:</b> {GLib.markup_escape_text(self.state.filesystem)}",
            f"<b>{_('Placement')}:</b> {GLib.markup_escape_text(self.state.placement)}",
            f"<b>{_('User')}:</b> {GLib.markup_escape_text(uc.username)}",
            f"<b>{_('Hostname')}:</b> {GLib.markup_escape_text(uc.hostname)}",
        ]
        if self.state.partition_plan:
            lines.append(f"<b>{_('Partitions')}:</b>")
            for part in self.state.partition_plan.partitions:
                lines.append(f"  • {part.role}: {part.size_mib} MiB ({part.fstype})")
        self.summary_label.set_markup("\n".join(lines))

    def _show_step(self, index: int):
        self.current_step = max(0, min(index, len(self._steps) - 1))
        self.stack.set_visible_child_name(str(self.current_step))
        self.btn_back.set_sensitive(self.current_step > 0)
        if self.current_step == self.STEP_SUMMARY:
            self._update_summary()
            self.btn_next.set_visible(False)
        else:
            self.btn_next.set_visible(True)
            self.btn_next.set_label(_("Next"))

    def _go_back(self):
        self._show_step(self.current_step - 1)

    def _go_next(self):
        error = self._validate_step()
        if error:
            dlg = Gtk.MessageDialog(
                transient_for=self.get_toplevel(),
                flags=0,
                message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.OK,
                text=error,
            )
            dlg.run()
            dlg.destroy()
            return
        if self.current_step < len(self._steps) - 1:
            self._show_step(self.current_step + 1)
"""Clean installation sources must materialize status before package preflight."""
import os
import subprocess

import pytest


@pytest.mark.parametrize("mounted", [False, True])
def test_bundle_overlay_composes_only_selected_modules(tmp_path, monkeypatch, mounted):
    import bundle_source
    bundles = tmp_path / "bundles"
    core = bundles / "00-core.sb"
    extra = bundles / "03-extra.sb"
    for module in (core, extra):
        (module / "var/lib/dpkg/status.d").mkdir(parents=True)
    monkeypatch.setattr(bundle_source, "list_live_module_names", lambda: [])
    monkeypatch.setattr(bundle_source, "_scratch_parent_for_bundles", lambda _base: str(tmp_path))
    commands = []

    def run(command, **_kwargs):
        commands.append(command)
        if command[0] == "mount" and not mounted:
            raise subprocess.CalledProcessError(1, command)
        if command[0] == "/usr/bin/minios-dpkg-state":
            assert command[1] == "compose"
            assert command[3:] == [str(core)]
            with open(command[2], "w") as output:
                output.write("Package: core\nStatus: install ok installed\n\n")
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr(bundle_source.subprocess, "run", run)
    with bundle_source.BundleOverlay(str(bundles), selected_modules=["00-core.sb"]) as root:
        assert os.path.isfile(os.path.join(root, "var/lib/dpkg/status"))
    assert not os.path.exists(root)
    assert any(cmd[0] == "/usr/bin/minios-dpkg-state" for cmd in commands)


def test_invalid_package_state_cleans_install_source(tmp_path, monkeypatch):
    import bundle_source
    core = tmp_path / "bundles/00-core.sb/var/lib/dpkg"
    core.mkdir(parents=True)
    (core / "status").write_text("legacy database")
    monkeypatch.setattr(bundle_source, "list_live_module_names", lambda: [])
    monkeypatch.setattr(bundle_source, "_scratch_parent_for_bundles", lambda _base: str(tmp_path))

    def run(command, **_kwargs):
        if command[0] in ("mount", "/usr/bin/minios-dpkg-state"):
            raise subprocess.CalledProcessError(1, command)
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr(bundle_source.subprocess, "run", run)
    with pytest.raises(subprocess.CalledProcessError):
        with bundle_source.BundleOverlay(str(tmp_path / "bundles")):
            pytest.fail("invalid source reached the installer")
    assert not list(tmp_path.glob("minios-native-overlay-*"))

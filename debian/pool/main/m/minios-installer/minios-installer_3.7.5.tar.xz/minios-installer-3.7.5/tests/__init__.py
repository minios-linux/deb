# minios-installer tests package

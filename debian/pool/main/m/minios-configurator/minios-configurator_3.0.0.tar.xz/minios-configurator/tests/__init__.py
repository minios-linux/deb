# MiniOS Configurator tests

# mini-commander
Mini Commander is very simplified clone of Midnight Commander for Linux.
It even includes viewer and editor.

I would like to call myself an author, but that's not so easy. The majority of the code,
including this text itself, was initially written by ChatGPT 4. Newer features
were automatically proposed and implemented by GPT-6 Astra.

ChatGPT doesn't generate code with an explicit license attached to it. The code it provides is
intended for educational and informational purposes, and users are free to use it as they see fit.
So, the license of Mini Commander is GNU GPL v3.

![mc](https://github.com/Tomas-M/mini-commander/assets/2259370/3ec02529-7e8d-4d74-9468-01f35b705b0f)

Tomas M
slax.org

## Features

- **Built-in viewer and editor:** open files with `F3` or edit them with `F4`,
  without launching an external program. Save in the editor with `F2`.
- **Editor blocks:** press `F3`, move to the other end, then press `F3` again
  to finish marking. `F5` copies the block to the cursor and keeps the original
  selected; `F6` moves it and selects the moved block. `F8` deletes the selection.
  Blocks can span multiple lines; another `F3` starts a new selection. Copying
  or moving inside the selected block leaves the text unchanged.
  Drag with the left mouse button to select a block without scrolling the view;
  the cursor follows the drag, and releasing the button fixes the selection.
  A plain click moves the cursor and clears the existing selection.
- **Contextual function keys:** the bottom bar follows the active panel, viewer,
  or editor. `F7` searches in the viewer and editor; `Shift+F7` finds the next match.
  Click a labeled button in this bar to invoke the same action as its function key.
- **UTF-8 support:** view and edit multilingual text, including wide characters
  and combining accents, with correct cursor movement and deletion. Dialog text
  fields and the command line accept UTF-8, and panel prefix search supports
  international file and directory names.
- **Syntax highlighting:** basic highlighting for C source and headers (`.c`,
  `.h`) and shell scripts (`.sh`). Files starting with `#!/` also receive shell
  highlighting, even without an extension.
- **See invisible characters:** by default, tabs appear as `<--->` in the editor,
  and trailing spaces appear as dots in the same color. `F9` toggles `HideTabs` /
  `ShowTabs`; when hidden, tabs appear as five spaces and trailing spaces as ordinary
  spaces. Tabs always appear as five spaces in the viewer and remain single
  characters for editing. The editor marks
  control characters. Its status line shows the line, column, byte position,
  file size, and Unicode code point under the cursor.
- **Editor save protection:** prompts before closing unsaved changes, preserves
  file ownership and permissions, and edits through symbolic links while keeping
  the links intact.
- **Editor undo:** `Ctrl+U` restores the previous edit, cursor movement, selection,
  or viewport position. History is kept in memory without a fixed limit and is
  released when the editor closes. Movement stores only a small state record;
  edits retain the bytes they replace. Undoing a saved edit marks the file modified.
- **Two independent panels:** switch with `Tab`. Each panel has its own sorting
  options (`F2`): name, size, or modification time, in either direction, with
  directories first or mixed with files.
- **Batch file operations:** mark items with `Insert`, then copy (`F5`),
  move/rename (`F6`), or delete (`F8`). Copying and
  deleting directories includes their contents.
  With an empty command line, `+` selects a mask, `-` unselects a mask, and `*`
  inverts the selection. The default mask `*` selects or clears all items except
  `..`, including directories and dotfiles. Masks support only `*` and `?`, where
  `?` matches one displayed UTF-8 character. Matching is case-sensitive.
- **File permissions:** press `Ctrl+X`, release it, then press `C` to open a
  Midnight Commander-style chmod dialog. Its 12 checkboxes cover owner, group,
  and other permissions, plus setuid, setgid, and the sticky bit. Use arrows or
  `Tab` to move, `Space` or a mouse click to toggle, and `Enter` to apply.
  Framed Permission and File sections show the settings and file details;
  blue letters in permission names identify keyboard shortcuts. `Enter` applies
  `Set` by default. Dialogs use Mini Commander's original ASCII frames (`+`, `-`,
  `|`) and standard buttons, including their usual focus highlighting.
  The octal mode updates as you edit. `Set` changes the current file and proceeds
  to the next marked file; `Set all` applies the complete mode to all remaining
  marked files. A changed checkbox gains a `*`; `Insert` or `T` toggles this mark
  independently (`Insert` also advances to the next control). `Marked all`
  copies only these bits, while `Set marked` and `Clear marked` enable or
  disable them across the remaining marked files,
  preserving every other bit. `Esc` or `Cancel` leaves pending changes unapplied.
  Directories are changed without recursion; symbolic links change their targets.
- **Moves across filesystems:** `F6` copies when a rename cannot cross a mount
  boundary, preserves ownership, permissions and timestamps, and removes the
  source only after the complete copy succeeds. Skipped, failed or aborted copies
  leave the source intact. Symbolic links and FIFOs are preserved; hard-linked
  files are copied independently.
- **Stable panel positions:** refreshing preserves the file under each panel's
  cursor and its scroll position. Sorting uses a stable merge sort for large lists.
- **Create nested directories:** `F7` accepts a path such as `projects/demo/src`
  and creates missing parent directories too.
- **Copy progress and controls:** see progress for the current file and the
  whole operation, skip a file, or abort. Error dialogs offer retry and skip
  options; overwrite prompts can apply a choice to the remaining files.
- **Symbolic links and file colors:** link targets are displayed and broken
  links are marked. Executables, selected archive formats, and source files
  have distinct colors. Copying a symbolic link copies the link itself.
  `Ctrl+X`, then `S` creates a symlink, with editable target and link name;
  defaults point to the file under the cursor and place the link in the other
  panel's directory. A relative link name uses the active directory; a relative
  target is stored literally and resolves from the new link's directory.
  Existing entries are not overwritten. `Ctrl+X`, then `Ctrl+S` edits the target
  of the symlink under the cursor, including a broken link, and reports an error
  for other file types. The compact edit dialog has its title in the frame,
  one line identifying the link, a target field, and OK/Cancel buttons.
  Editing replaces the link atomically after preparing
  its replacement; canceling leaves it unchanged. These commands operate on the
  file under the cursor, regardless of marked files.
- **Mouse navigation:** select items, double-click to open directories or run
  executables, and scroll with the wheel in supported terminals. Left dragging
  moves the panel cursor; right clicking toggles a file's selection like `Insert`.
  Right dragging marks or unmarks all crossed rows according to the first item,
  keeping that choice for the whole drag. A drag stays in the panel where it began.
  Dialog buttons such as OK, Cancel, Save, or the sorting choices accept left clicks;
  clicking a text field focuses it and positions the cursor at the clicked character.
- **Monochrome mode:** run `./mc -b` or `./mc --nocolor` to disable colors.

### Less obvious shortcuts

| Shortcut | Action |
| --- | --- |
| `Alt+S`, then type | Jump to a filename by its prefix; press `Alt+S` again while searching for the next match. |
| `Ctrl+Space` | Calculate the size of the directory under the cursor, including its contents (with no other items selected). |
| `Alt+Enter` | Insert the filename under the cursor literally, followed by a space. |
| `Alt+A` | Insert the active panel's directory path literally, with a trailing slash so a filename can be appended. |
| `Alt+P` / `Alt+N` | Previous/next command in the in-memory history; returning past the newest entry restores the unfinished command. |
| `Ctrl+U` | Swap the panels, including paths, sorting, selections, cursors and scroll positions; focus follows the original active panel. In the editor, undo. |
| `Ctrl+X`, then `C` | Edit permissions of the marked files, or the file under the cursor, using checkboxes. |
| `Ctrl+X`, then `S` | Create a symbolic link to the file under the cursor; edit its target and name in a dialog. |
| `Ctrl+X`, then `Ctrl+S` | Edit the target of the symlink under the cursor. |
| `Alt+G` | Go to a directory entered in a dialog; supports relative paths and `~`. |
| `Shift+F5` / `Shift+F6` / `Shift+F7` | Copy, move/rename, or create a directory with the name under the cursor prefilled, without its path. Typing appends to the name; relative targets use the active directory. |
| `Enter` | Execute a typed shell command in the active directory; with an empty command line, open a directory or run an executable. |
| `Ctrl+O` | Temporarily reveal terminal output; press any key to return to the panels. |
| `Ctrl+R` or `F9` | Refresh both panels. |
| `Ctrl+L` | Redraw the screen. |

Press `Alt+A`, then `Alt+Enter` to insert the full path of the file under the
cursor. These shortcuts do not add quotes or escapes; add them manually when needed.

The command line handles a simple `cd` itself: `cd`, `cd ~`, `cd ..`, and quoted
or escaped paths change the active panel. Compound shell commands such as
`cd /tmp && ls` execute in a child shell. Start with `./mc /source /destination`
to open independent initial paths; a single path initializes the left panel.


Usage:

    # Debian/Ubuntu build dependencies:
    sudo apt-get install build-essential libncursesw5-dev

    make
    ./mc

    # Result of compilation is standalone 'mc' binary, it does not need anything else.
    # There is no make install because 'mc' would interfere with midnight commander.
    # So install it manually, for example copy ./mc to your path if you like

Use a UTF-8 terminal and locale to display international file and directory names
correctly, for example `LC_ALL=C.UTF-8 ./mc`. Both builds use Unicode-capable
ncurses (`ncursesw`), and panel labels are shortened without splitting UTF-8
characters. The viewer, editor, dialog text fields, command line, and panel
prefix search support UTF-8, including wide characters and combining accents.
Command-line navigation and deletion operate on complete display characters,
and horizontal scrolling uses terminal columns. Editor search ignores letter case using
the active locale. Files keep their original bytes unless edited; other text
encodings are not converted automatically. Complex joined emoji sequences are
not treated as a single character. Panel prefix search remains case-sensitive.

For a small, fully static 32-bit x86 binary built with musl and ncurses, run
`sh static/build.sh`. The script uses the source archives in `static/sources`,
downloads any missing dependencies, builds and packs `static/mc`, and saves
linking and size reports. Temporary build files are cleaned up afterwards.
See [static build instructions](static/README.md).

#!/usr/bin/env python3
"""Build-time regressions using the real UI and disposable files (Python 3.6+)."""
import errno
import fcntl
import os
from pathlib import Path
import pty
import select
import signal
import struct
import sys
import tempfile
import termios
import time


class Terminal:
    def __init__(self, binary, home, left, right):
        self.output = bytearray()
        self.reaped = False
        self.pid, self.fd = pty.fork()
        if not self.pid:
            fcntl.ioctl(0, termios.TIOCSWINSZ, struct.pack('HHHH', 30, 110, 0, 0))
            env = os.environ.copy()
            env.update(HOME=str(home), TERM='xterm-256color', LC_ALL='C.UTF-8')
            os.chdir(str(home))
            os.execve(str(binary), [str(binary), str(left), str(right)], env)
        try:
            self.until(lambda: b'Quit' in self.output, 'initial panels')
        except BaseException:
            self.close()
            raise

    def read(self, seconds=0.1):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if not select.select([self.fd], [], [], min(0.03, max(0, end-time.monotonic())))[0]:
                continue
            try:
                data = os.read(self.fd, 65536)
            except OSError as error:
                if error.errno == errno.EIO:
                    break
                raise
            if not data:
                break
            self.output.extend(data)

    def until(self, condition, description):
        end = time.monotonic() + 6
        while not condition() and time.monotonic() < end:
            self.read()
        if not condition():
            raise AssertionError('Timed out: ' + description)

    def key(self, value):
        os.write(self.fd, value.encode('utf-8'))
        self.read()

    def alive(self):
        if self.reaped:
            return False
        pid, _status = os.waitpid(self.pid, os.WNOHANG)
        self.reaped = bool(pid)
        return not self.reaped

    def close(self):
        try:
            if self.alive():
                self.key('\x1b[21~')
                self.read(0.2)
            if self.alive():
                os.kill(self.pid, signal.SIGTERM)
                deadline = time.monotonic() + 1
                while self.alive() and time.monotonic() < deadline:
                    self.read(0.05)
            if self.alive():
                os.kill(self.pid, signal.SIGKILL)
                os.waitpid(self.pid, 0)
                self.reaped = True
        finally:
            os.close(self.fd)


def main():
    binary = Path(sys.argv[1]).resolve()
    cases = ('unicode-copy', 'self-copy', 'move', 'symlink-copy', 'edit-save',
             'symlink-edit', 'cancel-overwrite', 'terminal-resize')
    for name in cases:
        with tempfile.TemporaryDirectory(prefix='mini-commander-') as directory:
            root = Path(directory)
            left, right = root/'left', root/'right'
            left.mkdir()
            right.mkdir()
            source = left/'файл.txt'
            payload = b'Original text\n'
            source.write_bytes(payload)
            source.chmod(0o640)
            if name.startswith('symlink-'):
                source.unlink()
                (root/'real.txt').write_bytes(payload)
                (root/'real.txt').chmod(0o640)
                source.symlink_to('../real.txt')
            if name == 'self-copy':
                right = left
            destination = right/source.name
            if name == 'cancel-overwrite':
                destination.write_bytes(b'Existing target\n')
            terminal = Terminal(binary, root, left, right)
            try:
                if name == 'terminal-resize':
                    for rows, cols in ((24, 80), (30, 110)):
                        fcntl.ioctl(terminal.fd, termios.TIOCSWINSZ,
                                    struct.pack('HHHH', rows, cols, 0, 0))
                        terminal.read(0.15)
                        assert terminal.alive(), 'resize terminated the application'
                else:
                    terminal.key('\x1bOB')  # first file, after ..
                    if name in ('edit-save', 'symlink-edit'):
                        terminal.key('\x1bOS')  # F4
                        terminal.key('Ж')
                        terminal.key('\x1bOQ')  # F2
                        terminal.key('\r')
                        expected = 'Ж'.encode('utf-8') + payload
                        terminal.until(lambda: source.read_bytes() == expected, 'UTF-8 save')
                        assert source.stat().st_mode & 0o777 == 0o640
                        if name == 'symlink-edit':
                            assert source.is_symlink() and os.readlink(str(source)) == '../real.txt'
                        terminal.key('\x1b[21~')  # leave editor
                    else:
                        terminal.key('\x1b[17~' if name == 'move' else '\x1b[15~')
                        terminal.key('\r')
                        if name == 'self-copy':
                            terminal.until(lambda: b'same file' in bytes(terminal.output).lower(), 'self-copy refusal')
                            assert source.read_bytes() == payload
                            terminal.key('\r')
                        elif name == 'cancel-overwrite':
                            terminal.key('\x1b')
                            terminal.read(0.2)
                            assert destination.read_bytes() == b'Existing target\n'
                            assert source.read_bytes() == payload
                        elif name == 'symlink-copy':
                            terminal.until(destination.is_symlink, 'link copy')
                            assert os.readlink(str(destination)) == '../real.txt'
                        else:
                            terminal.until(destination.exists, 'destination creation')
                            terminal.until(lambda: destination.read_bytes() == payload, 'file copy')
                            assert destination.stat().st_mode & 0o777 == 0o640
                            if name == 'move':
                                terminal.until(lambda: not source.exists(), 'completed move')
                print('PASS: ' + name, flush=True)
            except BaseException:
                print(bytes(terminal.output).decode('utf-8', 'replace'), file=sys.stderr)
                raise
            finally:
                terminal.close()
    print('Mini Commander: {} terminal/file-operation regressions passed'.format(len(cases)))


if __name__ == '__main__':
    main()

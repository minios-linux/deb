# HANDOFF — orchestrator context for the filin/luftlift Rust port

You are **Claude**, the orchestrator of a multi-hour autonomous task. Your context
was just self-cleared to stay lean. This file is your memory. Read it fully, then
continue. **Keep this file updated every cycle** — it is the single source of truth.

## MISSION
Drive two other AI coding agents to build a clean-room **Rust port of owl (AWDL)
+ opendrop (AirDrop)** for Linux. The human (user) stepped away and wants to
return in a few hours to a *working, tested implementation* without having to read
the C/Python references himself. You do the integration/review; the agents code.

Honest target: the pure-software port (parsers, codecs, protocol, mDNS, TLS, HTTP)
fully implemented + unit-tested + integrated + compiling is achievable. Live
hardware-validated interop with a real Apple device is the one thing that may need
a final hands-on pass with the human present (flaky AWDL-sync-on-USB; needs the
Atheros card + an awake iPhone). Flag that at the end; don't block on it.

## THE SELF-CLEAR LOOP (keep doing this — it's how you survive multi-hour run)
Every cycle:
1. Review both agents (pty-2, pty-3): read screens, approve pending Codex prompts,
   review new commits (`cd /home/user/rust/opendrop && git log --oneline -15`),
   unblock anyone who's stuck/asking, nudge anyone idle to continue their PORT.md.
2. Update THIS file (handoff.md) with the new state (commits done, milestone, any
   blockers/decisions). Commit it: `git add handoff.md && git commit -m "chore(handoff): <state>"`.
3. Schedule the next heartbeat with **ScheduleWakeup** (delaySeconds ~180), prompt =
   "HEARTBEAT: read /home/user/rust/opendrop/handoff.md fully and continue
   orchestrating per it." Then STOP — the wakeup re-fires you fresh, which both
   clears stale context AND reliably makes you re-read this file.
   **DO NOT use `mcp__tttt__tttt_self_inject` for the self-clear.** It dumps text
   into your own stdin without re-reading handoff.md and the submit/enter gets
   dropped — the ScheduleWakeup internal heartbeat is the correct, only mechanism.
Tune the interval up (e.g. 300-600s) if agents need more time per milestone; down
if Codex is blocking on approvals. Cache cost is irrelevant across heartbeats.

**Event-based wake for pty-2 approvals:** a `notify_on_pattern` watcher (`notify-1`,
watching pty-2 for `Would you like to run|Press enter to confirm or esc`) injects a
heartbeat into pty-1 the moment Codex blocks on an approval — so you don't idle the
full ~180s while pty-2 waits. Check it's still registered with
`mcp__tttt__tttt_notify_list`; re-create it (see the notify_on_pattern call) if gone.
This is the ONE sanctioned inject into pty-1 — it's event-triggered + auto-submits,
unlike the broken self_inject self-clear.

## THE AGENTS & TERMINALS (tttt PTYs)
- **pty-1** = YOU (claude, root). Self-inject /clear here.
- **pty-2** = **gpt-5.5** via OpenAI Codex CLI → owns crate **`crates/filin-rs/`**
  (the AWDL/owl port). DRIVING QUIRKS: it's a TUI. To send a prompt: send the text,
  then [ENTER] as a SEPARATE call; sometimes needs a 2ND [ENTER] (it shows "[Pasted
  Content N chars]" then expands; press Enter again to submit). It asks for
  per-command APPROVAL ("Press enter to confirm or esc to cancel" / options 1/2/3) —
  approve with [ENTER] (option 1); use option 2 ("don't ask again for commands
  starting with…") to reduce future prompts. Check it every heartbeat or it blocks.
- **pty-3** = **GLM-5.2** (OpenCode CLI) → owns crate **`crates/luftlift-rs/`**
  (the AirDrop/opendrop port). Runs commands AUTONOMOUSLY (no approval prompts).
  To send a prompt: text then [ENTER]. Reports "paused"/status; nudge it to continue
  if it stops between milestones.
- **pty-7, pty-8** = root shells on the Linux box (for hardware/owl/opendrop testing
  if you get to hardware bring-up). SHORT commands only (long one-liners get mangled).
- **pty-9** = root shell on the MacBook (macOS 15.7.3, awdl0 MAC aa:bb:cc:dd:ee:03 —
  it's the neighbor AWDL master we kept syncing to). Only relevant for hardware tests.

Read a PTY: `mcp__tttt__tttt_pty_get_screen(session_id)`. Wait: `..._wait_for_idle`.
Send: `..._pty_send_keys(session_id, keys)` then a separate `[ENTER]`.

## REPO + CONVENTIONS
- Repo: `/home/user/rust/opendrop` (git, branch `main`, ONE working tree).
- Cargo workspace. Crates: `crates/filin-rs` (gpt-5.5), `crates/luftlift-rs` (GLM-5.2),
  `crates/opendrop-rs` (yours — orchestrator CLI, mostly empty for now).
- **Subdirectory ownership**: each agent edits ONLY its crate. You own the workspace
  `Cargo.toml`, `docs/`, `crates/opendrop-rs/`, and integration. If an agent needs a
  shared dep, hoist it into `[workspace.dependencies]` yourself.
- **TDD with staged commits**: `red(<crate>): …`, `green(<crate>): …`,
  `refactor(<crate>): …`. crate = `filin` or `luftlift`. Verify `cargo test` green.
- Naming (trademark-safe, do NOT revert): crate `filin-rs` (бин `filin`) = "eagle-owl"
  (Russian, riffs on upstream owl). crate `luftlift-rs` (bin `luftlift`) = "air-lift"
  (German). Never name things `awdl-rs`/`airdrop-rs`.

## SPECS & GROUND TRUTH (the agents have these; you point/enforce)
- `ARCHITECTURE.md`, `WORKFLOW.md` — overall design + TDD rules.
- `crates/filin-rs/PORT.md` — filin milestones (radiotap→802.11→AWDL frames→election→
  sync→channel→TX→awdl0).
- `crates/luftlift-rs/PORT.md` — luftlift milestones (dvzip→CPIO→chunked body→plist→
  mDNS/TLS/HTTP handlers→receive).
- `docs/awdl-sync.md` — THE critical lesson: AWDL sync must use radiotap **TSFT
  hardware timestamp**, not host clock (bridge TSF→monotonic via EMA+clamp offset).
- `docs/airdrop-protocol.md` — reverse-engineered iOS-18 details: chunked POSTs (no
  Content-Length), `application/x-dvzip` = framed `[u32 BE len][zlib]`→ODC CPIO
  (magic 070707), links are .webloc files. Reference decoder: `opendrop-patch/dvzip.py`.
- References: `owl/` (C), `opendrop-patch/` (patched Python + dvzip.py).
- Deeper hardware/protocol findings are in project memory (awdl-wifi-hardware.md).

## CURRENT STATE (UPDATE THIS EACH CYCLE)
Last updated: cycle 38 (*** carl9170 WEDGED (USB -110, firmware upload failed) -> FULL REBOOT. See restart-handoff.md ***).
- The carl9170 wedged at USB level: dmesg `usb 3-1: firmware upload failed (-110)` / `Failed to restart device`.
  Tried software re-enumeration (echo 0/1 > /sys/bus/usb/devices/3-1/authorized) — did not recover. Human is
  doing a FULL REBOOT of linux-host, which kills everything (orchestrator, agents, root shells, tttt PTYs).
- *** AFTER REBOOT: read restart-handoff.md — it has the complete rebuild procedure (hardware bring-up, stack
  launch cmds, tttt PTY/agent recreation + re-brief prompts, the loop). Code is committed (HEAD c6fec51) +
  green; binaries on disk; this reboot is ONLY to un-wedge the radio. Resume live-discovery testing. ***
- The cycle-37 discovery fixes (filin announce re-broadcast on social channels ~1s + denser-149 + luftlift 10s
  re-announce) were VERIFIED on-wire but NOT yet confirmed end-to-end against the iPhone (card wedged before the
  retry). That's the first thing to test after the radio is back.
--- PRIOR cycle-37 below ---
Last updated: cycle 37 (announce re-broadcast + denser-149 LIVE & verified on-wire; AWAITING human discovery retry).
- COMMITS: e4873ac fix(filin) re-broadcast cached mDNS announce on each social-channel visit; a43bd3e fix(filin)
  denser social dwell (fill null slots round-robin). filin 113 tests green, clippy clean, release built.
- VERIFIED LIVE (filin pid 1812754 debug): channel dwell now 44=182, 149=87, 6=80, 52=3 (149 way up from 1 slot).
  Re-broadcast firing ~1s: "re-broadcast cached mDNS announce on social channel" on ch149 27x, ch44 127x, ch6 25x.
  So the announce is now on 149 ~1/sec whenever filin is there (was only on luftlift's 10s cadence -> wasted hops
  fixed, per human's insight). luftlift pid 1813068 announcing every 10s.
- STACK on pty-7: filin 1812754 (RUST_LOG=filin_rs=debug), luftlift 1813068 (luftlift_rs=debug,
  LUFTLIFT_DUMP_UPLOAD=/tmp/ldrop_raw, -o /tmp/ldrop). Logs /tmp/fF.log + /tmp/lrF.log.
- AWAITING HUMAN: open iPhone AirDrop sheet -> luftlift should appear now. Then send PHOTO. SUCCESS = Discover/
  Ask/Upload in /tmp/lrF.log + non-empty file /tmp/ldrop + raw /tmp/ldrop_raw/upload-<ts>-iPhone.bin.
- REMINDER (per [[no-hardware-defeatism]]): hardware is proven (received real AirDrops cycles 28/29); failures =
  our software. Keep iterating on filin/luftlift logic, no hardware excuses.
--- PRIOR cycle-36 below ---
Last updated: cycle 36 (filin VISITS 149 but iPhone STILL not in picker = wasted hops; dispatched pty-5 announce re-broadcast + denser 149).
- iPhone opened AirDrop sheet, luftlift STILL not visible despite filin covering 149. DIAGNOSIS (human's insight,
  confirmed): the mDNS announce and the 149 hops don't coincide -> wasted hops. Evidence:
  - 149 in only 1/16 slots: final=[6,149,44,0,0,0,0,0,6,0,44,0,0,0,0,0] (~6% dwell on 149).
  - announce cadence 10s >> hop rate; multicast-spread sends each announce ONCE per channel then drops it, so
    between luftlift's 10s announces every 149 hop carries NO announce.
  - tcpdump awdl0: ZERO inbound mDNS queries from iPhone in 15s (can't rely on query-response either).
  - biggest "peer" [188,5,67,13,80,161] = filin's OWN MAC (loopback). Real external master [146,197,245,67,95,175].
- DISPATCHED pty-5 (idle, ctx ~153K — watch for degradation) FILIN_ANNOUNCE_CADENCE.md:
  A) cache latest multicast mDNS frame, RE-BROADCAST it on every social-channel (6/44/149) visit, rate-limit
     ~1s/channel, expire if stale (decouple discovery from luftlift 10s cadence); transfer-pin still wins.
  B) fill null chanseq slots round-robin 6/44/149 so 149 gets several slots not 1.
- STACK UP (no re-broadcast yet): filin 1806251 (RUST_LOG=filin_rs=debug) + luftlift 1806390 on pty-7.
- NOTE: this is RF/timing optimization over the carl9170 ~0.4%-sync link (the chronic ceiling). If this still
  doesn't land discovery, it may be the hardware ceiling needing the human's hands-on/better-radio pass.
--- PRIOR cycle-35 below ---
Last updated: cycle 35 (CH149 COVERAGE FIX LIVE — filin now tunes to 149; stack restarted; AWAITING human discovery retry).
- COMMITS: 3a83f2f debug(filin) raw chanseq hex+decoded log; e979ae5 fix(filin) cover AWDL social channels
  6/44/149 even when master omits them. filin 103 tests green, clippy clean, release built.
- VERIFIED LIVE: filin debug log now shows channel=149 (66x), 44 (137x), 6 (96x), 52 (23x) — 149 IS covered now.
  Chanseq debug confirms WHY 149 was missing: the only real external master [146,197,245,67,95,175] advertises
  decoded=[6,0,44,0,...] (6/44 only); filin's own anchor seq is 16x44. NO master advertised 149 — social
  coverage injects it. pty-5's decode was correct all along.
- STACK RESTARTED on pty-7 (NEW pids): filin 1806251 (RUST_LOG=filin_rs=DEBUG so channel= + chanseq logs show),
  luftlift 1806390 (RUST_LOG=luftlift_rs=debug, LUFTLIFT_DUMP_UPLOAD=/tmp/ldrop_raw, -o /tmp/ldrop). Logs
  /tmp/fF.log + /tmp/lrF.log.
- AWAITING HUMAN: open iPhone AirDrop sheet -> luftlift should now appear (filin visiting 149). Then send PHOTO.
  SUCCESS = Discover/Ask/Upload in /tmp/lrF.log + non-empty file in /tmp/ldrop + raw capture /tmp/ldrop_raw/
  upload-<ts>-iPhone.bin. If discovery now works but upload stalls again -> transfer-pin tuning (the pin holds
  128ms; bulk transfer needs continuous unicast RX to keep it armed).
--- PRIOR cycle-34 below ---
Last updated: cycle 34 (DISCOVERY REGRESSION: filin covers only ch6/44 never 149; dispatched pty-5 FILIN_CH149_COVERAGE.md).
- After the cycle-33 fixes the iPhone NO LONGER sees luftlift in the picker (it DID in cycle 32). Root-cause
  evidence from filin debug log (`switched monitor channel channel=N`): 167x ch44, 166x ch6, ZERO ch149 across
  333 hops. Real iPhone AirDrop needs the social channel 149. The mDNS announce is healthy + IS spread on-wire
  (tcpdump awdl0 confirmed) — pure CHANNEL-COVERAGE problem. Watched luftlift log 35s w/ sheet open => no Discover.
- WHY: hysteresis (4e91681) stopped the master thrash that was incidentally covering more channels; filin now
  commits to one master whose DECODED seq is only 6/44. Either Bug A's chanseq decode (0674ad1) DROPS 149, or the
  masters truly advertise 6/44 only.
- DISPATCHED pty-5 (idle, 99 tests) FILIN_CH149_COVERAGE.md: add raw-chanseq-hex + decoded-16-slot debug log,
  verify decode vs owl awdl_chan_num (is 149/0x95 dropped?), then fix so filin covers 149 (fix decode, and/or
  spread announce across social channels 6/44/149). TDD, filin-rs only, don't touch running filin pid.
- STACK UP (regressed, no 149): filin 1798331 + luftlift 1798360 on pty-7 (logs /tmp/fF.log /tmp/lrF.log;
  debug filin log was /tmp/fD.log). DO NOT ask human to retry until pty-5's 149 fix is rebuilt+restarted.
- NOTE: avoid restarting filin alone — it recreates awdl0 under luftlift; always restart BOTH (filin then luftlift).
- All cycle-33 fixes still valid (transfer-pin, hysteresis, decode); 149-coverage is the remaining discovery gap.
--- PRIOR cycle-33 below ---
Last updated: cycle 33 (filin transfer-pin + hysteresis + chanseq-decode COMMITTED; stack rebuilt+restarted; AWAITING human photo retry).
- COMMITS: 0674ad1 fix(filin) decode AWDL chanseq encoding to real channels; 4e91681 fix(filin) pin to active-
  transfer peer channel + master-adoption hysteresis. Tree green: filin 99 tests, clippy clean, release built.
- *** LOG-READING CORRECTION (important): the "adopted master channel sequence master=[174,7,157,222,152,95]"
  INFO log prints the 6-byte MASTER MAC ADDRESS (?master), NOT channel numbers. So the earlier "bogus channels
  174/232/245" was a MISREAD — those are randomized Apple master MACs. The real issue was filin FLIP-FLOPPING
  between TWO competing Apple masters, not bad channel decode. Bug A chanseq-decode is still a valid tested fix;
  actual hop channels are decoded separately (not shown in that log). ***
- STACK REBUILT+RESTARTED on pty-7 (NEW pids): filin 1797272, luftlift 1797291 (RUST_LOG=luftlift_rs=debug,
  LUFTLIFT_DUMP_UPLOAD=/tmp/ldrop_raw, -o /tmp/ldrop). Logs /tmp/fF.log + /tmp/lrF.log. VERIFIED: luftlift
  re-announcing every 10s; HYSTERESIS WORKING — master re-adoptions dropped 44/min -> 6/min (still 2 masters
  competing but the transfer-pin should hold channel during an active /Upload).
- AWAITING HUMAN: retry the iPhone photo. SUCCESS = upload completes -> non-empty file in /tmp/ldrop (+ raw
  capture /tmp/ldrop_raw/upload-<ts>-iPhone.bin). If it still stalls, check /tmp/lrF.log for "EOF before
  last-chunk" (still hopping mid-transfer -> transfer-pin not holding) vs a completed Upload.
--- PRIOR cycle-32 below ---
Last updated: cycle 32 (LIVE RE-TEST: picker+decode fixes WORK; NEW blocker = unicast /Upload stalls from filin chanseq thrash; dispatched pty-5).
- LIVE RE-TEST RESULT (iPhone photo, new stack pids filin 1785176 + luftlift 1785200):
  - ✅ PICKER/DISCOVERY now reliable: multiple Discover + 2 Ask (file_count=1) from iPhone; 10s re-announce
    ticking every 10s in /tmp/lrF.log. The picker-drop + 10s + multicast-spread fixes are effectively validated.
  - ✅ DECODE fix proven by its NEW correct behavior: instead of silently saving empty "." file, luftlift now
    logs `connection error error=chunked body: EOF before last-chunk (truncated)` — it correctly detects the
    upload was cut off. /tmp/ldrop + /tmp/ldrop_raw still EMPTY (transfer never completed, so no dump yet).
  - ❌ NEW BLOCKER = unicast /Upload STALLS mid-stream (human: "stalled mid-send", retries got "further" then
    stuck). ROOT CAUSE in /tmp/fF.log: filin re-adopts a master channel sequence ~44x/MIN (every ~1.4s),
    flip-flopping between SEVERAL sequences [174,232,206,171,81,217]/[202,83,223,212,135,216]/[206,71,161,75,
    223,188]/[146,197,245,67,95,175]. Those channel numbers are GARBAGE (not valid Wi-Fi channels) => chanseq
    TLV decode bug. Plus the thrash means filin is never stably co-channel with the iPhone => TLS upload EOFs.
- DISPATCHED pty-5 (GLM filin, idle after 547ec94) via FILIN_TRANSFER_STALL.md, 3 parts:
  A) decode AWDL chanseq ENCODING field to REAL channels (port owl src/channel.c+sync.c) — bogus 174/232/245.
  B) master-adoption hysteresis (stop 44x/min thrash; keep current master unless challenger persistently wins).
  C) PIN to active-transfer peer's channel + suppress hopping/re-adoption while unicast RX from it is recent
     (the human's hypothesis: filin hops away mid-/Upload). Lead with A+C. Separate commits, filin-rs only.
- STACK still UP (old filin 1785176 w/o these fixes). After pty-5 commits: rebuild+restart, human retries photo.
--- PRIOR cycle-31 below ---
Last updated: cycle 31 (ALL 3 FIXES COMMITTED + GREEN + STACK RESTARTED w/ debug+dump — awaiting human iPhone re-test).
- 3 commits landed + tree green (filin 84 + luftlift 104 lib/3 bin tests, clippy clean, release builds):
  - 43e6451 green(luftlift): fix iPhone /Upload decode (chunked truncation + CPIO dir filtering)
  - 71203ba fix(luftlift): re-announce mDNS every 10s instead of 60s
  - 547ec94 fix(filin): spread multicast announce across the channel hop cycle
- STACK RESTARTED on pty-7 (NEW pids): filin 1785176 (-i wlxbc05430d50a1 -c 44 -h awdl0 -N, RUST_LOG=filin_rs=info)
  + luftlift 1785200 (RUST_LOG=luftlift_rs=debug, LUFTLIFT_DUMP_UPLOAD=/tmp/ldrop_raw, -o /tmp/ldrop). Logs:
  /tmp/fF.log (filin), /tmp/lrF.log (luftlift). VERIFIED LIVE: luftlift logs "mDNS re-announcer started
  interval_secs=10" then "mDNS re-announced" exactly 10s later (10s change works). filin adopted master chanseq
  [146,197,245,67,95,175], peer table=2.
- ⚠️ WATCH: that master chanseq [146,197,245,67,95,175] looks odd (earlier good runs were ch 6/44/149). Could be
  opclass-encoded or a chanseq-parse quirk; not blocking (iPhone discovered+transferred before). Confirm via re-test.
- AWAITING HUMAN: re-send a PHOTO from iPhone. Then check: (1) luftlift STAYS in picker (10s re-announce + filin
  multicast spread), (2) the received file is NON-EMPTY in /tmp/ldrop (decode fix), (3) raw capture lands in
  /tmp/ldrop_raw/upload-<ts>-iPhone.bin (run `python3 opendrop-patch/dvzip.py <that>.bin` to cross-check decode).
- TODO (minor, pty-3 later): main.rs:136 comment still says re-announce "(60)" — stale, should say 10.
--- PRIOR cycle-30 below ---
Last updated: cycle 30 (DISPATCHED pty-3 to fix iPhone /Upload decode — chunked truncation + skip dir CPIO entries).
- ACTION THIS CYCLE: wrote LUFTLIFT_UPLOAD_DECODE.md + dispatched pty-3 (GLM luftlift, was idle) to fix the
  empty-"." Upload bug. Two root causes identified from reading the code:
  1. server.rs::read_chunked_stream (~L226) `usize::from_str_radix(...).unwrap_or(0)` SILENTLY treats any
     unparseable chunk-size line as the 0 last-chunk => truncates the iPhone body after the first chunk
     (first zlib block = just the "." CPIO header). Matches the "missing CRLF terminator" WARN + empty file.
  2. read_odc_cpio/decode_upload_body return the leading "." DIRECTORY entry (c_mode S_IFDIR 0o040000) which
     server then tries to write => "Is a directory (os error 21)". Must skip dir entries + "."/"..".
  Also asked pty-3 to add an env-gated raw /Upload body dump (LUFTLIFT_DUMP_UPLOAD=/tmp/upload.bin) so next
  live test we can diff vs `python3 opendrop-patch/dvzip.py`. NOTE: dvzip/CPIO core logic matches the Python
  reference byte-for-byte (verified) — Mac's 2 JPEGs decoded fine; bug is iPhone-chunk-framing specific.
- pty-3 is WORKING on it now (Bug1 chunked-trunc DONE, Bug2 skip-dir DONE, raw-dump in progress, then regr
  test + verify). Refined the dump per human: LUFTLIFT_DUMP_UPLOAD = a DIRECTORY, files named
  upload-<unix_ts>-<sender>.bin (sender from /Ask SenderComputerName, carried via shared state to /Upload).
  pty-2 (gpt-5.5) idle/stood down. notify-1 still armed.
  NEXT HEARTBEAT: check pty-3 committed the fix + tree green (cargo test -p luftlift-rs + clippy). Working tree
  currently does NOT compile = pty-3 mid-edit (expected). Then rebuild+restart luftlift, have human re-send a
  PHOTO from iPhone to re-test. ASK HUMAN what was sent (photo vs link/webloc).
- PICKER-DROP DIAGNOSIS (human asked "after a few min luftlift vanishes from picker — is re-announce working?"):
  YES it works — confirmed ON THE WIRE via `tcpdump -i awdl0 udp port 5353`: caught the re-announce burst at
  12:16:40 + 12:16:41 (announce + RFC6762 §8.3 1s retransmit): PTR luftlift-1763244._airdrop._tcp.local /
  SRV luftlift.local.:8771 / TXT flags=6 / AAAA fe80::a8bb:ccff:fedd:ee01. Running binary HAS the re-announcer.
  Root cause of picker-drop is BELOW mDNS = filin channel-hopping: re-announce is a ~1s burst every 60s; iPhone
  only hears it if filin TXes on the iPhone's listen channel at that instant. Misses -> 120s A/SRV TTL lapses ->
  drops from picker. FIXES: (a) luftlift quick = REANNOUNCE_SECS 60->~10 (mdns.rs const) for more chances;
  (b) filin deep = repeat multicast announce across the full master channel-hop cycle, not once on current chan.
  HUMAN APPROVED BOTH, wants TWO separate commits. DISPATCHED both this cycle:
  - (a) pty-3 luftlift: queued AFTER its /Upload fix as a SEPARATE commit fix(luftlift): re-announce every 10s
    (REANNOUNCE_SECS 60->10 in mdns.rs).
  - (b) pty-5 filin (GLM, idle, fresh 45K ctx, authored 5e221db): FILIN_MULTICAST_SPREAD.md — enqueue each
    multicast frame, TX it on every distinct channel of the adopted master chanseq across one hop cycle (fall
    back to anchor when no master); bounded/aged queue; ONE commit fix(filin): spread multicast announce across
    the channel hop cycle. Dispatched, pty-5 working.
  NEXT HEARTBEAT: watch for THREE commits total — luftlift /Upload fix, luftlift REANNOUNCE 10s, filin multicast
  spread. Then rebuild+restart full stack (filin then luftlift), have human re-send a PHOTO from iPhone, and
  watch the picker stays populated + the file decodes non-empty.
- STACK on pty-7: filin pid 1763226 + luftlift pid 1763244 (full-Rust). To restart: kill both; filin then luftlift.
--- PRIOR cycle-29 below ---
Last updated: cycle 29 (*** FULL-RUST STACK WORKS — but Upload decode yields empty file; live debug w/ human ***).
- *** MILESTONE: the FULL-RUST stack (filin + luftlift, NO owl, zero C code) works at the
  transport level. Swapped owl->filin: an iPhone DISCOVERED luftlift OVER FILIN (the
  multicast-TX fix worked!) and Discover+Ask+Upload all completed, awdl0 RX climbed to
  ~2519 pkts across filin's channel-hopping link. filin's full AWDL data path is validated
  live end-to-end. ***
- *** OPEN BUG (current): the received FILE IS EMPTY. luftlift log: "received file file=.
  bytes=0" + "Upload complete count=1" + "failed to save file=. error=Is a directory".
  The dvzip->CPIO decode only yielded the leading "." dir entry (0 bytes), NOT the real
  file — even though ~2500 pkts of data arrived. iPhone sender, file_count=1, TWICE.
  The Mac's 2 JPEGs decoded FINE earlier (over owl), so this is specific to the iPhone's
  upload / its chunk framing. Earlier saw a "missing CRLF terminator" WARN from the chunked
  body reader — likely the chunked-body reader truncates the real Apple upload (stops after
  the first/"." CPIO entry). ALSO: luftlift should SKIP "." / directory CPIO entries instead
  of trying to save them.
- ASK THE HUMAN: what did you send from the iPhone (photo vs link/webloc vs note)? Then have
  them send a PHOTO to compare (Mac photos worked).
- NEXT ACTIONS:
  1. Dispatch pty-3 (GLM luftlift, idle) to fix the Upload decode: harden the chunked-body
     reader for real Apple uploads (read the FULL multi-chunk body; handle the iPhone's
     chunk framing / the "missing CRLF terminator" case) + SKIP "."/directory CPIO entries
     so real files extract. Write task to a *.md file, point pty-3 at it (don't paste long
     multiline -> it mangles in OpenCode).
  2. Mac never saw luftlift in picker (only iPhone did) = discovery flakiness; chase
     separately (filin channel-hopping vs the Mac's listen windows; reduce contention).
- STACK RUNNING on pty-7 (FULL-RUST): filin pid 1763226 (-i wlxbc05430d50a1 -c 44 -h awdl0
  -N) + luftlift pid 1763244 (= luftlift-1763244 receive -o /tmp/ldrop). owl DOWN. carl9170
  healthy (rebooted; monitor ch44). To restart: kill both; filin then luftlift.
- FIXES committed this session: 6abe69e flush 100-continue (THE unlock for Mac Upload),
  d0c2637 pid-in-ReceiverComputerName, 52f02a1 link-local scope_id send, 5e221db filin
  multicast TX (no peer-gate), 5d4f782 luftlift periodic mDNS re-announce. Tree: filin 75 +
  luftlift 93 tests green, clippy clean.
- PROVEN EARLIER: AirDrop receive over owl+luftlift = real Mac AirDropped 2 valid JPEGs
  (FullSizeRender 333KB + Image 188KB). luftlift send+receive round-trips byte-identical
  (incl 512KB) locally. filin syncs (error_tu 0), channel-hops, peer table.
- ENV: owl/src/election.h PATCHED force-master (not used now since filin is running; revert
  + `make -C owl/build owl` for faithful owl). bluetoothd STOPPED pty-8. pty-5 = GLM filin
  (fresh ctx after /new). pty-3 = GLM luftlift. pty-7 = root hardware shell. Long OpenCode
  prompts -> write to *.md + short "read X and do it" pointer.
--- DEEP HISTORY (older cycles, mostly superseded) below ---

Last updated: cycle 28 (*** SHARING WORKS — real AirDrop receive validated end-to-end! ***).
- *** SUCCESS: a real Mac ("MacBook Pro") AirDropped files -> owl AWDL link ->
  luftlift RECEIVED them: FullSizeRender.jpg (333781 B, valid JPEG 1244x1838) + Image
  21-01-2026.jpeg (188237 B, valid JPEG 990x1150). Upload complete, files saved to
  /tmp/ldrop, images byte-valid. THE FULL AIRDROP RECEIVE PATH WORKS ON REAL HARDWARE. ***
- THE UNLOCK = the 100-continue FLUSH fix: server wrote "HTTP/1.1 100 Continue" but didn't
  flush() through rustls -> Apple sender deadlocked. Adding writer.flush()? fixed it. The
  running luftlift (pid 1741936) has GLM's working-tree fix baked into the release binary
  (that's why it works); GLM committed the flush fix (6abe69e); luftlift 89 tests green
  (89 tests, clippy clean) and WILL COMMIT the flush fix shortly. DO NOT restart luftlift
  until GLM commits (running binary works; a transient rebuild could regress it).
- Setup that worked: owl (force-master patched) on carl9170 ch44 (post-reboot, healthy)
  + luftlift-1741936 receive. Mac AirDrop -> works. (Reduced contention / good RF window.)
- REMAINING (nice-to-have, not blocking the headline win):
  - commit GLM's flush fix (pending).
  - filin multicast-announce TX-gating regression (so the FULL-Rust stack filin+luftlift
    works, not just owl+luftlift). pty-5/filin idle.
  - the carl9170 is still marginal (needed a reboot after 12h; better radio = more
    reliable). Bulk transfers still RF-sensitive but DO complete now.
--- PRIOR cycle-27 below ---
Last updated: cycle 27 (RADIO RECOVERED + stack up; GLM FOUND the /Upload bug = missing flush!).
- *** RADIO RECOVERED *** (human rebooted; carl9170 healthy: monitor ch44 UP, RX works,
  no -110). Stack RUNNING on pty-7: owl(force-master) pid 1741917 peering (3280+ frames,
  2 Apple peers) + luftlift pid 1741936 announced as luftlift-1741936 (picker-name fix
  works). Awaiting human's Mac send (stepped away mid-test; discover=0 so far).
- *** /Upload STALL ROOT CAUSE FOUND (real software regression, NOT just RF): ***
  server.rs Expect:100-continue path writes "HTTP/1.1 100 Continue" but DID NOT flush()
  it — on the TLS path rustls buffers the write internally, so the 100 never reaches the
  Apple sender, which waits forever for it before sending the Upload body => DEADLOCK.
  Exactly matches the live symptom (Mac "Waiting...", awdl0 RX freezes right after /Ask).
  Round-trips passed because our own sender doesn't gate on the 100. FIX = add
  writer.flush()? after the 100 Continue write. GLM (pty-3) finalizing fix + regression
  test (chunked + Expect:100-continue + multi-chunk dvzip). luftlift tests 84->86.
- WHEN GLM COMMITS THE FLUSH FIX: rebuild release (cargo build --release -p luftlift-rs),
  restart luftlift on pty-7, and RETEST the live Mac->luftlift transfer — the Upload now
  has a real chance to complete (was a deadlock, not just slow RF). Radio is healthy now.
- still TODO (filin): multicast-announce TX-gating regression (filin invisible to Apple).
  pty-5 idle. Tree: filin 68 + luftlift 84/86 green. owl patched force-master; bluetoothd
  stopped pty-8.
--- PRIOR cycle-26 below ---
Last updated: cycle 26 (LIVE TEST done + RADIO WEDGED; GLM fixing /Upload stall; picker-name fixed).
*** STATE CHANGE — do NOT try to restart the filin/luftlift stack: the carl9170 RADIO
    IS WEDGED and needs a REBOOT. Interface wlxbc05430d50a1 is GONE. ***
- LIVE TEST RESULTS (improved filin + luftlift vs real Mac/iPhone, over owl force-master):
  - filin CHANNEL HOPPING confirmed working live (monitor ch cycled 6<->44 per master seq;
    "adopted master channel sequence" logs). BUT filin has a REGRESSION: its new AW-gated
    TX gates out the MULTICAST mDNS announce -> NO Apple device sees luftlift under filin
    (owl works). Needs fix: multicast/broadcast frames must NOT be peer-channel-gated.
  - Over owl (force-master): Discover + /Ask WORK reliably (Mac + iPhone saw luftlift,
    Ask auto-accepted). But /Upload STALLS — awdl0 RX bursts then freezes, file never
    lands. Mac shows "almost complete but stuck". Likely causes: (a) marginal carl9170 RF
    (~0.4% sync) under multi-device contention, AND/OR (b) a luftlift /Upload REGRESSION:
    the OLD luftlift's Upload worked earlier; the NEW one (with Expect:100-continue fix
    614818e) stalls. Round-trip passes because our sender doesn't drive Expect:100-continue
    like a real Mac.
- RADIO: after 12h, carl9170 driver WEDGED (dmesg: kthread stack trace + 'writing reg ...
  failed (-110)' USB timeouts). Tried: replug (re-enumerated as Bus1 Dev046 AR9001U but
  no iface), modprobe -r (FATAL: in use, hung kthread), iw del + manual USB rebind -> no
  iface. NEEDS REBOOT. After reboot: re-setup (nmcli set wlxbc05430d50a1 managed no; iw
  set type monitor; ip link up; iw set channel 44) then restart owl(force-master)+luftlift.
- DELEGATED (pty-3 GLM luftlift, per LUFTLIFT_UPLOAD_STALL.md):
  - DONE: d0c2637 PID in ReceiverComputerName (picker shows luftlift-<pid> now).
  - IN PROGRESS: diagnose+fix the /Upload Expect:100-continue + chunked stall (TLS
    header/body boundary suspect) + regression test mimicking an Apple sender.
- STILL TODO (filin, when human/agent available): fix the multicast-announce TX-gating
  regression (the reason filin's luftlift was invisible to Apple). pty-5/filin idle.
- Tree green: filin 68 + luftlift 84 tests, builds. owl still patched force-master;
  bluetoothd stopped pty-8.
--- PRIOR cycle-25 below ---
Last updated: cycle 25 (AUTONOMOUS idle-monitor — all green, idle, ready for human; no change).
- Idle health-checks (cycles 24-25), nothing changed: tree green (filin 68 + luftlift
  84 tests, builds, clippy clean, git clean besides owl force-master patch). Stack
  alive on pty-7 (filin + luftlift receive). Both GLM agents idle/done, no stray
  prompts. No new code work — everything remaining is the human's live Apple test of
  filin channel hopping (see WAKEUP_REPORT.md). Monitoring at 30-min cadence.
--- PRIOR cycle-23 below ---
Last updated: cycle 23 (AUTONOMOUS — luftlift SEND+RECEIVE fully validated locally; scope_id bug fixed).
- *** luftlift FULL send+receive VALIDATED end-to-end (no Apple needed): ***
  - scope_id send bug FIXED + committed (52f02a1 fix(luftlift): set IPv6 scope_id for
    link-local send) — link-local fe80:: peers now get the awdl0 ifindex as scope_id.
  - luftlift->luftlift round-trip COMPLETE: 77B text (incl binary 0x00/0xff) AND 512KB
    random binary both transferred Discover->Ask->Upload and landed BYTE-IDENTICAL
    (md5 match). Full path: find/mDNS -> TLS connect+scope -> dvzip/zlib/ODC-CPIO ->
    chunked upload -> decode -> write. luftlift 84 tests, clippy clean.
  - This validates the SEND client we could never test vs Apple (BLE gap). Protocol is
    correct + robust at realistic size.
- both crates DONE + cross-validated: filin 68 tests (channel hopping etc.), luftlift
  84 tests. Workspace builds + clippy --all-targets clean.
- pty-3 perms granted this session: /proc/net/* and /tmp/* "always allow" (until OpenCode
  restart) so it can run round-trip tests.
- NO more code work to dispatch (audits done, send+receive validated). Remaining is
  Apple-hardware/live only (needs human + active Apple device). Both agents idle.
- WAKEUP_REPORT.md updated with this milestone.
--- PRIOR cycle-22 below ---
Last updated: cycle 22 (AUTONOMOUS — BOTH AUDITS COMPLETE; improved stack running & ready for live test).
- *** BOTH GLM AUDITS DONE. ***
- filin (pty-5, FILIN_AUDIT complete): channel hopping (adopt master chanseq + nl80211
  switch at AW boundaries, revert to anchor when no master), AW-gated data TX, A-MSDU
  decap, unicast same-channel gating + 3-TU guard. 68 tests, clippy clean. Idle.
  Mechanically verified on hardware: NEW build runs STABLE (no crash on live nl80211
  switching); stays on ch44 with no Apple master present (correct — needs an active
  Apple master to adopt a sequence and actually hop). Live hopping test needs an awake
  Apple device. Context ~230K (done; don't re-task — near limit).
- luftlift (pty-3, LUFTLIFT_AUDIT complete): 7 faithfulness fixes — Expect:100-continue
  deadlock, mDNS flags 1->0x06 (iOS-18 default, +--flags CLI), SenderID in /Ask,
  media-caps JSON, 406 x-cpio Content-Type, Connection:close, client skip-1xx. dvzip/
  CPIO/TLS already faithful. 77 tests, clippy clean. Idle. (plist_impl.rs also has
  ReceiverMediaCapabilities/RecordData refinements.)
- WORKSPACE: cargo build --release + clippy --workspace --all-targets clean; filin 68
  + luftlift 77 tests green.
- *** IMPROVED STACK IS RUNNING ON pty-7, READY FOR HUMAN'S LIVE TEST: ***
  filin pid 1706796 (channel-hopping) + luftlift receive pid 1706886 announced as
  luftlift-1706886. When human wakes + opens an Apple AirDrop sheet, it should engage
  with channel hopping + corrected mDNS flags. If stale, restart:
    pkill -f target/release/filin; pkill -f target/release/luftlift; (then re-run both)
  Compare baseline = owl force-master (owl/src/election.h patched; `make -C owl/build owl`).
- See WAKEUP_REPORT.md for the full overnight summary for the human.
- AUTONOMOUS FIND (cycle 22): ran a luftlift->luftlift round-trip (send to the running
  receiver) — exposed a REAL send bug: send to a link-local IPv6 (fe80::) fails
  `POST /Discover -> Error: Invalid argument (os error 22)` because the client builds
  SocketAddrV6 with scope_id=0 (missing the %awdl0 zone). Dispatched fix to pty-3 via
  LUFTLIFT_SEND_BUG.md (set scope_id from -i iface via if_nametoindex). NEXT CYCLE:
  verify fix builds + re-run round-trip (should complete Discover/Ask/Upload, file lands
  in receiver dir) = full luftlift send+receive validated locally w/o Apple. The find +
  mDNS discovery already work (round-trip discovered the receiver fine).
--- PRIOR cycle-21 below ---
Last updated: cycle 21 (AUTONOMOUS — both GLM audits progressing well; tree green).
- filin (pty-5): CHANNEL HOPPING DONE — a4f99a7 adopt master chanseq + switching,
  eb7f579 channel hopping + AW-gated data TX, 3fa3c69 A-MSDU. Now on per-peer
  same-channel unicast TX gating + sync-params TLV field correctness, then final
  FILIN_AUDIT RESULT notes. Tests 66 green, clippy clean. ⚠️ context ~223K (FULL) —
  still coherent/committing but if it stalls or loses thread next cycle, re-nudge via
  a *.md file with the remaining tasks (don't paste long prompts).
- luftlift (pty-3): LUFTLIFT_AUDIT.md written (15.5KB). Real interop fixes landing:
  614818e Expect:100-continue deadlock (Apple sender would hang). Remaining TODO:
  mDNS flags 1->0x06 (flagged "may block discovery" — potentially important!),
  SenderID in Ask builder, ReceiverMediaCapabilities JSON whitespace, 406 response.
  Tests 68 green, clippy clean. Healthy context (~94K).
- Tree: filin 66 + luftlift 68 tests green, both clippy --all-targets clean.
- No hardware test this cycle: Apple AWDL idle (human asleep, nothing to trigger it)
  + pty-5 mid-build. Resume live tests when channel hopping fully lands AND Apple AWDL
  is active on air.
--- PRIOR cycle-20 below ---
Last updated: cycle 20 (AUTONOMOUS — human ASLEEP; two parallel GLM audits running; "make it work well").
- HUMAN ASLEEP, fully autonomous, wants MOST COMPLETE/FAITHFUL impl possible. Don't
  rely on Mac-initiated sends (intermittent + nobody to tap). Keep tree green, commit,
  loop via ScheduleWakeup.
- LIVE TEST RESULT (filin w/ GLM's lower-layer fixes): RX/sync EXCELLENT (error_tu 0,
  peer table works, AwdlTlv=0), BUT luftlift never appears in Mac picker over filin
  (does over owl). ROOT CAUSE = filin stays fixed on ch44, no CHANNEL HOPPING; Apple
  listens across its channel seq (6/44/149) so filin's TX (announce+data) misses the
  Mac's windows. force-master on filin did NOT fix it (tried, reverted) -> the gap is
  channel hopping, not election. owl works because owl hops channels.
- DELEGATED NOW (both GLM-5.2, different crates, no conflict):
  - pty-5 filin: implement CHANNEL HOPPING + AW-gated TX (FILIN_AUDIT.md §7, port owl
    schedule.c/channel.c/sync.c/core.c: switch monitor chan via nl80211 per AW slot,
    gate TX to peer's listen channel), THEN finish all remaining FILIN_AUDIT gaps
    (§6 chanseq opclass, §9 election TLV values, §1 QoS/A-MSDU). Context ~178K (FULL —
    watch for compaction/limits). filin election stays faithful 60/0 as committed.
  - pty-3 luftlift (FRESH context via /new): faithfulness audit per LUFTLIFT_AUDIT_TASK.md
    -> LUFTLIFT_AUDIT.md + fixes (dvzip/CPIO/chunked-HTTP/plist/mDNS-flags/TLS/handlers/
    send), vs opendrop-patch python + docs/airdrop-protocol.md. Only edits luftlift.
  - pty-3 DONE earlier: c088323 fix(luftlift) mDNS goodbye on shutdown (ctrlc) + PID in
    name (luftlift-<pid>) + host_ttl=120. SHORT-TTL CAVEAT: mdns-sd 0.11 hardcodes
    other_ttl=4500 (PTR/TXT linger 75min on crash), setter is pub(crate) — would need a
    3-line mdns-sd vendor patch; deferred (goodbye+PID cover it).
- TOOLING LESSON: long multi-line prompts to OpenCode (pty-3/5) get eval'd by the shell
  / mangle on paste. WRITE the brief to a *.md file and send a SHORT one-line "read X
  and do it" instead. (I crashed pty-3's TUI doing this; relaunched with `opencode`.)
- tree state: filin 61 tests + luftlift 66 tests green, both build. My filin force-master
  test edit REVERTED (committed code faithful). owl still patched force-master
  (owl/src/election.h) + running on pty-7; bluetoothd stopped on pty-8.
--- PRIOR cycle-19 below ---
Last updated: cycle 19 (AUTONOMOUS mode — human napping; force-master WORKED; GLM deep in filin layers).
*** AUTONOMOUS: human asleep (hot weather), I test filin vs hardware on my own.
    Do NOT rely on Mac-initiated sends (need a human tap). Measure objective
    signals: filin sync stability, awdl0 RX climbing (peering), TX frame
    correctness vs owl (pcap diff). ***
- *** KEY FINDING — FORCE-MASTER fixes the data path on a churny link. ***
  Live: with multiple Apple devices (Mac+iPad+AppleTV), owl's elected master
  flip-flopped (13 re-elections, 6 MACs — AWDL MAC-randomization + near-equal
  metrics 511-524 + marginal RX). That churn strangled the unicast data path
  (Mac stuck "Waiting", awdl0 RX~13). FIX: patched owl to advertise a winning
  election (owl/src/election.h: METRIC_INIT 60->2000, COUNTER_INIT 0->2000000;
  rebuilt via `make -C owl/build owl`). owl became sole master -> Mac then
  completed Discover+Ask and STARTED a real file Upload (awdl0 RX 13->210, peer
  got an AirDrop UUID). Transfer was VERY SLOW (carl9170 ~0.4% sync = RF ceiling)
  and didn't survive a cancel. **owl is currently PATCHED (force-master).** Revert
  owl/src/election.h if a faithful owl baseline is needed. filin needs the same
  lesson: a deliberate master strategy (master stability >> being a follower on a
  contended link).
- BLE bootstrap PoC (for luftlift send->Apple): PARKED per human. Proven viable
  (hci0 works, captured 270 real AirDrop adverts type5/Apple-0x4c, broadcast our
  own) but synthetic advert didn't wake the Mac; needs exact-byte replay. Not now.
- DELEGATED NOW:
  - pty-5 (GLM): filin layer audit -> FILIN_AUDIT.md (DONE, 11.9KB) + fixes landed:
    b1f6570 real election, 3cd4cb0 peer table, 7d5e626 MIF-TLV tolerance, d98cb1f
    state aggregation, 2fe41ec wire runtime to election/peer/sync. STILL WORKING:
    sync/AW schedule, AW-gated TX timing + channel hopping, TX content (chanseq
    opclass encoding, real election values). Audit flags these as the peering
    blockers. Don't build/test mid-edit; wait for idle+commit.
  - pty-3 (GLM-5.2 luftlift): fix(luftlift) = 3 parts in one commit: (a) mDNS
    goodbye (TTL=0) on SIGINT/SIGTERM via ctrlc handler; (b) short record TTL (~120s)
    so ungraceful exits self-clear; (c) PID in mDNS instance name ("luftlift-<pid>")
    so picker entries are identifiable per-run. Stops ghost luftlift/linuxdrop entries.
    *** NEXT (human's instruction): when pty-3 finishes the goodbye fix, CLEAR its
    context (OpenCode /new or /clear — full at 135K tokens), then dispatch a fresh
    systematic LUFTLIFT faithfulness audit -> LUFTLIFT_AUDIT.md: compare luftlift-rs
    vs python reference opendrop-patch/ + docs/airdrop-protocol.md byte-for-byte —
    dvzip framing, ODC CPIO encode/decode, chunked HTTP, plist Discover/Ask/Upload
    (req+resp fields), TLS cert/cipher, mDNS TXT/flags/service props, handlers, send
    client. Then fix gaps. Parallels the filin audit; different crate so no conflict
    with pty-5. (Same idea: fresh context = unbiased audit, not rosy self-memory.) ***
- pty-2 (gpt-5.5): idle, stood down off filin.
- HARDWARE state: owl(patched,force-master) was running on pty-7; carl9170
  wlxbc05430d50a1 monitor ch44; bluetoothd stopped on pty-8 (BLE experiment) —
  restart with `systemctl start bluetooth` when done.
--- PRIOR cycle-18 below ---
Last updated: cycle 18 (REFRAME: lower AWDL layers only superficially work; full owl-vs-filin audit underway).
*** Human's call: filin's lower layers (election/sync/schedule/AW-timing/peer-table)
    are hacky/stubbed — they produce plausible numbers but don't actually peer.
    NOT a wrap-up; this is the real work. ***
- TX radiotap header fix (gpt-5.5 commits 59d1fd3/d7680d0): filin now puts frames
  on-air (it RXes its own injected frames = loopback, RX==TX==42). BUT confirmed via
  `tcpdump -i awdl0 'not ether src <ourmac>'` = ZERO inbound from the Mac. So the Mac
  still does NOT peer with filin. Earlier RX climb was filin's own loopback, not the Mac.
- KNOWN-HACKY (from FILIN_TX_DIAGNOSIS.md): filin election uses fixed self-master vals +
  fixed counters; TX timing is blind 110 TU (no availability-window gating); likely NO
  peer table; MIF frames still fail AwdlTlv(TooShort).
- DELEGATED to GLM (pty-5): systematic layer-by-layer owl-vs-filin audit -> FILIN_AUDIT.md,
  then FIX each layer (priority: election -> peer table -> sync/AW schedule -> AW-gated TX
  timing -> MIF TLV -> data path), commit per layer, TDD, keep green. gpt-5.5 (pty-2)
  STOOD DOWN — only GLM edits filin now. Monitor via FILIN_AUDIT.md + git log, not terminal.
- owl module map: election.c, sync.c, schedule.c, channel.c, peers.c, state.c, tx.c,
  rx.c, wire.c, frame.c; daemon/core.c (timers/AW), daemon/io.c (inject w/ radiotap).
- Diagnosis docs on disk (root *.md NOT gitignored but `git add` was being finicky —
  retry committing FILIN_TX_DIAGNOSIS.md / FILIN_RX_DIAGNOSIS_GPT.md / FILIN_AUDIT.md).
- Live test recipe + env unchanged (pty-7 filin+luftlift; pty-9 Mac osascript sheet;
  carl9170 wlxbc05430d50a1 ch44). The transfer is NOT done; data path still broken.
--- PRIOR cycle-17 below ---
Last updated: cycle 17 (data path: Mac won't peer w/ filin; prime suspect = missing TX radiotap header).
- Added periodic PSF/MIF self-announce TX (gpt-5.5 commit 1932ad2) + pcap dump
  (--pcap/FILIN_PCAP, commit 9b44793). filin still SYNCS.
- RETEST: still awdl0 RX=0 / Mac "Waiting". pcap of dropped frames = 55 Action, 3 Probe,
  2 Request, 1 Response, and ZERO frames addressed to our MAC aa:bb:cc:dd:ee:01 — the
  Mac sends filin NOTHING. So peer relationship never forms.
- Can't sniff our own TX (monitor-mode loopback unreliable; tcpdump saw 0 of owl's
  frames even though owl logs 'send MIF'). owl DOES peer with this Mac (its log shows
  RX Service Responses). So the diff must be done at SOURCE level.
- DELEGATED (gpt-5.5, pty-2): source-level owl-vs-filin TX diff -> FILIN_TX_DIAGNOSIS.md
  + fix. PRIME SUSPECT: filin's frame injection likely writes RAW 802.11 with NO
  radiotap TX header, so the carl9170 driver never actually transmits filin's frames
  (inject 'succeeds' but nothing goes on air) -> Mac never hears filin -> no peering.
  Check owl/src/io.c + tx.c (owl prepends a radiotap TX header) vs filin os::packet
  send + runtime TX. Secondary: PSF/MIF TLV byte-correctness, AW timing, election.
- If TX-radiotap-header is the fix, retest should make awdl0 RX climb >0 and complete
  the transfer = FULL Rust stack validated.
--- PRIOR cycle-16 below ---
Last updated: cycle 16 (LIVE: filin SYNCS! data-path TX self-announce is the last gap).
*** LIVE VALIDATION milestones so far ***
- ✅ luftlift received a real photo over a C-owl link (Stage 1). Bug fixed: /Ask
  TransferID optional (3539f53).
- ✅ filin radiotap RX fixed (carl9170 fields/TSFT fallback).
- ✅ filin FCS fix (gpt-5.5, commits fc710ae/a75412d): strip trailing 4B 802.11 FCS
  when radiotap flags&0x10 (carl9170 sets it). THIS made filin SYNC: sync_error ±3 TU,
  0 AWDL errors (was ~5000). Diagnosis race: gpt-5.5 found it (FILIN_RX_DIAGNOSIS_GPT.md);
  GLM/pty-5 stood down. owl ref: rx.c:456-463 strips FCS.
- ✅ mDNS discovery works THROUGH filin: the Mac sees "luftlift" in its picker.
- ❌ LAST GAP — unicast data path: Mac shows "Waiting", awdl0 RX=0 (no data frames
  decapsulated). ROOT CAUSE (confirmed reading runtime::run() lib.rs:1459): the loop
  ONLY receives — it NEVER transmits filin's own PSF/MIF action frames, so the Apple
  peer never registers filin in its AWDL peer table and won't send us unicast data.
  owl announces via timers: owl/daemon/core.c awdl_send_psf/mif/action, owl/src/tx.c
  builds PSF/MIF TLVs.
- IN PROGRESS (gpt-5.5, pty-2): TASK1 add --pcap/FILIN_PCAP dump of dropped RX frames
  (DLT 127 radiotap) for offline analysis [human's idea]; TASK2 add periodic PSF/MIF
  self-announce TX to runtime::run() (poll finite timeout + PSF ~110TU/MIF timers,
  build_action_body + election/sync TLVs, broadcast, inject). Goal: awdl0 RX > 0.
- ALSO KNOWN: MIF action frames now hit AwdlTlv(TooShort) (TLV parser) — lower priority;
  PSF sync already works. Captured MIF frame (64B preview), e.g. from peer aa:bb:cc:dd:ee:02:
  d0 00 00 00 ffffffffffff d2ef397f1d6d 002500ff9473 b02b 7f0017f2 08 10 03 00 ...
- ENV: pty-7 root@linux-host runs filin+luftlift; pty-9 = Mac (osascript opens its
  AirDrop send-sheet for ~90-120s to put AWDL on air); monitor iface wlxbc05430d50a1
  (carl9170 ch44). filin binary: target/release/filin. Live test recipe unchanged.
--- PRIOR cycle-15 detail below ---
Last updated: cycle 15 (LIVE HARDWARE PASS in progress with human — carl9170 + real Apple peer).
*** LIVE VALIDATION (human present, driving pty-7 root shell on linux-host) ***
- HARDWARE: monitor iface = wlxbc05430d50a1 (carl9170, monitor mode ch44). awdl0
  created by filin (or C-owl). Real Apple peer (iPad/Mac "MacBook Pro").
- ✅ luftlift (AirDrop) FULLY VALIDATED end-to-end over a C-owl AWDL link: received a
  real photo IMG_0226.png (568137 B, valid PNG) via Discover->Ask->Upload. Found+fixed
  a real interop bug live: /Ask has NO TransferID from real iOS -> made it optional
  (commit 3539f53 fix(luftlift): accept /Ask without TransferID). Link/webloc sends
  come as Ask file_count=0 + no Upload = KNOWN follow-up (not done).
- 🔧 filin (our AWDL layer) live debugging (Stage 2, swap C-owl -> filin):
  - awdl0 TAP create + MAC + MTU + IPv6 link-local + TX inject all WORK.
  - BUG1 FIXED: radiotap parser only knew present bits 0/1/5, errored on real carl9170
    headers (bits 1,2,3,5,11,14, no TSFT). gpt-5.5 fixed: skip-table + TSFT host-clock
    fallback (commits red/green parse carl9170 radiotap + tsft fallback + tolerate
    unknown fields). 1129->0 radiotap errors live.
  - BUG2 IN PROGRESS: real AWDL action frames (d0, Apple OUI 00:17:f2, ~5000 of them)
    ALL rejected as Awdl(TooShort). RX buf is 4096 (lib.rs:1388) so NOT truncation —
    real frames reach awdl::parse_action_frame (lib.rs:400, needs body>=16) but the
    body slice arrives <16, so the 802.11/AWDL body OFFSET is wrong. Root cause is in
    the runtime RX slicing (radiotap->802.11->action body), diverging from owl/src/rx.c.
  - DELEGATION (human-approved): GLM in pty-5 (fresh OpenCode) owns this fix now —
    comparing owl/src/rx.c + frame.h vs filin, writing diagnosis to repo-root
    FILIN_RX_DIAGNOSIS.md, then implementing the fix (TDD) + cargo build --release.
    Read the FILE (not terminal) for its report. gpt-5.5 (pty-2) STAYS OFF filin to
    avoid edit conflicts. gpt-5.5 already did radiotap fixes (commits up to 0b28a43).
  - NOTE: gpt-5.5 hit usage limit once (~02:18), human reset it. Watch for re-limit.
  - owl reference for AWDL action parse: rx.c awdl_parse_action_hdr (~L234):
    category=0x7f, oui=00:17:f2, version=AWDL_VERSION_COMPAT(=0x10), subtype PSF=0/MIF=3;
    struct awdl_action = category(1)+oui(3)+type(1)+version(1)+subtype(1).
- Live test recipe: kill owl/luftlift/filin; filin -i wlxbc05430d50a1 -c 44 -h awdl0 -N;
  then luftlift -i awdl0 receive -o /tmp/ldrop; human AirDrops a file; watch
  /tmp/ldrop + luftlift log for Discover/Ask/Upload, filin trace for sync_error.
--- earlier ---
Last updated: cycle 14 (DONE — pure-software port complete, verified, reported to human).
*** PRIOR: pure-software port complete, verified, reported. ***
- FINAL VERIFICATION (all green):
  - cargo build --release: clean, both bins (target/release/filin, .../luftlift).
  - cargo test --workspace: 92 passing (filin 28 + luftlift 64).
  - cargo clippy --workspace --all-targets -- -D warnings: clean.
  - filin --help works (accurate startup log, --help restored, -h=host iface).
  - luftlift --help (receive/find/send) + `luftlift find -d N` clean output (NSEC
    spam silenced).
- Both agents reported feature-complete and are standing by. Polish fixes all landed
  (filin 8070a38 help/log; luftlift 35543ad find-noise; filin 93e35b7 clippy).
- Reported success to the human this cycle. The ONE remaining item = live hardware
  interop pass (carl9170 monitor ch44 + awake iPhone); steps in crates/filin-rs/RUN.md.
- opendrop-rs = 16-line stub (optional wrapper; the two crate bins are the deliverable).
- IF the human returns and wants more: (a) live hardware bring-up w/ filin RUN.md;
  (b) luftlift real-fixture test once /tmp/upload.bin exists; (c) opendrop-rs unified
  CLI wrapper; (d) TLS integration test w/ threaded harness. None are blockers.
--- (prior cycle notes below) ---
Last updated: cycle 13 (ENDGAME: both feature-complete; release build+91 tests+clippy GREEN; 3 polish fixes in flight).
- BOTH CRATES FEATURE-COMPLETE. luftlift send landed (real TLS transport + main wiring),
  full peer = send+receive+find. filin done since cycle 11.
- Integration pass RESULTS:
  - `cargo build --release` = clean (both bins).
  - `cargo test --workspace` = 91 green (filin 27 + luftlift 64).
  - `cargo clippy --workspace --all-targets -- -D warnings` = clean (after filin fixed
    2 lints: slice::from_ref + items-after-test-module, commit 93e35b7).
  - `luftlift --help` clean (receive/find/send subcommands); `luftlift find -d 3` works.
- 3 POLISH FIXES DISPATCHED (verify landed next heartbeat, then write report):
  1. filin: restore `--help` long flag (was killed by disable_help_flag for -h host) +
     fix stale "skeleton — see PORT.md" startup log. (pty-2)
  2. luftlift: silence mdns_sd NSEC parse-error spam flooding `find` output (EnvFilter
     mdns_sd::service_daemon=off). (pty-3)
- NEXT: confirm those 3 land + re-run build/test/clippy + re-check `filin --help` and
  `luftlift find`; then WRITE THE SUCCESS REPORT to the human (this is the surface-to-
  human moment per the protocol). Mention opendrop-rs is an empty stub (the two crate
  bins are the deliverable). Live hardware interop = the one remaining manual pass.
--- (prior cycle notes below) ---
Last updated: cycle 12 (91 tests green; filin DONE; luftlift on its LAST milestone — send TLS+main).
- filin: COMPLETE (27 tests, clippy clean, RUN.md done). Standing by. No more work.
- luftlift: send client nearly done — CPIO/dvzip encoders, TLS client cfg, request
  builders + send flow (w/ UTI type map) all green. LAST item in flight: RustlsTransport
  (real TLS stream) + wire `send` into main.rs. 64 tests. Then it's a full peer
  (send+receive+find).
- Tree: 91 tests green (filin 27 + luftlift 64).
- *** NEXT HEARTBEAT = likely ENDGAME ***: once luftlift's send+main lands (watch for
  the green commit + idle), RUN THE INTEGRATION PASS:
    1. cd /home/user/rust/opendrop
    2. cargo build --release            (both bins compile in release)
    3. cargo test --workspace           (all green)
    4. cargo clippy --workspace --all-targets -- -D warnings
    5. ./target/release/filin --help ; ./target/release/luftlift --help
       (and `luftlift find -d 3` is safe/verified; do NOT run receive/awdl0 — no hw)
  Then write the SUCCESS REPORT to the human (see WHEN TO SURFACE): what works +
  tested (parsers/codecs/protocol/mDNS/TLS/HTTP, AWDL election/sync/TSFT bridge/
  channel/TX, AirDrop send+receive+find), how to run each bin, and the ONE remaining
  thing = live hardware interop pass (carl9170 monitor ch44 + awake iPhone; filin
  RUN.md has the steps). Don't claim live-validated — it's compile+unit-tested.
--- (prior cycle notes below) ---
Last updated: cycle 11 (filin COMPLETE incl OS layer; luftlift building send client; 79 tests green).
- filin (gpt-5.5): **DONE through all of PORT.md incl. the real OS layer** — TAP awdl0,
  AF_PACKET RX/TX, netdev ioctls (MAC/MTU1450/up), nl80211 channel set, binary poll
  loop, TAP<->AWDL inject/decap, TSFT-bridged sync-error logging. 27 tests, clippy
  clean, git clean. Idle. Tasked it with one finisher: crates/filin-rs/RUN.md operator
  guide for the hardware pass (then stand by). filin needs NO more feature work.
- luftlift (GLM-5.2): building `send` client (TDD) — sender HTTP done; doing CPIO
  encoder -> dvzip encoder -> TLS client cfg -> request builders -> send orchestration
  -> main wiring. 52 tests. Autonomous.
- Tree: 79 tests green (filin 27 + luftlift 52), both clippy clean.
- ENDGAME now mostly gated on luftlift `send`. When it lands: root `cargo build
  --release` + `cargo test --workspace` + `cargo clippy --workspace -- -D warnings`,
  run `filin --help` / `luftlift --help` / `luftlift find` sanity, then SUCCESS REPORT
  to human (what works + tested, how to run each bin, what needs the hardware pass).
  opendrop-rs is still a near-empty stub — the two crate bins (filin, luftlift) are the
  deliverables; opendrop-rs wrapper is optional, don't block on it.
--- (prior cycle notes below) ---
Last updated: cycle 10 (luftlift RECEIVE+FIND complete; filin awdl0 bringup wired; both finishing).
- luftlift (GLM-5.2): FEATURE-COMPLETE receive path — tls/mdns(announce+browse)/
  server(serve_forever + tested handle_one_connection)/netutil(/proc/net/if_inet6)/
  main CLI (receive -o | find -d | send). `find` VERIFIED working (browses 5s, prints
  peers). All deps crate-local (flate2, plist, rcgen 0.13, rustls 0.23 ring,
  rustls-pemfile, mdns-sd). I nudged it to implement the `send` CLIENT (TLS client +
  POST /Discover//Ask//Upload as x-dvzip) so it's a full peer like opendrop — TDD,
  autonomous. Known non-blockers it flagged: real-fixture test needs /tmp/upload.bin
  (absent here); TLS integration test needs threaded harness; receive needs real
  awdl0+IPv6 (hardware pass).
- filin (gpt-5.5): awdl0 bringup fully wired into binary — nl80211 channel set, link
  bringup, anchor channel, link poll loop; now Ethernet<->AWDL data encap (TX). Tests
  25 pass + the usual in-flight RED. Self-committing via auto-reviewer.
- ENDGAME getting close: when filin's TX encap + RX/TX loop land and luftlift's send
  lands, do the full root build/test/clippy pass + binary --help sanity + success
  report (run instr + awdl0/hardware-pass caveat). opendrop-rs CLI still ~empty —
  decide if it needs a thin wrapper or if the two crate bins suffice (likely suffice).
--- (prior cycle notes below) ---
Last updated: cycle 9 (TREE GREEN 69 tests; filin syscall layer in TDD; luftlift main wiring).
- filin (24 tests): syscall layer underway w/ good discipline — tap-iface-request,
  packet-socket-bind, netdev-ioctl-name all have TESTED planning fns + thin unsafe
  runtime glue (compile-tested). Adding MAC/MTU/flags ioctl helpers next, then the
  actual RX/TX loop + awdl0 creation. NOTE: Codex auto-reviewer now auto-approves
  narrow filin TDD commits (standing authorization) -> fewer pty-2 approval prompts;
  watcher still armed for real questions/blockers.
- luftlift (45 tests, clippy clean): netutil + main.rs receive flow, then find (mDNS
  browse). Near done.
--- (prior cycle notes below) ---
Last updated: cycle 8 (TREE GREEN 62 tests; filin unblocked into HW syscalls; luftlift ~done).
- ***libc = "0.2" added to [workspace.dependencies]*** (commit) to unblock filin's
  tun/AF_PACKET/netlink work. filin uses `libc = { workspace = true }` in its crate.
- filin (gpt-5.5): ALL pure-software done — RX/TX encode+decode, election, sync, TSFT
  bridge, channel, CLI, full injectable 802.11 action frames. 21 tests pass, clippy
  -D warnings clean. Now implementing the REAL awdl0 bring-up (/dev/net/tun + AF_PACKET
  RX/TX + ioctl/netlink) — told to keep raw syscalls in a thin commented unsafe layer
  w/ testable logic factored out. This is the hardware-touching code; compiles != live-
  validated (still needs the carl9170 + iPhone pass with the human).
- luftlift (GLM-5.2): chunked/plist/HTTP/handlers/TLS/mDNS-announce/HTTPS-accept-loop
  ALL green (41 tests). Now: netutil (iface IPv6 link-local resolution) + main.rs
  receive-flow wiring, then sender-side `find` (mDNS browse). Autonomous, no blocker.
- Tree: `cargo test --workspace` = 62 passing, 0 fail. Endgame is close.
- Housekeeping: `.claude/` is untracked (orchestrator/notify cfg) — leave it; don't
  `git add -A`, only add specific files so agents' WIP/.claude don't get co-committed.
--- (prior cycle notes below) ---
Last updated: cycle 7 (filin binary wired w/ honest hw TODO; luftlift on server loop).
- filin (gpt-5.5): + integrated RX (TSFT-required), AWDL data->Ethernet decap, clap
  CLI (-i/-c/-h/-N), binary uses validated config. The ONE remaining gap is the
  hardware-touching bit, honestly stubbed: `TODO(gpt-5.5): open monitor iface and
  create awdl0`. That netlink/rawsock + awdl0 TUN bring-up is THE part for the live
  hardware pass with the human (carl9170 monitor, ch44) — everything feeding it is
  tested. Don't block on it.
- luftlift (GLM-5.2): building handle_one_connection (pure fn: reader->TLS/HTTP/
  handlers->writer) + accept loop = the receive flow. Then wire into main.rs. Close
  to feature-complete. Autonomous, no blocker.
- ENDGAME (when luftlift's server loop + main wiring land): root `cargo build` +
  `cargo test --workspace` + `cargo clippy`; sanity-run both binaries' --help/-N
  dry path; then write success report (run instructions + the awdl0/hw-pass caveat).
--- (prior cycle notes below) ---
Last updated: cycle 6 (filin ALL PORT.md milestones DONE + integrating; luftlift on mDNS).
- filin (gpt-5.5): COMPLETE through PORT.md — parsers, election, sync, TSFT bridge,
  sync-error, channel freq/slot, TX backpressure queue, iface config (awdl0/mon/ch44)
  all green. Now writing INTEGRATED RX tests (radiotap+802.11+AWDL MIF end-to-end,
  TSFT timestamp + RSSI carry-through). Essentially feature-complete; verifying.
- luftlift (GLM-5.2): dvzip, CPIO, chunked, plist, HTTP parser, handlers, **TLS green**
  (543ccd7). Now on mDNS announce (mdns-sd ServiceInfo API), then wire receive flow
  in main.rs. ~2 milestones from feature-complete. Autonomous, no blocker.
- APPROACHING TARGET: once luftlift finishes mDNS + receive-loop wiring, do a full
  workspace integration pass (cargo build/test/clippy at root), wire opendrop-rs CLI
  if needed, then write the success report (how to run + hardware-pass caveat).
--- (prior cycle notes below) ---
Last updated: cycle 5 (filin channel logic DONE; luftlift thrashing rustls 0.23 API — watch).
- filin (gpt-5.5): + sync-error compute, channel<->frequency, channel-slot-for-EAW
  (with %16 wraparound) all green. Stack complete through CHANNEL. Remaining per
  PORT.md: TX (frame build/serialize) + awdl0 interface bring-up.
- luftlift (GLM-5.2): TLS cert-gen — **self-resolving the rustls 0.23 / rcgen 0.13
  churn on its own** (switched to CertificateParams::new(..).self_signed(&key_pair)
  and PrivateKeyDer::Pkcs8(PrivatePkcs8KeyDer::from(serialize_der)) to dodge the
  Clone issue). No injection needed — letting it self-resolve worked. If it regresses,
  the hint was: drop .with_safe_defaults() (gone in rustls 0.23); use
  .with_no_client_auth().with_single_cert(vec![cert_der], key_der)?.
--- (prior cycle notes below) ---
Last updated: cycle 4 (filin sync+TSFT bridge DONE; luftlift on TLS).
- filin (gpt-5.5): election (metric + tie-break) green; sync-update-from-hw-timestamp
  green; **TSFT bridge green** (the critical jitter-rejection / TSF->derived offset —
  matches docs/awdl-sync.md). Next: sync error calc + channel slot logic, then TX/awdl0.
- luftlift (GLM-5.2): /Discover //Ask /Upload handlers green. Now on M5 TLS cert gen
  (rcgen 0.13 generate_simple_self_signed -> rustls ServerConfig), then server loop,
  mDNS announce (mdns-sd), wire receive flow in main.rs. Adding rcgen/rustls to its
  OWN crate Cargo.toml — autonomous, no blocker. If it asks for a SHARED dep, hoist
  to [workspace.dependencies].
- Watch next: luftlift compiling against rcgen 0.13 (API churn risk) — if it thrashes
  on the rcgen API >2 cycles, that's a real blocker worth a nudge with the exact API.
--- (prior cycle notes below) ---
Last updated: cycle 3 (election algo + airdrop handlers underway).
- filin (gpt-5.5): all AWDL TLV parsers (action hdr, TLVs, sync-params, election-v2,
  channel-seq) green. Now into the ELECTION ALGORITHM ('elect higher metric master'
  green); compare_master by (counter, metric). Continuing through election/sync.
- luftlift (GLM-5.2): M3 chunked + M4 plist + M5 HTTP request parser all green. Now
  on M5 handlers (/Discover /Ask /Upload), then TLS(rcgen)+server loop, mDNS, wire
  receive flow in main.rs. Was iterating clippy -D warnings cleanup (lints, not real
  compile errors) — self-resolving, no blocker.
- NOTE on tree health: a workspace `cargo test` will often show a transient RED while
  an agent has written its next red test but not yet the green — and luftlift may
  briefly not compile under -D warnings mid-edit. Only intervene if a crate STAYS
  broken across cycles; otherwise let the owning agent finish its red/green pair.
--- (prior cycle notes below) ---
Last updated: cycle 2 (notify-1 watcher woke me on a pty-2 approval; both agents flying).
- filin (gpt-5.5): action header + AWDL TLVs + sync-params TLV all green; now on
  election-v2 TLV (RED just committed). Steady RED/green pairs, no blockers.
- luftlift (GLM-5.2): M3 chunked-body + M4 plist Discover/Ask done (green). Working
  M4 GREEN plist handlers + M5 (HTTP request parser, TLS rcgen, mDNS, handlers,
  receive loop) per its own todo list. Autonomous, no blockers.
- Tree carries a transient RED failure whenever an agent just committed a red stage;
  that's expected — confirm the matching green lands next cycle.
--- (prior cycle notes below) ---
Last updated: cycle 1 (fixed loop protocol: ScheduleWakeup, NOT self_inject).
- git log so far (newest first):
  - `82ec662 chore(handoff): orchestrator self-clear context (cycle 0)`
  - `529eea6 green(filin): parse radiotap header metadata` (gpt-5.5)
  - `ee15bb2 green(luftlift): odc cpio entry reader` (GLM)
  - `fe338ce red(luftlift): odc cpio entry reader`
  - `0f922b6 rename(crates): awdl-rs -> filin-rs, airdrop-rs -> luftlift-rs`
  - `3a5acbf red(awdl): parse radiotap header metadata`
  - `fb2ec41 green(airdrop): dvzip framed-zlib round-trip`
  - `c4d24db red(airdrop): dvzip framed-zlib round-trip` + scaffold/workflow.
- gpt-5.5 (filin): radiotap done (green). Wrote+committed `red(filin): parse 80211
  mac header` this cycle; now working the AWDL PSF vendor-action-frame parser
  (parse_action_frame, ActionSubtype::Psf, phy_tx/target_tx/TLVs). Continuing
  autonomously through filin PORT.md.
- GLM-5.2 (luftlift): dvzip + ODC CPIO reader done (green). Working autonomously on
  milestones 3→5: chunked HTTP body decode + minimal HTTP/1.1 request parser +
  plist + mDNS/TLS handlers. Read server.py.patched for grounding.
- Tree status: `cargo test` shows 1 expected RED failure (filin 802.11 header test,
  just committed as the red stage); gpt-5.5 is implementing its green now.
- Both on AUTONOMOUS directive (only stop on real blocker: workspace dep [name it],
  cross-crate contract, design fork).

## YOUR PER-HEARTBEAT CHECKLIST
1. `git -C /home/user/rust/opendrop log --oneline -15` — see new commits; sanity
   that they're stage-pure (red=test only, green=impl) and inside the right crate.
2. `cargo build` and `cargo test` at repo root — keep the tree green; if an agent
   broke the build, tell that agent to fix it (don't fix their crate yourself).
3. Read pty-2 screen: approve any pending command; if it asked you a blocker question,
   answer it (e.g., add the dep to workspace Cargo.toml, then tell it to proceed); if
   idle, nudge "continue your next PORT.md milestone, TDD + commits."
4. Read pty-3 screen: if blocked/asking, answer; if idle, nudge likewise.
5. If an agent needs a shared dep: add it to `[workspace.dependencies]` in the
   workspace Cargo.toml yourself, commit `chore(deps): add X`, tell the agent.
6. Update + commit this handoff.md, ScheduleWakeup ~180s, self-inject /clear to pty-1.

## WHEN TO SURFACE TO THE HUMAN (otherwise stay autonomous)
- A genuine design fork that needs his call.
- You've reached a working, tested implementation (report success + how to run +
  what still needs a hardware pass).
- A hard blocker you can't resolve (e.g., an agent is stuck in a loop, a dep won't
  build, or you need hardware he must set up).
Otherwise: keep driving, keep the loop, don't wait for him.

## HARDWARE (only if/when you reach integration & want live validation — optional, late)
- Working radio = **Atheros carl9170** USB, iface `wlxbc05430d50a1` on the Linux box
  (gives ~0.4% AWDL sync). Run owl-equivalent in plain monitor mode, channel 44.
- Realtek `wlx90de80df7307` (rtw88, our patched driver) = backup, marginal/crashy.
- This is the slow/flaky part; do it last and with the human ideally present.

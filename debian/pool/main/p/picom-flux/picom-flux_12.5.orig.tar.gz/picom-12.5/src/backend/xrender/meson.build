srcs += [ files('xrender.c') ]

# partclone-nbd rejects Partclone images with 16 KiB blocks

## Summary

`partclone-nbd` cannot expose some valid Partclone images through Linux NBD.
The reported case is an uncompressed Btrfs image whose Partclone header records
a 16 KiB block size. `partclone-nbd` passes that internal image block size
directly to the kernel as the NBD logical block size. On a conventional x86_64
kernel with 4 KiB pages, the kernel rejects the request with `EINVAL`.

This is not a compression or image-integrity failure. The image can pass
Clonezilla/Rescuezilla verification and still fail before the exported NBD
device becomes usable.

## Status

- Severity: major for affected images; Image Explorer is unavailable.
- Scope: confirmed for a Btrfs Partclone image with `block_size = 16384`.
- Upstream version: `0.0.3` at commit
  `7bb76d5892ec69654822a04718a91f9378b02589`.
- Rescuezilla `wip`: affected. Its two additional commits only add CPack
  metadata and documentation; `src/` and `include/` are identical to upstream.
- MiniOS package: `0.0.3-2` is affected because it intentionally packages the
  unmodified upstream program.
- Fix: implemented in `0.0.4` and qualified on Debian 13 with Linux 6.12.

## External Report

Rescuezilla issue 523 contains the original field report:

<https://github.com/rescuezilla/rescuezilla/issues/523>

Observed output:

```text
Processing partclone image with partclone-nbd:. Running: partclone-nbd -d /dev/nbd2 -c /dev/nbd1
[ INF ] Bitmap type is "bit".
[ INF ] Image loaded.
[ ERR ] Failed to send image block size (16384): Invalid argument.
```

The report used Rescuezilla 2.5.1 and an uncompressed backup of an Arch Linux
Btrfs filesystem. Another user reported that equivalent ext4 backups did not
show the failure.

## Reproduction

Prerequisites:

- a Partclone image whose header contains `block_size = 16384`;
- an unused `/dev/nbdN`;
- Linux NBD support;
- sufficient privileges to configure the NBD device.

For a directly readable, uncompressed image:

```sh
modprobe nbd
partclone-nbd -d /dev/nbd2 -c /path/to/btrfs.partclone-image
```

For a Clonezilla split or compressed image, first expose the joined and decoded
Partclone byte stream as an NBD source, then pass that source to
`partclone-nbd`:

```sh
partclone-nbd -d /dev/nbd2 -c /dev/nbd1
```

Expected result:

- `/dev/nbd2` is configured read-only with the source filesystem's exact byte
  capacity and can be mounted read-only.

Actual result:

- `NBD_SET_BLKSIZE` returns `EINVAL`;
- `partclone-nbd` exits before setting device capacity or entering its request
  loop;
- no filesystem can be mounted.

## Root Cause

### Partclone image metadata

`src/image.c` reads the Partclone header's internal block size into
`img->block_size` for both supported image formats:

```c
img->block_size = head.v1.block_size;
img->block_size = head.v2.block_size;
```

That value is correctly used by the image decoder to interpret the bitmap and
locate data inside the Partclone stream.

### Incorrect NBD configuration

`src/nbd.c` also uses the same value as the NBD device's logical and physical
block size:

```c
ioctl(device_sock, NBD_SET_BLKSIZE, img->block_size)
```

These are separate concepts. The Partclone block size describes the sparse
image format. The NBD block size describes the exported block device's I/O
geometry and must satisfy Linux block-layer constraints.

The Linux NBD driver handles `NBD_SET_BLKSIZE` through `nbd_set_size()`, which
calls `blk_validate_block_size()`. Current Linux defines a valid block size as
a power of two between 512 bytes and `BLK_MAX_BLOCK_SIZE`. Without the relevant
transparent-huge-page build option, `BLK_MAX_BLOCK_SIZE` is `PAGE_SIZE`.
Therefore a 16 KiB value is rejected on the common 4 KiB-page x86_64 kernel.

Relevant Linux sources:

- <https://github.com/torvalds/linux/blob/master/drivers/block/nbd.c>
- <https://github.com/torvalds/linux/blob/master/include/linux/blkdev.h>

The failure occurs at `NBD_SET_BLKSIZE`, before the subsequent
`NBD_SET_SIZE_BLOCKS` call. A later Rescuezilla comment suggests incorrect
512-byte padding as a possible cause of broader Image Explorer failures. That
may be a separate size/alignment problem, but it cannot explain this exact
error because the kernel has already rejected the block-size ioctl.

## Why Decoupling Is Feasible

The request worker does not require NBD requests to equal or align to
`img->block_size`. It receives byte offsets and byte lengths, then translates
them into Partclone blocks:

```c
u64 block = seek / img->block_size;
u32 offset = seek % img->block_size;
```

It also loops across Partclone block boundaries until the requested byte count
has been served. This suggests that the exported NBD device can use a smaller
logical block size while retaining the original `img->block_size` solely for
image decoding. This must still be confirmed by integration tests before a fix
is released.

## Proposed Fix Direction

Do not overwrite or reinterpret `img->block_size`. Introduce a separate NBD
logical block size that is valid for the running kernel, for example 4096 when
the device size is 4096-byte aligned and 512 otherwise.

Configure capacity from the exact byte size in the Partclone header:

```c
ioctl(device_sock, NBD_SET_BLKSIZE, nbd_block_size);
ioctl(device_sock, NBD_SET_SIZE, img->device_size);
```

Do not continue using `NBD_SET_SIZE_BLOCKS` with `img->blocks_count` after the
NBD and Partclone block sizes have been separated. That ioctl multiplies its
argument by the configured NBD block size and would report the wrong capacity.

This direction has two intended properties:

1. Partclone parsing continues to use the original 16 KiB block size.
2. Linux sees a conventional NBD geometry and the exact source-device capacity.

The final implementation must check every ioctl result and clean up the NBD
socket/device on all failure paths.

## Required Regression Tests

Unit-level tests alone are insufficient because the failure comes from a real
kernel ioctl. Qualification must include all of the following on Debian 13:

1. Build a Btrfs fixture that produces a Partclone v2 image with a 16 KiB
   header block size, or retain a minimal redistributable fixture with that
   metadata.
2. Confirm the unpatched binary fails at `NBD_SET_BLKSIZE` with `EINVAL`.
3. Connect the patched binary to a real `/dev/nbdN`.
4. Assert the exported device is read-only.
5. Assert `blockdev --getsize64` equals the Partclone header's `device_size`.
6. Mount the filesystem with `ro,nosuid,nodev,noexec`.
7. Read a fixture file and compare its SHA-256 digest.
8. Read data spanning both NBD and Partclone block boundaries.
9. Disconnect and assert no mount, process, NBD PID, nonzero NBD size, socket,
   or runtime journal remains.
10. Repeat existing ext4 tests for uncompressed, gzip, and xz streams to prevent
    regressions in already qualified images.

Additional coverage should exercise 512-byte fallback capacity, a device size
that is not 4096-byte aligned, malformed non-power-of-two header values, and
Partclone image formats 0001 and 0002.

## Temporary Product Mitigation

Until a kernel-backed regression test qualifies a fix:

- do not claim that every Partclone or Btrfs image is supported by Image
  Explorer;
- reject a selected image before NBD attachment when its Partclone header block
  size exceeds the supported exported NBD size;
- show an actionable message explaining that backup verification and restore
  remain separate from file browsing;
- preserve normal restore support rather than treating the valid backup as
  corrupt.

Compression does not remove the limitation. Uncompressed, gzip, and xz streams
all eventually present the same decoded Partclone header to `partclone-nbd`.

## Acceptance Criteria

The bug can be closed only when:

- a 16 KiB-block Btrfs Partclone image completes connect, status, read, mount,
  unmount, and disconnect on a 4 KiB-page Debian 13 kernel;
- exact byte capacity and read-only state are verified;
- cleanup leaves no NBD association or backend process;
- existing ext4 none/gzip/xz tests continue to pass;
- package and program versions identify the fixed source revision accurately.

## Resolution

Version `0.0.4` separates the Partclone image block size from the NBD logical
block size. It uses 4096-byte NBD blocks for aligned capacities, falls back to
512 bytes otherwise, and configures exact byte capacity with `NBD_SET_SIZE`.

Qualification was completed on Debian 13 with a 4 KiB-page Linux 6.12 kernel:

- a Partclone 0.3.36 Btrfs v2 image with a 16 KiB image block size connected,
  mounted read-only, and returned matching SHA-256 fixture data;
- reads crossing NBD and Partclone boundaries and reads of the final exported
  block completed successfully;
- both CRC32 and no-data-checksum Partclone images passed;
- a valid 512-byte-block raw image with a capacity not aligned to 4096 bytes
  exported its exact capacity using the 512-byte fallback;
- disconnect left zero NBD capacity, no kernel NBD PID, mount, or backend
  process;
- corrupted v2 header and bitmap CRC32 values were rejected before export.

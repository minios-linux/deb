/* Copyright © 2015-2016 Przemysław Kusiak
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the “Software”), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#include "partclone.h"
#include "options.h"
#include "log.h"
#include "image.h"
#include "io.h"
#include "crc.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <errno.h>
#include <string.h>

#include <stdlib.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/fs.h>

#define IMAGE_OPTIONS_V2_SIZE 18
#define CHECKSUM_NONE 0x00
#define CHECKSUM_CRC32 0x20
#define CHECKSUM_XXH64 0x30
#define CHECKSUM_XXH128 0x31

/* ----------------- INITIALIZATION  ----------------- */

struct new_header
{
    u8  magic[16]; // "partclone-image"
    u8  partclone_version_str[14]; // ex. "2.61"
    u8  image_version_str[4]; // "0002" (without terminating null)
    u16 endianess_checker; // ENDIANNESS_COMPATIBLE or ENDIANNESS_INCOMPATIBLE
    u8  fs_string[16]; // file system string
    u64 device_size; // size of source device in bytes
    u64 blocks_count; // number of blocks in the filesystem
    u64 used_blocks_filesystem; // used blocks (reported by filesystem)
    u64 used_blocks_bitmap; // used blocks (reported by bitmap)
    u32 block_size; // number of bytes in each block
    u32 feauture_size; // size of fields under bytes_per_block
    u16 image_version; // version of image (as in image_version_str)
    u16 cpu_bits; // partclone architecture (32-bit - 32, 64-bit - 64)
    u16 checksum_mode; // checksum algorithm used (CHECKSUM_CRC32 etc.)
    u16 checksum_size; // size of one checksum (ex. CHECKSUM_CRC32 - 4)
    u32 blocks_per_checksum; // how many blocks are checksumed
    u8  reseed_checksum; // reseed checksum after write (1 - yes, 0 - none)
    u8  bitmap_mode; // kind of bitmap (BM_BIT, BM_BYTE etc.)
    u32 crc32; // crc32 of fields above
} __attribute__ ((packed));

struct old_header
{
    u8  magic[15]; // "partclone-image" (without terminating null)
    u8  fs_string[15]; // file system string
    u8  image_version_str[4]; // "0001" (without terminating null)
    u8  padding[2];
    u32 block_size; // number of bytes in each block
    u64 device_size; // size of source device in bytes
    u64 blocks_count; // number of blocks in the filesystem
    u64 used_blocks; // used blocks
    u8  options[4096]; // not used
} __attribute__ ((packed));

union header
{
    struct old_header v1;
    struct new_header v2;
} __attribute__ ((packed));

static inline status load_byte_bitmap(struct image *img);
static status compute_additional_blocks(const struct image *img, u64 *additional_blocks);
static status load_bit_bitmap(struct image *img);
static status load_none_bitmap(struct image *img);
static status validate_backing_range(int fd, u64 offset, u64 length);
static status validate_data_range(const struct image *img);
static u64 bitmap_blocks_set(const struct image *img);

status load_image(struct image *img, struct options *options)
{
    /* -------------------- OPEN IMAGE FILE -------------------- */

    memset(img, 0, sizeof(*img));
    img->fd = -1;
    img->path = options->image_path;

    img->fd = open(img->path, O_RDONLY);

    if(img->fd == -1) {
        log_error("Cannot open image file: %s.", strerror(errno));
        goto error_1;
    } else {
        log_debug("Image file opened.");
    }

    if(lseek(img->fd, 0, SEEK_CUR) == -1) {
        log_error("Image must be seekable: %s.", strerror(errno));
        goto error_2;
    }

    if(options->elems_per_cache == 0) {
        log_error("Bitmap cache element size must not be zero.");
        goto error_2;
    }

    if(validate_backing_range(img->fd, 0, 34) == error) {
        goto error_2;
    }

    /* -------------------- LOAD DATA FROM IMAGE HEADER -------------------- */

    union header head;

    memset(&head, 0, sizeof(head));

    if(read_whole(img->fd, &head, 34) == error) {
        log_error("Cannot read image header: %s.", strerror(errno));
        goto error_2;
    } else {
        log_debug("Image header read.");
    }

    if(memcmp(head.v1.magic, "partclone-image", 15) != 0) {
        log_error("Incorrect image signature.");
        goto error_2;
    } else {
        log_debug("Correct image signature.");
    }

    if(memcmp(head.v1.image_version_str, "0001", 4) == 0) {
        if(validate_backing_range(img->fd, 0, sizeof(struct old_header)) == error ||
           set_file_offset(img->fd, 0, SEEK_SET) == error ||
           read_whole(img->fd, &head.v1, sizeof(head.v1)) == error) {
            log_error("Cannot read image header: %s.", strerror(errno));
            goto error_2;
        }
    } else if(memcmp(head.v2.image_version_str, "0002", 4) == 0) {
        if(validate_backing_range(img->fd, 0, sizeof(struct new_header)) == error ||
           set_file_offset(img->fd, 0, SEEK_SET) == error ||
           read_whole(img->fd, &head.v2, sizeof(head.v2)) == error) {
            log_error("Cannot read image header: %s.", strerror(errno));
            goto error_2;
        }
        if(~count_crc32(&head.v2, sizeof(head.v2) - sizeof(head.v2.crc32), 0) !=
           head.v2.crc32) {
            log_error("Invalid image header checksum.");
            goto error_2;
        }
    }

    if(memcmp(head.v1.image_version_str, "0001", 4) == 0) {

        log_debug("Detected supported image version 0001.");

        if(head.v1.blocks_count == 0 || head.v1.block_size == 0 ||
           head.v1.block_size > 64 * 1024 * 1024 ||
           head.v1.device_size == 0 ||
           head.v1.used_blocks > head.v1.blocks_count) {
            log_error("Invalid image geometry.");
            goto error_2;
        }

        img->bitmap_offset = sizeof(struct old_header);
        if(!checked_add_u64(head.v1.blocks_count, 8, &img->bitmap_disk_size) ||
           !checked_add_u64(img->bitmap_offset, img->bitmap_disk_size,
                            &img->data_offset)) {
            log_error("Image geometry is too large.");
            goto error_2;
        }

        img->blocks_count = head.v1.blocks_count;
        img->version = v1;
        img->block_size = head.v1.block_size;
        img->device_size = head.v1.device_size;
        img->used_blocks = head.v1.used_blocks;
        img->bitmap_elements_in_cache_element = options->elems_per_cache;

        /* 0001 images used corrupted checksum implementation - the first byte was
         * computed over and over again. To avoid a waste of time, checksum is
         * ignored.
         */

        img->chkmode = ignore;
        img->checksum_size = 4; /* CRC32 size */
        img->blocks_per_checksum = 1;
        img->bmpmode = byte;

        log_debug("Header data loaded.");


    } else if(memcmp(head.v2.image_version_str, "0002", 4) == 0) {

        log_debug("Detected supported image version 0002.");

        if(head.v2.endianess_checker != ENDIANNESS_COMPATIBLE) {
            log_error("Image byte order is incompatible.");
            goto error_2;
        }

        u16 expected_checksum_size;
        switch(head.v2.checksum_mode) {
        case CHECKSUM_NONE:   expected_checksum_size = 0; break;
        case CHECKSUM_CRC32:  expected_checksum_size = 4; break;
        case CHECKSUM_XXH64:  expected_checksum_size = 8; break;
        case CHECKSUM_XXH128: expected_checksum_size = 16; break;
        default:
            log_error("Unsupported image checksum mode.");
            goto error_2;
        }

        if(head.v2.feauture_size != IMAGE_OPTIONS_V2_SIZE ||
           head.v2.image_version != 0x0002 ||
           (head.v2.cpu_bits != 32 && head.v2.cpu_bits != 64) ||
           head.v2.reseed_checksum > 1 ||
           head.v2.checksum_size != expected_checksum_size ||
           head.v2.blocks_count == 0 || head.v2.block_size == 0 ||
           head.v2.block_size > 64 * 1024 * 1024 ||
           head.v2.device_size == 0 ||
           ((head.v2.checksum_size == 0) != (head.v2.blocks_per_checksum == 0)) ||
           head.v2.used_blocks_bitmap > head.v2.blocks_count ||
           (head.v2.bitmap_mode != bit && head.v2.bitmap_mode != byte &&
            head.v2.bitmap_mode != none) ||
           (head.v2.bitmap_mode == none &&
            head.v2.used_blocks_bitmap != head.v2.blocks_count)) {
            log_error("Invalid image geometry.");
            goto error_2;
        }

        img->bitmap_offset = sizeof(struct new_header);
        if(head.v2.bitmap_mode == bit) {
            if(!checked_divide_up_u64(head.v2.blocks_count, 8,
                                       &img->bitmap_disk_size)) {
                log_error("Invalid image geometry.");
                goto error_2;
            }
        } else if(head.v2.bitmap_mode == byte) {
            img->bitmap_disk_size = head.v2.blocks_count;
        } else {
            img->bitmap_disk_size = 0;
        }

        /* Version 0002 stores a CRC32 after BIT and BYTE bitmaps. */
        if((head.v2.bitmap_mode != none &&
            !checked_add_u64(img->bitmap_disk_size, sizeof(u32),
                             &img->bitmap_disk_size)) ||
           !checked_add_u64(img->bitmap_offset, img->bitmap_disk_size,
                             &img->data_offset)) {
            log_error("Image geometry is too large.");
            goto error_2;
        }

        img->blocks_count = head.v2.blocks_count;
        img->version = v2;
        img->blocks_per_checksum = head.v2.blocks_per_checksum;
        img->block_size = head.v2.block_size;
        img->bmpmode = head.v2.bitmap_mode;
        img->checksum_size = head.v2.checksum_size;
        img->device_size = head.v2.device_size;
        img->used_blocks = head.v2.used_blocks_bitmap;
        img->bitmap_elements_in_cache_element = options->elems_per_cache;

        log_debug("Header data loaded.");

    } else {

        log_error("Image version unsupported.");
        goto error_2;
    }

    if(validate_backing_range(img->fd, img->bitmap_offset,
                              img->bitmap_disk_size) == error) {
        goto error_2;
    }

    /* -------------------- DISPLAY DATA FROM IMAGE HEADER -------------------- */

    log_debug("%s", "");
    log_debug("Information from header:");
    log_debug("- device size: " fu64 " bytes", img->device_size);
    log_debug("- blocks count: " fu64, img->blocks_count);
    log_debug("- used blocks: " fu64, img->used_blocks);
    log_debug("- block size: " fu32 " bytes", img->block_size);
    log_debug("- checksum size: " fu16 " bytes", img->checksum_size);
    log_debug("- blocks per checksum: " fu32, img->blocks_per_checksum);
    log_debug("%s", "");

    /* -------------------- LOAD BITMAP -------------------- */

    switch (img->bmpmode)
    {
    case bit:
        log_info("Bitmap type is \"bit\".");

        if(load_bit_bitmap(img) == error) {
            goto error_2;
        }

        break;
    case none:
        log_info("Bitmap type is \"none\".");

        if(load_none_bitmap(img) == error) {
            goto error_2;
        }

        break;
    case byte:
        log_debug("Bitmap type is \"byte\".");

        if(load_byte_bitmap(img) == error) {
            goto error_2;
        }

        break;
    default:
        log_error("Unsupported bitmap type.");
        goto error_2;
    }

    /* -------------------- LOAD CACHE -------------------- */

    u64 cache_elements;

    if(!checked_divide_up_u64(img->bitmap_elements,
                              img->bitmap_elements_in_cache_element,
                              &cache_elements) ||
       !u64_to_size(cache_elements, &img->cache_elements) ||
       !checked_mul_u64(cache_elements, sizeof(*img->cache_ptr), &cache_elements) ||
       !u64_to_size(cache_elements, &img->cache_size)) {
        log_error("Bitmap cache is too large.");
        goto error_3;
    }

    log_debug("Memory required by cache array: " fu64 ".", img->cache_size);

    img->cache_ptr = calloc(img->cache_elements, sizeof(*img->cache_ptr));

    if(img->cache_ptr == NULL) {
        log_error("Allocation failed.");
        goto error_3;
    } else {
        log_debug("Memory for bitmap cache allocated.");
    }

    u64 i, j;
    u64 *cache_ptr = img->cache_ptr;
    u64 *bitmap_ptr = img->bitmap_ptr;

    *cache_ptr = 0;

    for (i = 1; i < img->cache_elements; i++) {

        *(cache_ptr + 1) = *cache_ptr;
        cache_ptr++;

        for (j = 0; j < img->bitmap_elements_in_cache_element; j++) {
            *cache_ptr += popcount(*bitmap_ptr++);
        }
    }

    log_debug("Cache created.");
    
    /* -------------------- OFFSET -------------------- */

    if(validate_data_range(img) == error) goto error_4;

    if(initialize_offset(img) == error) goto error_4;

    log_info("Image loaded.");
    return ok;

    /* -------------------- ERROR HANDLING -------------------- */

error_4:

    free(img->cache_ptr);

error_3:

    free(img->bitmap_ptr);
    log_debug("Memory allocated by bitmap released.");

error_2:

    if(close(img->fd) == -1) {
        log_error("Cannot close image file: %s", strerror(errno));
    } else {
        log_debug("Image file closed.");
    }

error_1:
    log_error("Cannot load image.");
    return error;
}

status close_image(struct image *img)
{
    free(img->cache_ptr);
    free(img->bitmap_ptr);

    log_debug("Memory allocated by bitmap and cache released.");

    if(close(img->fd) == -1) {
        log_error("Cannot close an image file: %s.", strerror(errno));
        return error;
    } else {
        log_debug("Image file closed.");
    }

    return ok;
}

// Device is larger than blocks area (NTFS)? Create empty blocks.
static status compute_additional_blocks(const struct image *img, u64 *additional_blocks)
{
    u64 blocks_area_size;

    if(!checked_mul_u64(img->blocks_count, img->block_size, &blocks_area_size)) {
        log_error("Image geometry is too large.");
        return error;
    }

    if(blocks_area_size < img->device_size) {
        if(!checked_divide_up_u64(img->device_size - blocks_area_size,
                                  img->block_size, additional_blocks) ||
           !checked_add_u64(img->blocks_count, *additional_blocks,
                             &blocks_area_size)) {
            log_error("Image geometry is too large.");
            return error;
        }
        log_debug("Blocks area size is smaller than device size.");
        log_debug("Creating " fu64 " additional blocks.", *additional_blocks);
    } else {
        *additional_blocks = 0;
        log_debug("Blocks area size is equal to device size.");
    }

    return ok;
}

static status load_byte_bitmap(struct image *img)
{
   /* -------------------- MAP BYTEMAP TO MEMORY -------------------- */

    u8 *bytearray_ptr;
    size_t length;
    u64 map_length;

    if(!checked_add_u64(img->bitmap_offset, img->bitmap_disk_size, &map_length) ||
       !u64_to_size(map_length, &length)) {
        log_error("Bytemap is too large to map.");
        goto error_1;
    }

    bytearray_ptr = mmap(NULL, length, PROT_READ, MAP_SHARED, img->fd, 0);

    if(bytearray_ptr == MAP_FAILED) {
        log_error("Cannot map bytemap to memory: %s.", strerror(errno));
        goto error_2;
    }

    u8 *bytearray = bytearray_ptr + img->bitmap_offset;

    log_debug("Bytemap mapped to memory.");

    /* -------------------- CHECK BITMAP SIGNATURE -------------------- */

    if(img->version == v1 &&
       memcmp(bytearray + img->blocks_count, "BiTmAgIc", 8) != 0) {
        log_error("Incorrect bitmap signature.");
        goto error_3;
    } else {
        log_debug("Correct bitmap signature.");
    }

    /* ------------------ ALLOCATE MEMORY FOR BITMAP ----------------- */

    u64 additional_blocks;
    u64 bitmap_blocks;
    u64 bitmap_bytes;

    if(compute_additional_blocks(img, &additional_blocks) == error ||
       !checked_add_u64(img->blocks_count, additional_blocks, &bitmap_blocks) ||
       !checked_divide_up_u64(bitmap_blocks, 64, &bitmap_blocks) ||
       !u64_to_size(bitmap_blocks, &img->bitmap_elements) ||
       !checked_mul_u64(bitmap_blocks, sizeof(*img->bitmap_ptr), &bitmap_bytes) ||
       !u64_to_size(bitmap_bytes, &img->bitmap_size)) {
        log_error("Bitmap is too large.");
        goto error_3;
    }

    log_debug("Memory required by bitmap: " fu64 ".", img->bitmap_size);

    img->bitmap_ptr = calloc(img->bitmap_elements, sizeof(*img->bitmap_ptr));

    if(img->bitmap_ptr == NULL) {
        log_error("Cannot allocate memory for bitmap.");
        goto error_1;
    } else {
        log_debug("Memory for bitmap allocated.");
    }

    /* -------------------- CREATE BITMAP FROM BYTEMAP -------------------- */

    for (u64 i = 0; i < img->blocks_count; i++) {
        u8 value = bytearray[i];
        if(value > 1) {
            log_error("Invalid value in BYTE bitmap.");
            goto error_4;
        }
        img->bitmap_ptr[i / 64] |= (u64)value << (i % 64);
    }

    if(img->version == v2) {
        u64 packed_size;
        u32 stored_crc;

        if(!checked_divide_up_u64(img->blocks_count, 8, &packed_size) ||
           packed_size > SIZE_MAX) {
            log_error("Bitmap is too large to checksum.");
            goto error_4;
        }
        memcpy(&stored_crc, bytearray_ptr + img->bitmap_offset + img->blocks_count,
               sizeof(stored_crc));
        if(~count_crc32(img->bitmap_ptr, (size_t)packed_size, 0) != stored_crc) {
            log_error("Invalid bitmap checksum.");
            goto error_4;
        }
    }

    /*
     * end of bitmap is already filled with zeroes (calloc)
     */

    /* --------------------- ADD ADDITIONAL BLOCKS ---------------------- */

    img->blocks_count += additional_blocks;

    /* ------------------------------------------------------------------ */

    log_debug("Bytemap loaded to bitmap.");

    if(munmap(bytearray_ptr, length) == -1) {
        log_error("Cannot unmap bytemap: %s.", strerror(errno));
        goto error_1;
    } else {
        log_debug("Bytemap unmapped.");
    }

    log_debug("Bitmap created.");

    return ok;

    /* -------------------- ERROR HANDLING -------------------- */

error_4:

    free(img->bitmap_ptr);
    img->bitmap_ptr = NULL;

error_3:

    if(munmap(bytearray_ptr, length) == -1) {
        log_error("Cannot unmap bytemap: %s.", strerror(errno));
    } else {
        log_debug("Bytemap unmapped.");
    }

error_2:

    free(img->bitmap_ptr);
    log_debug("Memory allocated by bitmap released.");

error_1:

    log_error("Cannot load bytemap to bitmap.");
    return error;
}

static status load_bit_bitmap(struct image *img)
{
    /* allocate memory for bitmap */
    u64 additional_blocks;
    u64 bitmap_blocks;
    u64 bitmap_bytes;
    u64 bitmap_disk_bytes;
    size_t bitmap_disk_size;

    if(compute_additional_blocks(img, &additional_blocks) == error ||
       !checked_add_u64(img->blocks_count, additional_blocks, &bitmap_blocks) ||
       !checked_divide_up_u64(bitmap_blocks, 64, &bitmap_blocks) ||
       !u64_to_size(bitmap_blocks, &img->bitmap_elements) ||
       !checked_mul_u64(bitmap_blocks, sizeof(*img->bitmap_ptr), &bitmap_bytes) ||
       !u64_to_size(bitmap_bytes, &img->bitmap_size) ||
       !checked_divide_up_u64(img->blocks_count, 8, &bitmap_disk_bytes) ||
       !u64_to_size(bitmap_disk_bytes, &bitmap_disk_size)) {
        log_error("Bitmap is too large.");
        goto error_1;
    }

    log_debug("Memory required by bitmap " fu64 " bytes.", img->bitmap_size);

    img->bitmap_ptr = calloc(img->bitmap_elements, sizeof(*img->bitmap_ptr));

    if(img->bitmap_ptr == NULL) {
        log_error("Cannnot allocate memory for bitmap: %s.", strerror(errno));
        goto error_1;
    } else {
        log_debug("Memory for bitmap allocated.");
    }

    if(set_file_offset(img->fd, img->bitmap_offset, SEEK_SET) == error) {
        log_error("Cannot set file image offset to bitmap.");
        goto error_2;
    } else {
        log_debug("Offset set to bitmap.");
    }

    if(read_whole(img->fd, img->bitmap_ptr, bitmap_disk_size) == error) {
        log_error("Cannot read bitmap: %s.", strerror(errno));
        goto error_2;
    }

    if(img->version == v2) {
        u32 stored_crc;

        if(read_whole(img->fd, &stored_crc, sizeof(stored_crc)) == error ||
           ~count_crc32(img->bitmap_ptr, bitmap_disk_size, 0) != stored_crc) {
            log_error("Invalid bitmap checksum.");
            goto error_2;
        }
    }

    img->blocks_count += additional_blocks;

   log_debug("Bitmap loaded.");

   return ok;

error_2:
   free(img->bitmap_ptr);
error_1:
   log_error("Cannot load bitmap.");
   return error;
}

static status load_none_bitmap(struct image *img)
{
    u64 additional_blocks;
    u64 bitmap_blocks;
    u64 bitmap_bytes;
    u64 full_elements;
    u64 remaining_bits;

    if(compute_additional_blocks(img, &additional_blocks) == error ||
       !checked_add_u64(img->blocks_count, additional_blocks, &bitmap_blocks) ||
       !checked_divide_up_u64(bitmap_blocks, 64, &bitmap_blocks) ||
       !u64_to_size(bitmap_blocks, &img->bitmap_elements) ||
       !checked_mul_u64(bitmap_blocks, sizeof(*img->bitmap_ptr), &bitmap_bytes) ||
       !u64_to_size(bitmap_bytes, &img->bitmap_size)) {
        log_error("Bitmap is too large.");
        return error;
    }

    img->bitmap_ptr = calloc(img->bitmap_elements, sizeof(*img->bitmap_ptr));
    if(img->bitmap_ptr == NULL) {
        log_error("Cannot allocate memory for bitmap.");
        return error;
    }

    full_elements = img->blocks_count / 64;
    remaining_bits = img->blocks_count % 64;
    memset(img->bitmap_ptr, 0xff, full_elements * sizeof(*img->bitmap_ptr));
    if(remaining_bits != 0) {
        img->bitmap_ptr[full_elements] =
            (UINT64_C(1) << remaining_bits) - 1;
    }
    img->blocks_count += additional_blocks;
    return ok;
}

static status validate_backing_range(int fd, u64 offset, u64 length)
{
    struct stat st;
    u64 backing_size;
    u64 end;

    if(fstat(fd, &st) == -1) {
        log_error("Cannot stat image: %s.", strerror(errno));
        return error;
    }

    if(S_ISREG(st.st_mode)) {
        if(st.st_size < 0) return error;
        backing_size = (u64)st.st_size;
    } else if(S_ISBLK(st.st_mode)) {
        if(ioctl(fd, BLKGETSIZE64, &backing_size) == -1) {
            log_error("Cannot get image block-device size: %s.", strerror(errno));
            return error;
        }
    } else {
        return ok;
    }

    if(!checked_add_u64(offset, length, &end) || end > backing_size) {
        log_error("Image is truncated or has invalid offsets.");
        return error;
    }

    return ok;
}

static u64 bitmap_blocks_set(const struct image *img)
{
    u64 blocks_set = 0;
    u64 full_elements = img->blocks_count / 64;
    u64 remainder = img->blocks_count % 64;
    u64 i;

    for(i = 0; i < full_elements; i++) blocks_set += popcount(img->bitmap_ptr[i]);
    if(remainder != 0) {
        u64 mask = (UINT64_C(1) << remainder) - 1;
        blocks_set += popcount(img->bitmap_ptr[full_elements] & mask);
    }

    return blocks_set;
}

static status validate_data_range(const struct image *img)
{
    u64 blocks_set = bitmap_blocks_set(img);
    u64 data_size;
    u64 checksum_count;
    u64 checksum_size;

    if(!checked_mul_u64(blocks_set, img->block_size, &data_size)) {
        log_error("Image data range is too large.");
        return error;
    }

    /* A checksum follows every complete checksum group. */
    checksum_count = img->blocks_per_checksum == 0 ? 0 :
                     blocks_set / img->blocks_per_checksum;
    if(!checked_mul_u64(checksum_count, img->checksum_size, &checksum_size) ||
       !checked_add_u64(data_size, checksum_size, &data_size)) {
        log_error("Image data range is too large.");
        return error;
    }

    return validate_backing_range(img->fd, img->data_offset, data_size);
}

/* ----------------- READING IMAGE ----------------- */

static inline status set_block_from_the_ground(struct image *img, u64 block);

status initialize_offset(struct image *img)
{
    if(img->blocks_count == 0 || img->bitmap_ptr == NULL) {
        log_error("Image bitmap is empty.");
        return error;
    }

    img->o_num = 0;
    img->o_bitmap_bit = 0;
    img->o_bitmap_ptr = img->bitmap_ptr;
    img->o_blocks_set = 0;
    img->o_existence = *img->bitmap_ptr & 1;
    img->o_remaining_bytes = img->block_size;

    if(set_file_offset(img->fd, img->data_offset, SEEK_SET) == error) {
        log_error("Cannot set file offset to data starting point.");
        return error;
    }

    log_debug("Image image created.");
    return ok;
}

status set_block(struct image *img, u64 block)
{
    if(block >= img->blocks_count) {
        log_error("Block number is outside the image.");
        return error;
    }

    if(block == img->o_num + 1) {
        if(next_block(img) == error) goto error;

    } else if(block != img->o_num) {
        if(set_block_from_the_ground(img, block) == error) goto error;

    } else {
        if(offset_in_current_block(img, 0) == error) goto error;
    }

    return ok;

    error: {
        log_error("Cannot set offset in " fu64 " block.", block);
        return error;
    }
}

static inline status set_block_from_the_ground(struct image *img, u64 block)
{
    u64 i;

    /* (a) compute basic values
     * (a) assign calculated data to the image
     * (b) find bitmap element corresponding to this block
     * (c) is the block present in the image
     * (d) find bitmap cache element corresponding to this block
     * (e) how many blocks are not included in finded bitmap cache element
     * (f) how many iterations are required
     * (g) count bits from 64 bit elements
     * (h) set bitmap pointer on the bitmap cache element
     * (i) how many bits are not included in the last iteration - create a mask
     *     for the last bitmap element
     * (j) add remaining bits by masking the current element using mask computed
     *     in point (g)
     * (k) compute offset
     */

    /* (a) ----------------------------------------------------------------- */
    img->o_num = block;
    img->o_remaining_bytes = img->block_size;

    /* (b) ----------------------------------------------------------------- */
    u64 bitmap_element = img->o_num / 64;
    img->o_bitmap_ptr = img->bitmap_ptr + bitmap_element;
    img->o_bitmap_bit = img->o_num % 64;

    /* (c) ----------------------------------------------------------------- */
    img->o_existence = (*img->o_bitmap_ptr >> img->o_bitmap_bit) & 1;

    /* (d) ----------------------------------------------------------------- */

    u64 cache_element =
        bitmap_element / img->bitmap_elements_in_cache_element;

    img->o_blocks_set = img->cache_ptr[cache_element];

    /* (e) ----------------------------------------------------------------- */
    u64 remaining_blocks =
        img->o_num - cache_element *
        img->bitmap_elements_in_cache_element * 64;

    /* (f) ----------------------------------------------------------------- */
    u64 iterations_num = remaining_blocks / 64;

    /* (g) ----------------------------------------------------------------- */
    u64 *bitmap_ptr =
        img->bitmap_ptr + cache_element *
        img->bitmap_elements_in_cache_element;

    /* (h) ----------------------------------------------------------------- */
    for (i = 0; i < iterations_num; i++) {
        img->o_blocks_set += popcount(*bitmap_ptr++);
    }

    /* (i) ----------------------------------------------------------------- */

    /* Why not 0xFFFFFFFFFFFFFFFF >> 64? This trick is necessary, because
     * shifting a 64-bit variable 64 bits is in fact shifting 0 bits.
     */

    u64 remaining_bits = remaining_blocks - iterations_num * 64;
    u64 last_bitmap_elem_mask = remaining_bits == 0 ? 0 :
        (UINT64_C(1) << remaining_bits) - 1;

    /* (j) ----------------------------------------------------------------- */
    img->o_blocks_set += popcount(*bitmap_ptr & last_bitmap_elem_mask);

    /* (h) ----------------------------------------------------------------- */
    u64 file_offset;
    u64 checksum_offset;

    if(!checked_mul_u64(img->o_blocks_set, img->block_size, &file_offset) ||
       !checked_mul_u64(img->blocks_per_checksum == 0 ? 0 :
                         img->o_blocks_set / img->blocks_per_checksum,
                         img->checksum_size, &checksum_offset) ||
       !checked_add_u64(file_offset, checksum_offset, &file_offset) ||
       !checked_add_u64(file_offset, img->data_offset, &file_offset)) {
        log_error("Image data offset is too large.");
        return error;
    }

    if(set_file_offset(img->fd, file_offset, SEEK_SET) == error) {
        return error;
    }

    return ok;
}

status next_block(struct image *img)
{
    /* (1) is the next element of bitmap in a new byte, or in an old byte?
     * (2) compute additional offset when jumping to next block
     * (3) is the block present in the image?
     * (4) change the total number of set blocks
     * (5) reset remaining bytes number
     * (6) jump to next block
     */


    /* (1) ----------------------------------------------------------------- */

    u8 next_bit_raw;
    u64 additional_offset;

    if(img->o_num >= img->blocks_count - 1) {
        img->o_num = img->blocks_count;
        img->o_existence = 0;
        img->o_remaining_bytes = 0;
        return ok;
    }

    next_bit_raw = img->o_bitmap_bit + 1;

    img->o_bitmap_bit = next_bit_raw % 64;
    img->o_bitmap_ptr += (next_bit_raw - 63) * (next_bit_raw / 63);
    img->o_num++;

    /* (2) ----------------------------------------------------------------- */

    if(!checked_add_u64((img->blocks_per_checksum != 0 &&
                         ((img->o_blocks_set + 1) % img->blocks_per_checksum) == 0) *
                         img->checksum_size, img->o_remaining_bytes,
                        &additional_offset)) {
        log_error("Image data offset is too large.");
        return error;
    }
    additional_offset *= img->o_existence;

    /* (3) ----------------------------------------------------------------- */

    img->o_existence =
        (*img->o_bitmap_ptr >> img->o_bitmap_bit) & 1;

    /* (4) ----------------------------------------------------------------- */

    img->o_blocks_set += img->o_existence;

    /* (5) ----------------------------------------------------------------- */

    img->o_remaining_bytes = img->block_size;

    /* (6) ----------------------------------------------------------------- */

    if(set_file_offset(img->fd, additional_offset, SEEK_CUR) == error) {
        log_error("Cannot set offset in next block.");
        return error;
    }

    return ok;
}

/* set a new offset inside a current block */
status offset_in_current_block(struct image *img, u64 offset)
{
    u32 blk_remaining;

    if(offset > img->block_size) {
        log_error("Offset is outside the current block.");
        return error;
    }

    blk_remaining = img->block_size - (u32)offset;

    if(blk_remaining > img->o_remaining_bytes) {
        if(set_block_from_the_ground(img, img->o_num) == error) return error;
    }

    if(set_file_offset(img->fd, img->o_remaining_bytes - blk_remaining, SEEK_CUR) == error) {
        log_error("Cannot set offset inside block.");
        return error;
    }

    img->o_remaining_bytes = blk_remaining;
    return ok;
}

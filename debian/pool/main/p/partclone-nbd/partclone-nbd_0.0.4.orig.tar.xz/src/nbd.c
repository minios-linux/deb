/* Copyright © 2015-2016 Przemysław Kusiak
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the “Software”), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#include "log.h"
#include "io.h"
#include "partclone.h"
#include "image.h"
#include "nbd.h"
#include "signals.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/sendfile.h>
#include <limits.h>
#include <signal.h>

// Macros from Linux kernel headers nbd.h and fs.h. Needed in start_client() method.

#define NBD_SET_SOCK        _IO( 0xab, 0 )
#define NBD_SET_BLKSIZE     _IO( 0xab, 1 )
#define NBD_SET_SIZE        _IO( 0xab, 2 )
#define NBD_DO_IT           _IO( 0xab, 3 )
#define NBD_CLEAR_SOCK      _IO( 0xab, 4 )
#define NBD_CLEAR_QUE       _IO( 0xab, 5 )
#define NBD_PRINT_DEBUG     _IO( 0xab, 6 )
#define NBD_SET_SIZE_BLOCKS _IO( 0xab, 7 )
#define NBD_DISCONNECT      _IO( 0xab, 8 )
#define NBD_SET_TIMEOUT     _IO( 0xab, 9 )
#define NBD_SET_FLAGS       _IO( 0xab, 10)
#define BLKROSET            _IO( 0x12, 93) /* set RO */

#define NBD_REQUEST_MAGIC       0x25609513
#define NBD_SIMPLE_REPLY_MAGIC  0x67446698
#define NBD_OPTS_MAGIC          0x49484156454F5054ULL
#define NBD_REP_MAGIC           0x3e889045565a9ULL

#define NBD_FLAG_FIXED_NEWSTYLE 0x0001
#define NBD_FLAG_NO_ZEROES      0x0002
#define NBD_FLAG_HAS_FLAGS      0x0001
#define NBD_FLAG_READ_ONLY      0x0002

#define NBD_FLAG_C_FIXED_NEWSTYLE 0x00000001
#define NBD_FLAG_C_NO_ZEROES      0x00000002

#define NBD_OPT_EXPORT_NAME 1
#define NBD_OPT_ABORT       2
#define NBD_OPT_GO          7

#define NBD_REP_ACK         1
#define NBD_REP_INFO        3
#define NBD_REP_ERR_UNSUP   0x80000001
#define NBD_REP_ERR_INVALID 0x80000003
#define NBD_REP_ERR_UNKNOWN 0x80000006

#define NBD_INFO_EXPORT     0
#define NBD_INFO_BLOCK_SIZE 3

#define NBD_CMD_READ        0
#define NBD_CMD_WRITE       1
#define NBD_CMD_DISC        2

#define NBD_SECTOR_SIZE          512U
#define NBD_MAX_REQUEST_SIZE     (32U * 1024U * 1024U)
#define NBD_ZERO_BUFFER_SIZE     (64U * 1024U)
#define NBD_MAX_OPTION_PAYLOAD   (4U * 1024U)


int get(int sock, void *buff, int count)
{
    int cnt = count;
    int pnt = 0;

    while(cnt > 0)
    {
        int once = recv(sock, buff, cnt, 0);

        if(once == 0) break;
        else if(once == -1 && errno == EINTR) {
            continue;
        } else if(once == -1) {
            log_error("Connection dropped: %s.", strerror(errno));
            break;
        }

        pnt += once;
        cnt -= once;
        buff = (u8*) buff + once;
    }

    return pnt;
}

ssize_t put(int sock, void *buff, size_t count)
{
    size_t cnt = count;
    size_t pnt = 0;

    while(cnt > 0) {
        ssize_t once = send(sock, buff, cnt, MSG_NOSIGNAL);

        if(once == 0) break;
        else if(once == -1 && errno == EINTR) {
            continue;
        } else if(once == -1) {
            log_error("Connection dropped: %s.", strerror(errno));
            break;
        }

        pnt += once;
        cnt -= once;
        buff = (u8*) buff + once;
    }

    if(pnt != count) log_error("Failed to send data to an image.");
    return pnt;
}

static inline status get16(int sock, u16 *v) {
    u8 bytes[2];
    if(get(sock, bytes, sizeof(bytes)) != (int)sizeof(bytes)) return error;
    *v = ((u16)bytes[0] << 8) | bytes[1];
    return ok;
}

static inline status put16(int sock, u16 v) {
    u8 bytes[2] = { (u8)(v >> 8), (u8)v };
    if(put(sock, bytes, sizeof(bytes)) != (ssize_t)sizeof(bytes)) return error;
    return ok;
}

static inline status get32(int sock, u32 *v) {
    u8 bytes[4];
    if(get(sock, bytes, sizeof(bytes)) != (int)sizeof(bytes)) return error;
    *v = ((u32)bytes[0] << 24) | ((u32)bytes[1] << 16) |
         ((u32)bytes[2] << 8) | bytes[3];
    return ok;
}

static inline status put32(int sock, u32 v) {
    u8 bytes[4] = {
        (u8)(v >> 24), (u8)(v >> 16), (u8)(v >> 8), (u8)v
    };
    if(put(sock, bytes, sizeof(bytes)) != (ssize_t)sizeof(bytes)) return error;
    return ok;
}

static inline status get64(int sock, u64 *v) {
    u8 bytes[8];
    if(get(sock, bytes, sizeof(bytes)) != (int)sizeof(bytes)) return error;
    *v = ((u64)bytes[0] << 56) | ((u64)bytes[1] << 48) |
         ((u64)bytes[2] << 40) | ((u64)bytes[3] << 32) |
         ((u64)bytes[4] << 24) | ((u64)bytes[5] << 16) |
         ((u64)bytes[6] << 8) | bytes[7];
    return ok;
}

static inline status put64(int sock, u64 v) {
    u8 bytes[8] = {
        (u8)(v >> 56), (u8)(v >> 48), (u8)(v >> 40), (u8)(v >> 32),
        (u8)(v >> 24), (u8)(v >> 16), (u8)(v >> 8), (u8)v
    };
    if(put(sock, bytes, sizeof(bytes)) != (ssize_t)sizeof(bytes)) return error;
    return ok;
}

static ssize_t sendfile_whole(int sock, int fd, size_t count)
{
    size_t sent = 0;

    while(sent < count) {
        ssize_t once = sendfile(sock, fd, NULL, count - sent);

        if(once > 0) {
            sent += (size_t)once;
        } else if(once == -1 && errno == EINTR) {
            continue;
        } else {
            break;
        }
    }

    return (ssize_t)sent;
}

static status send_reply(int sock, u64 handle, u32 error_number)
{
    if(     put32(sock, NBD_SIMPLE_REPLY_MAGIC) == error ||
            put32(sock, error_number) == error    ||
            put64(sock, handle) == error          ){
    /* ---------------------------------------------------------------------- */
        log_error("Failed to send reply for the request.");
        return error;
    }

    return ok;
}

static status discard(int sock, u32 count)
{
    u8 buffer[1024];

    while(count > 0) {
        u32 once = MIN(count, (u32)sizeof(buffer));
        if(get(sock, buffer, once) != (int)once) return error;
        count -= once;
    }

    return ok;
}

static status send_option_reply(int sock, u32 option, u32 type,
                                const void *payload, u32 length)
{
    if(put64(sock, NBD_REP_MAGIC) == error ||
       put32(sock, option) == error ||
       put32(sock, type) == error ||
       put32(sock, length) == error ||
       (length != 0 && put(sock, (void *)payload, length) != (ssize_t)length)) {
        log_error("Failed to send option reply.");
        return error;
    }

    return ok;
}

static status send_export_info(int sock, u32 option, struct image *img)
{
    u8 info[12];

    info[0] = 0;
    info[1] = NBD_INFO_EXPORT;
    info[2] = (u8)(img->device_size >> 56);
    info[3] = (u8)(img->device_size >> 48);
    info[4] = (u8)(img->device_size >> 40);
    info[5] = (u8)(img->device_size >> 32);
    info[6] = (u8)(img->device_size >> 24);
    info[7] = (u8)(img->device_size >> 16);
    info[8] = (u8)(img->device_size >> 8);
    info[9] = (u8)img->device_size;
    info[10] = 0;
    info[11] = NBD_FLAG_HAS_FLAGS | NBD_FLAG_READ_ONLY;

    return send_option_reply(sock, option, NBD_REP_INFO, info, sizeof(info));
}

static status send_block_size_info(int sock, u32 option)
{
    u8 info[14] = {
        0, NBD_INFO_BLOCK_SIZE,
        0, 0, 2, 0,                 /* minimum block size: 512 */
        0, 0, 2, 0,                 /* preferred block size: 512 */
        2, 0, 0, 0                  /* maximum block size: 32 MiB */
    };

    return send_option_reply(sock, option, NBD_REP_INFO, info, sizeof(info));
}

static status WORKER(int sock, struct image *img)
{
    void *zero;
    volatile status result = error;
    struct sigaction previous_sigpipe;
    struct sigaction ignore_sigpipe = { .sa_handler = SIG_IGN };
    int sigpipe_changed = 0;

    sigemptyset(&ignore_sigpipe.sa_mask);
    if(sigaction(SIGPIPE, &ignore_sigpipe, &previous_sigpipe) == -1) {
        log_error("Cannot ignore SIGPIPE: %s.", strerror(errno));
        goto error_1;
    }
    sigpipe_changed = 1;

    // A fixed buffer avoids trusting image block sizes for network I/O.
    zero = calloc(NBD_ZERO_BUFFER_SIZE, 1);

    if(zero == NULL) /* allocation failed */ {
        log_error("Cannot allocate memory for storing a chunk.");
        goto error_1;
    } else {
        log_debug("Memory for storing a chunk allocated.");
    }
    
    if(initialize_handling(sock) == error) goto error_3;

    // ====================================================================== //
    // ======================== REQUEST & REPLIES =========================== //
    // ====================================================================== //
    
    log_info("Waiting for requests ...");

    /* the great loop */
    for(;;)
    {
        u32 magic, count, type;
        u32 command, command_flags;
        u64 seek, handle;

        if(get32(sock, &magic) == error   || // 0x25609513
           get32(sock, &type) == error    || // 0 -read
           get64(sock, &handle) == error  || // handle
           get64(sock, &seek) == error    || // seek
           get32(sock, &count) == error   ){ // length
        // ----------------------------------------------------------------- //
            log_error("Failed to read request.");
            break;
        }

        if(magic != NBD_REQUEST_MAGIC) {
            log_error("Parsing request: Bad magic.");
            break;
        }

        command = type & 0xffff;
        command_flags = type & 0xffff0000;

        if(command == NBD_CMD_DISC && command_flags == 0 && count == 0) {
            log_info("Client sent a disconnect request.");
            result = ok;
            goto cleanup;
        }

        /* A write carries a payload. Close after the error to keep it from
         * becoming the next request header. */
        if(command == NBD_CMD_WRITE) {
            log_error("Parsing request: Write on a read-only export.");
            (void)send_reply(sock, handle, EPERM);
            break;
        }

        /* Unknown commands may carry a payload, so do not try to resynchronize
         * after replying to one. */
        if(command != NBD_CMD_READ) {
            log_error("Parsing request: Unsupported command.");
            (void)send_reply(sock, handle, EINVAL);
            break;
        }

        // verify request
        if(command_flags != 0 || count > NBD_MAX_REQUEST_SIZE ||
           seek % NBD_SECTOR_SIZE != 0 ||
           count % NBD_SECTOR_SIZE != 0 || seek > img->device_size ||
           count > img->device_size - seek) {
        // ----------------------------------------------------------------- //
            log_error("Parsing request: Invalid flags, range, or alignment.");
            if(send_reply(sock, handle, EINVAL) == error) break;
            continue;
        }

        if(send_reply(sock, handle, 0) == error) break;
        if(count == 0) continue;

        u64 block  = seek / img->block_size;
        u32 offset = seek % img->block_size;

        if(set_block(img, block) == error) goto error_3;
        if(offset_in_current_block(img, offset) == error) goto error_3;

        // send all chunks; size of chunk = size of image block (see *buff)
        for (;count > 0;) {

            u32 once_read = MIN(img->o_remaining_bytes, count);
            count -= once_read;
            img->o_remaining_bytes -= once_read;

            // ------------------------------------------------------------- //

            if(img->o_existence == 0) {
                u32 zero_left = once_read;

                while(zero_left > 0) {
                    u32 zero_once = MIN(zero_left, NBD_ZERO_BUFFER_SIZE);
                    if(put(sock, zero, zero_once) != (ssize_t)zero_once) {
                        log_error("Failed to write some zeroes to device: %s.", strerror(errno));
                        goto error_3;
                    }
                    zero_left -= zero_once;
                }

            } else {
                
                // direct transmission from device to device using sendfile
                if(sendfile_whole(sock, img->fd, once_read) != once_read) {
                    log_error("Failed to send some data from image to device: %s.", strerror(errno));
                    goto error_3;
                }

            }

            // ------------------------------------------------------------- //

            if (count > 0 && next_block(img) == error) goto error_3;
        }
    }

error_3:
cleanup:
    restore_handling();
    if(sigpipe_changed && sigaction(SIGPIPE, &previous_sigpipe, NULL) == -1) {
        log_error("Cannot restore SIGPIPE handler: %s.", strerror(errno));
        result = error;
    }
    free(zero);

error_1:
    log_debug("WORKER closed.");
    return result;
}

// SERVER MODE vs CLIENT MODE

// Both client mode and server mode try to gain socket to communicate with a
// client. Client can be on the same computer as partclone-nbd, or somewhere in
// the internet.

// Server mode can serve image to another computers through the INET socks.

// Client mode is much faster than server, because it uses UNIX(r) sockets,
// not INET sockets. But, of course, it's limited to one machine.

// Both client mode and server mode finally call WORKER function.

/* ------------------------- SERVER MODE --------------------------------- */

static status server_negotiation(int sock, struct image *img);

status start_server(struct image *img, struct options *options)
{
    status result = error;

    if(img->device_size == 0 || img->device_size % NBD_SECTOR_SIZE != 0) {
        log_error("Image size (" fu64 ") is not aligned to a 512-byte sector.",
                  img->device_size);
        return error;
    }

    // create listener socket
    int sock = socket(AF_INET, SOCK_STREAM, 0);

    if(sock == -1) {
        log_error("Failed to create a socket: %s.", strerror(errno));
        return error;
    } else {
        log_debug("Socket created.");
    }

    // allow to reuse address
    if(setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) == -1) {
        log_error("Failed to reuse address: %s.", strerror(errno));
    } else {
        log_debug("Address reused.");
    }

    // bind port to a socket
    struct sockaddr_in server_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(options->port),
        .sin_zero = { 0 }
    };

    if(inet_pton(AF_INET, options->address, &server_addr.sin_addr) != 1) {
        log_error("Invalid IPv4 listen address: %s.", options->address);
        goto error;
    }

    if(bind(sock, (struct sockaddr*) &server_addr, sizeof server_addr) == -1) {
        log_error("Failed to bind port to a socket: %s.", strerror(errno));
        goto error;
    } else {
        log_debug("Socket bound to a port.");
    }

    // start listening on a port
    if(listen(sock, 5) == -1) {
        log_error("Failed to start listening on a port.");
        goto error;
    } else {
        log_debug("Listening on a port started.");
    }

    log_info("Server initialized. Listening on %s:%i ...",
             options->address, options->port);

    for(;;) {

        /* accept a connection */
        struct sockaddr_in clientaddr;
        socklen_t clientaddrlen = sizeof clientaddr;

        int cl_sock = accept(sock, (struct sockaddr*) &clientaddr, &clientaddrlen);

        if(cl_sock == -1) {
            log_error("Failed to accept a connection.");
            continue;
        }

        struct timeval timeout = { .tv_sec = 30, .tv_usec = 0 };
        if(setsockopt(cl_sock, SOL_SOCKET, SO_RCVTIMEO, &timeout,
                      sizeof(timeout)) == -1 ||
           setsockopt(cl_sock, SOL_SOCKET, SO_SNDTIMEO, &timeout,
                      sizeof(timeout)) == -1) {
            log_error("Failed to set client timeout: %s.", strerror(errno));
            close(cl_sock);
            continue;
        }

        log_info("Connection made with %s.", inet_ntoa(clientaddr.sin_addr));
        result = server_negotiation(cl_sock, img);
        if(shutdown_requested()) break;
        if(result == ok) break;
    }

error:
    if(close(sock) == -1) {
        log_error("Failed to close main sock: %s.", strerror(errno));
    } else {
        log_debug("Main sock closed.");
    }

    return result;
}

static status server_negotiation(int sock, struct image *img)
{
    u8 zero[124] = { 0 };
    status result = error;
    u32 cl_flags;
    int no_zeroes;

    if(put(sock, "NBDMAGIC", 8) != 8 ||
       put64(sock, NBD_OPTS_MAGIC) == error ||
       put16(sock, NBD_FLAG_FIXED_NEWSTYLE | NBD_FLAG_NO_ZEROES) == error ||
       get32(sock, &cl_flags) == error) {
        log_error("Failed during NBD fixed-newstyle greeting.");
        goto error_1;
    }

    if((cl_flags & ~(NBD_FLAG_C_FIXED_NEWSTYLE | NBD_FLAG_C_NO_ZEROES)) != 0 ||
       (cl_flags & NBD_FLAG_C_FIXED_NEWSTYLE) == 0) {
        log_error("Unsupported NBD client global flags.");
        goto error_1;
    }
    no_zeroes = (cl_flags & NBD_FLAG_C_NO_ZEROES) != 0;

    for(;;) {
        u64 cl_magic;
        u32 cl_option, cl_length;

        if(get64(sock, &cl_magic) == error ||
           get32(sock, &cl_option) == error ||
           get32(sock, &cl_length) == error) {
            log_error("Failed to receive an NBD option.");
            goto error_1;
        }
        if(cl_magic != NBD_OPTS_MAGIC) {
            log_error("Unrecognized NBD option magic.");
            goto error_1;
        }
        if(cl_length > NBD_MAX_OPTION_PAYLOAD) {
            log_error("NBD option payload is too large.");
            goto error_1;
        }

        if(cl_option == NBD_OPT_EXPORT_NAME) {
            if(cl_length != 0) {
                if(discard(sock, cl_length) == error) goto error_1;
                log_error("Unknown NBD export name.");
                goto error_1;
            }
            if(put64(sock, img->device_size) == error ||
               put16(sock, NBD_FLAG_HAS_FLAGS | NBD_FLAG_READ_ONLY) == error ||
               (!no_zeroes && put(sock, zero, sizeof(zero)) != (ssize_t)sizeof(zero))) {
                log_error("Failed to send NBD export information.");
                goto error_1;
            }
            result = WORKER(sock, img);
            break;
        }

        if(cl_option == NBD_OPT_ABORT) {
            if(cl_length != 0) {
                if(discard(sock, cl_length) == error ||
                   send_option_reply(sock, cl_option, NBD_REP_ERR_INVALID,
                                     NULL, 0) == error)
                    goto error_1;
                continue;
            }
            if(send_option_reply(sock, cl_option, NBD_REP_ACK, NULL, 0) == error)
                goto error_1;
            break;
        }

        if(cl_option == NBD_OPT_GO) {
            u32 name_length;
            u16 info_count;
            int want_block_size = 0;

            if(cl_length < 6 || get32(sock, &name_length) == error ||
               name_length > cl_length - 6 || discard(sock, name_length) == error ||
               get16(sock, &info_count) == error ||
               info_count > (cl_length - 6 - name_length) / 2 ||
               cl_length != 6 + name_length + (u32)info_count * 2) {
                log_error("Malformed NBD_OPT_GO payload.");
                goto error_1;
            }
            for(u16 i = 0; i < info_count; ++i) {
                u16 info_type;
                if(get16(sock, &info_type) == error) goto error_1;
                if(info_type == NBD_INFO_BLOCK_SIZE) want_block_size = 1;
            }
            if(name_length != 0) {
                if(send_option_reply(sock, cl_option, NBD_REP_ERR_UNKNOWN, NULL, 0) == error)
                    goto error_1;
                continue;
            }
            if(send_export_info(sock, cl_option, img) == error ||
               (want_block_size && send_block_size_info(sock, cl_option) == error) ||
               send_option_reply(sock, cl_option, NBD_REP_ACK, NULL, 0) == error)
                goto error_1;
            result = WORKER(sock, img);
            break;
        }

        if(discard(sock, cl_length) == error ||
           send_option_reply(sock, cl_option, NBD_REP_ERR_UNSUP, NULL, 0) == error)
            goto error_1;
    }

error_1:
    if(close(sock) == -1) {
        log_error("Failed to close client sock: %s.", strerror(errno));
    } else {
        log_debug("Client sock closed.");
    }

    return result;
}

/* ------------------------- CLIENT MODE ---------------------------------- */

struct do_it_context {
    int device_sock;
    int communication_sock;
    int ioctl_error;
};

// this thread imitates a client.
static void *lock_on_do_it(void *arg)
{
    struct do_it_context *context = arg;

    if(block_signals_in_thread() == error) {
        context->ioctl_error = EINVAL;
        shutdown(context->communication_sock, SHUT_RDWR);
        return NULL;
    }

    if (ioctl(context->device_sock, NBD_DO_IT) == -1) {
        context->ioctl_error = errno;
        log_error("Failed to lock on NBD_DO_IT: %s.", strerror(errno));
        shutdown(context->communication_sock, SHUT_RDWR);
    }

    log_debug("Locking finished.");

    pthread_exit(0);
}


status start_client(struct image *img, struct options *options)
{
    int socket[2] = { -1, -1 }; // socket[0] goes to the kernel, socket[1] to us
    int device_sock = -1;
    int communication_sock = -1;
    int kernel_sock = -1;
    int thread_started = 0;
    int nbd_socket_set = 0;
    status result = error;
    pthread_t thread;
    u32 nbd_block_size = img->device_size % 4096 == 0 ? 4096 : 512;
    struct do_it_context do_it = {
        .device_sock = -1,
        .communication_sock = -1,
        .ioctl_error = 0
    };

    if(img->device_size == 0 || img->device_size % 512 != 0) {
        log_error("Image size (" fu64 ") is not aligned to a 512-byte sector.",
                  img->device_size);
        goto cleanup;
    }

    if (socketpair(PF_UNIX, SOCK_STREAM, 0, socket) == -1) {
        log_error("Cannot create a pair of sockets: %s.", strerror(errno));
        goto cleanup;
    } else {
        log_debug("A pair of sockets created.");
    }

    communication_sock = socket[1];
    kernel_sock = socket[0];
    device_sock = open(options->device_path, O_RDWR);

 
    if (device_sock == -1) {
        log_error("Failed to open %s device in RW mode: %s.", options->device_path, strerror(errno));
        goto cleanup;
    } else {
        log_debug("%s device opened.", options->device_path);
    }

    if (ioctl(device_sock, NBD_CLEAR_SOCK) == -1) {
        log_error("Failed to clear a NBD device socket: %s.", strerror(errno));
        goto cleanup;
    } else {
        log_debug("NBD device socket cleared.");
    }

    if (ioctl(device_sock, NBD_SET_SOCK, kernel_sock) == -1) {
        log_error("Failed to set socket for communication with kernel: %s.", strerror(errno));
        goto cleanup;
    } else {
        nbd_socket_set = 1;
        log_debug("Socket for communication with kernel set.");
    }

    if (ioctl(device_sock, NBD_SET_BLKSIZE, (unsigned long)nbd_block_size) == -1) {
        log_error("Failed to set NBD block size (" fu32 "): %s.", nbd_block_size, strerror(errno));
        goto cleanup;
    } else {
        log_debug("NBD block size (" fu32 ") set.", nbd_block_size);
    }

    if(img->device_size > (u64)ULONG_MAX) {
        log_error("Image size (" fu64 ") exceeds NBD_SET_SIZE limit on this platform.", img->device_size);
        goto cleanup;
    }

    if (ioctl(device_sock, NBD_SET_SIZE, (unsigned long)img->device_size) == -1) {
        log_error("Failed to set image size (" fu64 "): %s.", img->device_size, strerror(errno));
        goto cleanup;
    } else {
        log_debug("Image size (" fu64 ") set.", img->device_size);
    }

    if (ioctl(device_sock, NBD_SET_FLAGS,
              (unsigned long)(NBD_FLAG_HAS_FLAGS | NBD_FLAG_READ_ONLY)) == -1) {
        log_error("Failed to set NBD read-only flags: %s.", strerror(errno));
        goto cleanup;
    }

    if (ioctl(device_sock, BLKROSET, &(int){1}) == -1) {
        log_error("Failed to set read only device attribute: %s.", strerror(errno));
        goto cleanup;
    } else {
        log_debug("Read only device attribute set.");
    }

    // very hackish and complicated; lock thread imitate a client; this thread
    // imitate a server. Quoting official nbd client:

            /* Due to a race, the kernel NBD driver cannot
             * call for a reread of the partition table
             * in the handling of the NBD_DO_IT ioctl().
             * Therefore, this is done in the first open()
             * of the device. We therefore make sure that
             * the device is opened at least once after the
             * connection was made. This has to be done in a
             * separate process, since the NBD_DO_IT ioctl()
             * does not return until the NBD device has
             * disconnected. */

    do_it.device_sock = device_sock;
    do_it.communication_sock = communication_sock;

    int create_error = pthread_create(&thread, NULL, lock_on_do_it, &do_it);
    if(create_error != 0) {
        log_error("Failed to create lock thread: %s.", strerror(create_error));
        goto cleanup;
    } else {
        thread_started = 1;
        log_debug("Lock thread created.");
    }

    close(kernel_sock);
    kernel_sock = -1;

    result = WORKER(communication_sock, img);

cleanup:
    if(communication_sock != -1) close(communication_sock);

    if(device_sock != -1 && nbd_socket_set && ioctl(device_sock, NBD_DISCONNECT) == -1) {
        log_error("Cannot disconnect from NBD device: %s.", strerror(errno));
    }

    if(thread_started) {
        int join_error = pthread_join(thread, NULL);
        if(join_error != 0) {
            log_error("Failed to join NBD thread: %s.", strerror(join_error));
            result = error;
        }
        if(do_it.ioctl_error != 0) result = error;
    }

    if(device_sock != -1 && ioctl(device_sock, NBD_CLEAR_SOCK) == -1) {
        log_error("Failed to clear a NBD device socket: %s.", strerror(errno));
    }

    if(device_sock != -1) close(device_sock);
    if(kernel_sock != -1) close(kernel_sock);

    if(result == ok) return ok;
    log_msg(log_error, "Failed to initialize NBD device.");
    return error;
}

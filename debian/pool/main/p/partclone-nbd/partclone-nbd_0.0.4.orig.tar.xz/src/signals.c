/* Copyright © 2015-2016 Przemysław Kusiak
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the “Software”), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#include <signal.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>

#include "signals.h"
#include "partclone.h"
#include "log.h"

struct {
    int sig_num;
    char* sig_char;
} sigs_to_handle[] = {
    {SIGHUP,  "SIGHUP" },
    {SIGINT,  "SIGINT" },
    {SIGTERM, "SIGTERM"},
    {SIGQUIT, "SIGQUIT"},
    {SIGUSR1, "SIGUSR1"},
    {SIGUSR2, "SIGUSR2"},
    {0}
};

static struct sigaction previous_actions[6];
static int installed_actions;
static volatile sig_atomic_t caught_signal;
static volatile sig_atomic_t active_socket = -1;

static void internal_signal_handler(signal_t sig)
{
    caught_signal = sig;
    if(active_socket >= 0) close(active_socket);
}

/* to avoid duplication of signal handling */
status block_signals_in_thread(void)
{
    sigset_t mask;
    sigemptyset(&mask);

    for(int i = 0; sigs_to_handle[i].sig_num; i++) {
        sigaddset(&mask, sigs_to_handle[i].sig_num);
    }

    int result = pthread_sigmask(SIG_BLOCK, &mask, NULL);
    if(result != 0) {
        log_error("Cannot block signals in worker thread: %s.", strerror(result));
        return error;
    }

    return ok;
}

status initialize_handling(int worker_socket)
{
    // mask every signal during signal handler execution
    sigset_t mask;
    sigfillset(&mask);
    
    struct sigaction sa = {
        .sa_handler = &internal_signal_handler, 
        .sa_mask = mask,
        .sa_flags = 0
    };

    caught_signal = 0;
    active_socket = worker_socket;
    installed_actions = 0;
    for(int i = 0; sigs_to_handle[i].sig_num; i++) {

        if (sigaction(sigs_to_handle[i].sig_num, &sa,
                      &previous_actions[i]) == -1) {
            log_error("Cannot set %s handler.", sigs_to_handle[i].sig_char);
            restore_handling();
            return error;
        } else {
            installed_actions++;
            log_debug("%s handler set.", sigs_to_handle[i].sig_char);
        }
    }

    return ok;
}

void restore_handling(void)
{
    active_socket = -1;
    while(installed_actions > 0) {
        int i = --installed_actions;
        if(sigaction(sigs_to_handle[i].sig_num, &previous_actions[i], NULL) == -1) {
            log_error("Cannot restore %s handler.", sigs_to_handle[i].sig_char);
        }
    }
}

int shutdown_requested(void)
{
    return caught_signal != 0;
}

"""Canonical MiniOS security profile matrix.

This module intentionally returns message keys, config values, and data
structures. Installer/configurator packages own translations and UI formatting.
"""

from __future__ import absolute_import

import os


SECURITY_PROFILE_IDS = ("convenient", "balanced", "strict")
DEFAULT_SECURITY_PROFILE = {"live": "convenient", "native": "balanced"}

BASE_GROUPS = (
    "adm",
    "audio",
    "cdrom",
    "dialout",
    "dip",
    "lpadmin",
    "netdev",
    "plugdev",
    "scanner",
    "sudo",
    "video",
)
RISKY_GROUPS = ("docker", "libvirt", "kvm", "wireshark", "vboxsf", "vboxusers")

_PROFILE_CONFIG = {
    "convenient": {
        "LIVE_SUDO_MODE": "passwordless",
        "LIVE_POLKIT_MODE": "passwordless",
        "LIVE_SSH_PERMIT_ROOT_LOGIN": "true",
        "LIVE_SSH_PASSWORD_AUTHENTICATION": "true",
        "LIVE_XRDP_MODE": "relaxed",
        "LIVE_X11_MODE": "relaxed",
        "LIVE_ISSUE_PASSWORD_HINTS": "true",
        "LIVE_LOCKSCREEN_MODE": "relaxed",
    },
    "balanced": {
        "LIVE_CONFIG_CMDLINE": "noautologin",
        "LIVE_SUDO_MODE": "password",
        "LIVE_POLKIT_MODE": "password",
        "LIVE_SSH_PERMIT_ROOT_LOGIN": "false",
        "LIVE_SSH_PASSWORD_AUTHENTICATION": "true",
        "LIVE_XRDP_MODE": "hardened",
        "LIVE_X11_MODE": "hardened",
        "LIVE_ISSUE_PASSWORD_HINTS": "true",
        "LIVE_LOCKSCREEN_MODE": "hardened",
    },
    "strict": {
        "LIVE_CONFIG_CMDLINE": "noautologin",
        "LIVE_SUDO_MODE": "password",
        "LIVE_POLKIT_MODE": "password",
        "LIVE_SSH_PERMIT_ROOT_LOGIN": "false",
        "LIVE_SSH_PASSWORD_AUTHENTICATION": "false",
        "LIVE_XRDP_MODE": "disabled",
        "LIVE_X11_MODE": "hardened",
        "LIVE_ISSUE_PASSWORD_HINTS": "false",
        "LIVE_LOCKSCREEN_MODE": "hardened",
    },
}

_CAPABILITY_BY_CONFIG_KEY = {
    "LIVE_SUDO_MODE": "live-config.sudo.mode",
    "LIVE_POLKIT_MODE": "live-config.polkit.mode",
    "LIVE_SSH_PERMIT_ROOT_LOGIN": "live-config.ssh.permit-root-login",
    "LIVE_SSH_PASSWORD_AUTHENTICATION": "live-config.ssh.password-authentication",
    "LIVE_XRDP_MODE": "live-config.xrdp.mode",
    "LIVE_X11_MODE": "live-config.x11.mode",
    "LIVE_ISSUE_PASSWORD_HINTS": "live-config.issue.password-hints",
    "LIVE_LOCKSCREEN_MODE": "live-config.lockscreen.mode",
}


class SummaryItem(object):
    def __init__(self, key, params=None, severity="info"):
        self.key = key
        self.params = params or {}
        self.severity = severity


def validate_security_profile(profile):
    if profile not in SECURITY_PROFILE_IDS:
        raise ValueError("unsupported security profile: {0}".format(profile))
    return profile


def default_security_profile(install_mode):
    if install_mode not in DEFAULT_SECURITY_PROFILE:
        raise ValueError("unsupported install mode: {0}".format(install_mode))
    return DEFAULT_SECURITY_PROFILE[install_mode]


def profile_label_key(profile):
    profile = validate_security_profile(profile)
    return "security.profile.{0}.label".format(profile)


def profile_description_key(profile):
    profile = validate_security_profile(profile)
    return "security.profile.{0}.description".format(profile)


def profile_tradeoff_keys(profile):
    profile = validate_security_profile(profile)
    return ("security.profile.{0}.tradeoff".format(profile),)


def live_config_for_profile(profile):
    profile = validate_security_profile(profile)
    return dict(_PROFILE_CONFIG[profile])


def profile_required_capabilities(profile):
    cfg = live_config_for_profile(profile)
    requirements = []
    for key in sorted(_CAPABILITY_BY_CONFIG_KEY):
        requirements.append((_CAPABILITY_BY_CONFIG_KEY[key], cfg[key]))
    return requirements


def append_cmdline_tokens(existing, tokens):
    values = []
    seen = set()
    for token in (existing or "").split():
        if token and token not in seen:
            values.append(token)
            seen.add(token)
    for token in tokens or ():
        if token and token not in seen:
            values.append(token)
            seen.add(token)
    return " ".join(values)


def merge_live_config(profile_cfg, user_overrides):
    merged = dict(profile_cfg or {})
    user_overrides = user_overrides or {}
    for key, value in user_overrides.items():
        merged[key] = value
    if merged.get("DISABLE_SERVICES") and merged.get("ENABLE_SERVICES"):
        disabled = set(_split_services(merged.get("DISABLE_SERVICES")))
        enabled = [service for service in _split_services(merged.get("ENABLE_SERVICES")) if service not in disabled]
        if enabled:
            merged["ENABLE_SERVICES"] = ",".join(enabled)
        else:
            merged.pop("ENABLE_SERVICES", None)
    return merged


def _split_services(value):
    return [item.strip() for item in (value or "").split(",") if item.strip()]


def _join_unique_services(first, second):
    result = []
    for service in _split_services(first) + _split_services(second):
        if service not in result:
            result.append(service)
    return ",".join(result)


def filter_groups_for_profile(groups, profile):
    profile = validate_security_profile(profile)
    result = []
    risky = set(RISKY_GROUPS)
    for group in groups or ():
        if profile == "strict" and group in risky:
            continue
        if group not in result:
            result.append(group)
    return result


def merge_service_lists(enable, disable, profile):
    profile = validate_security_profile(profile)
    return list(enable or ()), list(disable or ())


def profile_summary_items(profile, install_mode, support_class, missing=None):
    profile = validate_security_profile(profile)
    items = [
        SummaryItem(
            "security.summary.profile",
            {"profile": profile, "install_mode": install_mode},
        )
    ]
    if support_class in ("legacy", "partial"):
        items.append(
            SummaryItem(
                "security.summary.support.{0}".format(support_class),
                {"missing": list(missing or ())},
                severity="warning",
            )
        )
    return items


def apply_security_profile(root, profile, log_cb, dry_run=False, runtime_mode=None):
    """Apply profile to *root*.

    Mutates files under *root* only. Service reload/restart is intentionally
    left to callers because installer and configurator have different privilege
    and init-system contexts.
    """

    profile = validate_security_profile(profile)
    if root in (None, ""):
        raise ValueError("root is required")
    cfg = live_config_for_profile(profile)
    _log(log_cb, "Applying security profile {0} to {1}".format(profile, root))
    _apply_sudo(root, cfg["LIVE_SUDO_MODE"], log_cb, dry_run)
    _apply_polkit(root, cfg["LIVE_POLKIT_MODE"], log_cb, dry_run)
    _apply_ssh(root, cfg, log_cb, dry_run)
    _apply_xrdp(root, cfg["LIVE_XRDP_MODE"], log_cb, dry_run)
    _apply_x11(root, cfg["LIVE_X11_MODE"], log_cb, dry_run)
    _apply_issue(root, cfg["LIVE_ISSUE_PASSWORD_HINTS"], log_cb, dry_run)
    _apply_lockscreen(root, cfg["LIVE_LOCKSCREEN_MODE"], log_cb, dry_run)


def _target_path(root, relative_path):
    return os.path.join(root, relative_path.lstrip("/"))


def _log(log_cb, message):
    if log_cb is not None:
        log_cb(message)


def _ensure_dir(path, dry_run):
    if not dry_run:
        os.makedirs(path, exist_ok=True)


def _write(path, text, mode, dry_run):
    if dry_run:
        return
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(path, "w") as handle:
        handle.write(text)
    os.chmod(path, mode)


def _remove(path, dry_run):
    if dry_run:
        return
    try:
        os.unlink(path)
    except OSError:
        pass


def _replace_or_append(path, key, value, sep="=", dry_run=False):
    line = "{0}{1}{2}".format(key, sep, value)
    if dry_run:
        return
    lines = []
    replaced = False
    if os.path.exists(path):
        with open(path, "r") as handle:
            for existing in handle.read().splitlines():
                if existing.startswith(key + sep):
                    lines.append(line)
                    replaced = True
                else:
                    lines.append(existing)
    if not replaced:
        lines.append(line)
    _write(path, "\n".join(lines) + "\n", 0o644, dry_run)


def _apply_sudo(root, mode, log_cb, dry_run):
    live_rule = _target_path(root, "etc/sudoers.d/live")
    minios_rule = _target_path(root, "etc/sudoers.d/minios")
    if mode == "disabled":
        _log(log_cb, "Security profile: disabling MiniOS sudo grant")
        _remove(live_rule, dry_run)
        _remove(minios_rule, dry_run)
        return

    _remove(live_rule, dry_run)
    if mode == "passwordless":
        line = "%sudo ALL=(ALL) NOPASSWD: ALL\n"
    else:
        line = "%sudo ALL=(ALL:ALL) ALL\n"
    _log(log_cb, "Security profile: writing sudo mode {0}".format(mode))
    _write(minios_rule, line, 0o440, dry_run)


def _apply_polkit(root, mode, log_cb, dry_run):
    live_rule = _target_path(root, "usr/share/polkit-1/rules.d/sudo_on_live.rules")
    minios_rule = _target_path(root, "usr/share/polkit-1/rules.d/49-minios-security.rules")
    if mode in ("password", "disabled"):
        _log(log_cb, "Security profile: removing MiniOS passwordless polkit rule")
        _remove(live_rule, dry_run)
        _remove(minios_rule, dry_run)
        return

    text = (
        "// MiniOS security profile: passwordless administrative actions for sudo users\n"
        "polkit.addRule(function(action, subject) {\n"
        "\tif (subject.local && subject.active && subject.isInGroup(\"sudo\")) {\n"
        "\t\treturn polkit.Result.YES;\n"
        "\t}\n"
        "});\n"
    )
    _log(log_cb, "Security profile: writing passwordless polkit rule")
    _remove(live_rule, dry_run)
    _write(minios_rule, text, 0o644, dry_run)


def _apply_ssh(root, cfg, log_cb, dry_run):
    ssh_dir = _target_path(root, "etc/ssh")
    main_config = os.path.join(ssh_dir, "sshd_config")
    dropin_dir = os.path.join(ssh_dir, "sshd_config.d")
    dropin = os.path.join(dropin_dir, "minios.conf")
    if not os.path.isdir(ssh_dir) and not os.path.exists(main_config):
        _log(log_cb, "Security profile: skipping SSH policy; OpenSSH config not present")
        return

    permit_root = "yes" if cfg["LIVE_SSH_PERMIT_ROOT_LOGIN"] == "true" else "no"
    password_auth = "yes" if cfg["LIVE_SSH_PASSWORD_AUTHENTICATION"] == "true" else "no"
    text = (
        "# Managed by MiniOS security profile\n"
        "PermitRootLogin {0}\n"
        "PasswordAuthentication {1}\n"
    ).format(permit_root, password_auth)
    _log(log_cb, "Security profile: writing SSH policy")
    _ensure_dir(dropin_dir, dry_run)
    _write(dropin, text, 0o644, dry_run)

    if os.path.exists(main_config) and not dry_run:
        with open(main_config, "r") as handle:
            content = handle.read()
        if "Include /etc/ssh/sshd_config.d/*.conf" not in content:
            with open(main_config, "a") as handle:
                if content and not content.endswith("\n"):
                    handle.write("\n")
                handle.write("Include /etc/ssh/sshd_config.d/*.conf\n")


def _apply_xrdp(root, mode, log_cb, dry_run):
    xrdp_ini = _target_path(root, "etc/xrdp/xrdp.ini")
    sesman_ini = _target_path(root, "etc/xrdp/sesman.ini")
    if not os.path.exists(xrdp_ini) and not os.path.exists(sesman_ini):
        _log(log_cb, "Security profile: skipping XRDP policy; XRDP config not present")
        return

    if mode == "disabled":
        _log(log_cb, "Security profile: disabling XRDP service links where present")
        for rel in (
            "etc/systemd/system/multi-user.target.wants/xrdp.service",
            "etc/systemd/system/multi-user.target.wants/xrdp-sesman.service",
            "etc/systemd/system/graphical.target.wants/xrdp.service",
            "etc/rc2.d/S01xrdp",
            "etc/rc3.d/S01xrdp",
            "etc/rc4.d/S01xrdp",
            "etc/rc5.d/S01xrdp",
        ):
            _remove(_target_path(root, rel), dry_run)
        return

    if mode == "hardened":
        _log(log_cb, "Security profile: hardening XRDP config")
        if os.path.exists(xrdp_ini):
            _replace_or_append(xrdp_ini, "port", "tcp://127.0.0.1:3389", dry_run=dry_run)
            _replace_or_append(xrdp_ini, "security_layer", "negotiate", dry_run=dry_run)
            _replace_or_append(xrdp_ini, "crypt_level", "high", dry_run=dry_run)
        if os.path.exists(sesman_ini):
            _replace_or_append(sesman_ini, "AllowRootLogin", "false", dry_run=dry_run)
            _replace_or_append(sesman_ini, "AlwaysGroupCheck", "true", dry_run=dry_run)


def _apply_x11(root, mode, log_cb, dry_run):
    if mode != "hardened":
        return
    _log(log_cb, "Security profile: hardening X11 launch config")
    wrapper = _target_path(root, "etc/X11/Xwrapper.config")
    if os.path.exists(wrapper):
        _replace_or_append(wrapper, "allowed_users", "console", dry_run=dry_run)
        _replace_or_append(wrapper, "needs_root_rights", "auto", dry_run=dry_run)

    start_xorg = _target_path(root, "usr/bin/start-xorg.sh")
    if os.path.exists(start_xorg) and not dry_run:
        with open(start_xorg, "r") as handle:
            content = handle.read()
        content = content.replace(" -ac -nolisten tcp", " -nolisten tcp")
        content = content.replace(" -ac\"", "\"")
        with open(start_xorg, "w") as handle:
            handle.write(content)


def _apply_issue(root, hints, log_cb, dry_run):
    if hints == "true":
        return
    issue = _target_path(root, "etc/issue")
    if not os.path.exists(issue):
        return
    _log(log_cb, "Security profile: removing default password hints from /etc/issue")
    if dry_run:
        return
    with open(issue, "r") as handle:
        lines = handle.read().splitlines()
    filtered = []
    skip_heading = False
    for line in lines:
        plain = line.replace("\x1b[1;33m", "").replace("\x1b[0;29m", "")
        if "Default password" in plain:
            skip_heading = True
            continue
        if skip_heading and ("root:" in plain or "live:" in plain):
            continue
        skip_heading = False
        filtered.append(line)
    _write(issue, "\n".join(filtered) + "\n", 0o644, dry_run)


def _apply_lockscreen(root, mode, log_cb, dry_run):
    if mode != "hardened":
        return
    _log(log_cb, "Security profile: preserving/enabling lockscreen settings where present")
    for home_root in (_target_path(root, "home"), _target_path(root, "root")):
        if not os.path.isdir(home_root):
            continue
        candidates = []
        if os.path.basename(home_root) == "home":
            for name in os.listdir(home_root):
                candidates.append(os.path.join(home_root, name, ".xscreensaver"))
        else:
            candidates.append(os.path.join(home_root, ".xscreensaver"))
        for path in candidates:
            if os.path.exists(path):
                _replace_or_append(path, "lock", " True", sep=":", dry_run=dry_run)

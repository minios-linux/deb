# python3-minios-security

Shared MiniOS Python helpers for capabilities discovery and security profile matrices.

This package is intentionally UI-neutral: it returns stable message keys and concrete config values. `minios-installer` and `minios-configurator` own translations and presentation.

## Public APIs

`minios_security.capabilities` reads `/usr/share/minios/capabilities/*.json` under a supplied root and classifies profile support as:

- `legacy`: no readable capabilities registry.
- `partial`: registry exists, but at least one required posture id/value is missing.
- `full`: every required posture id/value is present.

`minios_security.security_profiles` owns the canonical profile ids and defaults:

- `convenient`: live default, historical MiniOS convenience posture.
- `balanced`: native default, disables autologin, disables active remote management services (`ssh`, `xrdp`), and requires passwords for sudo/polkit while keeping SSH password auth policy available for later explicit re-enable.
- `strict`: disables autologin, SSH root login, SSH password auth, and strips risky groups such as `docker`/`libvirt` from newly created users.

## Mutator Coverage

`apply_security_profile(root, profile, log_cb, dry_run=False, runtime_mode=None)` mutates only files below `root`.

Current implemented mutations:

- sudo: removes legacy `/etc/sudoers.d/live` and writes/removes `/etc/sudoers.d/minios` according to the profile.
- PolicyKit: removes legacy `sudo_on_live.rules`; convenient writes a MiniOS passwordless rule, balanced/strict fall back to normal distribution authentication.
- OpenSSH: writes `/etc/ssh/sshd_config.d/minios.conf` when SSH config is present and ensures the main config includes drop-ins.
- XRDP: balanced hardens listener/security/root-login settings; strict removes common service enable links.
- X11: hardened mode removes `-ac` from MiniOS `start-xorg.sh` and tightens `Xwrapper.config` when present.
- Issue banner: strict removes default password hints from `/etc/issue` when present.
- Lockscreen: hardened mode preserves/enables `.xscreensaver` locking where user config files already exist.

Still pending for later phases: service reload/restart orchestration and richer desktop-specific lockscreen backends beyond file-level settings.

The mutator deliberately does not restart services. Installer and configurator have different init/elevation contexts, so callers handle service reloads through their own service abstraction.

import json
import os

from minios_security.capabilities import (
    get_config_key,
    has,
    load_capabilities,
    support_class,
    supports,
)


def _write_capabilities(tmpdir, package, capabilities):
    directory = tmpdir.mkdir("usr").mkdir("share").mkdir("minios").mkdir("capabilities")
    path = directory.join(package + ".json")
    path.write(
        json.dumps(
            {
                "schema": 1,
                "package": package,
                "version": "1",
                "capabilities": capabilities,
            }
        )
    )
    return str(path)


def _write_capabilities_file(root, package, capabilities):
    directory = os.path.join(str(root), "usr", "share", "minios", "capabilities")
    if not os.path.isdir(directory):
        os.makedirs(directory)
    path = os.path.join(directory, package + ".json")
    with open(path, "w") as handle:
        json.dump(
            {
                "schema": 1,
                "package": package,
                "version": "1",
                "capabilities": capabilities,
            },
            handle,
        )
    return path


def test_missing_registry_is_legacy(tmpdir):
    registry = load_capabilities(str(tmpdir))
    assert registry.is_legacy
    assert support_class(registry, [("live-config.sudo.mode", "password")]) == "legacy"


def test_enum_boolean_string_and_config_key(tmpdir):
    _write_capabilities(
        tmpdir,
        "minios-live-config",
        {
            "live-config.sudo.mode": {
                "type": "enum",
                "values": ["passwordless", "password", "disabled"],
                "config_key": "LIVE_SUDO_MODE",
            },
            "live-config.ssh.permit-root-login": {
                "type": "boolean",
                "config_key": "LIVE_SSH_PERMIT_ROOT_LOGIN",
            },
            "live-config.hostname": {"type": "string", "config_key": "LIVE_HOSTNAME"},
            "live-config.noautologin": {"type": "flag"},
        },
    )
    registry = load_capabilities(str(tmpdir))
    assert has(registry, "live-config.sudo.mode")
    assert supports(registry, "live-config.sudo.mode", "password")
    assert not supports(registry, "live-config.sudo.mode", "root")
    assert supports(registry, "live-config.ssh.permit-root-login", True)
    assert supports(registry, "live-config.ssh.permit-root-login", "false")
    assert not supports(registry, "live-config.ssh.permit-root-login", "False")
    assert supports(registry, "live-config.hostname", "minios")
    assert supports(registry, "live-config.noautologin", True)
    assert get_config_key(registry, "live-config.sudo.mode") == "LIVE_SUDO_MODE"


def test_support_class_full_and_partial(tmpdir):
    _write_capabilities(
        tmpdir,
        "minios-live-config",
        {
            "live-config.sudo.mode": {
                "type": "enum",
                "values": ["passwordless", "password"],
            }
        },
    )
    registry = load_capabilities(str(tmpdir))
    assert support_class(registry, [("live-config.sudo.mode", "password")]) == "full"
    assert support_class(registry, [("live-config.sudo.mode", "disabled")]) == "partial"


def test_collision_invalidates_only_collided_id(tmpdir):
    root = str(tmpdir)
    _write_capabilities_file(
        root,
        "minios-live-config",
        {
            "live-config.sudo.mode": {"type": "enum", "values": ["password"]},
            "live-config.hostname": {"type": "string"},
        },
    )
    _write_capabilities_file(
        root,
        "another-package",
        {
            "live-config.sudo.mode": {"type": "enum", "values": ["passwordless"]},
            "another.feature": {"type": "flag"},
        },
    )
    registry = load_capabilities(root)
    assert not has(registry, "live-config.sudo.mode")
    assert has(registry, "live-config.hostname")
    assert has(registry, "another.feature")
    assert support_class(registry, [("live-config.sudo.mode", "password")]) == "partial"


def test_package_filename_mismatch_skips_file(tmpdir):
    path = _write_capabilities(tmpdir, "minios-live-config", {"x.y": {"type": "flag"}})
    with open(path, "r") as handle:
        data = json.load(handle)
    data["package"] = "wrong"
    with open(path, "w") as handle:
        json.dump(data, handle)
    registry = load_capabilities(str(tmpdir))
    assert not has(registry, "x.y")
    assert registry.is_legacy

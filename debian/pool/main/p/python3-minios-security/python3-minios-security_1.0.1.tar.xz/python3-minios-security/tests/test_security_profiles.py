import pytest

from minios_security.security_profiles import (
    append_cmdline_tokens,
    apply_security_profile,
    default_security_profile,
    filter_groups_for_profile,
    live_config_for_profile,
    merge_live_config,
    merge_service_lists,
    profile_required_capabilities,
    validate_security_profile,
)


def test_defaults_by_mode():
    assert default_security_profile("live") == "convenient"
    assert default_security_profile("native") == "balanced"


def test_invalid_profile_raises():
    with pytest.raises(ValueError):
        validate_security_profile("locked-down")


def test_matrix_snapshot():
    assert live_config_for_profile("convenient") == {
        "LIVE_SECURITY_PROFILE": "convenient",
        "LIVE_SUDO_MODE": "passwordless",
        "LIVE_POLKIT_MODE": "passwordless",
        "LIVE_SSH_PERMIT_ROOT_LOGIN": "true",
        "LIVE_SSH_PASSWORD_AUTHENTICATION": "true",
        "LIVE_XRDP_MODE": "relaxed",
        "LIVE_X11_MODE": "relaxed",
        "LIVE_ISSUE_PASSWORD_HINTS": "true",
        "LIVE_LOCKSCREEN_MODE": "relaxed",
    }
    assert live_config_for_profile("balanced")["LIVE_CONFIG_CMDLINE"] == "noautologin"
    assert "DISABLE_SERVICES" not in live_config_for_profile("balanced")
    assert live_config_for_profile("strict")["LIVE_SSH_PASSWORD_AUTHENTICATION"] == "false"
    assert live_config_for_profile("strict")["LIVE_XRDP_MODE"] == "disabled"
    assert "DISABLE_SERVICES" not in live_config_for_profile("strict")


def test_required_capabilities_exclude_profile_label():
    ids = [item[0] for item in profile_required_capabilities("strict")]
    assert "live-config.security-profile.label" not in ids
    assert "live-config.sudo.mode" in ids
    assert "live-config.ssh.password-authentication" in ids


def test_cmdline_merge_preserves_existing_tokens():
    assert append_cmdline_tokens("quiet nox11autologin", ["noautologin", "quiet"]) == (
        "quiet nox11autologin noautologin"
    )


def test_merge_live_config_user_overrides_and_cmdline_union():
    profile_cfg = live_config_for_profile("balanced")
    merged = merge_live_config(
        profile_cfg,
        {"LIVE_HOSTNAME": "box", "LIVE_CONFIG_CMDLINE": "quiet"},
    )
    assert merged["LIVE_HOSTNAME"] == "box"
    assert merged["LIVE_CONFIG_CMDLINE"] == "quiet noautologin"


def test_merge_live_config_keeps_user_service_choices():
    profile_cfg = live_config_for_profile("balanced")
    merged = merge_live_config(
        profile_cfg,
        {"ENABLE_SERVICES": "ssh,xrdp,cups", "DISABLE_SERVICES": "bluetooth"},
    )
    assert merged["ENABLE_SERVICES"] == "ssh,xrdp,cups"
    assert merged["DISABLE_SERVICES"] == "bluetooth"


def test_group_filter_strict_strips_risky_groups_only():
    groups = ["sudo", "docker", "audio", "kvm", "audio"]
    assert filter_groups_for_profile(groups, "balanced") == [
        "sudo",
        "docker",
        "audio",
        "kvm",
    ]
    assert filter_groups_for_profile(groups, "strict") == ["sudo", "audio"]


def test_service_merge_does_not_apply_profile_exposure_policy():
    enable, disable = merge_service_lists(["ssh", "xrdp", "cups"], ["cups"], "balanced")
    assert enable == ["ssh", "xrdp", "cups"]
    assert disable == ["cups"]

    enable, disable = merge_service_lists(["ssh", "xrdp", "cups"], [], "strict")
    assert enable == ["ssh", "xrdp", "cups"]
    assert disable == []


def test_apply_security_profile_stub_logs_and_validates(tmpdir):
    messages = []
    apply_security_profile(str(tmpdir), "balanced", messages.append, dry_run=True)
    assert messages
    with pytest.raises(ValueError):
        apply_security_profile("", "balanced", messages.append)


def test_apply_security_profile_writes_sudo_polkit_ssh(tmpdir):
    root = tmpdir
    root.join("etc").mkdir()
    root.join("etc", "sudoers.d").mkdir()
    root.join("etc", "sudoers.d", "live").write("live ALL=(ALL) NOPASSWD: ALL\n")
    root.join("usr").mkdir()
    root.join("usr", "share").mkdir()
    root.join("usr", "share", "polkit-1").mkdir()
    root.join("usr", "share", "polkit-1", "rules.d").mkdir()
    root.join("usr", "share", "polkit-1", "rules.d", "sudo_on_live.rules").write("old\n")
    root.join("etc", "ssh").mkdir()
    root.join("etc", "ssh", "sshd_config").write(
        "Port 22\nInclude /etc/ssh/sshd_config.d/*.conf\n"
    )
    root.join("var").mkdir()
    root.join("var", "lib").mkdir()
    root.join("var", "lib", "dpkg").mkdir()
    root.join("var", "lib", "dpkg", "status").write(
        "Package: openssh-server\nVersion: 1:9.2p1-2\n"
    )

    apply_security_profile(str(root), "strict", lambda _msg: None)

    assert not root.join("etc", "sudoers.d", "live").check()
    assert root.join("etc", "sudoers.d", "minios").read() == "%sudo ALL=(ALL:ALL) ALL\n"
    assert not root.join("usr", "share", "polkit-1", "rules.d", "sudo_on_live.rules").check()
    assert not root.join("usr", "share", "polkit-1", "rules.d", "49-minios-security.rules").check()
    ssh_config = root.join("etc", "ssh", "sshd_config").read()
    assert ssh_config.startswith("# BEGIN MiniOS security profile\n")
    assert "PermitRootLogin no" in ssh_config
    assert "PasswordAuthentication no" in ssh_config
    assert "Include /etc/ssh/sshd_config.d/*.conf" in ssh_config
    assert not root.join("etc", "ssh", "sshd_config.d", "minios.conf").check()


def test_apply_security_profile_inlines_policy_for_bionic_openssh(tmpdir):
    root = tmpdir
    root.join("etc").mkdir()
    root.join("etc", "ssh").mkdir()
    root.join("etc", "ssh", "sshd_config.d").mkdir()
    root.join("etc", "ssh", "sshd_config.d", "minios.conf").write("old\n")
    root.join("etc", "ssh", "sshd_config").write(
        "Port 22\nInclude /etc/ssh/sshd_config.d/*.conf\n"
    )
    root.join("etc", "ssh", "sshd_config").chmod(0o600)
    root.join("var").mkdir()
    root.join("var", "lib").mkdir()
    root.join("var", "lib", "dpkg").mkdir()
    root.join("var", "lib", "dpkg", "status").write(
        "Package: openssh-server\nVersion: 1:7.6p1-4ubuntu0.7\n"
    )

    apply_security_profile(str(root), "strict", lambda _msg: None)

    ssh_config = root.join("etc", "ssh", "sshd_config").read()
    assert ssh_config.startswith("# BEGIN MiniOS security profile\n")
    assert "PermitRootLogin no" in ssh_config
    assert "PasswordAuthentication no" in ssh_config
    assert "Include /etc/ssh/sshd_config.d/*.conf" not in ssh_config
    assert not root.join("etc", "ssh", "sshd_config.d", "minios.conf").check()
    assert root.join("etc", "ssh", "sshd_config").stat().mode & 0o777 == 0o600

    root.join("etc", "sudoers.d", "minios").chmod(0o640)
    apply_security_profile(str(root), "convenient", lambda _msg: None)
    ssh_config = root.join("etc", "ssh", "sshd_config").read()
    assert ssh_config.count("# BEGIN MiniOS security profile") == 1
    assert "PermitRootLogin yes" in ssh_config
    assert "PasswordAuthentication yes" in ssh_config


def test_apply_security_profile_convenient_writes_passwordless_rules(tmpdir):
    root = tmpdir
    root.join("etc").mkdir()
    root.join("etc", "sudoers.d").mkdir()
    root.join("usr").mkdir()
    root.join("usr", "share").mkdir()
    root.join("usr", "share", "polkit-1").mkdir()
    root.join("usr", "share", "polkit-1", "rules.d").mkdir()

    apply_security_profile(str(root), "convenient", lambda _msg: None)

    assert root.join("etc", "sudoers.d", "minios").read() == "%sudo ALL=(ALL) NOPASSWD: ALL\n"
    assert "polkit.Result.YES" in root.join(
        "usr", "share", "polkit-1", "rules.d", "49-minios-security.rules"
    ).read()


def test_apply_security_profile_dry_run_does_not_write(tmpdir):
    apply_security_profile(str(tmpdir), "strict", lambda _msg: None, dry_run=True)
    assert not tmpdir.join("etc").check()


def test_apply_security_profile_balanced_hardens_xrdp_x11_and_lock(tmpdir):
    root = tmpdir
    root.join("etc").mkdir()
    root.join("etc", "xrdp").mkdir()
    root.join("etc", "xrdp", "xrdp.ini").write(
        "port=vsock://-1:3389 tcp://:3389\nsecurity_layer=rdp\ncrypt_level=none\n"
    )
    root.join("etc", "xrdp", "sesman.ini").write(
        "AllowRootLogin=true\nAlwaysGroupCheck=false\n"
    )
    root.join("etc", "X11").mkdir()
    root.join("etc", "X11", "Xwrapper.config").write(
        "allowed_users=anybody\nneeds_root_rights=yes\n"
    )
    root.join("usr").mkdir()
    root.join("usr", "bin").mkdir()
    root.join("usr", "bin", "start-xorg.sh").write(
        "exec /usr/bin/startx -- :0 vt7 -ac -nolisten tcp\n"
    )
    root.join("home").mkdir()
    root.join("home", "alice").mkdir()
    root.join("home", "alice", ".xscreensaver").write("lock: False\n")

    apply_security_profile(str(root), "balanced", lambda _msg: None)

    assert "port=tcp://127.0.0.1:3389" in root.join("etc", "xrdp", "xrdp.ini").read()
    assert "security_layer=negotiate" in root.join("etc", "xrdp", "xrdp.ini").read()
    assert "crypt_level=high" in root.join("etc", "xrdp", "xrdp.ini").read()
    assert "AllowRootLogin=false" in root.join("etc", "xrdp", "sesman.ini").read()
    assert "AlwaysGroupCheck=true" in root.join("etc", "xrdp", "sesman.ini").read()
    assert "allowed_users=console" in root.join("etc", "X11", "Xwrapper.config").read()
    assert "needs_root_rights=auto" in root.join("etc", "X11", "Xwrapper.config").read()
    assert " -ac " not in root.join("usr", "bin", "start-xorg.sh").read()
    assert "lock: True" in root.join("home", "alice", ".xscreensaver").read()


def test_apply_security_profile_strict_removes_issue_password_hints(tmpdir):
    root = tmpdir
    root.join("etc").mkdir()
    root.join("etc", "issue").write("Default passwords:\nroot: toor\nlive: evil\nKeep me\n")

    apply_security_profile(str(root), "strict", lambda _msg: None)

    issue = root.join("etc", "issue").read()
    assert "toor" not in issue
    assert "evil" not in issue
    assert "Keep me" in issue


def test_apply_security_profile_disabled_xrdp_removes_service_links(tmpdir):
    root = tmpdir
    root.join("etc").mkdir()
    root.join("etc", "xrdp").mkdir()
    root.join("etc", "xrdp", "xrdp.ini").write("port=tcp://:3389\n")
    root.join("etc", "systemd").mkdir()
    root.join("etc", "systemd", "system").mkdir()
    root.join("etc", "systemd", "system", "multi-user.target.wants").mkdir()
    root.join("etc", "systemd", "system", "multi-user.target.wants", "xrdp.service").write("x")

    apply_security_profile(str(root), "strict", lambda _msg: None)

    assert not root.join(
        "etc", "systemd", "system", "multi-user.target.wants", "xrdp.service"
    ).check()

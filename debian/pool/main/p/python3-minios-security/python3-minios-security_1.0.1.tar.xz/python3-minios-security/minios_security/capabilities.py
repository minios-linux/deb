"""Capabilities registry loader for MiniOS tools.

The registry is advisory metadata under
``/usr/share/minios/capabilities/*.json``. Presence of a capability id means
support; collisions fail closed for the collided ids only.
"""

from __future__ import absolute_import

import glob
import json
import os


CAPABILITIES_DIR = "usr/share/minios/capabilities"
VALID_TYPES = ("enum", "boolean", "string", "flag")


class CapabilityRecord(object):
    """One capability descriptor loaded from a package registry file."""

    def __init__(self, capability_id, package, version, descriptor, invalid=False):
        self.id = capability_id
        self.package = package
        self.version = version
        self.descriptor = descriptor
        self.invalid = invalid

    @property
    def type(self):
        return self.descriptor.get("type")

    @property
    def values(self):
        values = self.descriptor.get("values")
        if isinstance(values, list):
            return values
        return []

    @property
    def config_key(self):
        value = self.descriptor.get("config_key")
        if isinstance(value, str):
            return value
        return None


class CapabilityRegistry(object):
    """Loaded capability records plus non-fatal loader diagnostics."""

    def __init__(self, records=None, errors=None):
        self.records = records or {}
        self.errors = errors or []

    @property
    def is_legacy(self):
        return not self.records


def _root_join(root, relative_path):
    if root in (None, ""):
        root = "/"
    return os.path.join(root, relative_path)


def _log(log_cb, message):
    if log_cb is not None:
        log_cb(message)


def _valid_descriptor(descriptor):
    if not isinstance(descriptor, dict):
        return False
    cap_type = descriptor.get("type")
    if cap_type not in VALID_TYPES:
        return False
    values = descriptor.get("values")
    if cap_type == "enum":
        if not isinstance(values, list) or not values:
            return False
        seen = set()
        for value in values:
            if not isinstance(value, str) or value in seen:
                return False
            seen.add(value)
    return True


def _invalid_record(capability_id, record):
    if record is None:
        return CapabilityRecord(capability_id, "", "", {}, invalid=True)
    return CapabilityRecord(
        capability_id,
        record.package,
        record.version,
        record.descriptor,
        invalid=True,
    )


def load_capabilities(root="/", log_cb=None):
    """Load all capability JSON files under *root*.

    Returns a :class:`CapabilityRegistry`. Missing directories, unreadable
    files, schema mismatches, filename/package mismatches, and invalid
    descriptors are non-fatal. Duplicate ids are marked unsupported while other
    ids remain usable.
    """

    records = {}
    errors = []
    capabilities_dir = _root_join(root, CAPABILITIES_DIR)
    pattern = os.path.join(capabilities_dir, "*.json")

    for path in sorted(glob.glob(pattern)):
        filename = os.path.basename(path)
        expected_package = filename[:-5]
        try:
            with open(path, "r") as handle:
                data = json.load(handle)
        except Exception as exc:  # pragma: no cover - exact exception varies
            msg = "cannot load capabilities file {0}: {1}".format(path, exc)
            errors.append(msg)
            _log(log_cb, msg)
            continue

        if not isinstance(data, dict) or data.get("schema") != 1:
            msg = "unsupported capabilities schema in {0}".format(path)
            errors.append(msg)
            _log(log_cb, msg)
            continue

        package = data.get("package")
        if package != expected_package:
            msg = "capabilities package mismatch in {0}".format(path)
            errors.append(msg)
            _log(log_cb, msg)
            continue

        version = data.get("version")
        capabilities = data.get("capabilities")
        if not isinstance(capabilities, dict):
            msg = "invalid capabilities map in {0}".format(path)
            errors.append(msg)
            _log(log_cb, msg)
            continue

        for capability_id, descriptor in capabilities.items():
            if not isinstance(capability_id, str) or not _valid_descriptor(descriptor):
                msg = "invalid capability descriptor {0} in {1}".format(
                    capability_id, path
                )
                errors.append(msg)
                _log(log_cb, msg)
                continue

            if capability_id in records:
                msg = "capability id collision: {0}".format(capability_id)
                errors.append(msg)
                _log(log_cb, msg)
                records[capability_id] = _invalid_record(capability_id, records.get(capability_id))
                continue

            records[capability_id] = CapabilityRecord(
                capability_id,
                package,
                version if isinstance(version, str) else "",
                descriptor,
            )

    return CapabilityRegistry(records, errors)


def _records(registry):
    if registry is None:
        return {}
    if isinstance(registry, CapabilityRegistry):
        return registry.records
    return registry


def has(registry, capability_id):
    """Return true when *capability_id* is present and not collision-invalid."""

    record = _records(registry).get(capability_id)
    return record is not None and not record.invalid


def supports(registry, capability_id, value=True):
    """Return whether *capability_id* supports *value* according to its type."""

    record = _records(registry).get(capability_id)
    if record is None or record.invalid:
        return False

    cap_type = record.type
    if cap_type == "enum":
        return isinstance(value, str) and value in record.values
    if cap_type == "boolean":
        return value is True or value is False or value in ("true", "false")
    if cap_type == "string":
        return isinstance(value, str)
    if cap_type == "flag":
        return value is True or value is None
    return False


def get_config_key(registry, capability_id):
    record = _records(registry).get(capability_id)
    if record is None or record.invalid:
        return None
    return record.config_key


def support_class(registry, requirements):
    """Classify capability support as ``legacy``, ``partial``, or ``full``."""

    records = _records(registry)
    if not records:
        return "legacy"
    for capability_id, value in requirements:
        if not supports(registry, capability_id, value):
            return "partial"
    return "full"

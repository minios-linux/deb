# xfce4-tasklist-minios-plugin

MiniOS fork of Xfce Window Buttons for Xfce 4.20.

The source and binary packages are named `xfce4-tasklist-minios-plugin`.
The panel module is `minios-tasklist`, and the gettext/Lokit identity is
`xfce4-minios-tasklist-plugin`.

Localization configuration, terminology and lock state live in the parent
`minios-live` workspace. Run `lokit status --target xfce4-minios-tasklist-plugin`
from that workspace root; the PO catalogs remain in this repository.

It adds pinned applications, pin/unpin actions, drag-and-drop pinning and reordering, pinned-app management in settings, optional expansion across free panel space, and removes the grouped-window number badge. Visual styling is provided by the Greybird-MiniOS GTK theme.

## Pinned launchers without windows

Pinned application buttons are initialized when the panel connects to its Xfce
screen, even if there are no application windows yet. They stay visible on a
fresh desktop and return to their original slots when the last instance exits.
When **Fill all available panel space** is enabled, the tasklist retains a
nonzero minimum and natural length even with no buttons, so Xfce allocates the
whole free area between the bounding separators to it. A following expanding
separator is made fixed-width at runtime only while the tasklist is expanded;
its saved expansion preference is preserved and restored on tasklist collapse
or removal. The tasklist expansion preference is saved in xfconf and survives
relogin. Creating or removing a running window never requires restarting the
panel to restore the launchers.

## Window previews

Hover over a running window or grouped application button to see its thumbnail
after a short delay. Grouped buttons show individual window previews; clicking
a preview activates that window. The popup remains available briefly while
moving the pointer from the taskbar button to a thumbnail. The popup remains
open while the pointer is over either the taskbar button or any part of the
preview and disappears only after the pointer leaves both (including the
configurable grace period). Clicking a preview activates the chosen window.

With compositing and GTK animations enabled, hover previews rise from below
and fade in over 180 ms (up to 18 px of movement). After the hide delay they
slide down and fade out. Re-entering during dismissal reverses the animation
from its current position; moving to another task button preserves that
button's pending preview while the old popup finishes hiding. The popup's
native shadow, blur and clickable geometry move together. Disabling system
animations or compositing gives immediate transitions; owner removal and
configuration changes dispose of the popup and animation callbacks directly.

In the MiniOS Window Buttons panel-plugin settings, **Window previews** has a
master enable/disable checkbox and a **Configure** dialog with live settings:

- Maximum preview width (120–800 px; default 300 px) and height (80–340 px; default 192 px) for each window thumbnail, including its footer icon and title; smaller source windows keep their proportions
- Rectangular thumbnail canvases follow the configured limits, with the source image fitted proportionally inside; there is no fixed 128-pixel cap
- Hover delay (0–1500 ms; default 320 ms)
- Hide delay (0–1500 ms; default 230 ms)
- Update interval (0–5000 ms; default 850 ms; 0 means static preview)
- Group preview limit (1–8; default 6)
- Window decorations (disabled by default): capture only the client area, or include the frame/title bar when enabled (also available with window-switcher-style thumbnails)
- Window titles (enabled by default), with a separate bottom-right close X for that specific window (including in groups). The popup is an interactive X11 window, not a pointer-transparent tooltip, and failed close requests are reported without dismissing it.
- Window-switcher surface: current GTK theme (default), with an optional custom background color from the GTK color chooser
- Background opacity (0–100%, default 80%); thumbnail images and selection opacity are independent of the surface
- Corner radius (0–36 px, default 12 px)
- Border width (0–5 px, default 0 px)
- Interior padding around preview cards (0–64 px, default 24 px)
- Space between grouped thumbnails (0–20 px, default 4 px)
- Label text color: automatically contrasted with the theme or custom background, including when its entire preview card is hovered
- Whole-card selection with an adjustable content inset (0–32 px, default 5), optional custom color (default follows the GTK theme), radius (0–36 px, default 6), and opacity (0–100%, default 30); close and activation buttons remain interactive
- Optional OpenGL backdrop blur behind the translucent popup (controlled independently in xfwm4-gl); the plugin publishes its card-content rectangle using `_XFWM4_BLUR_CONTENT_RECT`, so the compositor's shadow is not included in the blur mask; XRender still displays ordinary transparency

The popup uses xfwm4's native Gaussian shadow, governed by the global
**Show shadows under popup windows** switch (`/general/show_popup_shadow`) and
the standard shadow opacity and offsets. There are no plugin-specific shadow
controls or CSS drop shadows. Saved `preview-shadow-enabled` and
`preview-shadow-opacity` values from earlier development builds are ignored.

The aspect ratio is preserved. When a group would exceed the monitor width,
individual thumbnails are reduced to fit. Appearance and opacity use a
transparent GTK popup and local CSS so other GTK windows are not recolored.
The final fit uses complete themed card requisitions, including caption and
close controls. If their minimum sizes cannot fit, fewer cards are displayed;
selection padding may shrink for that popup without changing its saved value.
Border and interior-padding changes dismiss an existing popup so the next
hover computes fresh bounds. Group previews honor the same workspace, monitor
and minimized-window filters as the group menu, and preview activation respects
the tasklist's workspace-switching preference.
Appearance options are on a separate tab in the preview settings dialog.
Changes take effect without restarting the panel. Disabling previews stops
capture and timers; the standard Xfce text tooltips remain available when enabled.

**Reset** in the preview settings dialog restores preview enablement,
dimensions, timing, Peek/frame options, titles/decorations and appearance,
including selection. The widget's property defaults are used directly, and the
controls update without closing the dialog. Pinned applications and general
panel-plugin behavior are preserved.

The thumbnail uses the redirected X11 **frame** pixmap via XComposite; it
crops to the client window by default. It works with both OpenGL and XRender. If a window's pixmap is
unavailable (for example, it is already minimized), the last captured preview
is used, then its application icon as a fallback. A fully disabled compositor
may likewise show an icon. No screenshot of the entire desktop is taken.

## Shared window-switcher appearance and real-window outline

The preview always uses the current GTK theme's native `#xfwm-tabwin` style.
Appearance settings customize that surface directly: color, opacity, rounded
corners, border, card spacing and padding work together with the same themed
thumbnail layout and checked-card selection. The old style switch and separate
legacy layout are removed; saved `preview-tabwin-style` values are ignored.
The window image keeps its configurable
size limits, cropping, and XComposite cache; as in `xfwm4`'s `getClientIcon`,
the application badge is composited at the bottom center of the thumbnail,
so the footer does not repeat the icon. This shares GTK styling and visual
conventions without incorrectly sharing GPU textures across processes.
The surface CSS, defaults and theme fallback are shared with xfwm4 through
`common/xfwm-tabwin-style.h`, alongside the existing thumbnail composition
header. The window manager exposes equivalent options in **Window Manager
Tweaks → Cycling → Appearance**; each component keeps its own saved values.

**Peek on hover** is the single selection-effect mode control, shared with
the window switcher: Off, Dim other windows or Hide other windows. Two additional switches
control the **real window-switcher frame** and the **highlight inside that
frame**. Disabling the frame always disables the fill. With Peek Off, the
frame is mandatory and its toggle cannot be disabled. The panel sends the
window ID and fill flag via `_XFWM4_HOVER_FRAME` and `xfwm4` uses its original
wireframe renderer, including the fallback for XRender or disabled compositing.
The WM's wireframe is input-transparent, so a selected window overlapping the
popup cannot block activation or close buttons on later cards in a group.
A hovered card receives the current GTK theme's checked-button styling,
including its caption and outer content inset. The image activation button
does not draw a second, tightly fitted selection. All transient effects stop
on hover exit, and the WM cancels a
lost-panel frame after 850 milliseconds without a heartbeat.

## OpenGL Peek

The optional **Peek on hover** setting offers three modes: Off (default),
Dim other windows, and Hide other windows. Dim mode also has a configurable
opacity for the other windows (default 15%). Hovering a particular thumbnail
draws its window above ordinary windows without mapping, activating,
restacking or changing any client's real X11 state; this also works for
minimized windows whose last texture is retained by the GL compositor.
The visual transition is smoothed in OpenGL and cancelled on hover exit.
A 1.1-second heartbeat guard prevents a stuck Peek if the panel crashes.
Peek is unavailable with XRender or when compositing is off; the ordinary
thumbnail popup remains functional.

## Regression tests

With the development dependencies, Xvfb and xauth installed, run an out-of-tree
Meson build and `meson test -C <build-directory> --print-errorlogs`.
The five GTK regression cases cover filtered groups, workspace-aware preview
activation, grouped-window tooltips, complete card sizing and separator
restoration after panel reordering/removal. Windowing operations use a
deterministic backend; these tests do not replace testing against a running WM.

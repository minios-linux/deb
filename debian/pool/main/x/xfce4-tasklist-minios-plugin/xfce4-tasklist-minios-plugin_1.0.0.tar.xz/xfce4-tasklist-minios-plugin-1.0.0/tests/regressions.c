/* Exercise production GTK layouts/lifecycles with a deterministic windowing
 * backend. No WM or compositor is required; Xvfb supplies only the GTK display. */
#include "config.h"
#include <libxfce4panel/libxfce4panel.h>
#include <libxfce4windowing/libxfce4windowing.h>
#include <libxfce4windowing/xfw-x11.h>

static GList *backend_windows;
static XfwWorkspace *active_workspace;
static guint workspace_calls, activation_calls, minimize_calls;
static GdkPixbuf *backend_icon;
static const gchar *backend_name (XfwWindow *w) { return "A long window title for layout regression coverage"; }
static XfwWindowState backend_state (XfwWindow *w) { return GPOINTER_TO_UINT (g_object_get_data (G_OBJECT (w), "state")); }
static GdkPixbuf *backend_get_icon (XfwWindow *w, gint size, gint scale)
{
  g_assert_cmpint (size, >, 0);
  return backend_icon;
}
static gulong backend_xid (XfwWindow *w) { return 0; }
static XfwWorkspace *backend_workspace (XfwWindow *w) { return g_object_get_data (G_OBJECT (w), "workspace"); }
static XfwWorkspaceState backend_workspace_state (XfwWorkspace *w) { return XFW_WORKSPACE_STATE_NONE; }
static XfwWorkspace *backend_active_workspace (XfwWorkspaceGroup *g) { return active_workspace; }
static gboolean backend_switch (XfwWorkspace *w, GError **e) { ++workspace_calls; active_workspace = w; return TRUE; }
static gboolean backend_activate (XfwWindow *w, XfwSeat *s, guint64 timestamp, GError **e)
{
  /* Simulate a WM configured to bring/ignore cross-workspace activation:
   * callers must prepare the workspace before requesting activation. */
  g_assert_true (active_workspace == backend_workspace (w));
  g_assert_cmpuint (timestamp, ==, 1234);
  ++activation_calls;
  return TRUE;
}
static gboolean backend_minimize (XfwWindow *w, gboolean minimized, GError **e) { ++minimize_calls; return TRUE; }
static GList *backend_get_windows (XfwScreen *s) { return backend_windows; }

#define xfw_window_get_name backend_name
#define xfw_window_get_state backend_state
#define xfw_window_is_active(w) ((backend_state (w) & XFW_WINDOW_STATE_ACTIVE) != 0)
#define xfw_window_is_minimized(w) ((backend_state (w) & XFW_WINDOW_STATE_MINIMIZED) != 0)
#define xfw_window_is_pinned(w) ((backend_state (w) & XFW_WINDOW_STATE_PINNED) != 0)
#define xfw_window_get_icon backend_get_icon
#define xfw_window_x11_get_xid backend_xid
#define xfw_window_get_workspace backend_workspace
#define xfw_workspace_get_state backend_workspace_state
#define xfw_workspace_group_get_active_workspace backend_active_workspace
#define xfw_workspace_activate backend_switch
#define xfw_window_activate backend_activate
#define xfw_window_set_minimized backend_minimize
#define xfw_screen_get_windows backend_get_windows
#define gtk_get_current_event_time() 1234

/* Register the panel type statically in the test executable, rather than
 * through a panel-owned dynamic module. All plugin behavior stays production. */
#undef XFCE_PANEL_DEFINE_PLUGIN_RESIDENT
#define XFCE_PANEL_DEFINE_PLUGIN_RESIDENT(Type, name) G_DEFINE_TYPE (Type, name, XFCE_TYPE_PANEL_PLUGIN)
#include "../tasklist-widget.c"
#include "../tasklist.c"

static GObject *backend_object (GType parent, const gchar *name)
{
  GType type = g_type_from_name (name);
  if (type == 0)
    {
      GTypeQuery query;
      g_type_query (parent, &query);
      type = g_type_register_static_simple (parent, name, query.class_size, NULL,
                                            query.instance_size, NULL, 0);
    }
  return g_object_new (type, NULL);
}

static XfceTasklist *new_tasklist (void)
{
  return g_object_ref_sink (g_object_new (XFCE_TYPE_TASKLIST, NULL));
}

static void test_group_scope (void)
{
  XfceTasklist *t = new_tasklist ();
  GtkWidget *host = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  GtkWidget *button = gtk_button_new ();
  gtk_container_add (GTK_CONTAINER (host), button);
  gtk_widget_show_all (host);
  XfwWindow *window = XFW_WINDOW (backend_object (XFW_TYPE_WINDOW, "RegressionWindow"));
  XfwWindow *excluded = XFW_WINDOW (backend_object (XFW_TYPE_WINDOW, "RegressionWindow"));
  XfceTasklistChild hidden = { .type = CHILD_TYPE_GROUP_MENU, .window = excluded, .button = gtk_button_new () };
  XfceTasklistChild visible = { .type = CHILD_TYPE_GROUP_MENU, .window = window, .button = gtk_button_new () };
  g_object_ref_sink (hidden.button); g_object_ref_sink (visible.button);
  gtk_widget_show (visible.button);
  XfceTasklistChild group = { .type = CHILD_TYPE_GROUP, .button = button, .tasklist = t };
  group.windows = g_slist_append (group.windows, &hidden);
  group.windows = g_slist_append (group.windows, &visible);
  t->screen = g_object_ref (xfw_screen_get_default ());
  t->display = gdk_display_get_default ();
  t->preview_group_limit = 1;
  t->preview_hover_anchor = &group;
  tasklist_preview_show_timeout (t);
  g_assert_nonnull (t->preview_popup);
  GtkWidget *row = g_object_get_data (G_OBJECT (t->preview_popup), "tasklist-preview-row");
  GList *cards = gtk_container_get_children (GTK_CONTAINER (row));
  g_assert_cmpuint (g_list_length (cards), ==, 1);
  g_assert_true (g_object_get_data (G_OBJECT (cards->data), "tasklist-preview-window") == window);
  g_list_free (cards);
  tasklist_preview_hide (t);
  /* All members filtered out must not leave an empty popup or timers. */
  gtk_widget_hide (visible.button);
  t->preview_hover_anchor = &group;
  tasklist_preview_show_timeout (t);
  g_assert_null (t->preview_popup);
  g_assert_cmpuint (t->preview_card_poll_id, ==, 0);
  g_clear_object (&t->screen); t->display = NULL;
  g_slist_free (group.windows);
  gtk_widget_destroy (host);
  g_object_unref (hidden.button); g_object_unref (visible.button);
  g_object_unref (excluded); g_object_unref (window); g_object_unref (t);
}

static gboolean wake_iteration (gpointer data) { return G_SOURCE_REMOVE; }
static void test_activation (void)
{
  XfceTasklist *t = new_tasklist ();
  XfwWindow *window = XFW_WINDOW (backend_object (XFW_TYPE_WINDOW, "RegressionWindow"));
  GObject *a = g_object_new (G_TYPE_OBJECT, NULL), *b = g_object_new (G_TYPE_OBJECT, NULL);
  g_object_set_data (G_OBJECT (window), "workspace", b);
  XfceTasklistChild child = { .type = CHILD_TYPE_GROUP_MENU, .window = window, .tasklist = t };
  child.button = xfce_arrow_button_new (GTK_ARROW_DOWN);
  g_object_ref_sink (child.button);
  t->screen = g_object_ref (xfw_screen_get_default ());
  t->windows = g_list_append (NULL, &child);
  t->all_workspaces = TRUE; t->switch_workspace = TRUE; t->all_blinking = FALSE;
  active_workspace = (XfwWorkspace *) a;
  workspace_calls = activation_calls = minimize_calls = 0;
  backend_windows = g_list_append (NULL, window);
  GtkWidget *preview = g_object_ref_sink (gtk_button_new ());
  g_object_set_data (G_OBJECT (preview), "tasklist-preview-window", window);
  g_idle_add (wake_iteration, NULL);
  tasklist_preview_activate (GTK_BUTTON (preview), t);
  g_assert_cmpuint (workspace_calls, ==, 1);
  g_assert_cmpuint (activation_calls, ==, 1);
  /* Clicking the preview of an already-active window must not minimize it. */
  g_object_set_data (G_OBJECT (window), "state", GUINT_TO_POINTER (XFW_WINDOW_STATE_ACTIVE));
  tasklist_preview_activate (GTK_BUTTON (preview), t);
  g_assert_cmpuint (minimize_calls, ==, 0);
  xfce_tasklist_button_activate (&child, 1234);
  g_assert_cmpuint (minimize_calls, ==, 1);
  /* With switch-workspace disabled, a minimized target is left to the WM. */
  t->switch_workspace = FALSE;
  g_object_set_data (G_OBJECT (window), "state", GUINT_TO_POINTER (XFW_WINDOW_STATE_MINIMIZED));
  xfce_tasklist_button_activate_full (&child, 1234, TRUE);
  g_assert_cmpuint (workspace_calls, ==, 1);
  g_list_free (t->windows); t->windows = NULL;
  g_clear_object (&t->screen);
  g_list_free (backend_windows); backend_windows = NULL;
  g_object_unref (preview);
  g_object_unref (child.button); g_object_unref (window);
  g_object_unref (a); g_object_unref (b); g_object_unref (t);
}

static void test_tooltips (void)
{
  XfceTasklist *t = new_tasklist ();
  XfwWindow *window = XFW_WINDOW (backend_object (XFW_TYPE_WINDOW, "RegressionWindow"));
  XfceTasklistChild child = { .type = CHILD_TYPE_GROUP_MENU, .window = window, .button = gtk_button_new () };
  g_object_ref_sink (child.button);
  t->windows = g_list_append (NULL, &child);
  g_object_set (t, "preview-enabled", FALSE, NULL);
  child.type = CHILD_TYPE_WINDOW;
  gchar *text = gtk_widget_get_tooltip_text (child.button);
  g_assert_cmpstr (text, ==, backend_name (window)); g_free (text);
  g_object_set (t, "show-tooltips", FALSE, NULL);
  g_assert_false (gtk_widget_get_has_tooltip (child.button));
  g_list_free (t->windows); t->windows = NULL;
  g_object_unref (child.button); g_object_unref (window); g_object_unref (t);
}

static void test_card_fit (void)
{
  XfceTasklist *t = new_tasklist ();
  g_object_set (t, "preview-width", 120, "preview-height", 80, NULL);
  XfwWindow *window = XFW_WINDOW (backend_object (XFW_TYPE_WINDOW, "RegressionWindow"));
  t->preview_effective_selection_padding = 32;
  g_hash_table_insert (t->preview_cache, window, g_object_ref (backend_icon));
  t->preview_effective_width = 70; t->preview_effective_height = 80;
  t->preview_popup = gtk_window_new (GTK_WINDOW_POPUP);
  GtkWidget *frame = gtk_frame_new (NULL), *row = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 4);
  gtk_container_add (GTK_CONTAINER (t->preview_popup), frame);
  gtk_container_add (GTK_CONTAINER (frame), row);
  gtk_container_set_border_width (GTK_CONTAINER (row), 24);
  for (guint i = 0; i < 8; ++i) tasklist_preview_add_window (t, row, window);
  gtk_widget_show_all (frame);
  g_assert_true (tasklist_preview_fit (t, row, 640, 128));
  GtkRequisition req;
  gtk_widget_get_preferred_size (frame, NULL, &req);
  g_assert_cmpint (req.width, <=, 640);
  g_assert_cmpint (req.height, <=, 128);
  GList *cards = gtk_container_get_children (GTK_CONTAINER (row));
  g_assert_cmpuint (g_list_length (cards), >, 0);
  for (GList *li = cards; li != NULL; li = li->next)
    {
      GtkRequisition card_req;
      gtk_widget_get_preferred_size (li->data, NULL, &card_req);
      g_assert_cmpint (card_req.width, <=, 120);
      g_assert_cmpint (card_req.height, <=, 80);
    }
  g_list_free (cards);
  /* Bounds that cannot hold even the close control fail rather than hang. */
  g_assert_false (tasklist_preview_fit (t, row, 1, 1));
  tasklist_preview_hide (t);
  g_object_unref (window); g_object_unref (t);
}

static gboolean child_expand (GtkWidget *box, GtkWidget *child)
{
  gboolean value;
  gtk_container_child_get (GTK_CONTAINER (box), child, "expand", &value, NULL);
  return value;
}
static void test_separator_reorder (void)
{
  GtkWidget *box = g_object_ref_sink (gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0));
  TasklistPlugin *plugin = g_object_new (TASKLIST_TYPE_PLUGIN, "name", "minios-tasklist", "unique-id", 1, NULL);
  GtkWidget *s1 = g_object_new (XFCE_TYPE_PANEL_PLUGIN, "name", "separator", "unique-id", 2, NULL);
  GtkWidget *s2 = g_object_new (XFCE_TYPE_PANEL_PLUGIN, "name", "separator", "unique-id", 3, NULL);
  gtk_box_pack_start (GTK_BOX (box), GTK_WIDGET (plugin), FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box), s1, TRUE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box), s2, TRUE, FALSE, 0);
  xfce_panel_plugin_set_expand (XFCE_PANEL_PLUGIN (s1), TRUE);
  xfce_panel_plugin_set_expand (XFCE_PANEL_PLUGIN (s2), TRUE);
  xfce_panel_plugin_set_expand (XFCE_PANEL_PLUGIN (plugin), TRUE);
  tasklist_plugin_watch_separator (plugin);
  g_assert_false (child_expand (box, s1));
  gtk_box_reorder_child (GTK_BOX (box), s1, 0);
  tasklist_plugin_watch_separator (plugin);
  g_assert_true (child_expand (box, s1));
  g_assert_false (child_expand (box, s2));
  xfce_panel_plugin_set_expand (XFCE_PANEL_PLUGIN (plugin), FALSE);
  tasklist_plugin_watch_separator (plugin);
  g_assert_true (child_expand (box, s2));
  xfce_panel_plugin_set_expand (XFCE_PANEL_PLUGIN (plugin), TRUE);
  tasklist_plugin_watch_separator (plugin);
  g_signal_connect (plugin, "destroy", G_CALLBACK (tasklist_plugin_restore_separator), NULL);
  plugin->separator_watch_id = g_timeout_add (250, tasklist_plugin_watch_separator, plugin);
  gtk_widget_destroy (GTK_WIDGET (plugin));
  g_assert_true (child_expand (box, s2));
  gtk_widget_destroy (box); g_object_unref (box);
}

int main (int argc, char **argv)
{
  gtk_test_init (&argc, &argv, NULL);
  backend_icon = gdk_pixbuf_new (GDK_COLORSPACE_RGB, FALSE, 8, 96, 96);
  gdk_pixbuf_fill (backend_icon, 0x336699ff);
  g_test_add_func ("/tasklist/group-scope", test_group_scope);
  g_test_add_func ("/tasklist/workspace-activation", test_activation);
  g_test_add_func ("/tasklist/group-tooltip", test_tooltips);
  g_test_add_func ("/tasklist/card-monitor-fit", test_card_fit);
  g_test_add_func ("/tasklist/separator-reorder", test_separator_reorder);
  int result = g_test_run ();
  g_object_unref (backend_icon);
  return result;
}

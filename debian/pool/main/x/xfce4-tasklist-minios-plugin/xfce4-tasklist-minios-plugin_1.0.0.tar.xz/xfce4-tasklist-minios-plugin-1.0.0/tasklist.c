/*
 * Copyright (C) 2008-2010 Nick Schermer <nick@xfce.org>
 *
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "tasklist-widget.h"
#include "tasklist.h"

#include "common/panel-private.h"
#include "common/panel-utils.h"
#include "common/panel-xfconf.h"

#include <libxfce4ui/libxfce4ui.h>
#include <gio/gdesktopappinfo.h>
#include <libintl.h>


#define HANDLE_SIZE (4)
#define TASKLIST_(String) dgettext (TASKLIST_GETTEXT_PACKAGE, String)

static const GtkTargetEntry tasklist_pin_targets[] = {
  { "text/uri-list", 0, 0 }
};


struct _TasklistPlugin
{
  XfcePanelPlugin __parent__;

  /* the tasklist widget */
  GtkWidget *tasklist;
  GtkWidget *handle;
  GtkWidget *overridden_separator;
  gulong separator_notify_id;
  guint separator_watch_id;
  guint initial_expand_id;
};



static void
tasklist_plugin_construct (XfcePanelPlugin *panel_plugin);
static void
tasklist_plugin_mode_changed (XfcePanelPlugin *panel_plugin,
                              XfcePanelPluginMode mode);
static gboolean
tasklist_plugin_size_changed (XfcePanelPlugin *panel_plugin,
                              gint size);
static void
tasklist_plugin_nrows_changed (XfcePanelPlugin *panel_plugin,
                               guint nrows);
static void
tasklist_plugin_screen_position_changed (XfcePanelPlugin *panel_plugin,
                                         XfceScreenPosition position);
static void
tasklist_plugin_configure_plugin (XfcePanelPlugin *panel_plugin);
static gboolean
tasklist_plugin_handle_draw (GtkWidget *widget,
                             cairo_t *cr,
                             TasklistPlugin *plugin);
static void
tasklist_plugin_drag_data_received (GtkWidget *widget,
                                    GdkDragContext *context,
                                    gint x,
                                    gint y,
                                    GtkSelectionData *data,
                                    guint info,
                                    guint time,
                                    TasklistPlugin *plugin);
static void
tasklist_plugin_pinned_refresh (GtkWidget *listbox);
static void
tasklist_plugin_pinned_remove_clicked (GtkButton *button,
                                       GtkWidget *listbox);
static void
tasklist_plugin_pinned_move_clicked (GtkButton *button,
                                     GtkWidget *listbox);



/* define and register the plugin */
XFCE_PANEL_DEFINE_PLUGIN_RESIDENT (TasklistPlugin, tasklist_plugin)



static void
tasklist_plugin_class_init (TasklistPluginClass *klass)
{
  XfcePanelPluginClass *plugin_class;

  plugin_class = XFCE_PANEL_PLUGIN_CLASS (klass);
  plugin_class->construct = tasklist_plugin_construct;
  plugin_class->mode_changed = tasklist_plugin_mode_changed;
  plugin_class->size_changed = tasklist_plugin_size_changed;
  plugin_class->nrows_changed = tasklist_plugin_nrows_changed;
  plugin_class->screen_position_changed = tasklist_plugin_screen_position_changed;
  plugin_class->configure_plugin = tasklist_plugin_configure_plugin;
}



static void
tasklist_plugin_init (TasklistPlugin *plugin)
{
  GtkWidget *box;

  bindtextdomain (TASKLIST_GETTEXT_PACKAGE, LOCALEDIR);
  bind_textdomain_codeset (TASKLIST_GETTEXT_PACKAGE, "UTF-8");

  /* create widgets */
  box = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
  gtk_container_add (GTK_CONTAINER (plugin), box);
  g_object_bind_property (G_OBJECT (plugin), "orientation",
                          G_OBJECT (box), "orientation",
                          G_BINDING_SYNC_CREATE);
  gtk_widget_show (box);

  plugin->handle = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
  gtk_box_pack_start (GTK_BOX (box), plugin->handle, FALSE, FALSE, 0);
  g_signal_connect (G_OBJECT (plugin->handle), "draw",
                    G_CALLBACK (tasklist_plugin_handle_draw), plugin);
  gtk_widget_set_size_request (plugin->handle, 8, 8);
  gtk_widget_show (plugin->handle);

  plugin->tasklist = g_object_new (XFCE_TYPE_TASKLIST, NULL);
  gtk_box_pack_start (GTK_BOX (box), plugin->tasklist, TRUE, TRUE, 0);

  /* Accept Whisker .desktop drops on the entire expanded plugin area,
   * not only on existing task buttons. */
  gtk_drag_dest_set (GTK_WIDGET (plugin), GTK_DEST_DEFAULT_ALL,
                     tasklist_pin_targets, G_N_ELEMENTS (tasklist_pin_targets),
                     GDK_ACTION_COPY);
  g_signal_connect (G_OBJECT (plugin), "drag-data-received",
                    G_CALLBACK (tasklist_plugin_drag_data_received), plugin);

  g_object_bind_property (G_OBJECT (plugin->tasklist), "show-handle",
                          G_OBJECT (plugin->handle), "visible",
                          G_BINDING_SYNC_CREATE);
}



/* An immediately following expanding Xfce separator traditionally absorbs
 * the spare panel width. When the tasklist itself is set to expand, that
 * separator must return to its normal 8px size and act as a visual boundary.
 * Do not change the separator's xfconf setting: restore its own preference
 * when tasklist expansion is disabled or the tasklist is removed. */
static GtkWidget *
tasklist_plugin_next_separator (XfcePanelPlugin *panel_plugin)
{
  GtkWidget *parent = gtk_widget_get_parent (GTK_WIDGET (panel_plugin));
  GtkWidget *separator = NULL;
  GList *children, *self;

  if (!GTK_IS_CONTAINER (parent))
    return NULL;
  children = gtk_container_get_children (GTK_CONTAINER (parent));
  self = g_list_find (children, GTK_WIDGET (panel_plugin));
  if (self != NULL && self->next != NULL)
    {
      GtkWidget *widget = GTK_WIDGET (self->next->data);
      if (XFCE_IS_PANEL_PLUGIN (widget) &&
          g_strcmp0 (xfce_panel_plugin_get_name (XFCE_PANEL_PLUGIN (widget)),
                     "separator") == 0)
        separator = widget;
    }
  g_list_free (children);
  return separator;
}

static void tasklist_plugin_neighbor_expand_notify (GObject *, GParamSpec *, TasklistPlugin *);

static void
tasklist_plugin_release_separator (TasklistPlugin *plugin)
{
  GtkWidget *separator = plugin->overridden_separator;
  if (separator == NULL) return;
  if (plugin->separator_notify_id != 0)
    g_signal_handler_disconnect (separator, plugin->separator_notify_id);
  plugin->separator_notify_id = 0;
  GtkWidget *parent = gtk_widget_get_parent (separator);
  if (GTK_IS_CONTAINER (parent))
    gtk_container_child_set (GTK_CONTAINER (parent), separator, "expand",
                             xfce_panel_plugin_get_expand (XFCE_PANEL_PLUGIN (separator)), NULL);
  g_object_remove_weak_pointer (G_OBJECT (separator), (gpointer *) &plugin->overridden_separator);
  plugin->overridden_separator = NULL;
}

static void
tasklist_plugin_sync_adjacent_separator (XfcePanelPlugin *panel_plugin)
{
  TasklistPlugin *plugin = TASKLIST_PLUGIN (panel_plugin);
  GtkWidget *separator = tasklist_plugin_next_separator (panel_plugin);
  GtkWidget *parent = gtk_widget_get_parent (GTK_WIDGET (panel_plugin));

  if (!xfce_panel_plugin_get_expand (panel_plugin)) separator = NULL;
  if (separator != plugin->overridden_separator)
    {
      tasklist_plugin_release_separator (plugin);
      plugin->overridden_separator = separator;
      if (separator != NULL)
        {
          g_object_add_weak_pointer (G_OBJECT (separator), (gpointer *) &plugin->overridden_separator);
          plugin->separator_notify_id = g_signal_connect (separator, "notify::expand",
            G_CALLBACK (tasklist_plugin_neighbor_expand_notify), plugin);
        }
    }

  if (separator != NULL && GTK_IS_CONTAINER (parent))
    {
      gboolean expanded;
      gtk_container_child_get (GTK_CONTAINER (parent), separator, "expand", &expanded, NULL);
      if (expanded)
        gtk_container_child_set (GTK_CONTAINER (parent), separator, "expand", FALSE, NULL);
    }
}

static void
tasklist_plugin_expand_notify (GObject *object, GParamSpec *pspec, gpointer unused)
{
  tasklist_plugin_sync_adjacent_separator (XFCE_PANEL_PLUGIN (object));
}

static void
tasklist_plugin_neighbor_expand_notify (GObject *object, GParamSpec *pspec,
                                       TasklistPlugin *plugin)
{
  tasklist_plugin_sync_adjacent_separator (XFCE_PANEL_PLUGIN (plugin));
}

static void
tasklist_plugin_restore_separator (GtkWidget *widget, gpointer data)
{
  TasklistPlugin *plugin = TASKLIST_PLUGIN (widget);
  if (plugin->separator_watch_id != 0)
    { g_source_remove (plugin->separator_watch_id); plugin->separator_watch_id = 0; }
  if (plugin->initial_expand_id != 0)
    { g_source_remove (plugin->initial_expand_id); plugin->initial_expand_id = 0; }
  tasklist_plugin_release_separator (plugin);
}

/* PanelItembar has no public reorder signal. Track adjacency even when an
 * item moves within the same parent, which emits no parent-set notification. */
static gboolean
tasklist_plugin_watch_separator (gpointer data)
{
  tasklist_plugin_sync_adjacent_separator (XFCE_PANEL_PLUGIN (data));
  return G_SOURCE_CONTINUE;
}

/* Xfce creates the plugin before connecting provider-signal and inserting it
 * into the panel itembar. set_expand(TRUE) in construct updates the local
 * property, but its signal gets lost; replay it once the host is ready. */
static gboolean
tasklist_plugin_publish_initial_expand (gpointer user_data)
{
  XfcePanelPlugin *panel_plugin = XFCE_PANEL_PLUGIN (user_data);
  TASKLIST_PLUGIN (panel_plugin)->initial_expand_id = 0;

  if (xfce_panel_plugin_get_expand (panel_plugin))
    {
      xfce_panel_plugin_set_expand (panel_plugin, FALSE);
      xfce_panel_plugin_set_expand (panel_plugin, TRUE);
    }

  tasklist_plugin_sync_adjacent_separator (panel_plugin);
  return G_SOURCE_REMOVE;
}

static void
tasklist_plugin_construct (XfcePanelPlugin *panel_plugin)
{
  TasklistPlugin *plugin = TASKLIST_PLUGIN (panel_plugin);
  const PanelProperty expand_properties[] = {
    { "expand", G_TYPE_BOOLEAN },
    { NULL }
  };
  const PanelProperty properties[] = {
    { "show-labels", G_TYPE_BOOLEAN },
    { "grouping", G_TYPE_BOOLEAN },
    { "include-all-workspaces", G_TYPE_BOOLEAN },
    { "include-all-monitors", G_TYPE_BOOLEAN },
    { "flat-buttons", G_TYPE_BOOLEAN },
    { "switch-workspace-on-unminimize", G_TYPE_BOOLEAN },
    { "show-only-minimized", G_TYPE_BOOLEAN },
    { "show-wireframes", G_TYPE_BOOLEAN },
    { "show-handle", G_TYPE_BOOLEAN },
    { "show-tooltips", G_TYPE_BOOLEAN },
    { "sort-order", G_TYPE_UINT },
    { "window-scrolling", G_TYPE_BOOLEAN },
    { "wrap-windows", G_TYPE_BOOLEAN },
    { "include-all-blinking", G_TYPE_BOOLEAN },
    { "middle-click", G_TYPE_UINT },
    { "label-decorations", G_TYPE_BOOLEAN },
    { "pinned-apps", G_TYPE_PTR_ARRAY },
    { "preview-enabled", G_TYPE_BOOLEAN },
    { "preview-width", G_TYPE_INT },
    { "preview-height", G_TYPE_INT },
    { "preview-hover-delay", G_TYPE_INT },
    { "preview-hide-delay", G_TYPE_INT },
    { "preview-refresh-interval", G_TYPE_INT },
    { "preview-group-limit", G_TYPE_INT },
    { "preview-show-titles", G_TYPE_BOOLEAN },
    { "preview-background-custom", G_TYPE_BOOLEAN },
    { "preview-background-color", G_TYPE_STRING },
    { "preview-background-opacity", G_TYPE_INT },
    { "preview-corner-radius", G_TYPE_INT },
    { "preview-border-width", G_TYPE_INT },
    { "preview-spacing", G_TYPE_INT },
    { "preview-content-padding", G_TYPE_INT },
    { "preview-selection-padding", G_TYPE_INT },
    { "preview-selection-custom", G_TYPE_BOOLEAN },
    { "preview-selection-color", G_TYPE_STRING },
    { "preview-selection-radius", G_TYPE_INT },
    { "preview-selection-opacity", G_TYPE_INT },
    { "preview-peek-mode", G_TYPE_INT },
    { "preview-peek-opacity", G_TYPE_INT },
    { "preview-outline-enabled", G_TYPE_BOOLEAN },
    { "preview-outline-fill", G_TYPE_BOOLEAN },
    { "preview-show-decorations", G_TYPE_BOOLEAN },
    { NULL }
  };

  /* The taskbar is the flexible area of the panel: consume all space
   * left between the fixed launchers and the notification area. */
  xfce_panel_plugin_set_expand (panel_plugin, TRUE);
  g_signal_connect (panel_plugin, "notify::expand",
                    G_CALLBACK (tasklist_plugin_expand_notify), NULL);
  g_signal_connect (panel_plugin, "destroy",
                    G_CALLBACK (tasklist_plugin_restore_separator), NULL);

  /* show configure */
  xfce_panel_plugin_menu_show_configure (XFCE_PANEL_PLUGIN (plugin));

  /* bind all properties */
  panel_properties_bind (NULL, G_OBJECT (plugin->tasklist),
                         xfce_panel_plugin_get_property_base (panel_plugin),
                         properties, FALSE);
  /* Keep the user's Fill all available panel space choice across logins. */
  panel_properties_bind (NULL, G_OBJECT (panel_plugin),
                         xfce_panel_plugin_get_property_base (panel_plugin),
                         expand_properties, FALSE);

  /* show the tasklist */
  gtk_widget_show (plugin->tasklist);

  plugin->separator_watch_id = g_timeout_add (250, tasklist_plugin_watch_separator, plugin);

  plugin->initial_expand_id = g_idle_add_full (G_PRIORITY_DEFAULT_IDLE,
                   tasklist_plugin_publish_initial_expand,
                   g_object_ref (panel_plugin), g_object_unref);
}



static void
tasklist_plugin_mode_changed (XfcePanelPlugin *panel_plugin,
                              XfcePanelPluginMode mode)
{
  TasklistPlugin *plugin = TASKLIST_PLUGIN (panel_plugin);

  /* set the new tasklist mode */
  xfce_tasklist_set_mode (XFCE_TASKLIST (plugin->tasklist), mode);
}



static gboolean
tasklist_plugin_size_changed (XfcePanelPlugin *panel_plugin,
                              gint size)
{
  TasklistPlugin *plugin = TASKLIST_PLUGIN (panel_plugin);

  /* set the tasklist size */
  xfce_tasklist_set_size (XFCE_TASKLIST (plugin->tasklist), size);

  return TRUE;
}



static void
tasklist_plugin_nrows_changed (XfcePanelPlugin *panel_plugin,
                               guint nrows)
{
  TasklistPlugin *plugin = TASKLIST_PLUGIN (panel_plugin);

  /* set the tasklist nrows */
  xfce_tasklist_set_nrows (XFCE_TASKLIST (plugin->tasklist), nrows);
}



static void
tasklist_plugin_screen_position_changed (XfcePanelPlugin *panel_plugin,
                                         XfceScreenPosition position)
{
  TasklistPlugin *plugin = TASKLIST_PLUGIN (panel_plugin);

  /* update monitor geometry; this function is also triggered when
   * the panel is moved to another monitor during runtime */
  xfce_tasklist_update_monitor_geometry (XFCE_TASKLIST (plugin->tasklist));
}



static GPtrArray *
tasklist_plugin_pinned_get_ids (GtkWidget *tasklist)
{
  GPtrArray *values = NULL;
  GPtrArray *ids = g_ptr_array_new_with_free_func (g_free);

  g_object_get (tasklist, "pinned-apps", &values, NULL);
  if (values != NULL)
    {
      for (guint i = 0; i < values->len; i++)
        {
          GValue *value = g_ptr_array_index (values, i);
          if (G_VALUE_HOLDS_STRING (value) && g_value_get_string (value) != NULL)
            g_ptr_array_add (ids, g_strdup (g_value_get_string (value)));
        }
      g_ptr_array_unref (values);
    }

  return ids;
}


static void
tasklist_plugin_pinned_set_ids (GtkWidget *tasklist,
                                GPtrArray *ids)
{
  GPtrArray *values = g_ptr_array_new_with_free_func ((GDestroyNotify) g_free);

  for (guint i = 0; i < ids->len; i++)
    {
      GValue *value = g_new0 (GValue, 1);
      g_value_init (value, G_TYPE_STRING);
      g_value_set_string (value, g_ptr_array_index (ids, i));
      g_ptr_array_add (values, value);
    }

  g_object_set (tasklist, "pinned-apps", values, NULL);
  for (guint i = 0; i < values->len; i++)
    g_value_unset (g_ptr_array_index (values, i));
  g_ptr_array_unref (values);
}


static void
tasklist_plugin_pinned_refresh (GtkWidget *listbox)
{
  GtkWidget *tasklist = g_object_get_data (G_OBJECT (listbox), "tasklist");
  GList *children;
  GPtrArray *ids;

  children = gtk_container_get_children (GTK_CONTAINER (listbox));
  for (GList *li = children; li != NULL; li = li->next)
    gtk_widget_destroy (GTK_WIDGET (li->data));
  g_list_free (children);

  ids = tasklist_plugin_pinned_get_ids (tasklist);
  for (guint i = 0; i < ids->len; i++)
    {
      const gchar *desktop_id = g_ptr_array_index (ids, i);
      GDesktopAppInfo *app = g_desktop_app_info_new (desktop_id);
      GtkWidget *row = gtk_list_box_row_new ();
      GtkWidget *box = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 8);
      GtkWidget *icon = gtk_image_new ();
      GtkWidget *labels = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
      GtkWidget *name;
      GtkWidget *id_label;
      GtkWidget *up = gtk_button_new_from_icon_name ("go-up-symbolic", GTK_ICON_SIZE_BUTTON);
      GtkWidget *down = gtk_button_new_from_icon_name ("go-down-symbolic", GTK_ICON_SIZE_BUTTON);
      GtkWidget *remove = gtk_button_new_from_icon_name ("list-remove-symbolic", GTK_ICON_SIZE_BUTTON);
      const gchar *display_name = desktop_id;

      if (app != NULL)
        {
          GIcon *gicon = g_app_info_get_icon (G_APP_INFO (app));
          display_name = g_app_info_get_display_name (G_APP_INFO (app));
          if (gicon != NULL)
            gtk_image_set_from_gicon (GTK_IMAGE (icon), gicon, GTK_ICON_SIZE_BUTTON);
        }

      name = gtk_label_new (display_name);
      gtk_label_set_xalign (GTK_LABEL (name), 0.0);
      id_label = gtk_label_new (desktop_id);
      gtk_label_set_xalign (GTK_LABEL (id_label), 0.0);
      gtk_style_context_add_class (gtk_widget_get_style_context (id_label), "dim-label");

      gtk_box_pack_start (GTK_BOX (labels), name, FALSE, FALSE, 0);
      gtk_box_pack_start (GTK_BOX (labels), id_label, FALSE, FALSE, 0);
      gtk_box_pack_start (GTK_BOX (box), icon, FALSE, FALSE, 0);
      gtk_box_pack_start (GTK_BOX (box), labels, TRUE, TRUE, 0);
      gtk_box_pack_start (GTK_BOX (box), up, FALSE, FALSE, 0);
      gtk_box_pack_start (GTK_BOX (box), down, FALSE, FALSE, 0);
      gtk_box_pack_start (GTK_BOX (box), remove, FALSE, FALSE, 0);
      gtk_container_add (GTK_CONTAINER (row), box);
      gtk_container_add (GTK_CONTAINER (listbox), row);

      gtk_widget_set_sensitive (up, i > 0);
      gtk_widget_set_sensitive (down, i + 1 < ids->len);
      g_object_set_data_full (G_OBJECT (up), "desktop-id", g_strdup (desktop_id), g_free);
      g_object_set_data (G_OBJECT (up), "direction", GINT_TO_POINTER (-1));
      g_object_set_data_full (G_OBJECT (down), "desktop-id", g_strdup (desktop_id), g_free);
      g_object_set_data (G_OBJECT (down), "direction", GINT_TO_POINTER (1));
      g_object_set_data_full (G_OBJECT (remove), "desktop-id", g_strdup (desktop_id), g_free);
      g_signal_connect (up, "clicked", G_CALLBACK (tasklist_plugin_pinned_move_clicked), listbox);
      g_signal_connect (down, "clicked", G_CALLBACK (tasklist_plugin_pinned_move_clicked), listbox);
      g_signal_connect (remove, "clicked", G_CALLBACK (tasklist_plugin_pinned_remove_clicked), listbox);

      if (app != NULL)
        g_object_unref (app);
    }
  g_ptr_array_unref (ids);
  gtk_widget_show_all (listbox);
}


static void
tasklist_plugin_pinned_remove_clicked (GtkButton *button,
                                       GtkWidget *listbox)
{
  GtkWidget *tasklist = g_object_get_data (G_OBJECT (listbox), "tasklist");
  const gchar *desktop_id = g_object_get_data (G_OBJECT (button), "desktop-id");
  GPtrArray *ids = tasklist_plugin_pinned_get_ids (tasklist);

  for (guint i = 0; i < ids->len; i++)
    if (g_strcmp0 (g_ptr_array_index (ids, i), desktop_id) == 0)
      {
        g_ptr_array_remove_index (ids, i);
        break;
      }

  tasklist_plugin_pinned_set_ids (tasklist, ids);
  g_ptr_array_unref (ids);
  tasklist_plugin_pinned_refresh (listbox);
}


static void
tasklist_plugin_pinned_move_clicked (GtkButton *button,
                                     GtkWidget *listbox)
{
  GtkWidget *tasklist = g_object_get_data (G_OBJECT (listbox), "tasklist");
  const gchar *desktop_id = g_object_get_data (G_OBJECT (button), "desktop-id");
  gint direction = GPOINTER_TO_INT (g_object_get_data (G_OBJECT (button), "direction"));
  GPtrArray *ids = tasklist_plugin_pinned_get_ids (tasklist);

  for (guint i = 0; i < ids->len; i++)
    if (g_strcmp0 (g_ptr_array_index (ids, i), desktop_id) == 0)
      {
        gint target = (gint) i + direction;
        if (target >= 0 && target < (gint) ids->len)
          {
            gpointer tmp = ids->pdata[i];
            ids->pdata[i] = ids->pdata[target];
            ids->pdata[target] = tmp;
          }
        break;
      }

  tasklist_plugin_pinned_set_ids (tasklist, ids);
  g_ptr_array_unref (ids);
  tasklist_plugin_pinned_refresh (listbox);
}


static void
tasklist_plugin_drag_data_received (GtkWidget *widget,
                                    GdkDragContext *context,
                                    gint x,
                                    gint y,
                                    GtkSelectionData *data,
                                    guint info,
                                    guint time,
                                    TasklistPlugin *plugin)
{
  gchar **uris = gtk_selection_data_get_uris (data);
  gboolean success = FALSE;

  if (uris != NULL)
    success = xfce_tasklist_pin_uris (XFCE_TASKLIST (plugin->tasklist), uris);
  g_strfreev (uris);
  gtk_drag_finish (context, success, FALSE, time);
}



/* Advanced preview controls live in a small secondary dialog so the normal
 * Xfce plugin settings window keeps its usual compact dimensions.  All
 * bindings are bidirectional and are removed when the dialog is destroyed. */
static void
tasklist_plugin_preview_spin (GtkGrid *grid, GtkWidget *tasklist,
                              const gchar *property, const gchar *text,
                              gint minimum, gint maximum, gint step, gint row,
                              const gchar *tooltip)
{
  GtkWidget *label = gtk_label_new_with_mnemonic (text);
  GtkWidget *spin = gtk_spin_button_new_with_range (minimum, maximum, step);
  gtk_label_set_xalign (GTK_LABEL (label), 0.0);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin), TRUE);
  gtk_spin_button_set_update_policy (GTK_SPIN_BUTTON (spin), GTK_UPDATE_IF_VALID);
  gtk_widget_set_hexpand (spin, TRUE);
  gtk_label_set_mnemonic_widget (GTK_LABEL (label), spin);
  if (tooltip != NULL)
    {
      gtk_widget_set_tooltip_text (spin, tooltip);
      gtk_widget_set_tooltip_text (label, tooltip);
    }
  gtk_grid_attach (grid, label, 0, row, 1, 1);
  gtk_grid_attach (grid, spin, 1, row, 1, 1);
  /* GtkSpinButton uses double values. GBinding handles int/double conversion. */
  g_object_bind_property (G_OBJECT (tasklist), property,
                          G_OBJECT (spin), "value",
                          G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
}

/* Keep the color picker GTK-native, while persisting a simple #RRGGBB
 * xfconf string. This avoids the old RGBA channel binder and is locale-safe. */
static gboolean
tasklist_plugin_color_to_picker (GBinding *binding,
                                 const GValue *from,
                                 GValue *to, gpointer data)
{
  GdkRGBA color;
  const gchar *text = g_value_get_string (from);
  if (text == NULL || !gdk_rgba_parse (&color, text))
    return FALSE;
  color.alpha = 1.0;
  g_value_set_boxed (to, &color);
  return TRUE;
}

static gboolean
tasklist_plugin_picker_to_color (GBinding *binding,
                                 const GValue *from,
                                 GValue *to, gpointer data)
{
  const GdkRGBA *c = g_value_get_boxed (from);
  if (c == NULL)
    return FALSE;
  g_value_take_string (to, g_strdup_printf ("#%02x%02x%02x",
                     (guint) (255 * c->red + 0.5),
                     (guint) (255 * c->green + 0.5),
                     (guint) (255 * c->blue + 0.5)));
  return TRUE;
}

static gboolean
tasklist_plugin_peek_enables_optional_frame (GBinding *binding,
                                            const GValue *source,
                                            GValue *target, gpointer data)
{
  g_value_set_boolean (target, g_value_get_int (source) != 0);
  return TRUE;
}

static void
tasklist_plugin_preview_reset (GtkButton *button, TasklistPlugin *plugin)
{
  guint count;
  GParamSpec **properties = g_object_class_list_properties (G_OBJECT_GET_CLASS (plugin->tasklist), &count);
  /* The widget's property specifications are the authoritative defaults.
   * Reset only preview settings, preserving launchers and panel behavior. */
  for (guint i = 0; i < count; i++)
    if (g_str_has_prefix (properties[i]->name, "preview-") &&
        (properties[i]->flags & G_PARAM_WRITABLE))
      {
        GValue value = G_VALUE_INIT;
        g_value_init (&value, G_PARAM_SPEC_VALUE_TYPE (properties[i]));
        g_param_value_set_default (properties[i], &value);
        g_object_set_property (G_OBJECT (plugin->tasklist), properties[i]->name, &value);
        g_value_unset (&value);
      }
  g_free (properties);
}

static void
tasklist_plugin_preview_settings_clicked (GtkButton *button,
                                          TasklistPlugin *plugin)
{
  GtkWidget *dialog, *notebook, *general, *appearance, *checkbox, *content;
  GtkWidget *use_custom, *color, *color_label;
  GtkWindow *parent = GTK_WINDOW (gtk_widget_get_toplevel (GTK_WIDGET (button)));
  dialog = gtk_dialog_new_with_buttons (TASKLIST_("Window preview settings"), parent,
                                        GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                         _("_Close"), GTK_RESPONSE_CLOSE, NULL);
  GtkWidget *reset = gtk_button_new_with_mnemonic (TASKLIST_("_Reset"));
  gtk_box_pack_start (GTK_BOX (gtk_dialog_get_action_area (GTK_DIALOG (dialog))), reset, FALSE, FALSE, 0);
  g_signal_connect (reset, "clicked", G_CALLBACK (tasklist_plugin_preview_reset), plugin);
  gtk_window_set_resizable (GTK_WINDOW (dialog), FALSE);
  content = gtk_dialog_get_content_area (GTK_DIALOG (dialog));
  notebook = gtk_notebook_new ();
  gtk_container_set_border_width (GTK_CONTAINER (notebook), 10);
  gtk_box_pack_start (GTK_BOX (content), notebook, TRUE, TRUE, 0);

  general = gtk_grid_new ();
  gtk_container_set_border_width (GTK_CONTAINER (general), 10);
  gtk_grid_set_row_spacing (GTK_GRID (general), 10);
  gtk_grid_set_column_spacing (GTK_GRID (general), 14);
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), general,
                            gtk_label_new (TASKLIST_("Size and behavior")));

  /* Both dimensions are limits; the window preview preserves its own
   * aspect ratio and therefore need not fill either dimension. */
  tasklist_plugin_preview_spin (GTK_GRID (general), plugin->tasklist,
    "preview-width", TASKLIST_("Maximum _width (px):"), 120, 800, 10, 0,
    TASKLIST_("The preview will not exceed this width; its proportions are preserved."));
  tasklist_plugin_preview_spin (GTK_GRID (general), plugin->tasklist,
    "preview-height", TASKLIST_("Maximum _height (px):"), 80, 340, 10, 1,
    TASKLIST_("The preview, including its app icon and title, will not exceed this height."));
  tasklist_plugin_preview_spin (GTK_GRID (general), plugin->tasklist,
    "preview-hover-delay", TASKLIST_("Show _delay (ms):"), 0, 1500, 25, 2,
    TASKLIST_("Time to wait before showing a thumbnail after hovering."));
  tasklist_plugin_preview_spin (GTK_GRID (general), plugin->tasklist,
    "preview-hide-delay", TASKLIST_("Hide d_elay (ms):"), 0, 1500, 25, 3,
    TASKLIST_("Time to move the pointer from the panel into the preview."));
  tasklist_plugin_preview_spin (GTK_GRID (general), plugin->tasklist,
    "preview-refresh-interval", TASKLIST_("_Refresh interval (ms):"), 0, 5000, 50, 4,
    TASKLIST_("How often to update thumbnails. Set to 0 for a static image."));
  tasklist_plugin_preview_spin (GTK_GRID (general), plugin->tasklist,
    "preview-group-limit", TASKLIST_("Max windows per _group:"), 1, 8, 1, 5,
    TASKLIST_("Maximum number of thumbnails shown for a grouped application."));
  {
    GtkWidget *peek_label = gtk_label_new_with_mnemonic (TASKLIST_("_Peek on hover:"));
    GtkWidget *peek = gtk_combo_box_text_new ();
    gtk_combo_box_text_append_text (GTK_COMBO_BOX_TEXT (peek), TASKLIST_("Off"));
    gtk_combo_box_text_append_text (GTK_COMBO_BOX_TEXT (peek), TASKLIST_("Dim other windows"));
    gtk_combo_box_text_append_text (GTK_COMBO_BOX_TEXT (peek), TASKLIST_("Hide other windows"));
    gtk_grid_attach (GTK_GRID (general), peek_label, 0, 6, 1, 1);
    gtk_grid_attach (GTK_GRID (general), peek, 1, 6, 1, 1);
    gtk_label_set_mnemonic_widget (GTK_LABEL (peek_label), peek);
    g_object_bind_property (G_OBJECT (plugin->tasklist), "preview-peek-mode",
                            G_OBJECT (peek), "active",
                            G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
    tasklist_plugin_preview_spin (GTK_GRID (general), plugin->tasklist,
      "preview-peek-opacity", TASKLIST_("Other windows _opacity (%):"),
      0, 100, 5, 7, TASKLIST_("Only used when Peek dims other windows; GL required."));
  }
  {
    GtkWidget *frame = gtk_check_button_new_with_mnemonic (
                              TASKLIST_("Draw _frame around selected window"));
    GtkWidget *fill = gtk_check_button_new_with_mnemonic (
                              TASKLIST_("_Highlight inside frame"));
    gtk_widget_set_tooltip_text (frame, TASKLIST_(
      "When Peek is Off, the selected window must still have a frame."));
    gtk_grid_attach (GTK_GRID (general), frame, 0, 8, 2, 1);
    gtk_grid_attach (GTK_GRID (general), fill, 0, 9, 2, 1);
    g_object_bind_property (G_OBJECT (plugin->tasklist), "preview-outline-enabled",
                            G_OBJECT (frame), "active",
                            G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
    g_object_bind_property (G_OBJECT (plugin->tasklist), "preview-outline-fill",
                            G_OBJECT (fill), "active",
                            G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
    g_object_bind_property_full (G_OBJECT (plugin->tasklist),
                                 "preview-peek-mode",
                                 G_OBJECT (frame), "sensitive",
                                 G_BINDING_SYNC_CREATE,
                                 tasklist_plugin_peek_enables_optional_frame,
                                 NULL, NULL, NULL);
    g_object_bind_property (G_OBJECT (frame), "active",
                            G_OBJECT (fill), "sensitive",
                            G_BINDING_SYNC_CREATE);
  }
  checkbox = gtk_check_button_new_with_mnemonic (TASKLIST_("Show window _titles"));
  gtk_grid_attach (GTK_GRID (general), checkbox, 0, 10, 2, 1);
  g_object_bind_property (G_OBJECT (plugin->tasklist), "preview-show-titles",
                          G_OBJECT (checkbox), "active",
                          G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
  checkbox = gtk_check_button_new_with_mnemonic (TASKLIST_("Show window _decorations"));
  gtk_grid_attach (GTK_GRID (general), checkbox, 0, 11, 2, 1);
  g_object_bind_property (G_OBJECT (plugin->tasklist), "preview-show-decorations",
                          G_OBJECT (checkbox), "active",
                          G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);

  appearance = gtk_grid_new ();
  gtk_container_set_border_width (GTK_CONTAINER (appearance), 10);
  gtk_grid_set_row_spacing (GTK_GRID (appearance), 10);
  gtk_grid_set_column_spacing (GTK_GRID (appearance), 14);
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), appearance,
                            gtk_label_new (TASKLIST_("Appearance")));

  /* The color chooser works like the Xfce panel background color picker;
   * the background opacity is adjusted separately so preview images remain
   * opaque and readable. */
  use_custom = gtk_check_button_new_with_mnemonic (TASKLIST_("Use _custom background color"));
  gtk_grid_attach (GTK_GRID (appearance), use_custom, 0, 0, 2, 1);
  g_object_bind_property (G_OBJECT (plugin->tasklist), "preview-background-custom",
                          G_OBJECT (use_custom), "active",
                          G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
  color_label = gtk_label_new_with_mnemonic (TASKLIST_("Background _color:"));
  gtk_label_set_xalign (GTK_LABEL (color_label), 0.0);
  color = gtk_color_button_new ();
  gtk_color_chooser_set_use_alpha (GTK_COLOR_CHOOSER (color), FALSE);
  gtk_widget_set_hexpand (color, TRUE);
  gtk_label_set_mnemonic_widget (GTK_LABEL (color_label), color);
  gtk_grid_attach (GTK_GRID (appearance), color_label, 0, 1, 1, 1);
  gtk_grid_attach (GTK_GRID (appearance), color, 1, 1, 1, 1);
  g_object_bind_property_full (G_OBJECT (plugin->tasklist), "preview-background-color",
                               G_OBJECT (color), "rgba",
                               G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE,
                               tasklist_plugin_color_to_picker,
                               tasklist_plugin_picker_to_color, NULL, NULL);
  g_object_bind_property (G_OBJECT (use_custom), "active",
                          G_OBJECT (color), "sensitive", G_BINDING_SYNC_CREATE);
  g_object_bind_property (G_OBJECT (use_custom), "active",
                          G_OBJECT (color_label), "sensitive", G_BINDING_SYNC_CREATE);

  tasklist_plugin_preview_spin (GTK_GRID (appearance), plugin->tasklist,
    "preview-background-opacity", TASKLIST_("Background _opacity (%):"),
    0, 100, 5, 2, TASKLIST_("Transparency of the popup background; window images stay opaque."));
  tasklist_plugin_preview_spin (GTK_GRID (appearance), plugin->tasklist,
    "preview-corner-radius", TASKLIST_("Corner _radius (px):"),
    0, 36, 1, 3, TASKLIST_("Rounded corners of the preview popup."));
  tasklist_plugin_preview_spin (GTK_GRID (appearance), plugin->tasklist,
    "preview-border-width", TASKLIST_("_Border width (px):"),
    0, 5, 1, 4, TASKLIST_("Set to 0 to hide the outline."));
  tasklist_plugin_preview_spin (GTK_GRID (appearance), plugin->tasklist,
    "preview-spacing", TASKLIST_("Space between _windows (px):"),
    0, 20, 1, 5, TASKLIST_("Gap between thumbnails when an application has several windows."));
  tasklist_plugin_preview_spin (GTK_GRID (appearance), plugin->tasklist,
    "preview-content-padding", TASKLIST_("_Padding around previews (px):"),
    0, 64, 1, 6, TASKLIST_("Space between the popup edge and its preview cards."));

  GtkWidget *selection_label = gtk_label_new (NULL);
  gtk_label_set_markup (GTK_LABEL (selection_label), TASKLIST_("<b>Selection</b>"));
  gtk_widget_set_halign (selection_label, GTK_ALIGN_START);
  gtk_grid_attach (GTK_GRID (appearance), selection_label, 0, 7, 2, 1);
  tasklist_plugin_preview_spin (GTK_GRID (appearance), plugin->tasklist,
    "preview-selection-padding", TASKLIST_("Selection _padding (px):"), 0, 32, 1, 8,
    TASKLIST_("Distance between the thumbnail and the edge of its selection."));
  GtkWidget *selection_custom = gtk_check_button_new_with_mnemonic (TASKLIST_("Use custom _selection color"));
  gtk_grid_attach (GTK_GRID (appearance), selection_custom, 0, 9, 2, 1);
  g_object_bind_property (plugin->tasklist, "preview-selection-custom", selection_custom, "active", G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
  GtkWidget *selection_color = gtk_color_button_new ();
  gtk_color_chooser_set_use_alpha (GTK_COLOR_CHOOSER (selection_color), FALSE);
  gtk_grid_attach (GTK_GRID (appearance), gtk_label_new (TASKLIST_("Selection color:")), 0, 10, 1, 1);
  gtk_grid_attach (GTK_GRID (appearance), selection_color, 1, 10, 1, 1);
  g_object_bind_property_full (plugin->tasklist, "preview-selection-color", selection_color, "rgba",
    G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE, tasklist_plugin_color_to_picker, tasklist_plugin_picker_to_color, NULL, NULL);
  g_object_bind_property (selection_custom, "active", selection_color, "sensitive", G_BINDING_SYNC_CREATE);
  tasklist_plugin_preview_spin (GTK_GRID (appearance), plugin->tasklist,
    "preview-selection-radius", TASKLIST_("Selection corner radius (px):"), 0, 36, 1, 11, NULL);
  tasklist_plugin_preview_spin (GTK_GRID (appearance), plugin->tasklist,
    "preview-selection-opacity", TASKLIST_("Selection opacity (%):"), 0, 100, 5, 12, NULL);

  gtk_widget_show_all (dialog);
  gtk_dialog_run (GTK_DIALOG (dialog));
  gtk_widget_destroy (dialog);
}


static void
tasklist_plugin_configure_plugin (XfcePanelPlugin *panel_plugin)
{
  TasklistPlugin *plugin = TASKLIST_PLUGIN (panel_plugin);
  GtkBuilder *builder;
  GObject *dialog;
  GObject *object;

  /* setup the dialog */
  builder = panel_utils_builder_new (panel_plugin, "/org/xfce/panel/tasklist-dialog.glade", &dialog);
  if (G_UNLIKELY (builder == NULL))
    return;

#define TASKLIST_DIALOG_BIND(name, property) \
  object = gtk_builder_get_object (builder, (name)); \
  panel_return_if_fail (G_IS_OBJECT (object)); \
  g_object_bind_property (G_OBJECT (plugin->tasklist), (name), \
                          G_OBJECT (object), (property), \
                          G_BINDING_BIDIRECTIONAL \
                            | G_BINDING_SYNC_CREATE);

#define TASKLIST_DIALOG_BIND_INV(name, property) \
  object = gtk_builder_get_object (builder, (name)); \
  panel_return_if_fail (G_IS_OBJECT (object)); \
  g_object_bind_property (G_OBJECT (plugin->tasklist), \
                          name, G_OBJECT (object), \
                          property, \
                          G_BINDING_BIDIRECTIONAL \
                            | G_BINDING_SYNC_CREATE \
                            | G_BINDING_INVERT_BOOLEAN);

  TASKLIST_DIALOG_BIND ("show-labels", "active")
  TASKLIST_DIALOG_BIND ("grouping", "active")
  TASKLIST_DIALOG_BIND ("include-all-workspaces", "active")
  TASKLIST_DIALOG_BIND ("include-all-monitors", "active")
  TASKLIST_DIALOG_BIND ("flat-buttons", "active")
  TASKLIST_DIALOG_BIND_INV ("switch-workspace-on-unminimize", "active")
  TASKLIST_DIALOG_BIND ("show-only-minimized", "active")
  TASKLIST_DIALOG_BIND ("show-wireframes", "active")
  TASKLIST_DIALOG_BIND ("show-handle", "active")
  TASKLIST_DIALOG_BIND ("show-tooltips", "active")
  TASKLIST_DIALOG_BIND ("sort-order", "active")
  TASKLIST_DIALOG_BIND ("window-scrolling", "active")
  TASKLIST_DIALOG_BIND ("middle-click", "active")

  if (!WINDOWING_IS_X11 ())
    {
      /* not functional in x11, so avoid confusion */
      object = gtk_builder_get_object (builder, "include-all-workspaces");
      gtk_widget_hide (GTK_WIDGET (object));
      object = gtk_builder_get_object (builder, "switch-workspace-on-unminimize");
      gtk_widget_hide (GTK_WIDGET (object));
      object = gtk_builder_get_object (builder, "show-wireframes");
      gtk_widget_hide (GTK_WIDGET (object));
    }

  {
    GtkWidget *vbox = GTK_WIDGET (gtk_builder_get_object (builder, "vbox1"));
    GtkWidget *behavior_box = GTK_WIDGET (gtk_builder_get_object (builder, "vbox2"));
    GtkWidget *expand = gtk_check_button_new_with_mnemonic (TASKLIST_("_Fill all available panel space"));
    GtkWidget *frame = gtk_frame_new (NULL);
    GtkWidget *frame_label = gtk_label_new (NULL);
    GtkWidget *outer = gtk_box_new (GTK_ORIENTATION_VERTICAL, 6);
    GtkWidget *scroller = gtk_scrolled_window_new (NULL, NULL);
    GtkWidget *listbox = gtk_list_box_new ();
    GtkWidget *preview_frame = gtk_frame_new (NULL);
    GtkWidget *preview_label = gtk_label_new (NULL);
    GtkWidget *preview_box = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 9);
    GtkWidget *preview_check = gtk_check_button_new_with_mnemonic (
                                       TASKLIST_("_Enable window previews"));
    GtkWidget *preview_button = gtk_button_new_with_mnemonic (TASKLIST_("_Configure..."));

    /* Keep new behavior controls inside the stock Behavior section. */
    gtk_box_pack_start (GTK_BOX (behavior_box), expand, FALSE, FALSE, 0);
    g_object_bind_property (G_OBJECT (panel_plugin), "expand",
                            G_OBJECT (expand), "active",
                            G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);

    /* A compact top-level toggle, with the more detailed options in a modal
     * window that does not force the original Xfce dialog off-screen. */
    gtk_label_set_markup (GTK_LABEL (preview_label), TASKLIST_("<b>Window previews</b>"));
    gtk_frame_set_label_widget (GTK_FRAME (preview_frame), preview_label);
    gtk_container_set_border_width (GTK_CONTAINER (preview_box), 6);
    gtk_box_pack_start (GTK_BOX (preview_box), preview_check, TRUE, TRUE, 0);
    gtk_box_pack_start (GTK_BOX (preview_box), preview_button, FALSE, FALSE, 0);
    gtk_container_add (GTK_CONTAINER (preview_frame), preview_box);
    gtk_box_pack_start (GTK_BOX (vbox), preview_frame, FALSE, FALSE, 0);
    g_object_bind_property (G_OBJECT (plugin->tasklist), "preview-enabled",
                            G_OBJECT (preview_check), "active",
                            G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
    g_signal_connect (preview_button, "clicked",
                      G_CALLBACK (tasklist_plugin_preview_settings_clicked), plugin);
    gtk_widget_show_all (preview_frame);

    gtk_label_set_markup (GTK_LABEL (frame_label), TASKLIST_("<b>Pinned applications</b>"));
    gtk_frame_set_label_widget (GTK_FRAME (frame), frame_label);
    gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scroller), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
    gtk_widget_set_size_request (scroller, -1, 130);
    gtk_container_add (GTK_CONTAINER (scroller), listbox);
    gtk_box_pack_start (GTK_BOX (outer), scroller, TRUE, TRUE, 0);
    gtk_container_set_border_width (GTK_CONTAINER (outer), 6);
    gtk_container_add (GTK_CONTAINER (frame), outer);
    gtk_box_pack_start (GTK_BOX (vbox), frame, TRUE, TRUE, 0);
    g_object_set_data (G_OBJECT (listbox), "tasklist", plugin->tasklist);
    tasklist_plugin_pinned_refresh (listbox);
  }

  gtk_widget_show_all (GTK_WIDGET (dialog));
}



static gboolean
tasklist_plugin_handle_draw (GtkWidget *widget,
                             cairo_t *cr,
                             TasklistPlugin *plugin)
{
  GtkAllocation allocation;
  GtkStyleContext *ctx;
  gdouble x, y;
  guint i;
  GdkRGBA fg_rgba;

  panel_return_val_if_fail (TASKLIST_IS_PLUGIN (plugin), FALSE);
  panel_return_val_if_fail (plugin->handle == widget, FALSE);

  if (!gtk_widget_is_drawable (widget))
    return FALSE;

  gtk_widget_get_allocation (widget, &allocation);
  ctx = gtk_widget_get_style_context (widget);

  gtk_style_context_get_color (ctx, gtk_widget_get_state_flags (widget), &fg_rgba);
  /* Tone down the foreground color a bit for the separators */
  fg_rgba.alpha = 0.5;
  gdk_cairo_set_source_rgba (cr, &fg_rgba);
  cairo_set_antialias (cr, CAIRO_ANTIALIAS_NONE);

  x = (allocation.width - HANDLE_SIZE) / 2;
  y = (allocation.height - HANDLE_SIZE) / 2;
  cairo_set_line_width (cr, 1.0);
  /* draw the handle */
  for (i = 0; i < 3; i++)
    {
      if (xfce_panel_plugin_get_orientation (XFCE_PANEL_PLUGIN (plugin)) == GTK_ORIENTATION_HORIZONTAL)
        {
          cairo_move_to (cr, x, y + (i * HANDLE_SIZE) - (HANDLE_SIZE / 2));
          cairo_line_to (cr, x + HANDLE_SIZE, y + (i * HANDLE_SIZE) - (HANDLE_SIZE / 2));
        }
      else
        {
          cairo_move_to (cr, x + (i * HANDLE_SIZE) - (HANDLE_SIZE / 2), y);
          cairo_line_to (cr, x + (i * HANDLE_SIZE) - (HANDLE_SIZE / 2), y + HANDLE_SIZE);
        }
      cairo_stroke (cr);
    }

  return TRUE;
}

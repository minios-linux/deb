/* Periodic thumbnail readback runs on a private XCB connection. Never use the
 * GTK/GDK connection or its process-wide Xlib error traps from the worker. */
#ifndef TASKLIST_PREVIEW_CAPTURE_H
#define TASKLIST_PREVIEW_CAPTURE_H

#include <stdlib.h>
#include <gdk-pixbuf/gdk-pixbuf.h>
#include <xcb/xcb.h>
#include <xcb/composite.h>

static guint8
tasklist_capture_channel (guint32 pixel, guint32 mask)
{
  if (mask == 0) return 0;
  while (!(mask & 1)) { mask >>= 1; pixel >>= 1; }
  return ((guint64) (pixel & mask) * 255 + mask / 2) / mask;
}

static GdkPixbuf *
tasklist_preview_capture_xcb (const gchar *display_name, guint32 client,
                              gint max_width, gint max_height,
                              gboolean decorations)
{
  xcb_connection_t *connection = xcb_connect (display_name, NULL);
  xcb_query_tree_reply_t *tree = NULL;
  xcb_get_window_attributes_reply_t *attributes = NULL;
  xcb_get_geometry_reply_t *geometry = NULL, *client_geometry = NULL;
  xcb_translate_coordinates_reply_t *position = NULL;
  xcb_get_image_reply_t *image = NULL;
  xcb_composite_query_version_reply_t *version = NULL;
  xcb_generic_error_t *error = NULL;
  xcb_pixmap_t pixmap = XCB_NONE;
  xcb_window_t frame = client;
  GdkPixbuf *result = NULL;
  gint crop_x = 0, crop_y = 0, crop_width, crop_height, bpp = 0, pad = 0;
  guint32 red = 0, green = 0, blue = 0;

  if (xcb_connection_has_error (connection)) goto out;
  version = xcb_composite_query_version_reply (connection,
    xcb_composite_query_version (connection, 0, 2), NULL);
  if (version == NULL) goto out;
  tree = xcb_query_tree_reply (connection, xcb_query_tree (connection, client), NULL);
  if (tree == NULL) goto out;
  if (tree->parent != XCB_NONE && tree->parent != tree->root) frame = tree->parent;
  attributes = xcb_get_window_attributes_reply (connection,
    xcb_get_window_attributes (connection, frame), NULL);
  geometry = xcb_get_geometry_reply (connection, xcb_get_geometry (connection, frame), NULL);
  if (attributes == NULL || geometry == NULL ||
      attributes->map_state != XCB_MAP_STATE_VIEWABLE ||
      geometry->width == 0 || geometry->height == 0 ||
      geometry->width > 8192 || geometry->height > 8192 ||
      (guint64) geometry->width * geometry->height > 16000000) goto out;

  crop_width = geometry->width;
  crop_height = geometry->height;
  if (!decorations && frame != client)
    {
      client_geometry = xcb_get_geometry_reply (connection,
        xcb_get_geometry (connection, client), NULL);
      position = xcb_translate_coordinates_reply (connection,
        xcb_translate_coordinates (connection, client, frame, 0, 0), NULL);
      if (client_geometry != NULL && position != NULL &&
          position->dst_x >= 0 && position->dst_y >= 0 &&
          position->dst_x < geometry->width && position->dst_y < geometry->height &&
          client_geometry->width > 0 && client_geometry->height > 0)
        {
          crop_x = position->dst_x; crop_y = position->dst_y;
          crop_width = MIN (client_geometry->width, geometry->width - crop_x);
          crop_height = MIN (client_geometry->height, geometry->height - crop_y);
        }
    }

  pixmap = xcb_generate_id (connection);
  error = xcb_request_check (connection,
    xcb_composite_name_window_pixmap_checked (connection, frame, pixmap));
  if (error != NULL) { pixmap = XCB_NONE; goto out; }
  image = xcb_get_image_reply (connection,
    xcb_get_image (connection, XCB_IMAGE_FORMAT_Z_PIXMAP, pixmap,
                   crop_x, crop_y, crop_width, crop_height, ~0u), NULL);
  if (image == NULL) goto out;

  const xcb_setup_t *setup = xcb_get_setup (connection);
  for (xcb_format_iterator_t it = xcb_setup_pixmap_formats_iterator (setup); it.rem; xcb_format_next (&it))
    if (it.data->depth == image->depth)
      { bpp = it.data->bits_per_pixel; pad = it.data->scanline_pad; break; }
  for (xcb_screen_iterator_t screen = xcb_setup_roots_iterator (setup); screen.rem; xcb_screen_next (&screen))
    for (xcb_depth_iterator_t depth = xcb_screen_allowed_depths_iterator (screen.data); depth.rem; xcb_depth_next (&depth))
      for (xcb_visualtype_iterator_t visual = xcb_depth_visuals_iterator (depth.data); visual.rem; xcb_visualtype_next (&visual))
        if (visual.data->visual_id == attributes->visual)
          { red = visual.data->red_mask; green = visual.data->green_mask; blue = visual.data->blue_mask; }
  if ((bpp != 16 && bpp != 24 && bpp != 32) || pad == 0 || !red || !green || !blue) goto out;
  gint image_stride = ((crop_width * bpp + pad - 1) / pad) * (pad / 8);
  if ((guint64) image_stride * crop_height > (guint) xcb_get_image_data_length (image)) goto out;
  gdouble ratio = MIN (1.0, MIN ((gdouble) max_width / crop_width,
                               (gdouble) max_height / crop_height));
  gint width = MAX (1, (gint) (crop_width * ratio));
  gint height = MAX (1, (gint) (crop_height * ratio));
  result = gdk_pixbuf_new (GDK_COLORSPACE_RGB, FALSE, 8, width, height);
  if (result != NULL)
    {
      const guint8 *input = xcb_get_image_data (image);
      guint8 *output = gdk_pixbuf_get_pixels (result);
      gint stride = gdk_pixbuf_get_rowstride (result), bytes = bpp / 8;
      for (gint y = 0; y < height; ++y)
        for (gint x = 0; x < width; ++x)
          {
            gint sx = MIN (crop_width - 1, (gint) ((x + .5) * crop_width / width));
            gint sy = MIN (crop_height - 1, (gint) ((y + .5) * crop_height / height));
            const guint8 *pixel = input + sy * image_stride + sx * bytes;
            guint32 raw = 0;
            for (gint i = 0; i < bytes; ++i)
              raw |= (guint32) pixel[i] << (8 * (setup->image_byte_order == XCB_IMAGE_ORDER_LSB_FIRST ? i : bytes - i - 1));
            guint8 *dest = output + y * stride + x * 3;
            dest[0] = tasklist_capture_channel (raw, red);
            dest[1] = tasklist_capture_channel (raw, green);
            dest[2] = tasklist_capture_channel (raw, blue);
          }
    }
out:
  if (pixmap != XCB_NONE) xcb_free_pixmap (connection, pixmap);
  free (error); free (version); free (tree); free (attributes); free (geometry);
  free (client_geometry); free (position); free (image);
  xcb_disconnect (connection);
  return result;
}

#endif

#include "ui.h"
int main(int argc, char **argv) {
    if (argc!=4) return 2;
    ui_set("icons.theme",argv[1],"test",1);
    char *path=ui_icon_path(argv[2],atoi(argv[3]));
    if (!path) return 1;
    puts(path); free(path); ui_icons_reset(); return 0;
}

#!/usr/bin/python3
"""Check icon-theme INI whitespace, inheritance and size metadata order."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile

binary = str(Path(sys.argv[1]).resolve())
with tempfile.TemporaryDirectory(prefix='xlunch-icon-theme-') as tmp:
    root = Path(tmp)
    data = root/'data'
    env = dict(os.environ, HOME=str(root), XDG_DATA_HOME=str(data), XDG_DATA_DIRS=str(root/'empty'))
    theme = data/'icons/SpacingProbe'
    parent = data/'icons/ParentProbe'
    for folder in (theme/'small', theme/'large', theme/'scalable', parent/'apps'):
        folder.mkdir(parents=True)
    for folder in (theme/'small', theme/'large', theme/'scalable'):
        (folder/'sample.png').write_bytes(b'lookup-only')
    (parent/'apps/inherited.png').write_bytes(b'lookup-only')
    parent.joinpath('index.theme').write_text('[Icon Theme]\nDirectories=apps\n[apps]\nSize=64\nType=Fixed\n')
    count = 0
    for whitespace in (False, True):
        eq = ' \t= \t' if whitespace else '='
        pad = '  ' if whitespace else ''
        lines = ['[Icon Theme]', 'Name'+eq+'Spacing probe', 'Inherits'+eq+'ParentProbe',
                 'Directories'+eq+'small,large,scalable', '[small]', 'Size'+eq+'16', 'Type'+eq+'Fixed',
                 '[large]', 'Type'+eq+'Fixed', 'Size'+eq+'64', '[scalable]', 'Type'+eq+'Scalable',
                 'MinSize'+eq+'100', 'MaxSize'+eq+'256', 'Size'+eq+'128']
        theme.joinpath('index.theme').write_text('\n'.join(pad+line+pad for line in lines)+'\n')
        for name, size, expected in [('sample',16,theme/'small/sample.png'),
                                     ('sample',64,theme/'large/sample.png'),
                                     ('sample',240,theme/'scalable/sample.png'),
                                     ('inherited',64,parent/'apps/inherited.png')]:
            result = subprocess.run([binary,'SpacingProbe',name,str(size)],env=env,
                                    stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True)
            assert result.returncode == 0 and result.stdout.strip()==str(expected), (whitespace,name,size,result.stdout,result.stderr,str(expected))
            count += 1
    (theme/'large/browser.png').write_bytes(b'lookup-only')
    (parent/'apps/browser-special.png').write_bytes(b'lookup-only')
    for name, expected in [('browser-unavailable',theme/'large/browser.png'),
                           ('browser-special',parent/'apps/browser-special.png'),
                           ('browser-unavailable-variant',theme/'large/browser.png')]:
        result=subprocess.run([binary,'SpacingProbe',name,'64'],env=env,
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True)
        assert result.returncode==0 and result.stdout.strip()==str(expected), (name,result.stdout,result.stderr)
        count += 1
    print('Icon theme tests: %d whitespace/inheritance/size/fallback cases passed' % count)

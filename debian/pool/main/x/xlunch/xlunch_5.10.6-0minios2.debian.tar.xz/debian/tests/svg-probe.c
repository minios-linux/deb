#include "ui.h"
int main(int argc,char **argv) {
    if (argc!=2) return 2;
    Imlib_Image direct=ui_svg_image(argv[1],64,64);
    if (!direct) { fprintf(stderr,"native SVG rendering unavailable\n"); return 1; }
    imlib_context_set_image(direct);
    DATA32 *data=imlib_image_get_data_for_reading_only();
    int good=(data[32*64+32]>>24)==255 && (data[0]>>24)==0;
    imlib_free_image();
    if (!good) { fprintf(stderr,"SVG aspect ratio or alpha changed\n"); return 1; }
    Imlib_Image image=ui_icon_image(argv[1],64,64);
    if (!image) { fprintf(stderr,"catalog requires an Imlib2 SVG loader\n"); return 1; }
    imlib_context_set_image(image);
    data=imlib_image_get_data_for_reading_only();
    int w=imlib_image_get_width(),h=imlib_image_get_height(),visible=0;
    for (int i=0;i<w*h;i++) if (data[i]>>24) visible++;
    if (!visible) return 1;
    if (ui_svg_image("/xlunch-test-nonexistent.svg",64,64)!=NULL) return 1;
    if (ui_svg_image(argv[1],0,64)!=NULL) return 1;
    printf("SVG tests: native rendering, aspect ratio, alpha, loader fallback and invalid input passed\n");
    ui_icons_reset();
    /* Exercise entry registration, not just the renderer: this used to replace
       perfectly readable SVGs with the ghost before Focus could draw them. */
    focus_mode=1; icon_size=64;
    for (int hide=0;hide<=1;hide++) {
        hide_missing=hide;
        node_t *entry=calloc(1,sizeof(*entry));
        entry->id=strdup("svg-probe.desktop"); entry->name=strdup("SVG probe");
        snprintf(entry->title,sizeof(entry->title),"SVG probe");
        snprintf(entry->icon,sizeof(entry->icon),"%s",argv[1]);
        push_entry(entry);
        if (!entries || strcmp(entries->icon,argv[1])) {
            fprintf(stderr,"Focus replaced or hid a valid SVG during entry registration (hide=%d)\n",hide);
            return 1;
        }
        if (!ui_icon_image(entries->icon,64,64)) return 1;
        clear_entries(); ui_icons_reset();
    }
    printf("SVG entry tests: Focus retains and renders valid icons with/without hide-missing\n");
    return 0;
}

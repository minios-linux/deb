#!/usr/bin/python3
"""Native desktop discovery: no real HOME, desktop, cache or execution."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile

with tempfile.TemporaryDirectory(prefix="xlunch-catalog-") as tmp:
    root = Path(tmp)
    user, system = root / "user", root / "system"
    for path in (user / "applications", system / "applications", root / "home"):
        path.mkdir(parents=True)
    expected = {}
    def entry(name, extra="", visible=True, body=None, personal=False):
        path = (user if personal else system) / "applications" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        content = body if body is not None else "[Desktop Entry]\nType=Application\nName=Example\nExec=/bin/true\n" + extra
        path.write_text(content, encoding="utf-8")
        expected[name.replace("/", "-")] = (visible, path)
        return path
    entry("basic.desktop")
    entry("hidden.desktop", "Hidden=true\n", False)
    entry("nodisplay.desktop", "NoDisplay=true\n", False)
    entry("try-missing.desktop", "TryExec=xlunch-test-nonexistent-executable\n", False)
    entry("try-found.desktop", "TryExec=/bin/true\n")
    entry("try-dir.desktop", "TryExec=/tmp\n", False)
    entry("only-match.desktop", "OnlyShowIn=Fluxbox;\n")
    entry("only-other.desktop", "OnlyShowIn=GNOME;\n", False)
    entry("not-match.desktop", "NotShowIn=Fluxbox;\n", False)
    entry("not-other.desktop", "NotShowIn=GNOME;\n")
    entry("org.example.DBus.desktop", body="[Desktop Entry]\nType=Application\nName=Bus\nDBusActivatable=true\n")
    entry("no-command.desktop", visible=False, body="[Desktop Entry]\nType=Application\nName=No command\n")
    entry("nested/tools.desktop")
    entry("file with spaces.desktop")
    entry("override.desktop")
    entry("override.desktop", personal=True, visible=False, body="[Desktop Entry]\nHidden=true\n")
    entry("prefer-user.desktop")
    entry("prefer-user.desktop", personal=True, body="[Desktop Entry]\nType=Application\nName=User preference\nExec=/bin/true\n")
    entry("action.desktop", "[Desktop Action Extra]\nName=Wrong title\nHidden=true\n")
    entry("link.desktop", visible=False, body="[Desktop Entry]\nType=Link\nName=Link\nURL=https://example.invalid/\n")
    entry("unicode.desktop", body="[Desktop Entry]\nType=Application\nName=Редактор 日本語\nExec=/bin/true\n")
    entry("metadata.desktop", "Categories=Utility;TextEditor;\nComment=Edit files\nKeywords=text;editor;\n")
    for name, sep in (("spaces", " = "), ("tabs", "\t=\t"), ("mixed", " \t= \t")):
        entry(name + ".desktop", body="[Desktop Entry]\nType"+sep+"Application\nName"+sep+"Example\nExec"+sep+"/bin/true\n")
    for name, key, value, visible in (("hidden", "Hidden", "true", False), ("nodisplay", "NoDisplay", "true", False), ("tryexec", "TryExec", "xlunch-test-nonexistent-executable", False), ("onlyshowin", "OnlyShowIn", "GNOME;", False), ("notshowin", "NotShowIn", "Fluxbox;", False)):
        entry("spaced-"+name+".desktop", key+" = "+value+"\n", visible)
    entry("escaped-space.desktop", body="[Desktop Entry]\nType=Application\nName=  \\sLeading\nExec=/bin/true\n")
    entry("crlf.desktop", visible=False, body="[Desktop Entry]\r\nType = Application\r\nName = Hidden\r\nExec = /bin/true\r\nNoDisplay = true")
    entry("wrapper.desktop", "X-Xlunch-Executable=xlunch-test-nonexistent-executable\n")
    env = dict(os.environ, HOME=str(root / "home"), XDG_DATA_HOME=str(user), XDG_DATA_DIRS=str(system), XDG_CACHE_HOME=str(root / "cache"), XDG_CURRENT_DESKTOP="Fluxbox:XFCE", LC_ALL="C.UTF-8")
    out = subprocess.check_output([sys.argv[1]], env=env, universal_newlines=True, timeout=30)
    rows = {parts[0]: parts[1:] for parts in (line.split("\t") for line in out.splitlines())}
    for name, (visible, path) in expected.items():
        assert (name in rows) == visible, (name, visible, rows.get(name))
        if visible:
            assert rows[name][1] == str(path), (name, rows[name])
        print("PASS catalog:", name)
    assert rows["prefer-user.desktop"][0] == "User preference"
    assert rows["action.desktop"][0] == "Example"
    assert rows["unicode.desktop"][0] == "Редактор 日本語"
    assert rows["escaped-space.desktop"][0] == " Leading", rows["escaped-space.desktop"]
    assert rows["metadata.desktop"][2:] == ["Utility;TextEditor;", "Edit files", "text;editor;"]
    print("Native catalog: %s visibility/path cases and metadata checks passed" % len(expected))

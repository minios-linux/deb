#include "ui.h"
int main(int argc,char **argv) {
    if (argc!=2) return 2;
    Imlib_Image direct=ui_svg_image(argv[1],64,64);
    if (!direct) { fprintf(stderr,"native SVG rendering unavailable\n"); return 1; }
    imlib_context_set_image(direct);
    DATA32 *data=imlib_image_get_data_for_reading_only();
    int good=(data[32*64+32]>>24)==255 && (data[0]>>24)==0;
    imlib_free_image();
    if (!good) { fprintf(stderr,"SVG aspect ratio or alpha changed\n"); return 1; }
    Imlib_Image image=ui_icon_image(argv[1],64,64);
    if (!image) { fprintf(stderr,"catalog requires an Imlib2 SVG loader\n"); return 1; }
    imlib_context_set_image(image);
    data=imlib_image_get_data_for_reading_only();
    int w=imlib_image_get_width(),h=imlib_image_get_height(),visible=0;
    for (int i=0;i<w*h;i++) if (data[i]>>24) visible++;
    if (!visible) return 1;
    if (ui_svg_image("/xlunch-test-nonexistent.svg",64,64)!=NULL) return 1;
    if (ui_svg_image(argv[1],0,64)!=NULL) return 1;
    printf("SVG tests: native rendering, aspect ratio, alpha, loader fallback and invalid input passed\n");
    ui_icons_reset();
    return 0;
}

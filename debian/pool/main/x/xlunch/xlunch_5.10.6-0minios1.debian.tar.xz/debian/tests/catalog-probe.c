#include "ui.h"
int main(void) {
    if (!setlocale(LC_ALL, "")) return 2;
    ui_load_entries();
    for (node_t *p=entries; p; p=p->next)
        printf("%s\t%s\t%s\t%s\t%s\t%s\n", p->id, p->name, p->desktop_file,
               p->categories ? p->categories : "", p->description ? p->description : "",
               p->keywords ? p->keywords : "");
    clear_entries();
    return 0;
}

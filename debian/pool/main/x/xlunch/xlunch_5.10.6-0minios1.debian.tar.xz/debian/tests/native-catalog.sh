#!/bin/sh
# Test the actual upstream parser without an X server or installed applications.
set -eu
work=$(mktemp -d)
trap 'rm -rf -- "$work"' EXIT
# Rename only the application's entry point; link all production parser code.
${CC:-cc} ${CPPFLAGS:-} ${CFLAGS:-} -Isrc -Dmain=xlunch_main -c src/main.c -o "$work/main.o"
set --
for file in src/*.c; do
    [ "$file" = src/main.c ] || set -- "$@" "$file"
done
${CC:-cc} ${CPPFLAGS:-} ${CFLAGS:-} -Isrc debian/tests/catalog-probe.c "$work/main.o" "$@" \
    -o "$work/catalog" ${LDFLAGS:-} -lImlib2 -lX11 -lm -ldl
python3 debian/tests/native-catalog.py "$work/catalog"

${CC:-cc} ${CPPFLAGS:-} ${CFLAGS:-} -Isrc debian/tests/svg-probe.c "$work/main.o" "$@" \
    -o "$work/svg-probe" ${LDFLAGS:-} -lImlib2 -lX11 -lm -ldl
printf '%s\n' '<svg xmlns="http://www.w3.org/2000/svg" width="80" height="40" viewBox="0 0 80 40"><rect width="80" height="40" fill="#00aa00"/></svg>' > "$work/probe.svg"
mkdir "$work/no-loaders"
IMLIB2_LOADER_PATH="$work/no-loaders" "$work/svg-probe" "$work/probe.svg"

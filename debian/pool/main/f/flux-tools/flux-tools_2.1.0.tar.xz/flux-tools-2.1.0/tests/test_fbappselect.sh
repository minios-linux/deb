#!/bin/bash
# Exercise dispatch without an X server, package installation or user data.
set -eu
SOURCE_DIR=$(cd -- "$(dirname -- "$0")/.." && pwd)
TEST_ROOT=$(mktemp -d)
trap 'rm -rf -- "$TEST_ROOT"' EXIT
export HOME="$TEST_ROOT/home" TMPDIR="$TEST_ROOT/tmp with spaces" DISPLAY=:99
export FBAPPSELECT_PROFILE="$SOURCE_DIR/etc/xlunch/minios-focus.ini"
export MENU_OUTPUT="$TEST_ROOT/menu-args" CALL_LOG="$TEST_ROOT/calls" LAUNCH_ARGS="$TEST_ROOT/launch-args"
mkdir -p "$TEST_ROOT/bin" "$TMPDIR" "$HOME"
export PATH="$TEST_ROOT/bin:$PATH"
fail() { echo "FAIL: $*" >&2; exit 1; }
cat >"$TEST_ROOT/bin/xlunch" <<'SH'
#!/bin/bash
printf '%s\n' "$@" >"$MENU_OUTPUT"
printf '%s' "${MENU_CHOICE:-}"
exit "${MENU_STATUS:-0}"
SH
printf '#!/bin/sh\nexit 99\n' >"$TEST_ROOT/bin/xlunch_genquick"
printf '#!/bin/sh\nprintf "notify %%s\\n" "$*" >>"$CALL_LOG"\n' >"$TEST_ROOT/bin/fbstartupnotify"
printf '#!/bin/sh\nexit 0\n' >"$TEST_ROOT/bin/gtkask"
cat >"$TEST_ROOT/bin/gio" <<'SH'
#!/bin/sh
if [ "$1" = help ]; then
    [ "${OLD_GIO:-0}" = 1 ] || echo '  launch   Launch a desktop file'
    exit 0
fi
printf 'gio\n' >>"$CALL_LOG"
printf '%s\n' "$@" >"$LAUNCH_ARGS"
exit "${LAUNCH_STATUS:-0}"
SH
for tool in gtk-launch xterm fblogout; do
    cat >"$TEST_ROOT/bin/$tool" <<'SH'
#!/bin/sh
printf '%s\n' "${0##*/}" >>"$CALL_LOG"
printf '%s\n' "$@" >"$LAUNCH_ARGS"
exit "${LAUNCH_STATUS:-0}"
SH
done
chmod +x "$TEST_ROOT/bin/"*
bash "$SOURCE_DIR/bin/fbappselect"
grep -qx -- --multiple "$MENU_OUTPUT" || fail 'global xlunch lock was not bypassed'
grep -qx -- --nostdin "$MENU_OUTPUT" || fail 'menu may block on inherited stdin'
grep -qx -- --ui-config "$MENU_OUTPUT" || fail 'native profile not loaded'
! grep -qx -- --input "$MENU_OUTPUT" || fail 'legacy DSV still used'
[ -z "$(find "$TMPDIR" -type f -print -quit)" ] || fail 'temporary file leaked'
echo 'PASS: native catalog uses profile, no DSV, no global xlunch lock'

if MENU_STATUS=42 bash "$SOURCE_DIR/bin/fbappselect"; then fail 'menu failure ignored'; else status=$?; fi
[ "$status" -eq 42 ] || fail 'menu status changed'
echo 'PASS: menu errors propagate without launching an application'

export MENU_CHOICE="$TEST_ROOT/selected app.desktop"
printf '[Desktop Entry]\nType=Application\nExec=probe\n' >"$MENU_CHOICE"
bash "$SOURCE_DIR/bin/fbappselect"
printf 'launch\n%s\n' "$MENU_CHOICE" >"$TEST_ROOT/expected"
cmp "$LAUNCH_ARGS" "$TEST_ROOT/expected" || fail 'desktop path changed'
! grep -qx xterm "$CALL_LOG" || fail 'desktop parsed as shell code'
echo 'PASS: desktop paths are passed intact to GIO'
OLD_GIO=1 bash "$SOURCE_DIR/bin/fbappselect"
[ "$(cat "$LAUNCH_ARGS")" = 'selected app.desktop' ] || fail 'GTK fallback got wrong ID'
export XDG_DATA_HOME="$TEST_ROOT/xdg data"
export MENU_CHOICE="$XDG_DATA_HOME/applications/nested/tool.desktop"
mkdir -p "${MENU_CHOICE%/*}"
printf '[Desktop Entry]\nType=Application\nExec=probe\n' >"$MENU_CHOICE"
OLD_GIO=1 bash "$SOURCE_DIR/bin/fbappselect"
[ "$(cat "$LAUNCH_ARGS")" = nested-tool.desktop ] || fail 'nested desktop ID lost'
if LAUNCH_STATUS=42 bash "$SOURCE_DIR/bin/fbappselect"; then fail 'launch failure ignored'; else status=$?; fi
[ "$status" -eq 42 ] || fail 'launch failure status changed'
[ "$(tail -n1 "$CALL_LOG")" = 'notify false' ] || fail 'cursor was not restored'
echo 'PASS: legacy GTK, recursive IDs and launch errors are handled'

: >"$CALL_LOG"
MENU_CHOICE=fblogout bash "$SOURCE_DIR/bin/fbappselect"
[ "$(cat "$CALL_LOG")" = fblogout ] || fail 'logout bypassed its helper'
echo 'PASS: Session action retains MiniOS logout/authorization handling'
export MENU_CHOICE='printf "%s\n" "two words"; echo raw-command'
bash "$SOURCE_DIR/bin/fbappselect"
[ "$(tail -n1 "$LAUNCH_ARGS")" = "$MENU_CHOICE" ] || fail 'shell command interpolated in wrapper'
[ "$(tail -n1 "$CALL_LOG")" = xterm ] || fail 'typed command did not use terminal'
echo 'PASS: explicit commands are passed separately to a terminal'

mkdir -p "$HOME/.config/xlunch"
printf '[grid]\nlabel_lines=3\n' >"$HOME/.config/xlunch/focus.ini"
MENU_CHOICE= bash "$SOURCE_DIR/bin/fbappselect"
grep -Fxq "$HOME/.config/xlunch/focus.ini" "$MENU_OUTPUT" || fail 'user profile not loaded'
echo 'PASS: user profile is loaded after system settings without being rewritten'
rm "$MENU_OUTPUT"
exec 9>"$HOME/.fluxbox/fbappselect-${DISPLAY//[^a-zA-Z0-9_.-]/_}.lock"
flock 9
bash "$SOURCE_DIR/bin/fbappselect"
[ ! -e "$MENU_OUTPUT" ] || fail 'concurrent menu was opened'
exec 9>&-
echo 'PASS: per-user/display lock prevents duplicate menus'
if FBAPPSELECT_PROFILE="$TEST_ROOT/missing" bash "$SOURCE_DIR/bin/fbappselect"; then fail 'missing profile accepted'; fi
echo 'PASS: missing profile fails clearly instead of changing catalog mode'

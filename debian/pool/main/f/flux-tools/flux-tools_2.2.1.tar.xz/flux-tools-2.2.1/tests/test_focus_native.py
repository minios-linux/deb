#!/usr/bin/python3
"""Optional Focus/GIO integration in an owned X server >= 1000x700; no host installs."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

SOURCE = Path(__file__).resolve().parents[1]
BINARY = Path(os.environ.get('XLUNCH_BINARY', shutil.which('xlunch') or '/usr/bin/xlunch')).resolve()
if os.geteuid() == 0:
    raise SystemExit('Run this test as an ordinary user in a disposable DISPLAY.')
if not BINARY.is_file() or not os.environ.get('DISPLAY'):
    raise SystemExit('Set XLUNCH_BINARY and use xvfb-run -a python3 tests/test_focus_native.py')
results = []

def check(name, condition, detail=None):
    row = {'name': name, 'pass': bool(condition)}
    if detail is not None:
        row['detail'] = detail
    results.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)
    assert condition, row

with tempfile.TemporaryDirectory(prefix='flux-native-') as temp:
    root = Path(temp)
    home = root / 'home with spaces'
    data, system = root / 'data', root / 'system'
    for p in (home, data/'applications', system/'applications', root/'bin', root/'cache', root/'runtime', root/'working directory'):
        p.mkdir(parents=True, exist_ok=True)
    (root/'runtime').chmod(0o700)
    env = dict(os.environ, HOME=str(home), XDG_DATA_HOME=str(data), XDG_DATA_DIRS=str(system),
               XDG_CONFIG_HOME=str(root/'config'), XDG_CACHE_HOME=str(root/'cache'),
               XDG_RUNTIME_DIR=str(root/'runtime'), XDG_CURRENT_DESKTOP='Fluxbox',
               LC_ALL='C.UTF-8', PATH=str(root/'bin')+':'+str(SOURCE/'bin')+':'+os.environ['PATH'])
    env.pop('LANGUAGE', None)
    profile = root/'focus.ini'
    text = (SOURCE/'etc/xlunch/minios-focus.ini').read_text()
    assets = os.environ.get('XLUNCH_ASSETS')
    if assets:
        text = text.replace('/usr/share/xlunch/focus-icons/', str(Path(assets).resolve())+'/')
    fonts = os.environ.get('XLUNCH_FONT_DIR')
    if fonts:
        text = text.replace('/usr/share/fonts/opentype/inter/', str(Path(fonts).resolve())+'/')
    profile.write_text(text)
    env['FBAPPSELECT_PROFILE'] = str(profile)
    # Redirect only installed artwork paths in the test wrapper. Use actual
    # MiniOS images when supplied, otherwise create distinct 48px PNG fixtures.
    import struct
    import zlib
    def png(path, rgb):
        def chunk(kind, data):
            return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
        raw=(b'\0'+bytes(rgb)*48)*48
        path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',48,48,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b''))
    menu_source=os.environ.get('XLUNCH_MENU_ICONS')
    wrapper=(SOURCE/'bin/fbappselect').read_text()
    for name, rgb in [('org.xfce.panel.applicationsmenu.png',(20,90,200)),
                      ('org.xfce.panel.applicationsmenu-hi.png',(20,180,220))]:
        dest=root/name
        if menu_source: shutil.copyfile(str(Path(menu_source)/name),str(dest))
        else: png(dest,rgb)
        wrapper=wrapper.replace('/usr/share/icons/hicolor/48x48/apps/'+name,str(dest))
    menu_wrapper=root/'fbappselect'
    menu_wrapper.write_text(wrapper)

    def script(name, text):
        p = root/'bin'/name
        p.write_text(text)
        p.chmod(0o755)
        return p
    script('xlunch', '#!/bin/sh\nexec '+__import__('shlex').quote(str(BINARY))+' --windowed --width 1000 --height 700 "$@"\n')
    script('fbstartupnotify', '#!/bin/sh\nexit 0\n')
    script('gtkask', '#!/bin/sh\nexit 0\n')
    script('pkexec', '#!/bin/sh\nprintf denied >"$TEST_ROOT/auth"\nexit 91\n')
    script('runuser', '#!/bin/sh\nprintf forbidden >"$TEST_ROOT/guest"\nexit 92\n')
    script('xhost', '#!/bin/sh\nprintf forbidden >"$TEST_ROOT/xhost"\nexit 93\n')
    script('fblogout', '#!/bin/sh\nprintf selected >"$TEST_ROOT/session"\n')
    script('xterm', '#!/usr/bin/python3\nimport os,sys,json\nopen(os.environ["TEST_ROOT"]+"/terminal","w").write(json.dumps(sys.argv[1:]))\n')
    env['TEST_ROOT'] = str(root)
    record = script('record command', '#!/usr/bin/python3\nimport os,sys,json\np=os.environ["TEST_ROOT"]+"/launched"\nopen(p+".tmp","w").write(json.dumps({"uid":os.getuid(),"argv":sys.argv[1:],"cwd":os.getcwd(),"home":os.environ["HOME"]}))\nos.rename(p+".tmp",p)\n')
    # Redirect only fixed executable paths; all privilege decisions are production code.
    liveapp = (SOURCE/'bin/fbliveapp').read_text().replace('/usr/bin/vlc', str(record)).replace('/usr/bin/minios-installer', str(record))
    script('fbliveapp', liveapp)
    real_gio = shutil.which('gio')
    script('gio', '#!/bin/sh\nif [ "$1" = help ] && [ "${FORCE_GTK:-0}" = 1 ]; then exit 0; fi\nexec '+__import__('shlex').quote(real_gio)+' "$@"\n')
    def entry(path, name, command, extra=''):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text('[Desktop Entry]\nType = Application\nName = '+name+'\nExec = '+command+'\nTerminal=false\nStartupNotify=false\nCategories=Utility;\n'+extra)
    entry(system/'applications/probe.desktop', 'Wrong system entry', '/bin/false')
    selected = data/'applications/probe.desktop'
    entry(selected, 'NativeUserProbe', 'fbliveapp vlc "two words" "semi;colon"', 'Path='+str(root/'working directory')+'\n')
    entry(system/'applications/masked.desktop', 'MaskedSystemProbe', '/bin/false')
    (data/'applications/masked.desktop').write_text('[Desktop Entry]\nHidden = true\n')
    subprocess.run([str(BINARY),'--ui-config',str(profile),'--rebuild-cache'],env=env,check=True,stdout=subprocess.DEVNULL)
    check('native-cache-owned-by-user', all(p.stat().st_uid == os.getuid() for p in (root/'cache').rglob('*')))
    check('native-cache-private-directory', (root/'cache/xlunch').stat().st_mode & 0o777 == 0o700)
    def run_menu(query, expected=0, toggle=False):
        proc = subprocess.Popen(['bash', str(menu_wrapper)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True)
        try:
            wid = None
            for _ in range(80):
                q = subprocess.run(['xdotool','search','--onlyvisible','--class','^xlunch-windowed$'],env=env,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,universal_newlines=True)
                if q.returncode == 0 and q.stdout.strip():
                    wid=q.stdout.splitlines()[0]
                    break
                if proc.poll() is not None:
                    break
                time.sleep(.1)
            if not wid:
                raise AssertionError('No Focus window: '+str(proc.communicate(timeout=3)))
            subprocess.run(['xdotool','windowfocus','--sync',wid],env=env,check=True)
            time.sleep(.15)
            if toggle:
                geometry=subprocess.check_output(['xdotool','getwindowgeometry','--shell',wid],env=env,universal_newlines=True)
                height=int(dict(line.split('=',1) for line in geometry.splitlines() if '=' in line)['HEIGHT'])
                subprocess.run(['xdotool','mousemove','--sync','--window',wid,'24',str(height-26)],env=env,check=True)
                time.sleep(.2)
                subprocess.run(['xdotool','click','1'],env=env,check=True)
            else:
                subprocess.run(['xdotool','type','--clearmodifiers','--delay','8',query],env=env,check=True)
                time.sleep(.2)
                subprocess.run(['xdotool','key','--clearmodifiers','Return'],env=env,check=True)
            out, err=proc.communicate(timeout=10)
            check('menu-selection-'+query,proc.returncode==expected, {'rc':proc.returncode,'stderr':err[-300:]})
        finally:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill();proc.communicate()
    def await_record():
        for _ in range(100):
            if (root/'launched').exists():
                return json.loads((root/'launched').read_text())
            time.sleep(.05)
        raise AssertionError('Application did not record its launch')
    run_menu('NativeUserProbe')
    got=await_record()
    check('native-gio-preserves-user-and-home',got['uid']==os.getuid() and got['home']==str(home),got)
    check('native-gio-preserves-arguments-and-working-directory',got['argv']==['two words','semi;colon'] and got['cwd']==str(root/'working directory'))
    check('ordinary-user-never-switched-or-elevated',not any((root/p).exists() for p in ('guest','auth','xhost')))
    # Cold scans use the GTK fallback too, including standard recursive desktop IDs.
    (root/'launched').unlink()
    selected.unlink()
    nested=data/'applications/nested/probe.desktop'
    entry(nested,'NativeGtkProbe','fbliveapp vlc "nested argument"')
    env['FORCE_GTK']='1';env['XDG_CACHE_HOME']=str(root/'gtk-cache')
    run_menu('NativeGtkProbe')
    got=await_record();check('native-gtk-recursive-id-and-user',got['uid']==os.getuid() and got['argv']==['nested argument'])
    env.pop('FORCE_GTK');(root/'launched').unlink()
    # The real installation wrapper must still take the authorization path.
    entry(data/'applications/installer.desktop','NativeAuthorizationProbe','fbliveapp minios-installer')
    env['XDG_CACHE_HOME']=str(root/'auth-cache')
    run_menu('NativeAuthorizationProbe')
    for _ in range(100):
        if (root/'auth').exists():break
        time.sleep(.03)
    check('installer-retains-authorization-boundary',(root/'auth').exists() and not (root/'launched').exists())
    command='printf "%s\\n" "two words"; echo literal'
    run_menu('> '+command)
    args=json.loads((root/'terminal').read_text())
    check('explicit-command-is-terminal-argument',args[-1].strip()==command)
    # Inject a user-configured action using the same upstream output protocol as Session.
    override=root/'config/xlunch/focus.ini';override.parent.mkdir(parents=True)
    override.write_text('[entry.sessionprobe]\nlabel=NativeSessionProbe\ncommand=fblogout\noutput=fblogout\ncategories=System\n')
    run_menu('NativeSessionProbe')
    check('session-retains-existing-helper',(root/'session').read_text()=='selected')
    # Cache write failure must not prevent a regular user's application menu.
    override.unlink();(root/'auth').unlink()
    ro=root/'read-only-cache';ro.mkdir();ro.chmod(0o500);env['XDG_CACHE_HOME']=str(ro)
    try:
        run_menu('NativeGtkProbe');got=await_record()
        check('unwritable-cache-does-not-break-launch',got['uid']==os.getuid())
    finally:
        ro.chmod(0o700)
    check('no-privilege-leaks-after-all-launches',not any((root/p).exists() for p in ('guest','auth','xhost')))
    for name in ('launched','terminal','session'):
        path=root/name
        if path.exists(): path.unlink()
    env['XDG_CACHE_HOME']=str(root/'toggle-cache')
    run_menu('', toggle=True)
    check('menu-toggle-closes-without-application-or-session-action',
          not any((root/name).exists() for name in ('launched','terminal','session','auth','guest','xhost')))

if os.environ.get('FOCUS_TEST_RESULT'):
    Path(os.environ['FOCUS_TEST_RESULT']).write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('Focus integration: %d checks passed' % len(results))

# Flux Tools

Shell helpers for the MiniOS Flux desktop. The package uses the existing X11
and GTK toolchain without adding a service or application registry.

## Launching applications

`fbdesktop` seeds the standard launchers once. `fbappselect` uses upstream xlunch Focus and its native desktop catalog (xlunch >= 5.10.6-0minios2); `fbliveapp APPLICATION [ARGUMENT...]` offers to install a supported application when it is missing. No DSV generator runs when opening the application menu.

The system profile is `/etc/xlunch/minios-focus.ini`. A user can add an overlay at `${XDG_CONFIG_HOME:-$HOME/.config}/xlunch/focus.ini`; it is read after system settings and translated labels, and is never rewritten. `FBAPPSELECT_PROFILE` selects an alternative base profile. Categories, localized application names, desktop visibility and per-user caches are handled by xlunch. Two-line labels use the upstream `grid.label_lines` setting. The profile uses the existing MiniOS Inter font; no additional font package is required. The separate logout dialog remains on its small, fixed DSV action list.

The lower-left menu button is retained as an upstream image-button overlay. It closes the fullscreen menu without starting a program. The footer is aligned with the application grid to keep the button area clear.

Prefix a terminal command with `>` in the Focus search field. Normal text searches applications; it is not interpreted as shell code. Session opens the existing `fblogout` helper, preserving authorization and current-session targeting.

Desktop files are launched through `gio launch`; older GLib versions use
`gtk-launch` with the desktop ID from the same XDG application directories.
The package requires `libglib2.0-bin (>= 2.67.2)` or `libgtk-3-bin` so a
compatible desktop launcher is installed even without recommended packages.
Quoted arguments, field codes, `TryExec`, `Path` and terminal requests are left
to the desktop launcher rather than interpreted as shell code. Free-form
commands typed into xlunch run in a terminal and retain shell syntax.

Only one application menu, logout menu and startup-cursor watcher run per user/display. The menu wrappers use `--multiple` to bypass xlunch's shared `/tmp/xlunch.lock`, keeping their own user/display locks instead.
The watcher restores the cursor after at most ten seconds if no window appears.
A menu invocation no longer kills all xlunch processes.

## User settings

The initialization marker remains `~/.fluxbox/fbdesktop.initialized`.
Successful initialization does not replace existing launchers; subsequent
runs refresh the MIME cache without recreating deleted entries. Failed writes
do not set the marker, so the next run can complete initialization.

For ordinary users, application entries follow `XDG_DATA_HOME`, defaulting to
`~/.local/share/applications`. Root's standard entries stay in
`/usr/share/applications` and are readable by other users. User-selected MIME
associations are never changed. The hidden image viewer uses `NoDisplay`, not
`Hidden`, so it still handles images when absent from the application menu.

VLC and Chromium use `guest` only when invoked from a root session. Installer
and Configurator request root privileges with pkexec when needed; other MiniOS
applications retain their own privilege handling. VLC's initial privacy
setting is written only for a missing config, as its owner, outside the
privileged package installation. Existing files and symlinks are preserved.
Firefox language packs are optional and use regional package names.

## Session helpers

`fbsetkb LAYOUT` saves a layout only after applying it successfully.
`fbscreensize MODE [-n]` selects the primary connected display, or the first
connected display when there is no primary. After a successful mode change,
it reinitializes only this display's Compton with SIGUSR1; `-n` omits that step.

`fbprintscreen` saves into the XDG pictures directory (or `~/Pictures`), then
uses gpicview or feh when available. Capture failures remove partial images.
`fblogout` ends only the current user's Fluxbox on the current display. Power
actions use the system reboot/poweroff commands and pkexec for non-root users.
Failures remove the temporary blank overlay and are reported to the caller.

`gtk-bookmarks-update` maintains root's automounted-volume bookmarks. It uses
a bounded flock in `/root/.fluxbox`, preserves personal bookmarks and encodes
volume names as file URIs. Other users' bookmarks are not modified.

## Compatibility with 1.x

Version 2.0.0 includes deliberate default-behavior changes, not only fixes.
Free-form launcher input always runs in a terminal. Resolution changes
prefer the primary display and reinitialize an existing Compton rather
than starting or replacing it. Invalid arguments and failed actions now
return nonzero statuses; callers must handle these failures.

Command names, the initialization marker and user data formats remain
unchanged. No migration is required. Version 2.0.1 corrects the missing
desktop-launcher dependency introduced in 2.0.0.

## Tests and development

Run `make test` for metadata, required launcher dependencies, shell syntax
and regression tests. System-changing
commands are stubbed and files are confined to temporary directories; these
tests do not install packages, signal desktop processes or power off the host.
They use the existing build dependencies and base-system utilities.

`make test-launch` additionally exercises the actual GIO launcher.
`FORCE_GTK=1 make test-launch` tests the GTK fallback and requires an X display;
on a headless development machine it can run under an existing Xvfb setup.
No test packages are added to the runtime dependencies.

The Debian-native release authority is `debian/changelog`. `make test` checks
that every manual and gettext catalog has the same version. Run translations
from the minios-live workspace with `lokit translate --target flux-tools`.
`update-po.sh` is an offline gettext maintenance helper, not a translation
provider; extraction errors preserve the previous template and return failure.

## Scope

Desktop discovery, icon lookup and visibility filtering belong to the upstream native xlunch catalog.
Flux Tools does not add a second application filter. The current policy for
removing package launcher duplicates after a successful fbliveapp installation
is retained; external package installations are not intercepted. No automatic
migration or restoration of user-deleted launchers is performed.

## Compatibility with 2.0

Version 2.1 uses Focus with the native catalog instead of the legacy generator. Use `>` for commands and profile settings for appearance; application launching, installation and privilege boundaries are unchanged. Do not replace `fbdesktop`, `fbliveapp` or `fbstartupnotify` with Slax helpers as part of an xlunch update. The legacy `xlunch_genquick` remains in the xlunch package for external callers, but is not required by this menu.

Run `xvfb-run -a -s "-screen 0 1280x800x24" make test-focus` as an ordinary user for real Focus/GIO/GTK integration. Set `XLUNCH_BINARY` to an uninstalled binary and optionally `XLUNCH_ASSETS` to its `extra/focus-icons` directory. An owned X server must be at least 1000x700. `XLUNCH_FONT_DIR` and `XLUNCH_MENU_ICONS` can select extracted Inter fonts and menu-button PNGs for an uninstalled build. The test needs Python 3, Xvfb, xauth and xdotool, creates private user directories, and stubs authorization and power actions. These are test tools, not added runtime dependencies.

## Installation badges and Firefox variants

Focus uses its upstream install badge and installed-first ordering. Generated
install-on-demand entries declare `X-Xlunch-Executable` using the read-only
`fbliveapp --executable APPLICATION` query; the marker names the application,
not the always-present installation wrapper. The Store target is
`/usr/bin/minios-store-launcher`.

The legacy `firefox-esr-flux.desktop` ID and `fbliveapp firefox-esr` action stay
valid. An installed ESR browser is preferred, then an installed Firefox. If
neither is present, Ubuntu Bionic selects `firefox` with `firefox-locale-*`,
other Ubuntu releases use `firefox-esr` with `firefox-esr-locale-*`, and
Debian uses `firefox-esr` with `firefox-esr-l10n-*`. For Ubuntu ESR, the
Mozilla Team PPA is configured after consent only if the ESR package is
not available from existing APT sources, following the image recipe.
Optional missing language packs do not prevent installation. Launches
retain the calling user's identity.

At login, fbdesktop adds missing availability metadata to recognized existing
wrapper entries. It preserves custom commands and existing markers, file mode,
symlinks, and deleted entries; it does not regenerate initialized profiles.
Administrator-owned files that the caller cannot write are left unchanged.

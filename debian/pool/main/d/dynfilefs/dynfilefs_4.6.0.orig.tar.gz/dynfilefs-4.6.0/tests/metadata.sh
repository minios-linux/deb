#!/bin/sh
set -eu
ROOT=$(CDPATH='' cd -- "$(dirname "$0")/.." && pwd)
version=$(sed -n 's/^AC_INIT(\[dynfilefs\], \[\([^]]*\)\]).*/\1/p' "$ROOT/configure.ac")
test -n "$version"
grep -Fq "char *program_banner = \"dynfilefs $version -" "$ROOT/dynfilefs.c"
grep -Fxq "DYNFILEFS_VERSION = $version" "$ROOT/buildroot/package/dynfilefs/dynfilefs.mk"
for manual in dynfilefs mount.dynfilefs; do
    grep -Fq "\"dynfilefs $version\"" "$ROOT/debian/$manual.8"
done
entry=$(sed -n '1p' "$ROOT/debian/changelog")
case "$entry" in
    "dynfilefs ($version-"*") unstable;"*) ;;
    *) printf 'Changelog does not match AC_INIT: %s\n' "$entry" >&2; exit 1 ;;
esac
grep -Fxq 'off_t format_version=400;' "$ROOT/dynfilefs.c"
printf 'PASS metadata: application %s, storage format 400\n' "$version"

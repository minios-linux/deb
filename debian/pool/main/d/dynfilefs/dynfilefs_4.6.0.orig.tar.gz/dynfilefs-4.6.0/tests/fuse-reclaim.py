#!/usr/bin/env python3
"""Opt-in real FUSE test: python3 tests/fuse-reclaim.py /path/to/dynfilefs.

Uses only a private temporary storage image, no loop devices or root required.
Requires a usable /dev/fuse and fusermount. Fails rather than silently skipping.
Pass --loop to also test ext4 -> loop -> FUSE fstrim (requires mount privileges).
Set DYNFILEFS_LEGACY_BINARY to test reopening with an older format-400 reader.
"""

import ctypes
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


def main():
    binary = str(Path(sys.argv[1]).resolve())
    fusermount = shutil.which("fusermount")
    if not fusermount:
        raise RuntimeError("fusermount is required")
    libc = ctypes.CDLL(None, use_errno=True)
    libc.fallocate.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_longlong, ctypes.c_longlong]
    libc.fallocate.restype = ctypes.c_int
    with tempfile.TemporaryDirectory(prefix="dynfilefs-fuse-") as directory:
        root = Path(directory)
        mount = root / "mount"
        mount.mkdir()
        storage = root / "storage"
        image = mount / "virtual.dat"
        process = None

        def start(executable=binary):
            nonlocal process
            process = subprocess.Popen(
                [executable, "-f", str(storage), "-m", str(mount), "-s", "8", "-p", "4", "-d"],
                stdout=log, stderr=log,
            )
            for _ in range(100):
                if process.poll() is not None:
                    raise RuntimeError("FUSE daemon exited before mount")
                if image.exists():
                    return
                time.sleep(0.05)
            raise RuntimeError("FUSE mount timed out")

        def stop():
            if process is not None and process.poll() is None:
                subprocess.run([fusermount, "-u", str(mount)], check=True)
                process.wait(timeout=10)

        def command(*arguments):
            subprocess.run([binary, *arguments], check=True, timeout=60)

        try:
            with (root / "fuse.log").open("w+") as log:
                try:
                    start()
                    with image.open("r+b", buffering=0) as stream:
                        # Two segments, plus enough live data to measure real
                        # physical allocation and to leave a reclaimable gap.
                        payload = b"A" * (1024 * 1024)
                        stream.write(payload)
                        stream.seek(4 * 1024 * 1024)
                        stream.write(b"B" * 4096)
                        os.fsync(stream.fileno())
                        segment = root / "storage.0"
                        before = segment.stat()
                        if libc.fallocate(stream.fileno(), 3, 0, len(payload) - 4096):
                            raise OSError(ctypes.get_errno(), "FUSE PUNCH_HOLE failed")
                        stream.seek(0)
                        assert stream.read(len(payload) - 4096) == bytes(len(payload) - 4096)
                        command("--reclaim", str(image))
                        assert segment.stat().st_size == before.st_size
                        reclaimed = segment.stat()
                        if os.environ.get("DYNFILEFS_EXPECT_NO_PUNCH"):
                            assert reclaimed.st_blocks == before.st_blocks
                        command("--compact", str(image))
                        after = segment.stat()
                        assert after.st_size < before.st_size
                        assert after.st_blocks < before.st_blocks
                        print("Allocated segment bytes: before={}, reclaim={}, compact={}".format(
                            before.st_blocks * 512, reclaimed.st_blocks * 512, after.st_blocks * 512), flush=True)
                        stream.seek(len(payload) - 4096)
                        assert stream.read(4096) == b"A" * 4096
                        stream.seek(4 * 1024 * 1024)
                        assert stream.read(4096) == b"B" * 4096
                        assert os.fstat(stream.fileno()).st_size == 8 * 1024 * 1024
                    stop()
                    start()
                    with image.open("r+b", buffering=0) as stream:
                        stream.seek(len(payload) - 4096)
                        assert stream.read(4096) == b"A" * 4096
                        stream.seek(4 * 1024 * 1024)
                        assert stream.read(4096) == b"B" * 4096
                        stream.seek(len(payload) - 4096)
                        stream.write(bytes(4096))
                        os.fsync(stream.fileno())
                        command("--reclaim", str(image), "--scan-zeroes")
                        stream.seek(len(payload) - 4096)
                        assert stream.read(4096) == bytes(4096)
                    print("PASS: real FUSE discard, reclaim, compact, zero scan, remount, split data")
                    legacy = os.environ.get("DYNFILEFS_LEGACY_BINARY")
                    if legacy:
                        stop()
                        start(str(Path(legacy).resolve()))
                        with image.open("r+b", buffering=0) as stream:
                            stream.seek(len(payload) - 4096)
                            assert stream.read(4096) == bytes(4096)
                            stream.seek(4 * 1024 * 1024)
                            assert stream.read(4096) == b"B" * 4096
                            stream.seek(4096)
                            stream.write(b"C" * 4096)
                            os.fsync(stream.fileno())
                        stop()
                        start()
                        with image.open("rb", buffering=0) as stream:
                            stream.seek(4096)
                            assert stream.read(4096) == b"C" * 4096
                        print("PASS: old format-400 binary reads/writes reclaimed storage; new binary reopens it")
                    if "--loop" in sys.argv[2:]:
                        inner = root / "inner"
                        inner.mkdir()
                        subprocess.run(["mkfs.ext4", "-q", "-F", "-b", "4096", "-E", "nodiscard", str(image)], check=True)
                        subprocess.run(["mount", "-o", "loop", str(image), str(inner)], check=True)
                        mounted = True
                        try:
                            keep = os.urandom(65536)
                            with (inner / "keep").open("wb") as stream:
                                stream.write(keep)
                                stream.flush()
                                os.fsync(stream.fileno())
                            with (inner / "victim").open("wb") as stream:
                                stream.write(os.urandom(1024 * 1024))
                                stream.flush()
                                os.fsync(stream.fileno())
                            before = sum(p.stat().st_blocks for p in root.glob("storage.*"))
                            (inner / "victim").unlink()
                            # Commit ext4's pending free transaction before
                            # asking FITRIM which extents are available.
                            subprocess.run(["sync", "-f", str(inner)], check=True)
                            subprocess.run(["fstrim", "-v", str(inner)], check=True)
                            command("--compact", str(image))
                            after = sum(p.stat().st_blocks for p in root.glob("storage.*"))
                            assert after < before, (before, after)
                            assert (inner / "keep").read_bytes() == keep
                            subprocess.run(["umount", str(inner)], check=True)
                            mounted = False
                            subprocess.run(["e2fsck", "-f", "-n", str(image)], check=True)
                            subprocess.run(["mount", "-o", "loop", str(image), str(inner)], check=True)
                            mounted = True
                            assert (inner / "keep").read_bytes() == keep
                            assert not (inner / "victim").exists()
                            print(f"PASS: ext4/loop fstrim and compact; allocated bytes {before * 512} -> {after * 512}")
                        finally:
                            if mounted:
                                subprocess.run(["umount", str(inner)], check=True)
                except BaseException:
                    log.flush()
                    log.seek(0)
                    print("\n".join(log.read().splitlines()[-80:]), file=sys.stderr)
                    raise
                finally:
                    stop()
        finally:
            if process is not None and process.poll() is None:
                process.terminate()
                process.wait(timeout=10)


if __name__ == "__main__":
    main()

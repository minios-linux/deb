#define _GNU_SOURCE 1
#include <stdio.h>
#include <string.h>

#define main dynfilefs_entrypoint
#include "../dynfilefs.c"
#undef main

static int test_mount_options(void)
{
    size_MB = 0;
    split_size_MB = 0;
    option_parse_error = 0;
    free(fuse_options);
    fuse_options = NULL;

    set_options("rw,size=64,split=16,default_permissions");

    if (size_MB != 64 || split_size_MB != 16 || option_parse_error ||
        fuse_options == NULL || strcmp(fuse_options, "rw,default_permissions") != 0) {
        fprintf(stderr, "-o parser produced size=%lld split=%lld\n",
                (long long)size_MB, (long long)split_size_MB);
        free(fuse_options);
        fuse_options = NULL;
        return 1;
    }
    set_options("ro");
    if (strcmp(fuse_options, "rw,default_permissions,ro") != 0) {
        fprintf(stderr, "repeated FUSE options were not preserved\n");
        free(fuse_options);
        fuse_options = NULL;
        return 1;
    }
    free(fuse_options);
    fuse_options = NULL;
    return 0;
}

static int test_size_parsing(void)
{
    off_t bytes;

    option_parse_error = 0;
    set_size_MB("-12");
    if (size_MB != 12 || option_parse_error) {
        fprintf(stderr, "legacy negative size coercion changed\n");
        return 1;
    }
    set_size_MB("12junk");
    if (!option_parse_error) {
        fprintf(stderr, "malformed size was accepted\n");
        return 1;
    }
    option_parse_error = 0;
    set_split_size_MB("999999999999999999999999999999");
    if (!option_parse_error) {
        fprintf(stderr, "overflowing split size was accepted\n");
        return 1;
    }
    if (mb_to_bytes(64, &bytes) != 0 || bytes != 64 * 1024 * 1024) {
        fprintf(stderr, "megabyte conversion failed\n");
        return 1;
    }
    return 0;
}

static int test_read_at_eof(void)
{
    char bytes[2] = {1, 1};
    size_t index_size;

    virtual_size = DATA_BLOCK_SIZE;
    split_size = DATA_BLOCK_SIZE;
    max_files = 1;
    offset_block_size = sizeof(off_t);

    if (dynfilefs_read(dynfilefs_path, bytes, 1, virtual_size, NULL) != 0) {
        fprintf(stderr, "read at EOF did not return zero\n");
        return 1;
    }

    index_size = header_size + sizeof(off_t);
    indexes[0] = calloc(1, index_size);
    if (indexes[0] == NULL)
        return 1;
    if (dynfilefs_read(dynfilefs_path, bytes, sizeof(bytes), virtual_size - 1, NULL) != 1 ||
        bytes[0] != 0) {
        fprintf(stderr, "read crossing EOF was not clamped\n");
        free(indexes[0]);
        indexes[0] = NULL;
        return 1;
    }
    free(indexes[0]);
    indexes[0] = NULL;
    return 0;
}

static int test_failed_write_is_not_published(void)
{
    char byte = 1;
    size_t index_size = header_size + sizeof(off_t);
    int result;

    virtual_size = DATA_BLOCK_SIZE;
    split_size = DATA_BLOCK_SIZE;
    max_files = 1;
    offset_block_size = sizeof(off_t);
    indexes[0] = calloc(1, index_size);
    files[0] = fopen("/dev/null", "r");
    last_block_offsets[0] = index_size;
    if (indexes[0] == NULL || files[0] == NULL)
        return 1;

    result = dynfilefs_write(dynfilefs_path, &byte, 1, 0, NULL);
    fclose(files[0]);
    files[0] = NULL;
    off_t mapping = -1;
    if (result >= 0 || get_data_offset(0, &mapping) != 0 || mapping != 0) {
        fprintf(stderr, "failed first write published an index mapping\n");
        free(indexes[0]);
        indexes[0] = NULL;
        return 1;
    }
    free(indexes[0]);
    indexes[0] = NULL;
    return 0;
}

static int test_metadata_io(void)
{
    struct metaStruct expected = {400, 16 * 1024 * 1024, 64 * 1024 * 1024};
    struct metaStruct actual = {};
    FILE *file = tmpfile();

    if (file == NULL)
        return 1;
    if (fseeko(file, meta_header_offset, SEEK_SET) != 0 ||
        fwrite(&expected.version, sizeof(expected.version), 1, file) != 1 ||
        fflush(file) != 0 || read_metadata(file, &actual) == 0) {
        fprintf(stderr, "partial metadata was accepted\n");
        fclose(file);
        return 1;
    }
    if (write_metadata(file, &expected) != 0 || fflush(file) != 0 ||
        read_metadata(file, &actual) != 0 ||
        memcmp(&expected, &actual, sizeof(expected)) != 0) {
        fprintf(stderr, "complete metadata did not round-trip\n");
        fclose(file);
        return 1;
    }
    fclose(file);
    return 0;
}

static int test_index_mapping(void)
{
    char *index = NULL;
    size_t map_size = DATA_BLOCK_SIZE + sizeof(off_t);
    FILE *file = tmpfile();

    if (file == NULL)
        return 1;
    if (ftruncate(fileno(file), map_size - 1) != 0 ||
        map_index(file, map_size, &index) == 0) {
        fprintf(stderr, "short index file was mapped\n");
        fclose(file);
        return 1;
    }
    if (ftruncate(fileno(file), map_size) != 0 ||
        map_index(file, map_size, &index) != 0) {
        fprintf(stderr, "complete index file was not mapped\n");
        fclose(file);
        return 1;
    }
    munmap(index, map_size);
    fclose(file);
    return 0;
}

static int test_index_validation(void)
{
    off_t target;
    size_t index_size;

    virtual_size = DATA_BLOCK_SIZE;
    split_size = DATA_BLOCK_SIZE;
    max_files = 1;
    offset_block_size = sizeof(off_t);
    index_size = header_size + offset_block_size;
    indexes[0] = calloc(1, index_size);
    last_block_offsets[0] = index_size + DATA_BLOCK_SIZE;
    if (indexes[0] == NULL)
        return 1;

    target = meta_header_offset;
    memcpy(indexes[0] + header_size, &target, sizeof(target));
    if (get_data_offset(0, &target) != -EIO) {
        fprintf(stderr, "metadata-pointing index was accepted\n");
        free(indexes[0]);
        indexes[0] = NULL;
        return 1;
    }
    target = index_size + DATA_BLOCK_SIZE;
    memcpy(indexes[0] + header_size, &target, sizeof(target));
    if (get_data_offset(0, &target) != 0) {
        fprintf(stderr, "valid format-400 index was rejected\n");
        free(indexes[0]);
        indexes[0] = NULL;
        return 1;
    }
    free(indexes[0]);
    indexes[0] = NULL;
    return 0;
}

static int test_duplicate_index_validation(void)
{
    off_t target;
    size_t index_size;

    virtual_size = 2 * DATA_BLOCK_SIZE;
    split_size = virtual_size;
    max_files = 1;
    offset_block_size = 2 * sizeof(off_t);
    index_size = header_size + offset_block_size;
    indexes[0] = calloc(1, index_size);
    target = index_size + DATA_BLOCK_SIZE;
    last_block_offsets[0] = target;
    if (indexes[0] == NULL)
        return 1;
    memcpy(indexes[0] + header_size, &target, sizeof(target));
    memcpy(indexes[0] + header_size + sizeof(target), &target, sizeof(target));
    if (validate_index(0) == 0) {
        fprintf(stderr, "duplicate physical block mappings were accepted\n");
        free(indexes[0]);
        indexes[0] = NULL;
        return 1;
    }
    free(indexes[0]);
    indexes[0] = NULL;
    return 0;
}

static int test_allocator_recovery(void)
{
    off_t data_start = 6144;

    if (recover_last_block_offset(data_start, data_start) != data_start ||
        recover_last_block_offset(data_start + DATA_BLOCK_SIZE + 1, data_start) !=
            data_start + DATA_BLOCK_SIZE ||
        recover_last_block_offset(data_start + 2 * DATA_BLOCK_SIZE, data_start) !=
            data_start + DATA_BLOCK_SIZE) {
        fprintf(stderr, "allocator tail recovery is incorrect\n");
        return 1;
    }
    return 0;
}

static int test_fsync_barrier(void)
{
    size_t map_size = DATA_BLOCK_SIZE + sizeof(off_t);

    max_files = 1;
    offset_block_size = sizeof(off_t);
    files[0] = tmpfile();
    mainfile = tmpfile();
    if (files[0] == NULL || mainfile == NULL ||
        ftruncate(fileno(files[0]), map_size) != 0 ||
        map_index(files[0], map_size, &indexes[0]) != 0)
        return 1;
    indexes[0][0] = 1;
    if (dynfilefs_fsync(dynfilefs_path, 1, NULL) != 0) {
        fprintf(stderr, "fsync barrier failed\n");
        munmap(indexes[0], map_size);
        fclose(files[0]);
        indexes[0] = NULL;
        files[0] = NULL;
        return 1;
    }
    munmap(indexes[0], map_size);
    fclose(files[0]);
    fclose(mainfile);
    indexes[0] = NULL;
    files[0] = NULL;
    mainfile = NULL;
    return 0;
}

static int test_truncate_semantics(void)
{
    virtual_size = 64 * 1024 * 1024;
    max_files = 0;

    if (dynfilefs_truncate(dynfilefs_path, virtual_size) != 0 ||
        dynfilefs_truncate(dynfilefs_path, 0) != -EOPNOTSUPP ||
        dynfilefs_truncate(dynfilefs_path, virtual_size * 2) != -EOPNOTSUPP) {
        fprintf(stderr, "truncate reported a size change it did not perform\n");
        return 1;
    }
    return 0;
}

struct directory_test {
    int capacity;
    int count;
    off_t last_offset;
    char names[3][16];
};

static int directory_filler(void *buffer, const char *name,
                            const struct stat *st, off_t offset)
{
    struct directory_test *test = buffer;
    (void)st;

    if (test->count >= test->capacity) return 1;
    snprintf(test->names[test->count], sizeof(test->names[test->count]), "%s", name);
    test->count++;
    test->last_offset = offset;
    return 0;
}

static int test_fuse_metadata_semantics(void)
{
    struct stat st;
    struct directory_test first = {.capacity = 1};
    struct directory_test rest = {.capacity = 3};

    virtual_size = 4096;
    if (dynfilefs_getattr(dynfilefs_path, &st) != 0 ||
        st.st_mode != (S_IFREG | 0644)) {
        fprintf(stderr, "virtual file permissions do not match writable behavior\n");
        return 1;
    }
    if (dynfilefs_readdir("/", &first, directory_filler, 0, NULL) != 0 ||
        first.count != 1 || strcmp(first.names[0], ".") != 0 || first.last_offset != 1) {
        fprintf(stderr, "readdir did not stop at a full buffer\n");
        return 1;
    }
    if (dynfilefs_readdir("/", &rest, directory_filler, first.last_offset, NULL) != 0 ||
        rest.count != 2 || strcmp(rest.names[0], "..") != 0 ||
        strcmp(rest.names[1], "virtual.dat") != 0) {
        fprintf(stderr, "readdir did not resume from its offset\n");
        return 1;
    }
    return 0;
}

static int test_segment_layout_validation(void)
{
    char path[16];
    int count;

    if (segment_path(path, sizeof(path), "changes", 12) != 0 ||
        strcmp(path, "changes.12") != 0 ||
        segment_path(path, 5, "changes", 12) == 0) {
        fprintf(stderr, "segment path validation failed\n");
        return 1;
    }
    if (calculate_file_count(100, 30, &count) != 0 || count != 4 ||
        calculate_file_count(MAX_SPLIT_FILES + 1, 1, &count) == 0 ||
        calculate_file_count(1, 0, &count) == 0) {
        fprintf(stderr, "segment count validation failed\n");
        return 1;
    }
    return 0;
}

static int test_safe_storage_open(void)
{
    char directory[] = "/tmp/dynfilefs-open-XXXXXX";
    char path[128];
    char link_path[128];
    bool created;
    FILE *file;

    if (mkdtemp(directory) == NULL)
        return 1;
    snprintf(path, sizeof(path), "%s/storage", directory);
    snprintf(link_path, sizeof(link_path), "%s/link", directory);

    errno = 0;
    file = open_storage(path, false, &created);
    if (file != NULL || errno != ENOENT || created) {
        fprintf(stderr, "missing committed storage was accepted\n");
        return 1;
    }
    file = open_storage(path, true, &created);
    if (file == NULL || !created) {
        fprintf(stderr, "new storage was not created safely\n");
        return 1;
    }
    fclose(file);
    if (symlink(path, link_path) != 0)
        return 1;
    file = open_storage(link_path, true, &created);
    if (file != NULL) {
        fprintf(stderr, "storage symlink was followed\n");
        fclose(file);
        return 1;
    }
    return 0;
}

static int test_storage_lock(void)
{
    char path[] = "/tmp/dynfilefs-lock-XXXXXX";
    int fd = mkstemp(path);
    FILE *file = fd < 0 ? NULL : fdopen(fd, "r+");
    pid_t child;
    int status;

    if (file == NULL || lock_storage(file) != 0)
        return 1;
    child = fork();
    if (child == 0) {
        FILE *other = fopen(path, "r+");
        if (other == NULL)
            _exit(2);
        _exit(lock_storage(other) == 0 ? 1 : 0);
    }
    if (child < 0 || waitpid(child, &status, 0) < 0) {
        fclose(file);
        return 1;
    }
    fclose(file);
    unlink(path);
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        fprintf(stderr, "second process acquired storage lock\n");
        return 1;
    }
    return 0;
}

// --- helpers and fault injection for the transactional write path ------------

static ssize_t failing_pwrite(int fd, const void *b, size_t n, off_t o)
{
    (void)fd; (void)b; (void)n; (void)o;
    errno = EIO;
    return -1;
}

static ssize_t enospc_pwrite(int fd, const void *b, size_t n, off_t o)
{
    (void)fd; (void)b; (void)n; (void)o;
    errno = ENOSPC;
    return -1;
}

static int failing_fdatasync(int fd)
{
    (void)fd;
    errno = EIO;
    return -1;
}

static int short_write_pending;

static ssize_t short_once_pwrite(int fd, const void *buffer, size_t size,
                                 off_t offset)
{
    if (short_write_pending && size > 1) {
        short_write_pending = 0;
        return pwrite(fd, buffer, size / 2, offset);
    }
    return pwrite(fd, buffer, size, offset);
}

static int fdatasync_calls;
static int fail_fdatasync_call;

static int staged_fdatasync(int fd)
{
    fdatasync_calls++;
    if (fdatasync_calls == fail_fdatasync_call) {
        errno = EIO;
        return -1;
    }
    return fdatasync(fd);
}

static int pwrite_saw_write_lock;

static ssize_t lock_checking_pwrite(int fd, const void *buffer, size_t size,
                                    off_t offset)
{
    int result = pthread_mutex_trylock(&dynfilefs_mutex);

    if (result == EBUSY) {
        pwrite_saw_write_lock = 1;
    } else if (result == 0) {
        pthread_mutex_unlock(&dynfilefs_mutex);
    }
    return pwrite(fd, buffer, size, offset);
}

static void teardown_one_segment(void)
{
    free(allocations[0].slots);
    memset(&allocations[0], 0, sizeof(allocations[0]));
    if (indexes[0]) { free(indexes[0]); indexes[0] = NULL; }
    if (files[0]) { fclose(files[0]); files[0] = NULL; }
    hook_pwrite = pwrite;
    hook_fdatasync = fdatasync;
    hook_fallocate = fallocate;
    hook_ftruncate = ftruncate;
    degraded_readonly = 0;
    short_write_pending = 0;
    fdatasync_calls = 0;
    fail_fdatasync_call = 0;
    pwrite_saw_write_lock = 0;
}

static int setup_one_segment(off_t data_blocks)
{
    size_t index_size;

    header_size = DATA_BLOCK_SIZE;
    virtual_size = data_blocks * DATA_BLOCK_SIZE;
    split_size = virtual_size;
    max_files = 1;
    offset_block_size = data_blocks * (off_t)sizeof(off_t);
    degraded_readonly = 0;
    index_dirty_lo[0] = 0;
    index_dirty_hi[0] = 0;
    hook_pwrite = pwrite;
    hook_fdatasync = fdatasync;

    index_size = header_size + offset_block_size;
    indexes[0] = calloc(1, index_size);
    files[0] = tmpfile();
    if (indexes[0] == NULL || files[0] == NULL) return -1;
    if (ftruncate(fileno(files[0]), index_size) != 0) return -1;
    last_block_offsets[0] = index_size;
    return 0;
}

// A failed data write latches degraded, leaves the block as an unreferenced
// orphan (the allocator does not rewind), and rejects later writes read-only.
static int test_degraded_latch_and_orphan(void)
{
    char block[100];
    off_t before;

    memset(block, 0x5a, sizeof(block));
    if (setup_one_segment(4) != 0) { teardown_one_segment(); return 1; }
    before = last_block_offsets[0];
    hook_pwrite = failing_pwrite;

    if (dynfilefs_write(dynfilefs_path, block, sizeof(block), 0, NULL) >= 0) {
        fprintf(stderr, "failed data write was reported as success\n");
        teardown_one_segment();
        return 1;
    }
    if (!degraded_readonly || last_block_offsets[0] == before) {
        fprintf(stderr, "write failure did not latch degraded or rewound the allocator\n");
        teardown_one_segment();
        return 1;
    }
    hook_pwrite = pwrite;
    if (dynfilefs_write(dynfilefs_path, block, sizeof(block), 0, NULL) != -EROFS) {
        fprintf(stderr, "degraded device accepted a new write\n");
        teardown_one_segment();
        return 1;
    }
    teardown_one_segment();
    return 0;
}

// ENOSPC while writing a new data block leaves its index entry unpublished and
// latches degraded before the write can be acknowledged.
static int test_data_write_enospc(void)
{
    char block[100];
    off_t mapping = -1;

    memset(block, 0x5a, sizeof(block));
    if (setup_one_segment(4) != 0) { teardown_one_segment(); return 1; }
    hook_pwrite = enospc_pwrite;

    if (dynfilefs_write(dynfilefs_path, block, sizeof(block), 0, NULL) != -ENOSPC) {
        fprintf(stderr, "data write failure did not surface ENOSPC\n");
        teardown_one_segment();
        return 1;
    }
    if (!degraded_readonly || get_data_offset(0, &mapping) != 0 || mapping != 0 ||
        index_dirty_hi[0] != 0) {
        fprintf(stderr, "ENOSPC published an index entry or did not latch degraded\n");
        teardown_one_segment();
        return 1;
    }
    teardown_one_segment();
    return 0;
}

// A sub-block write stores a full zero-initialized 4 KiB block (no stale tail),
// and the index entry becomes durable on disk only at the fsync barrier, never
// before its data.
static int test_full_block_and_deferred_index(void)
{
    char in[10];
    char out[DATA_BLOCK_SIZE];
    off_t mapped = 0;
    off_t disk_entry = 0;

    memset(in, 0xab, sizeof(in));
    if (setup_one_segment(4) != 0) { teardown_one_segment(); return 1; }

    if (dynfilefs_write(dynfilefs_path, in, sizeof(in), 0, NULL) != (int)sizeof(in)) {
        fprintf(stderr, "sub-block write did not report its length\n");
        teardown_one_segment();
        return 1;
    }
    if (get_data_offset(0, &mapped) != 0 || mapped == 0) {
        fprintf(stderr, "new block was not published in memory\n");
        teardown_one_segment();
        return 1;
    }
    // Full block on disk: first 10 bytes user data, remainder zero-filled.
    if (pread(fileno(files[0]), out, DATA_BLOCK_SIZE, mapped) != DATA_BLOCK_SIZE) {
        teardown_one_segment();
        return 1;
    }
    for (int i = 0; i < 10; i++) if ((unsigned char)out[i] != 0xab) {
        fprintf(stderr, "user bytes were not stored\n");
        teardown_one_segment();
        return 1;
    }
    for (int i = 10; i < DATA_BLOCK_SIZE; i++) if (out[i] != 0) {
        fprintf(stderr, "stale tail exposed in a new block\n");
        teardown_one_segment();
        return 1;
    }
    // Before fsync the durable index entry on disk is still zero.
    if (pread(fileno(files[0]), &disk_entry, sizeof(disk_entry), header_size) != sizeof(disk_entry) ||
        disk_entry != 0) {
        fprintf(stderr, "index was published to disk before the fsync barrier\n");
        teardown_one_segment();
        return 1;
    }
    if (dynfilefs_fsync(dynfilefs_path, 1, NULL) != 0) {
        fprintf(stderr, "fsync barrier failed\n");
        teardown_one_segment();
        return 1;
    }
    // After fsync the durable index entry matches the in-memory mapping.
    if (pread(fileno(files[0]), &disk_entry, sizeof(disk_entry), header_size) != sizeof(disk_entry) ||
        disk_entry != mapped) {
        fprintf(stderr, "index was not made durable at the fsync barrier\n");
        teardown_one_segment();
        return 1;
    }
    teardown_one_segment();
    return 0;
}

static int test_retryable_index_write_failure(void)
{
    char in[32];
    off_t mapped = 0;
    off_t disk_entry = 0;

    memset(in, 0x44, sizeof(in));
    if (setup_one_segment(4) != 0) { teardown_one_segment(); return 1; }
    if (dynfilefs_write(dynfilefs_path, in, sizeof(in), 0, NULL) != (int)sizeof(in) ||
        get_data_offset(0, &mapped) != 0 || mapped == 0) {
        teardown_one_segment();
        return 1;
    }

    hook_pwrite = failing_pwrite;
    if (dynfilefs_fsync(dynfilefs_path, 1, NULL) == 0 || index_dirty_hi[0] == 0) {
        fprintf(stderr, "failed index publication was not retained for retry\n");
        teardown_one_segment();
        return 1;
    }
    hook_pwrite = pwrite;
    if (dynfilefs_fsync(dynfilefs_path, 1, NULL) != 0 || index_dirty_hi[0] != 0 ||
        pread(fileno(files[0]), &disk_entry, sizeof(disk_entry), header_size) !=
            (ssize_t)sizeof(disk_entry) || disk_entry != mapped) {
        fprintf(stderr, "index publication retry did not commit the mapping\n");
        teardown_one_segment();
        return 1;
    }
    teardown_one_segment();
    return 0;
}

static int test_short_index_write(void)
{
    char in[32];
    off_t mapped = 0;
    off_t disk_entry = 0;

    memset(in, 0x55, sizeof(in));
    if (setup_one_segment(4) != 0) { teardown_one_segment(); return 1; }
    if (dynfilefs_write(dynfilefs_path, in, sizeof(in), 0, NULL) != (int)sizeof(in) ||
        get_data_offset(0, &mapped) != 0 || mapped == 0) {
        teardown_one_segment();
        return 1;
    }
    short_write_pending = 1;
    hook_pwrite = short_once_pwrite;
    if (dynfilefs_fsync(dynfilefs_path, 1, NULL) != 0 || short_write_pending ||
        index_dirty_hi[0] != 0 ||
        pread(fileno(files[0]), &disk_entry, sizeof(disk_entry), header_size) !=
            (ssize_t)sizeof(disk_entry) || disk_entry != mapped) {
        fprintf(stderr, "short index write was not completed\n");
        teardown_one_segment();
        return 1;
    }
    teardown_one_segment();
    return 0;
}

static int test_retryable_index_sync_failure(void)
{
    char in[32];
    off_t mapped = 0;
    off_t disk_entry = 0;

    memset(in, 0x66, sizeof(in));
    if (setup_one_segment(4) != 0) { teardown_one_segment(); return 1; }
    if (dynfilefs_write(dynfilefs_path, in, sizeof(in), 0, NULL) != (int)sizeof(in) ||
        get_data_offset(0, &mapped) != 0 || mapped == 0) {
        teardown_one_segment();
        return 1;
    }

    fail_fdatasync_call = 2;
    hook_fdatasync = staged_fdatasync;
    if (dynfilefs_fsync(dynfilefs_path, 1, NULL) == 0 || index_dirty_hi[0] == 0) {
        fprintf(stderr, "failed index sync was not retained for retry\n");
        teardown_one_segment();
        return 1;
    }
    hook_fdatasync = fdatasync;
    if (dynfilefs_fsync(dynfilefs_path, 1, NULL) != 0 || index_dirty_hi[0] != 0 ||
        pread(fileno(files[0]), &disk_entry, sizeof(disk_entry), header_size) !=
            (ssize_t)sizeof(disk_entry) || disk_entry != mapped) {
        fprintf(stderr, "index sync retry did not commit the mapping\n");
        teardown_one_segment();
        return 1;
    }
    teardown_one_segment();
    return 0;
}

static int test_write_serialization(void)
{
    char in[32];

    memset(in, 0x77, sizeof(in));
    if (setup_one_segment(4) != 0) { teardown_one_segment(); return 1; }
    hook_pwrite = lock_checking_pwrite;
    if (dynfilefs_write(dynfilefs_path, in, sizeof(in), 0, NULL) != (int)sizeof(in) ||
        !pwrite_saw_write_lock) {
        fprintf(stderr, "physical write ran outside the fsync serialization lock\n");
        teardown_one_segment();
        return 1;
    }
    teardown_one_segment();
    return 0;
}

static int test_large_file_ranges(void)
{
    virtual_size = (off_t)8 * 1024 * 1024 * 1024;

    if (sizeof(off_t) != 8 || range_exceeds_virtual(0, 4096) ||
        range_exceeds_virtual(virtual_size - 4096, 4096) ||
        !range_exceeds_virtual(virtual_size - 1, 2) ||
        !range_exceeds_virtual(virtual_size + 1, 0)) {
        fprintf(stderr, "large-file range validation is not 64-bit safe\n");
        return 1;
    }
    return 0;
}

// A synchronization failure at the barrier latches degraded.
static int test_fsync_failure_latches_degraded(void)
{
    char in[100];

    memset(in, 0x33, sizeof(in));
    if (setup_one_segment(4) != 0) { teardown_one_segment(); return 1; }
    if (dynfilefs_write(dynfilefs_path, in, sizeof(in), 0, NULL) != (int)sizeof(in)) {
        teardown_one_segment();
        return 1;
    }
    hook_fdatasync = (int (*)(int))failing_fdatasync;
    if (dynfilefs_fsync(dynfilefs_path, 1, NULL) == 0 || !degraded_readonly) {
        fprintf(stderr, "fsync failure did not latch degraded\n");
        teardown_one_segment();
        return 1;
    }
    teardown_one_segment();
    return 0;
}

static int punch_calls, truncate_calls;
static int punch_unsupported(int fd, int mode, off_t offset, off_t length)
{
    punch_calls++;
    errno = EOPNOTSUPP;
    return -1;
}

static int count_truncate(int fd, off_t end)
{
    truncate_calls++;
    return ftruncate(fd, end);
}

#define CHECK_RECLAIM(condition) do { if (!(condition)) { \
    fprintf(stderr, "reclaim check failed at line %d: %s\n", __LINE__, #condition); \
    teardown_one_segment(); return 1; } } while (0)

static int discard_range(off_t offset, off_t length)
{
    return dynfilefs_fallocate(dynfilefs_path,
        FALLOC_FL_PUNCH_HOLE | FALLOC_FL_KEEP_SIZE, offset, length, NULL);
}

static int test_discard_reuse(void)
{
    char block[DATA_BLOCK_SIZE], out[DATA_BLOCK_SIZE];
    off_t first, replacement;
    struct stat before, after;
    CHECK_RECLAIM(setup_one_segment(4) == 0);
    hook_fallocate = punch_unsupported;
    memset(block, 0x6d, sizeof(block));
    for (int i = 0; i < 3; i++)
        CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, block, sizeof(block), i * DATA_BLOCK_SIZE, NULL) == sizeof(block));
    CHECK_RECLAIM(dynfilefs_fsync(dynfilefs_path, 0, NULL) == 0);
    CHECK_RECLAIM(get_data_offset(0, &first) == 0 && first != 0);
    CHECK_RECLAIM(fstat(fileno(files[0]), &before) == 0);
    CHECK_RECLAIM(discard_range(0, DATA_BLOCK_SIZE) == 0 && punch_calls == 1);
    CHECK_RECLAIM(dynfilefs_read(dynfilefs_path, out, sizeof(out), 0, NULL) == sizeof(out));
    CHECK_RECLAIM(memcmp(out, empty, sizeof(out)) == 0);
    // Simulate reopening: reconstruct allocation state from durable format 400.
    free(allocations[0].slots);
    memset(&allocations[0], 0, sizeof(allocations[0]));
    CHECK_RECLAIM(pread(fileno(files[0]), indexes[0], header_size + offset_block_size, 0) == header_size + offset_block_size);
    CHECK_RECLAIM(validate_index(0) == 0);
    CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, block, 10, 3 * DATA_BLOCK_SIZE, NULL) == 10);
    CHECK_RECLAIM(get_data_offset(3 * DATA_BLOCK_SIZE, &replacement) == 0 && replacement == first);
    CHECK_RECLAIM(fstat(fileno(files[0]), &after) == 0 && after.st_size == before.st_size);
    CHECK_RECLAIM(dynfilefs_read(dynfilefs_path, out, sizeof(out), 3 * DATA_BLOCK_SIZE, NULL) == sizeof(out));
    CHECK_RECLAIM(memcmp(out, block, 10) == 0 && memcmp(out + 10, empty, sizeof(out) - 10) == 0);
    CHECK_RECLAIM(discard_range(0, virtual_size) == 0);
    CHECK_RECLAIM(fstat(fileno(files[0]), &after) == 0 && after.st_size == header_size + offset_block_size);
    CHECK_RECLAIM(last_block_offsets[0] == header_size + offset_block_size);
    CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, block, sizeof(block), 0, NULL) == sizeof(block));
    CHECK_RECLAIM(get_data_offset(0, &replacement) == 0 && replacement == first);
    teardown_one_segment();
    return 0;
}

static int test_discard_barriers(void)
{
    char block[DATA_BLOCK_SIZE], out[DATA_BLOCK_SIZE];
    off_t target, disk_entry;
    CHECK_RECLAIM(setup_one_segment(4) == 0);
    memset(block, 0x71, sizeof(block));
    CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, block, sizeof(block), 0, NULL) == sizeof(block));
    CHECK_RECLAIM(dynfilefs_fsync(dynfilefs_path, 0, NULL) == 0);
    CHECK_RECLAIM(get_data_offset(0, &target) == 0);
    hook_fallocate = punch_unsupported;
    hook_ftruncate = count_truncate;
    hook_pwrite = failing_pwrite;
    CHECK_RECLAIM(discard_range(0, DATA_BLOCK_SIZE) == -EIO);
    CHECK_RECLAIM(degraded_readonly && punch_calls == 0 && truncate_calls == 0);
    CHECK_RECLAIM(pread(fileno(files[0]), &disk_entry, sizeof(disk_entry), header_size) == sizeof(disk_entry));
    CHECK_RECLAIM(disk_entry == target);
    CHECK_RECLAIM(pread(fileno(files[0]), out, sizeof(out), target) == sizeof(out) && memcmp(out, block, sizeof(out)) == 0);
    CHECK_RECLAIM(allocations[0].slots[1] == SLOT_RETIRED);
    CHECK_RECLAIM(discard_range(0, DATA_BLOCK_SIZE) == -EROFS);
    hook_pwrite = pwrite;
    // An uncertain index sync must also postpone all physical reclamation.
    fdatasync_calls = 0;
    fail_fdatasync_call = 2;
    hook_fdatasync = staged_fdatasync;
    CHECK_RECLAIM(dynfilefs_fsync(dynfilefs_path, 0, NULL) == -EIO);
    CHECK_RECLAIM(truncate_calls == 0 && allocations[0].slots[1] == SLOT_RETIRED);
    hook_fdatasync = fdatasync;
    CHECK_RECLAIM(dynfilefs_fsync(dynfilefs_path, 0, NULL) == 0 && truncate_calls == 1);
    CHECK_RECLAIM(degraded_readonly); // Sync retry does not silently re-enable writes.
    teardown_one_segment();
    return 0;
}

static int test_discard_partial_segments(void)
{
    char block[DATA_BLOCK_SIZE], out[DATA_BLOCK_SIZE];
    CHECK_RECLAIM(setup_one_segment(4) == 0);
    max_files = 2;
    virtual_size = split_size * 2;
    files[1] = tmpfile();
    indexes[1] = calloc(1, header_size + offset_block_size);
    CHECK_RECLAIM(files[1] != NULL && indexes[1] != NULL);
    CHECK_RECLAIM(ftruncate(fileno(files[1]), header_size + offset_block_size) == 0);
    last_block_offsets[1] = header_size + offset_block_size;
    memset(block, 0x5a, sizeof(block));
    for (off_t offset = split_size - DATA_BLOCK_SIZE; offset <= split_size; offset += DATA_BLOCK_SIZE)
        CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, block, sizeof(block), offset, NULL) == sizeof(block));
    CHECK_RECLAIM(discard_range(split_size - DATA_BLOCK_SIZE / 2, DATA_BLOCK_SIZE) == 0);
    CHECK_RECLAIM(dynfilefs_read(dynfilefs_path, out, sizeof(out), split_size - DATA_BLOCK_SIZE, NULL) == sizeof(out));
    CHECK_RECLAIM(memcmp(out, block, DATA_BLOCK_SIZE / 2) == 0 && memcmp(out + DATA_BLOCK_SIZE / 2, empty, DATA_BLOCK_SIZE / 2) == 0);
    CHECK_RECLAIM(dynfilefs_read(dynfilefs_path, out, sizeof(out), split_size, NULL) == sizeof(out));
    CHECK_RECLAIM(memcmp(out, empty, DATA_BLOCK_SIZE / 2) == 0 && memcmp(out + DATA_BLOCK_SIZE / 2, block, DATA_BLOCK_SIZE / 2) == 0);
    CHECK_RECLAIM(discard_range(-1, 1) == -EINVAL);
    CHECK_RECLAIM(discard_range(virtual_size - 1, 2) == -EINVAL);
    CHECK_RECLAIM(discard_range(0, 0) == -EINVAL);
    CHECK_RECLAIM(dynfilefs_fallocate(dynfilefs_path, 0, 0, DATA_BLOCK_SIZE, NULL) == -EOPNOTSUPP);
    CHECK_RECLAIM(discard_range(split_size - DATA_BLOCK_SIZE, DATA_BLOCK_SIZE * 2) == 0);
    CHECK_RECLAIM(validate_index(0) == 0 && validate_index(1) == 0);
    free(indexes[1]); indexes[1] = NULL;
    fclose(files[1]); files[1] = NULL;
    free(allocations[1].slots); memset(&allocations[1], 0, sizeof(allocations[1]));
    teardown_one_segment();
    return 0;
}

static int test_compact(void)
{
    char block[DATA_BLOCK_SIZE], out[DATA_BLOCK_SIZE];
    off_t before, after;
    struct stat st;
    struct reclaim_request request = {0};
    struct fuse_file_info fi = { .flags = O_RDWR };
    CHECK_RECLAIM(dynfilefs_open(dynfilefs_path, &fi) == 0);
    CHECK_RECLAIM(setup_one_segment(4) == 0);
    hook_fallocate = punch_unsupported;
    memset(block, 0x2c, sizeof(block));
    for (int i = 0; i < 4; i++)
        CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, block, sizeof(block), i * DATA_BLOCK_SIZE, NULL) == sizeof(block));
    CHECK_RECLAIM(get_data_offset(3 * DATA_BLOCK_SIZE, &before) == 0);
    CHECK_RECLAIM(discard_range(0, 3 * DATA_BLOCK_SIZE) == 0);
    CHECK_RECLAIM(dynfilefs_ioctl(dynfilefs_path, DYNFILEFS_RECLAIM, NULL, &fi, 0, &request) == 0 && request.done);
    CHECK_RECLAIM(get_data_offset(3 * DATA_BLOCK_SIZE, &after) == 0 && after == before);
    request = (struct reclaim_request){ .flags = RECLAIM_COMPACT };
    CHECK_RECLAIM(dynfilefs_ioctl(dynfilefs_path, DYNFILEFS_RECLAIM, NULL, &fi, 0, &request) == 0 && request.done && request.moved_bytes == DATA_BLOCK_SIZE);
    CHECK_RECLAIM(get_data_offset(3 * DATA_BLOCK_SIZE, &after) == 0 && after < before);
    CHECK_RECLAIM(fstat(fileno(files[0]), &st) == 0 && st.st_size == after + DATA_BLOCK_SIZE);
    CHECK_RECLAIM(dynfilefs_read(dynfilefs_path, out, sizeof(out), 3 * DATA_BLOCK_SIZE, NULL) == sizeof(out) && memcmp(out, block, sizeof(out)) == 0);
    CHECK_RECLAIM(validate_index(0) == 0);
    // Zero scan is opt-in and does not need relocation.
    CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, empty, sizeof(block), 3 * DATA_BLOCK_SIZE, NULL) == sizeof(block));
    request = (struct reclaim_request){ .flags = RECLAIM_ZEROES };
    CHECK_RECLAIM(dynfilefs_ioctl(dynfilefs_path, DYNFILEFS_RECLAIM, NULL, &fi, 0, &request) == 0 && request.done);
    CHECK_RECLAIM(get_data_offset(3 * DATA_BLOCK_SIZE, &after) == 0 && after == 0);
    fi.flags = O_RDONLY;
    CHECK_RECLAIM(dynfilefs_open(dynfilefs_path, &fi) == 0);
    CHECK_RECLAIM(dynfilefs_ioctl(dynfilefs_path, DYNFILEFS_RECLAIM, NULL, &fi, 0, &request) == -EBADF);
    teardown_one_segment();
    return 0;
}

static ssize_t fail_index_pwrite(int fd, const void *buffer, size_t size, off_t offset)
{
    if (offset < header_size + offset_block_size) { errno = EIO; return -1; }
    return pwrite(fd, buffer, size, offset);
}

static int test_compact_failure(void)
{
    char block[DATA_BLOCK_SIZE], out[DATA_BLOCK_SIZE];
    off_t source, disk_entry;
    struct reclaim_request request = { .flags = RECLAIM_COMPACT };
    CHECK_RECLAIM(setup_one_segment(4) == 0);
    hook_fallocate = punch_unsupported;
    memset(block, 0x7e, sizeof(block));
    CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, block, sizeof(block), 0, NULL) == sizeof(block));
    CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, block, sizeof(block), DATA_BLOCK_SIZE, NULL) == sizeof(block));
    CHECK_RECLAIM(discard_range(0, DATA_BLOCK_SIZE) == 0);
    CHECK_RECLAIM(get_data_offset(DATA_BLOCK_SIZE, &source) == 0);
    hook_pwrite = fail_index_pwrite;
    hook_ftruncate = count_truncate;
    CHECK_RECLAIM(reclaim_step(&request) == -EIO && degraded_readonly && truncate_calls == 0);
    CHECK_RECLAIM(pread(fileno(files[0]), &disk_entry, sizeof(disk_entry), header_size + sizeof(off_t)) == sizeof(disk_entry) && disk_entry == source);
    CHECK_RECLAIM(pread(fileno(files[0]), out, sizeof(out), source) == sizeof(out) && memcmp(out, block, sizeof(out)) == 0);
    // New in-memory mapping also remains readable after the publication error.
    CHECK_RECLAIM(dynfilefs_read(dynfilefs_path, out, sizeof(out), DATA_BLOCK_SIZE, NULL) == sizeof(out) && memcmp(out, block, sizeof(out)) == 0);
    teardown_one_segment();
    return 0;
}

static int test_reclaim_model(void)
{
    enum { BLOCKS = 16, BYTES = BLOCKS * DATA_BLOCK_SIZE };
    unsigned char expected[BYTES] = {0}, actual[BYTES], input[DATA_BLOCK_SIZE];
    uint32_t state = 0x4197e;
    CHECK_RECLAIM(setup_one_segment(BLOCKS) == 0);
    hook_fallocate = punch_unsupported;
    for (int step = 0; step < 300; step++)
    {
        state = state * 1664525U + 1013904223U;
        size_t offset = state % BYTES;
        size_t length = 1 + (state >> 16) % DATA_BLOCK_SIZE;
        if (length > BYTES - offset) length = BYTES - offset;
        if (step % 3 == 0)
        {
            CHECK_RECLAIM(discard_range(offset, length) == 0);
            memset(expected + offset, 0, length);
        }
        else
        {
            memset(input, step % 7 ? state >> 24 : 0, length);
            CHECK_RECLAIM(dynfilefs_write(dynfilefs_path, (char *)input, length, offset, NULL) == (int)length);
            memcpy(expected + offset, input, length);
        }
        if (step % 5 == 0)
        {
            struct reclaim_request request = { .flags = RECLAIM_COMPACT | RECLAIM_ZEROES };
            CHECK_RECLAIM(reclaim_step(&request) == 0 && request.done);
        }
        if (step % 17 == 0)
        {
            struct stat st;
            CHECK_RECLAIM(dynfilefs_fsync(dynfilefs_path, 0, NULL) == 0);
            free(allocations[0].slots);
            memset(&allocations[0], 0, sizeof(allocations[0]));
            CHECK_RECLAIM(pread(fileno(files[0]), indexes[0], header_size + offset_block_size, 0) == header_size + offset_block_size);
            CHECK_RECLAIM(fstat(fileno(files[0]), &st) == 0);
            last_block_offsets[0] = recover_last_block_offset(st.st_size, header_size + offset_block_size);
        }
        CHECK_RECLAIM(validate_index(0) == 0);
        CHECK_RECLAIM(dynfilefs_read(dynfilefs_path, (char *)actual, BYTES, 0, NULL) == BYTES);
        CHECK_RECLAIM(memcmp(actual, expected, BYTES) == 0);
    }
    teardown_one_segment();
    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s TEST\n", argv[0]);
        return 2;
    }
    if (strcmp(argv[1], "mount-options") == 0)
        return test_mount_options();
    if (strcmp(argv[1], "discard-reuse") == 0) return test_discard_reuse();
    if (strcmp(argv[1], "discard-barriers") == 0) return test_discard_barriers();
    if (strcmp(argv[1], "discard-partial-segments") == 0) return test_discard_partial_segments();
    if (strcmp(argv[1], "compact") == 0) return test_compact();
    if (strcmp(argv[1], "compact-failure") == 0) return test_compact_failure();
    if (strcmp(argv[1], "reclaim-model") == 0) return test_reclaim_model();
    if (strcmp(argv[1], "size-parsing") == 0)
        return test_size_parsing();
    if (strcmp(argv[1], "read-at-eof") == 0)
        return test_read_at_eof();
    if (strcmp(argv[1], "failed-write") == 0)
        return test_failed_write_is_not_published();
    if (strcmp(argv[1], "metadata-io") == 0)
        return test_metadata_io();
    if (strcmp(argv[1], "index-mapping") == 0)
        return test_index_mapping();
    if (strcmp(argv[1], "index-validation") == 0)
        return test_index_validation();
    if (strcmp(argv[1], "duplicate-index") == 0)
        return test_duplicate_index_validation();
    if (strcmp(argv[1], "allocator-recovery") == 0)
        return test_allocator_recovery();
    if (strcmp(argv[1], "fsync-barrier") == 0)
        return test_fsync_barrier();
    if (strcmp(argv[1], "truncate-semantics") == 0)
        return test_truncate_semantics();
    if (strcmp(argv[1], "fuse-metadata") == 0)
        return test_fuse_metadata_semantics();
    if (strcmp(argv[1], "segment-layout") == 0)
        return test_segment_layout_validation();
    if (strcmp(argv[1], "safe-open") == 0)
        return test_safe_storage_open();
    if (strcmp(argv[1], "storage-lock") == 0)
        return test_storage_lock();

    if (strcmp(argv[1], "degraded-latch") == 0)
        return test_degraded_latch_and_orphan();
    if (strcmp(argv[1], "data-write-enospc") == 0)
        return test_data_write_enospc();
    if (strcmp(argv[1], "full-block-deferred-index") == 0)
        return test_full_block_and_deferred_index();
    if (strcmp(argv[1], "retryable-index-write") == 0)
        return test_retryable_index_write_failure();
    if (strcmp(argv[1], "short-index-write") == 0)
        return test_short_index_write();
    if (strcmp(argv[1], "retryable-index-sync") == 0)
        return test_retryable_index_sync_failure();
    if (strcmp(argv[1], "write-serialization") == 0)
        return test_write_serialization();
    if (strcmp(argv[1], "large-file-ranges") == 0)
        return test_large_file_ranges();
    if (strcmp(argv[1], "fsync-failure-degraded") == 0)
        return test_fsync_failure_latches_degraded();

    fprintf(stderr, "unknown test: %s\n", argv[1]);
    return 2;
}

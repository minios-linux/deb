#!/usr/bin/env python3
"""Test on disposable FAT32/exFAT backing filesystems; requires mount privileges.

Usage: python3 tests/backing-reclaim.py /absolute/path/to/dynfilefs
Only regular temporary image files are formatted. mount -o loop allocates and
releases the loop devices; no caller-supplied block device is accepted.
"""

import os
from pathlib import Path
import subprocess
import sys
import tempfile


def main():
    binary = str(Path(sys.argv[1]).resolve())
    suite = Path(__file__).with_name("fuse-reclaim.py")
    for filesystem in ("vfat", "exfat"):
        with tempfile.TemporaryDirectory(prefix="dynfilefs-backing-") as directory:
            root = Path(directory)
            image = root / "backing.img"
            with image.open("wb") as stream:
                stream.truncate(128 * 1024 * 1024)
            if filesystem == "vfat":
                subprocess.run(["mkfs.vfat", "-F", "32", str(image)], check=True)
            else:
                subprocess.run(["mkfs.exfat", str(image)], check=True)
            mount = root / "backing"
            mount.mkdir()
            subprocess.run(["mount", "-t", filesystem, "-o", "loop", str(image), str(mount)], check=True)
            try:
                environment = dict(os.environ, TMPDIR=str(mount), DYNFILEFS_EXPECT_NO_PUNCH="1")
                print("Testing backing filesystem: " + filesystem, flush=True)
                subprocess.run([sys.executable, str(suite), binary, "--loop"],
                               env=environment, check=True, timeout=180)
            finally:
                subprocess.run(["umount", str(mount)], check=True)
            checker = "fsck.vfat" if filesystem == "vfat" else "fsck.exfat"
            subprocess.run([checker, "-n", str(image)], check=True)
            print("PASS: " + filesystem + " backing filesystem and post-test fsck", flush=True)


if __name__ == "__main__":
    main()

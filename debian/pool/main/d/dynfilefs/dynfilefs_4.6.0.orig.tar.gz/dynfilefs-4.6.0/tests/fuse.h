#ifndef DYNFILEFS_TEST_FUSE_H
#define DYNFILEFS_TEST_FUSE_H

#include <stdint.h>
#include <sys/stat.h>
#include <sys/types.h>

struct fuse_file_info {
    uint64_t fh;
    int flags;
};

#define FUSE_IOCTL_UNRESTRICTED (1 << 1)

typedef int (*fuse_fill_dir_t)(void *, const char *, const struct stat *, off_t);

struct fuse_operations {
    int (*getattr)(const char *, struct stat *);
    int (*readdir)(const char *, void *, fuse_fill_dir_t, off_t, struct fuse_file_info *);
    int (*open)(const char *, struct fuse_file_info *);
    int (*read)(const char *, char *, size_t, off_t, struct fuse_file_info *);
    int (*write)(const char *, const char *, size_t, off_t, struct fuse_file_info *);
    int (*fallocate)(const char *, int, off_t, off_t, struct fuse_file_info *);
    int (*ioctl)(const char *, int, void *, struct fuse_file_info *, unsigned int, void *);
    int (*fsync)(const char *, int, struct fuse_file_info *);
    int (*flush)(const char *, struct fuse_file_info *);
    int (*release)(const char *, struct fuse_file_info *);
    void (*destroy)(void *);
    int (*truncate)(const char *, off_t);
    int (*chmod)(const char *, mode_t);
    int (*chown)(const char *, uid_t, gid_t);
};

static inline int fuse_main(int argc, char **argv,
                            const struct fuse_operations *operations,
                            void *user_data)
{
    (void)argc;
    (void)argv;
    (void)operations;
    (void)user_data;
    return 0;
}

#endif

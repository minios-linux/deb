#!/bin/sh
set -eu

ROOT=$(CDPATH='' cd -- "$(dirname "$0")/.." && pwd)
BUILD_DIR=${TMPDIR:-/tmp}/dynfilefs-tests-$$
trap 'rm -rf "$BUILD_DIR"' EXIT INT TERM
mkdir -p "$BUILD_DIR"
sh "$ROOT/tests/metadata.sh"

${CC:-cc} -std=gnu11 -Wall -Wextra -Wno-unused-parameter \
    -D_FILE_OFFSET_BITS=64 -D_LARGEFILE_SOURCE=1 -D_LARGE_FILES \
    ${TEST_CFLAGS:-} \
    -I"$ROOT/tests" "$ROOT/tests/test_dynfilefs.c" -pthread \
    -o "$BUILD_DIR/test_dynfilefs"

failed=0
count=0
for test in discard-reuse discard-barriers discard-partial-segments compact \
    compact-failure reclaim-model mount-options size-parsing read-at-eof \
    failed-write metadata-io index-mapping index-validation duplicate-index \
    allocator-recovery fsync-barrier truncate-semantics fuse-metadata \
    segment-layout safe-open storage-lock degraded-latch data-write-enospc \
    full-block-deferred-index retryable-index-write short-index-write \
    retryable-index-sync write-serialization large-file-ranges fsync-failure-degraded
do
    count=$((count + 1))
    if "$BUILD_DIR/test_dynfilefs" "$test"; then
        printf 'PASS %s\n' "$test"
    else
        printf 'FAIL %s\n' "$test"
        failed=$((failed + 1))
    fi
done
printf '%s storage tests, %s failed; metadata test passed\n' "$count" "$failed"
test "$failed" -eq 0

# dynfilefs

`dynfilefs` exposes dynamically allocated block storage as a regular file through
FUSE2. The resulting `virtual.dat` can be used with loop devices, filesystem
tools, and disk-image utilities.

This project is a compatibility-focused fork of
[DynFileFS](https://github.com/Tomas-M/dynfilefs). Its application version is
independent of the preserved DynFileFS format 400 on-disk layout. The inherited
on-disk banner is intentionally unchanged so existing storage remains readable
and writable by both dynfilefs and DynFileFS 4.04.

The commands are `dynfilefs` and `mount.dynfilefs`. The `dynblk` command is
reserved for the independent [kernel block-device project](https://github.com/minios-linux/dynblk);
this FUSE package installs no `dynblk` or `mount.dynblk` aliases.

The format-400 on-disk banner and existing data remain unchanged. The Debian
package can be installed alongside the independent kernel-backed `dynblk`.
Historical tags and release assets retain their original names.

## Requirements

- Linux with FUSE2 support
- `libfuse2` 2.9 or later for native dynamically linked builds
- A loop-capable kernel when `virtual.dat` is mounted as a block image

Release Debian packages are native amd64 builds produced in an Ubuntu 18.04
environment and use the system FUSE2 library. Static release binaries are
i686/musl builds intended for initrd use; running them on amd64 requires kernel
IA32 emulation. Static builds are smoke-tested in an Ubuntu 18.04 userland with
the stock 4.15 kernel baseline.

## Usage

```text
dynfilefs -f storage_file -m mount_dir [-s size_MB] [-p split_size_MB] [-d]
```

- `-f`, `--file`: base path for metadata and storage segments.
- `-m`, `--mountdir`: empty directory where FUSE exposes `virtual.dat`.
- `-s`, `--size`: virtual image size in MB. A larger value grows existing
  storage; a `+` prefix grows it by the specified amount.
- `-p`, `--split`: maximum data size in MB per storage segment.
- `-d`: run in the foreground with debug output.
- `-o size=N,split=N`: mount-helper form of the size and split options.

Example:

```sh
sudo install -d /var/lib/dynfilefs /mnt/dynfilefs /mnt/image
sudo dynfilefs -f /var/lib/dynfilefs/changes.dat -s 1024 -m /mnt/dynfilefs
sudo mke2fs -F /mnt/dynfilefs/virtual.dat
sudo mount -o loop /mnt/dynfilefs/virtual.dat /mnt/image
```

Example `/etc/fstab` entries:

```fstab
/var/lib/dynfilefs/changes.dat /mnt/dynfilefs dynfilefs size=1024,split=1000 0 0
/mnt/dynfilefs/virtual.dat /mnt/image auto loop 0 0
```

## Discard and reclaim (format 400)

Complete discarded 4-KiB blocks are unmapped and become reusable physical
slots. Partial blocks are zeroed only in the requested range. Allocation state
is reconstructed lazily from each segment's existing index, with no new disk
metadata, sidecars, or format conversion. The in-memory map uses one byte per
physical 4-KiB slot, with geometrically grown capacity.

The inner filesystem must tell dynfilefs which blocks are unused:

```sh
fstrim /mnt/image
dynfilefs --reclaim /mnt/dynfilefs/virtual.dat
# Explicit relocation, useful for backing filesystems without hole punching:
dynfilefs --compact /mnt/dynfilefs/virtual.dat
```

The path passed to these commands is the **mounted virtual.dat**, not a storage
segment or the loop device. The daemon and command must both support reclaim.
The filesystem can stay mounted. Loop discard is handled through FUSE
`fallocate(PUNCH_HOLE | KEEP_SIZE)`; end-to-end trim requires support in the
running kernel's loop/FUSE path and the inner filesystem.

Discard automatically punches retired ranges when the backing filesystem
supports it and truncates completely free segment tails. Unsupported punching
falls back to tail truncation and internal reuse, without relocating live data.
`--reclaim` also finds unreferenced physical slots left by previous mounts.
On FAT/exFAT, internal gaps do not return host free space until they reach the
tail, or an explicit `--compact` moves live blocks into earlier free slots.

`--compact` makes a logical-order pass within each segment, moving blocks only
to lower free physical offsets. Each ioctl scans at most 64 logical blocks;
ordinary I/O can run between calls. Initial allocation reconstruction and
segment cleanup may scan a whole segment's metadata/allocation map. A pass is
not a snapshot and does not promise to eliminate every gap; another pass may
help, including when concurrent writes change the layout. Stopping the command
leaves completed steps in place. No automatic path moves live blocks.

Both commands accept an optional `--scan-zeroes`, which also reads mapped
blocks and unmaps those containing only zeroes. Deleted files are not assumed
to contain zeroes. This option does not replace filesystem trim. Ordinary
zero writes to already allocated blocks do not automatically unmap them.

Data is synchronized before publishing a relocated mapping. Removed mappings
are synchronized before old slots can be punched, truncated, or reused.
Reads, writes, and reclaim share the I/O lock. Uncertain write/sync failures
latch the daemon read-only; sync retries remain possible but do not re-enable
writes. Format 400 still has a single index, not a journal: these ordering rules
do not add protection against torn index writes or devices ignoring flushes.

The logical image size stays unchanged. Check actual allocated bytes with
`du` on the backing segments and free space on the backing filesystem, rather
than the virtual image's size or the number of trimmed logical bytes.

## Build

```sh
./autogen.sh
./configure
make -j"$(nproc)"
make check
```

Storage unit/fault-injection tests can also run without FUSE development files:

```sh
sh tests/run.sh
TEST_CFLAGS='-fsanitize=address,undefined -g' sh tests/run.sh
```

An opt-in integration test uses a private temporary image and a real FUSE mount:

```sh
python3 tests/fuse-reclaim.py /absolute/path/to/dynfilefs
# Also exercise ext4 -> loop -> FUSE trim, with mount/loop privileges:
python3 tests/fuse-reclaim.py /absolute/path/to/dynfilefs --loop
# The same suite on disposable FAT32 and exFAT backing images (mount privileges):
python3 tests/backing-reclaim.py /absolute/path/to/dynfilefs
```

Set `DYNFILEFS_LEGACY_BINARY` to an older dynfilefs executable to additionally
verify read/write interoperability after reclaim. The integration test requires
`fusermount`, a usable `/dev/fuse`, and a backing filesystem where the test's
allocation savings can be measured. The `--loop` test also needs ext4 tools,
`mount`, `umount`, and `fstrim`; missing prerequisites fail the test.
The backing-filesystem test additionally needs `dosfstools` and `exfatprogs`.

Build a native Debian package with:

```sh
dpkg-buildpackage -b -us -uc
```

Reproducible static i686/musl build instructions are in
[`buildroot/README.md`](buildroot/README.md). Static binaries are not stored in
the source repository; verified binaries and checksums are published with
[GitHub releases](https://github.com/minios-linux/dynfilefs/releases).

## License

dynfilefs is distributed under the GNU General Public License, version 2 or later.
See [`LICENSE`](LICENSE). Original DynFileFS authorship is retained in the
source and on-disk compatibility banner.

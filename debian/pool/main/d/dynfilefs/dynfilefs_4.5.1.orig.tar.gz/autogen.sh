#!/bin/sh
set -eu

autoreconf -fi
rm -rf autom4te.cache

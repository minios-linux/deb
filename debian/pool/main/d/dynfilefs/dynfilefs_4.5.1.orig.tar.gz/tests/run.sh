#!/bin/sh
set -eu

ROOT=$(CDPATH='' cd -- "$(dirname "$0")/.." && pwd)
BUILD_DIR=${TMPDIR:-/tmp}/dynfilefs-tests-$$
trap 'rm -rf "$BUILD_DIR"' EXIT INT TERM
mkdir -p "$BUILD_DIR"

${CC:-cc} -std=gnu11 -Wall -Wextra -Wno-unused-parameter \
    -D_FILE_OFFSET_BITS=64 -D_LARGEFILE_SOURCE=1 -D_LARGE_FILES \
    ${TEST_CFLAGS:-} \
    -I"$ROOT/tests" "$ROOT/tests/test_dynfilefs.c" -pthread \
    -o "$BUILD_DIR/test_dynfilefs"

failed=0
"$BUILD_DIR/test_dynfilefs" mount-options || failed=1
"$BUILD_DIR/test_dynfilefs" size-parsing || failed=1
"$BUILD_DIR/test_dynfilefs" read-at-eof || failed=1
"$BUILD_DIR/test_dynfilefs" failed-write || failed=1
"$BUILD_DIR/test_dynfilefs" metadata-io || failed=1
"$BUILD_DIR/test_dynfilefs" index-mapping || failed=1
"$BUILD_DIR/test_dynfilefs" index-validation || failed=1
"$BUILD_DIR/test_dynfilefs" duplicate-index || failed=1
"$BUILD_DIR/test_dynfilefs" allocator-recovery || failed=1
"$BUILD_DIR/test_dynfilefs" fsync-barrier || failed=1
"$BUILD_DIR/test_dynfilefs" truncate-semantics || failed=1
"$BUILD_DIR/test_dynfilefs" fuse-metadata || failed=1
"$BUILD_DIR/test_dynfilefs" segment-layout || failed=1
"$BUILD_DIR/test_dynfilefs" safe-open || failed=1
"$BUILD_DIR/test_dynfilefs" storage-lock || failed=1
"$BUILD_DIR/test_dynfilefs" degraded-latch || failed=1
"$BUILD_DIR/test_dynfilefs" data-write-enospc || failed=1
"$BUILD_DIR/test_dynfilefs" full-block-deferred-index || failed=1
"$BUILD_DIR/test_dynfilefs" retryable-index-write || failed=1
"$BUILD_DIR/test_dynfilefs" short-index-write || failed=1
"$BUILD_DIR/test_dynfilefs" retryable-index-sync || failed=1
"$BUILD_DIR/test_dynfilefs" write-serialization || failed=1
"$BUILD_DIR/test_dynfilefs" large-file-ranges || failed=1
"$BUILD_DIR/test_dynfilefs" fsync-failure-degraded || failed=1
exit "$failed"

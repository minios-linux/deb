/*
  Original author: Tomas M <tomas@slax.org>
  DynFileFS modifications: MiniOS Linux contributors
  SPDX-License-Identifier: GPL-2.0-or-later

  Dynamic block storage, provides a large logical device allocated on disk only as needed
  You can then for example make a filesystem on it and mount it using mount -o loop

  This program can be distributed under the terms of the GNU GPL.
  See the file LICENSE.
*/

#define _ATFILE_SOURCE 1
#define _GNU_SOURCE 1
#define FUSE_USE_VERSION 26

#include <fuse.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <pthread.h>
#include <getopt.h>
#include <sys/wait.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdbool.h>
#include <sys/file.h>

#define MAX_SPLIT_FILES 9999
#define DATA_BLOCK_SIZE 4096

char *dynfilefs_path = "/virtual.dat";
char *storage_file = "";
char *mount_dir = "";
char *program_banner = "dynfilefs 4.5.1 - DynFileFS format 400 compatible storage";
char *format_banner = "DynfilefsFS 4.00 (c) 2023 Tomas M <www.slax.org>";
char header[DATA_BLOCK_SIZE] = {};
char empty[DATA_BLOCK_SIZE] = {};

off_t size_MB = 0;
off_t split_size_MB = 0;
off_t increase_size_MB = 0;
int option_parse_error = 0;
char *fuse_options = NULL;

off_t format_version=400;
off_t virtual_size = 0;
off_t split_size = 0;
off_t header_size = DATA_BLOCK_SIZE;
off_t offset_block_size = 0;

int max_files = 1;

struct metaStruct
{
   off_t version;
   off_t split_size;
   off_t virtual_size;
};

int debug=0;
int meta_header_offset = DATA_BLOCK_SIZE / 2;

static int read_metadata(FILE *file, struct metaStruct *meta)
{
   if (fseeko(file, meta_header_offset, SEEK_SET) != 0) return -1;
   if (fread(meta, sizeof(*meta), 1, file) != 1) return -1;
   return 0;
}

static int write_metadata(FILE *file, const struct metaStruct *meta)
{
   if (fseeko(file, meta_header_offset, SEEK_SET) != 0) return -1;
   if (fwrite(meta, sizeof(*meta), 1, file) != 1) return -1;
   return 0;
}

static off_t recover_last_block_offset(off_t file_size, off_t data_start)
{
   off_t data_size;

   if (file_size <= data_start) return data_start;
   data_size = file_size - data_start;
   return data_start + ((data_size - 1) / DATA_BLOCK_SIZE) * DATA_BLOCK_SIZE;
}

static int map_index(FILE *file, size_t map_size, char **index)
{
   struct stat st;
   void *mapped;

   if (fstat(fileno(file), &st) != 0 || st.st_size < (off_t)map_size) {
      errno = EINVAL;
      return -1;
   }
   mapped = mmap(NULL, map_size, PROT_READ|PROT_WRITE, MAP_PRIVATE, fileno(file), 0);
   if (mapped == MAP_FAILED) return -1;
   *index = mapped;
   return 0;
}

static int segment_path(char *buffer, size_t size, const char *base, int index)
{
   int length = snprintf(buffer, size, "%s.%i", base, index);

   if (length < 0 || (size_t)length >= size) {
      errno = ENAMETOOLONG;
      return -1;
   }
   return 0;
}

static int calculate_file_count(off_t total_size, off_t segment_size, int *count)
{
   off_t result;

   if (total_size <= 0 || segment_size <= 0) return -1;
   result = total_size / segment_size + (total_size % segment_size != 0);
   if (result <= 0 || result > MAX_SPLIT_FILES) return -1;
   *count = result;
   return 0;
}

static FILE *open_storage(const char *path, bool allow_create, bool *created)
{
   struct stat st;
   FILE *file;
   int fd;

   *created = false;
   fd = open(path, O_RDWR|O_CLOEXEC|O_NOFOLLOW);
   if (fd < 0)
   {
      if (errno != ENOENT || !allow_create) return NULL;
      fd = open(path, O_RDWR|O_CLOEXEC|O_NOFOLLOW|O_CREAT|O_EXCL, 0666);
      if (fd < 0) return NULL;
      *created = true;
   }
   if (fstat(fd, &st) != 0 || !S_ISREG(st.st_mode))
   {
      int err = errno == 0 ? EINVAL : errno;
      close(fd);
      errno = err;
      return NULL;
   }
   file = fdopen(fd, "r+");
   if (file == NULL)
   {
      int err = errno;
      close(fd);
      errno = err;
   }
   return file;
}

static int lock_storage(FILE *file)
{
   return flock(fileno(file), LOCK_EX|LOCK_NB);
}

static int sync_parent_directory(const char *path)
{
   char *copy = strdup(path);
   char *slash;
   const char *directory;
   int fd;
   int result;

   if (copy == NULL) return -1;
   slash = strrchr(copy, '/');
   if (slash == NULL)
      directory = ".";
   else if (slash == copy)
   {
      slash[1] = '\0';
      directory = copy;
   }
   else
   {
      *slash = '\0';
      directory = copy;
   }
   fd = open(directory, O_RDONLY|O_DIRECTORY|O_CLOEXEC);
   free(copy);
   if (fd < 0) return -1;
   result = fsync(fd);
   close(fd);
   return result;
}

pthread_mutex_t dynfilefs_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_rwlock_t index_lock = PTHREAD_RWLOCK_INITIALIZER;
FILE * mainfile;
FILE * files[MAX_SPLIT_FILES] = {0};
char * indexes[MAX_SPLIT_FILES] = {0};
off_t last_block_offsets[MAX_SPLIT_FILES] = {0};

// Dirty index byte range per segment, published to disk with pwrite at the
// fsync barrier (never through a writable shared mmap). A hi of 0 means clean,
// which is also the zero-initialized state, so no explicit reset is required at
// mount time.
off_t index_dirty_lo[MAX_SPLIT_FILES];
off_t index_dirty_hi[MAX_SPLIT_FILES];

// Once an uncertain writeback or publication fails the device
// latches read-only: reads and retryable sync stay available, new writes are
// rejected, and the allocator never rewinds to reuse uncertain bytes.
int degraded_readonly = 0;

// Injectable syscall seams so tests can deterministically force I/O failures.
static ssize_t (*hook_pwrite)(int, const void *, size_t, off_t) = pwrite;
static int (*hook_fdatasync)(int) = fdatasync;

static int add_sizes(off_t left, off_t right, off_t *result);

static void mark_index_dirty(int ix, off_t seek)
{
   off_t end = seek + (off_t)sizeof(off_t);

   if (index_dirty_hi[ix] == 0)
   {
      index_dirty_lo[ix] = seek;
      index_dirty_hi[ix] = end;
      return;
   }
   if (seek < index_dirty_lo[ix]) index_dirty_lo[ix] = seek;
   if (end > index_dirty_hi[ix]) index_dirty_hi[ix] = end;
}

static void index_dirty_reset(int ix)
{
   index_dirty_lo[ix] = 0;
   index_dirty_hi[ix] = 0;
}

static int pwrite_all(int fd, const void *buffer, size_t size, off_t offset)
{
   const char *cursor = buffer;
   size_t written = 0;

   while (written < size)
   {
      off_t current;
      ssize_t result;

      if (add_sizes(offset, (off_t)written, &current) != 0) return -EFBIG;
      result = hook_pwrite(fd, cursor + written, size - written, current);
      if (result < 0)
      {
         if (errno == EINTR) continue;
         return -errno;
      }
      if (result == 0) return -EIO;
      if ((size_t)result > size - written) return -EIO;
      written += (size_t)result;
   }
   return 0;
}


static int dynfilefs_fsync(const char *path, int isdatasync, struct fuse_file_info *fi)
{
   // Crash-ordering is enforced here, not on every write: first make the data
   // durable, then publish the dirty index range with a checked pwrite, then
   // make the index durable. A complete data block is therefore always durable
   // before the index entry that points at it (B4). No per-write fdatasync.
   pthread_mutex_lock(&dynfilefs_mutex);

   for (int ix = 0; ix < max_files; ix++)
   {
      if (fflush(files[ix]) != 0)
      {
         int err = errno;
         degraded_readonly = 1;
         pthread_mutex_unlock(&dynfilefs_mutex);
         return -err;
      }
      if (hook_fdatasync(fileno(files[ix])) != 0)
      {
         int err = errno;
         degraded_readonly = 1;
         pthread_mutex_unlock(&dynfilefs_mutex);
         return -err;
      }
   }

   for (int ix = 0; ix < max_files; ix++)
   {
      off_t lo, hi;

      pthread_rwlock_rdlock(&index_lock);
      lo = index_dirty_lo[ix];
      hi = index_dirty_hi[ix];
      pthread_rwlock_unlock(&index_lock);

      if (hi == 0 || indexes[ix] == NULL) continue;

      int result = pwrite_all(fileno(files[ix]), indexes[ix] + lo,
                              (size_t)(hi - lo), lo);
      if (result != 0)
      {
         degraded_readonly = 1;
         pthread_mutex_unlock(&dynfilefs_mutex);
         return result;
      }
      if (hook_fdatasync(fileno(files[ix])) != 0)
      {
         int err = errno;
         degraded_readonly = 1;
         pthread_mutex_unlock(&dynfilefs_mutex);
         return -err;
      }
      pthread_rwlock_wrlock(&index_lock);
      index_dirty_reset(ix);
      pthread_rwlock_unlock(&index_lock);
   }

   if (mainfile != NULL)
   {
      if (fflush(mainfile) != 0 || fsync(fileno(mainfile)) != 0)
      {
         int err = errno;
         degraded_readonly = 1;
         pthread_mutex_unlock(&dynfilefs_mutex);
         return -err;
      }
   }
   pthread_mutex_unlock(&dynfilefs_mutex);
   return 0;
}

static int dynfilefs_flush(const char *path, struct fuse_file_info *fi)
{
   for (int ix = 0; ix < max_files; ix++)
      if (fflush(files[ix]) != 0) return -errno;
   return 0;
}


static int dynfilefs_getattr(const char *path, struct stat *stbuf)
{
	int res = 0;

	memset(stbuf, 0, sizeof(struct stat));
	if (strcmp(path, "/") == 0) {
		stbuf->st_mode = S_IFDIR | 0755;
		stbuf->st_nlink = 2;
	} else if (strcmp(path, dynfilefs_path) == 0) {
		stbuf->st_mode = S_IFREG | 0644;
		stbuf->st_nlink = 1;
		stbuf->st_size = virtual_size;
	} else
		res = -ENOENT;

	return res;
}

static int dynfilefs_readdir(const char *path, void *buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{
	if (strcmp(path, "/") != 0)
		return -ENOENT;

	if (offset <= 0 && filler(buf, ".", NULL, 1) != 0) return 0;
	if (offset <= 1 && filler(buf, "..", NULL, 2) != 0) return 0;
	if (offset <= 2) filler(buf, dynfilefs_path + 1, NULL, 3);

	return 0;
}


static int dynfilefs_open(const char *path, struct fuse_file_info *fi)
{
	if (strcmp(path, dynfilefs_path) != 0)
		return -ENOENT;

	return 0;
}



// discover real position of data for offset
//
static int validate_data_offset(int ix, off_t target)
{
   off_t data_start = header_size + offset_block_size;
   off_t minimum;
   off_t block_end;

   if (target == 0) return 0;
   if (ix < 0 || ix >= max_files || add_sizes(data_start, DATA_BLOCK_SIZE, &minimum) != 0)
      return -EIO;
   if (target < minimum || (target - data_start) % DATA_BLOCK_SIZE != 0 ||
       target > last_block_offsets[ix] ||
       add_sizes(target, DATA_BLOCK_SIZE - 1, &block_end) != 0)
      return -EIO;
   return 0;
}

static int get_data_offset(off_t offset, off_t *target)
{
   off_t seek;
   int ix;

   if (offset < 0 || split_size <= 0 || offset >= virtual_size) return -EIO;
   ix = offset / split_size;
   if (ix < 0 || ix >= max_files) return -EIO;

   seek = header_size + (offset - split_size * ix) / DATA_BLOCK_SIZE * sizeof(offset);
   if (seek < header_size || seek > header_size + offset_block_size - (off_t)sizeof(*target))
      return -EIO;

   pthread_rwlock_rdlock(&index_lock);
   memcpy(target, indexes[ix] + seek, sizeof(*target));
   int result = validate_data_offset(ix, *target);
   pthread_rwlock_unlock(&index_lock);
   return result;
}

// These functions are always called when write operation is locked.
static int reserve_data_offset(off_t offset, off_t *data_offset)
{
   int ix = offset / split_size;

   pthread_rwlock_wrlock(&index_lock);
   if (add_sizes(last_block_offsets[ix], DATA_BLOCK_SIZE, data_offset) != 0)
   {
      pthread_rwlock_unlock(&index_lock);
      return -EFBIG;
   }
   last_block_offsets[ix] = *data_offset;
   pthread_rwlock_unlock(&index_lock);
   return 0;
}

static void publish_data_offset(off_t offset, off_t data_offset)
{
   int ix = offset / split_size;
   off_t seek = header_size + (offset - split_size * ix) / DATA_BLOCK_SIZE * sizeof(offset);

   pthread_rwlock_wrlock(&index_lock);
   memcpy(indexes[ix] + seek, &data_offset, sizeof(data_offset));
   // The mapping is private, so this update is only the in-memory read view.
   // Record the dirty range; it becomes durable, ordered after its data, when
   // the fsync barrier writes it with pwrite.
   mark_index_dirty(ix, seek);
   pthread_rwlock_unlock(&index_lock);
}

static int compare_offsets(const void *left, const void *right)
{
   off_t a = *(const off_t *)left;
   off_t b = *(const off_t *)right;
   return (a > b) - (a < b);
}

static int validate_index(int ix)
{
   off_t entries = split_size / DATA_BLOCK_SIZE;
   off_t *allocated;
   size_t allocated_count = 0;

   allocated = malloc((size_t)entries * sizeof(*allocated));
   if (allocated == NULL) return -1;

   for (off_t entry = 0; entry < entries; entry++)
   {
      off_t target;
      off_t seek = header_size + entry * sizeof(target);

      memcpy(&target, indexes[ix] + seek, sizeof(target));
      if (validate_data_offset(ix, target) != 0)
      {
         free(allocated);
         return -1;
      }
      if (target != 0) allocated[allocated_count++] = target;
   }
   qsort(allocated, allocated_count, sizeof(*allocated), compare_offsets);
   for (size_t entry = 1; entry < allocated_count; entry++)
      if (allocated[entry] == allocated[entry - 1])
      {
         free(allocated);
         return -1;
      }
   free(allocated);
   return 0;
}

static int range_exceeds_virtual(off_t offset, size_t size)
{
   if (offset < 0 || offset > virtual_size) return 1;
   return (uintmax_t)size > (uintmax_t)(virtual_size - offset);
}



static int dynfilefs_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
    size_t tot = 0;
    off_t data_offset;
    ssize_t len = 0;
    size_t rd;
    int ix;

    if (offset < 0) return -EINVAL;
    if (offset >= virtual_size || size == 0) return 0;
    if (range_exceeds_virtual(offset, size))
       size = (size_t)(virtual_size - offset);

    while (tot < size)
    {
        ix = offset / split_size;

        rd = DATA_BLOCK_SIZE - (offset % DATA_BLOCK_SIZE);
        if (tot + rd > size) rd = size - tot;
        len = rd;

        if (get_data_offset(offset, &data_offset) != 0) return -EIO;
        if (data_offset != 0)
        {
           len = pread(fileno(files[ix]), buf, rd, data_offset + (offset % DATA_BLOCK_SIZE));
           if (len == 0) { len = rd; memset(buf, 0, len); }
           if (len < 0) return -errno;
        }
        else
           memset(buf, 0, len);

        tot += len;
        buf += len;
        offset += len;
    }

    return tot;
}


static int dynfilefs_write(const char *path, const char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
    if (range_exceeds_virtual(offset, size)) return -ENOSPC;

    size_t tot = 0;
    off_t data_offset;
    ssize_t len;
    size_t wr;
    int ix;

    while (tot < size)
    {
       ix = offset / split_size;

       wr = DATA_BLOCK_SIZE - (offset % DATA_BLOCK_SIZE);
       if (tot + wr > size) wr = size - tot;
       len=0;

       pthread_mutex_lock(&dynfilefs_mutex);

       // Fsync and every physical write use the same lock, so no admitted
       // write can race a transition to the degraded read-only state.
       if (degraded_readonly)
       {
          pthread_mutex_unlock(&dynfilefs_mutex);
          return -EROFS;
       }

        if (get_data_offset(offset, &data_offset) != 0)
        {
           pthread_mutex_unlock(&dynfilefs_mutex);
           return -EIO;
        }

       // skip writing empty blocks if not already exist
       if (!memcmp(&empty, buf, wr) && data_offset == 0)
       {
          len = wr;
       }
       else // write block
       {
           if (data_offset == 0)
           {
              char block[DATA_BLOCK_SIZE];

              if (reserve_data_offset(offset, &data_offset) != 0)
              {
                 pthread_mutex_unlock(&dynfilefs_mutex);
                 return -EFBIG;
              }

              // Write a full, zero-initialized 4 KiB block with the user bytes
              // merged in, so a sub-block write can never expose a stale tail.
              memset(block, 0, DATA_BLOCK_SIZE);
              memcpy(block + (offset % DATA_BLOCK_SIZE), buf, wr);

              int result = pwrite_all(fileno(files[ix]), block,
                                      DATA_BLOCK_SIZE, data_offset);
              if (result != 0)
              {
                 // The data write is uncertain: latch degraded and leave the
                 // block as an unreferenced orphan. The allocator does not
                 // rewind to reuse these physical bytes.
                 degraded_readonly = 1;
                 pthread_mutex_unlock(&dynfilefs_mutex);
                 return result;
              }
              // The data is written; its index entry becomes durable only after
              // the data does, at the next fsync barrier.
              publish_data_offset(offset, data_offset);
              len = wr;
           }
       }

       if (len == 0)
       {
          off_t physical_offset;
          if (add_sizes(data_offset, offset % DATA_BLOCK_SIZE, &physical_offset) != 0)
          {
             pthread_mutex_unlock(&dynfilefs_mutex);
             return -EFBIG;
          }
          int result = pwrite_all(fileno(files[ix]), buf, wr, physical_offset);
          if (result != 0)
          {
             degraded_readonly = 1;
             pthread_mutex_unlock(&dynfilefs_mutex);
             return result;
          }
          len = wr;
       }

       pthread_mutex_unlock(&dynfilefs_mutex);

       tot += len;
       buf += len;
       offset += len;
    }

    return tot;
}

static void dynfilefs_destroy(void *fi)
{
   size_t map_size = header_size + offset_block_size;

   dynfilefs_fsync(dynfilefs_path, 0, NULL);
   for (int ix = 0; ix < max_files; ix++)
   {
      if (indexes[ix] != NULL)
      {
         munmap(indexes[ix], map_size);
         indexes[ix] = NULL;
      }
      if (files[ix] != NULL)
      {
         fclose(files[ix]);
         files[ix] = NULL;
      }
   }
   if (mainfile != NULL)
   {
      fclose(mainfile);
      mainfile = NULL;
   }
   free(fuse_options);
   fuse_options = NULL;
}

static int dynfilefs_release(const char *path, struct fuse_file_info *fi)
{
   return dynfilefs_flush(path, fi);
}

static int dynfilefs_truncate(const char *path, off_t size)
{
   if (size != virtual_size) return -EOPNOTSUPP;
   return dynfilefs_flush(path, NULL);
}

static int dynfilefs_chmod(const char *path, mode_t mode)
{
   return 0;
}

static int dynfilefs_chown(const char *path, uid_t uid, gid_t gid)
{
   return 0;
}


static struct fuse_operations dynfilefs_oper = {
	.getattr	= dynfilefs_getattr,
	.readdir	= dynfilefs_readdir,
	.open		= dynfilefs_open,
	.read		= dynfilefs_read,
	.write		= dynfilefs_write,
	.fsync		= dynfilefs_fsync,
	.flush		= dynfilefs_flush,
	.release	= dynfilefs_release,
	.destroy	= dynfilefs_destroy,
	.truncate	= dynfilefs_truncate,
	.chmod		= dynfilefs_chmod,
	.chown		= dynfilefs_chown,
};

static void usage(char * cmd)
{
       printf("\n");
       printf("%s\n", program_banner);
       printf("\n");
       printf("usage: %s -f storage_file -m mount_dir [ -s size_MB ] [ -p split_size_MB ] [ -d ]\n", cmd);
       printf("       %s -o[size=size_MB][split=split_size_MB] storage_file mount_dir\n", cmd);
       printf("\n");
       printf("This command mounts a virtual filesystem to [mount_dir], creating a virtual file [mount_dir]/virtual.dat\n");
       printf("with a specified size in MB [size_MB]. All modifications to this virtual.dat file are then stored to disk,\n");
       printf("to files with [storge_file] base name.\n");
       printf("\n");
       printf("Metadata related to the virtual.dat file is saved to the [storage_file] itself,\n");
       printf("while actual data modifications are stored in separate files with the same base name,\n");
       printf("each having incremented extension (e.g., .0, .1, .2), depending on the specified split_size.\n");
       printf("\n");
       printf("The following parameters can be provided:\n\n");
       printf("\n");
       printf("  -d                       - Debug mode; do not fork to background\n");
       printf("\n");
       printf("  --file [storage_file]\n");
       printf("  [storage_file]\n");
       printf("  -f [storage_file]        - Path to the file where changes to the virtual file will be stored.\n");
       printf("                           - The storage file is created with the provided name to store metadata,\n");
       printf("                             and then additional storage files are created with the same base name\n");
       printf("                             with extension suffixes such as .0, .1, .2, etc.\n");
       printf("                           - If the storage exists, it will be reused.\n");
       printf("\n");
       printf("  --mountdir [mount_dir]\n");
       printf("  [mount_dir]\n");
       printf("  -m [mount_dir]           - Specifies the directory where the filesystem will be mounted.\n");
       printf("                           - The directory must be empty, or the mount operation will be refused.\n");
       printf("\n");
       printf("  --size [size_MB]\n");
       printf("  -o size=[size_MB]\n");
       printf("  -s [size_MB]             - Sets the size of the virtual.dat file in MB.\n");
       printf("                           - If storage file exists, you can specify bigger size_MB than before,\n");
       printf("                             in that case the size of virtual file will be enlarged.\n");
       printf("                           - If the specified size_MB is smaller than before, it will be ignored\n");
       printf("                             and the previous stored value of size_MB will be reused.\n");
       printf("                           - If the size is specified as +size_MB (note the plus sign prefix),\n");
       printf("                             then the virtual file will grow by size_MB if storage_file exists.\n");
       printf("\n");
       printf("  --split [split_size_MB]\n");
       printf("  -o split=[split_size_MB]\n");
       printf("  -p [split_size_MB ]      - Sets the maximum data size per storage file. Multiple files\n");
       printf("                             will be created if [size_MB] > [split_size_MB].\n");
       printf("                             Beware that actual file size (including internal indexes) may be\n");
       printf("                             bigger than split_size_MB, so use max 4088 on FAT32 to be safe,\n");
       printf("                             because FAT32 does not support individual files bigger than 4GB.\n");
       printf("                           - This parameter is ignored if storage file exists,\n");
       printf("                             in that case the previous stored value is reused.\n");
       printf("\n");
       printf("Example usage:\n");
       printf("\n");
       printf("  # %s -f /var/lib/dynfilefs/changes.dat -s 1024 -m /mnt/dynfilefs\n", cmd);
       printf("  # mke2fs -F /mnt/virtual.dat\n");
       printf("  # mount -o loop /mnt/virtual.dat /mnt\n");
       printf("\n");
       printf("The [storage_file] has about 2 MB overhead for each 1GB of data (that is 0.2%%)\n");
       printf("\n");
}

static int parse_size_value(const char *value, off_t *result)
{
    char *end = NULL;
    intmax_t parsed;
    uintmax_t magnitude;
    off_t converted;

    errno = 0;
    parsed = strtoimax(value, &end, 10);
    if (errno == ERANGE || end == value || *end != '\0') return -1;
    magnitude = parsed < 0 ? (uintmax_t)(-(parsed + 1)) + 1 : (uintmax_t)parsed;
    converted = (off_t)magnitude;
    if (converted < 0 || (uintmax_t)converted != magnitude) return -1;
    *result = converted;
    return 0;
}

static int mb_to_bytes(off_t megabytes, off_t *bytes)
{
    uintmax_t product;
    off_t converted;

    if (megabytes < 0 || (uintmax_t)megabytes > UINTMAX_MAX / 1024 / 1024) return -1;
    product = (uintmax_t)megabytes * 1024 * 1024;
    converted = (off_t)product;
    if (converted < 0 || (uintmax_t)converted != product) return -1;
    *bytes = converted;
    return 0;
}

static int add_sizes(off_t left, off_t right, off_t *result)
{
    uintmax_t sum;
    off_t converted;

    if (left < 0 || right < 0 || (uintmax_t)left > UINTMAX_MAX - (uintmax_t)right) return -1;
    sum = (uintmax_t)left + (uintmax_t)right;
    converted = (off_t)sum;
    if (converted < 0 || (uintmax_t)converted != sum) return -1;
    *result = converted;
    return 0;
}

static void set_size_MB(const char * optarg){
    if (optarg[0] == '+') {
        optarg++;
        if (parse_size_value(optarg, &increase_size_MB) != 0) option_parse_error = 1;
        size_MB = increase_size_MB;
    } else {
        if (parse_size_value(optarg, &size_MB) != 0) option_parse_error = 1;
    }
}

static void set_split_size_MB(const char * optarg){
    if (parse_size_value(optarg, &split_size_MB) != 0) option_parse_error = 1;
}

static int append_fuse_option(const char *option)
{
    size_t current = fuse_options == NULL ? 0 : strlen(fuse_options);
    size_t length = strlen(option);
    char *updated;

    if (length == 0) return 0;
    if (current > SIZE_MAX - length - 2) return -1;
    updated = realloc(fuse_options, current + length + (current != 0) + 1);
    if (updated == NULL) return -1;
    fuse_options = updated;
    if (current != 0) fuse_options[current++] = ',';
    memcpy(fuse_options + current, option, length + 1);
    return 0;
}

static void set_options(const char *options)
{
    char *copy = strdup(options);
    char *state = NULL;
    char *option;

    if (copy == NULL) {
       option_parse_error = 1;
       return;
    }
    for (option = strtok_r(copy, ",", &state); option != NULL;
         option = strtok_r(NULL, ",", &state)) {
       if (strncmp(option, "size=", 5) == 0)
          set_size_MB(option + 5);
       else if (strncmp(option, "split=", 6) == 0)
          set_split_size_MB(option + 6);
       else if (append_fuse_option(option) != 0)
          option_parse_error = 1;
    }
    free(copy);
}

int main(int argc, char *argv[])
{
    int argument_index = 0;
    int previous_max_files = 0;
    bool main_created = false;
    bool main_needs_update = false;
    struct metaStruct updated_main_meta = {};
    char ** argvb = argv;
    int argcb = argc;
    while (1)
    {
       int option_index = 0;
       static struct option long_options[] = {
           {"options",      required_argument, 0, 'o'},
           {"file",         required_argument, 0, 'f' },
           {"mountdir",     required_argument, 0, 'm' },
           {"size",         required_argument, 0, 's' },
           {"split",        required_argument, 0, 'p' },
           {"debug",        no_argument,       0, 'd' },
           {0,              0,                 0,  0 }
       };

       int c = getopt_long(argcb, argvb, "f:o:m:s:p:d",long_options, &option_index);

       if (c == -1){
           if (optind < argcb) {
               argument_index += 1;
               switch(argument_index){
                   case 1:
                       storage_file = argvb[optind];
                       break;
                   case 2:
                       mount_dir = argvb[optind];
                       break;
               }
               argcb -= optind;
               argvb += optind;
               optind = 0;
               continue;
           } else {
               break;
           }
       }

       switch (c)
       {
           case 'f':
               storage_file = optarg;
               break;

           case 'm':
               mount_dir = optarg;
               break;
            case 'o': {
                set_options(optarg);
                break;
            };
           case 's':
               set_size_MB(optarg);
               break;

           case 'p':
               set_split_size_MB(optarg);
               break;

           case 'd':
               debug = 1;
           default:
               break;
        }
    }

    if (option_parse_error)
    {
       printf("Invalid size or split option. Values must be whole megabytes in range.\n");
       return 1;
    }
    if (!strcmp(storage_file,"")) { usage(argv[0]); return 1; }

    if (mb_to_bytes(size_MB, &virtual_size) != 0 ||
        mb_to_bytes(split_size_MB, &split_size) != 0)
    {
       printf("Requested size is too large.\n");
       return 1;
    }
    if (split_size <= 0) split_size = virtual_size;

    // open main file when it exists
    mainfile = open_storage(storage_file, true, &main_created);
    if (mainfile == NULL)
    {
       printf("cannot open %s: %s\n", storage_file, strerror(errno));
       return 1;
    }
    if (lock_storage(mainfile) != 0)
    {
       printf("storage file %s is already in use\n", storage_file);
       return 1;
    }
    if (!main_created)
    {
       struct stat main_stat;
       if (fstat(fileno(mainfile), &main_stat) != 0)
       {
          printf("cannot inspect %s: %s\n", storage_file, strerror(errno));
          return 1;
       }
       if (main_stat.st_size == 0) main_created = true;
    }
    if (!main_created)
    {
       struct metaStruct meta = {};

       // check version and other parameters
        if (read_metadata(mainfile, &meta) != 0)
        {
           printf("cannot read header metadata from file %s\n", storage_file);
           return 1;
       }
       if (meta.version != format_version)
       {
          printf("The existing storage file %s is using incompatible data format version %lli. Current version is %lli. This is an error.\n", storage_file, (long long)meta.version, (long long)format_version);
          return 1;
       }

         if (meta.split_size < DATA_BLOCK_SIZE ||
             meta.split_size % DATA_BLOCK_SIZE != 0 ||
             meta.virtual_size <= 0 || meta.virtual_size % DATA_BLOCK_SIZE != 0)
        {
           printf("The existing storage file %s contains invalid size metadata.\n", storage_file);
           return 1;
        }
        split_size=meta.split_size;
        if (calculate_file_count(meta.virtual_size, split_size, &previous_max_files) != 0)
        {
           printf("The existing storage file %s contains invalid segment metadata.\n", storage_file);
           return 1;
        }
        if (increase_size_MB > 0)
        {
           off_t increase_size;
           if (mb_to_bytes(increase_size_MB, &increase_size) != 0 ||
               add_sizes(meta.virtual_size, increase_size, &virtual_size) != 0)
           {
              printf("Requested size increase is too large.\n");
              return 1;
           }
        }
       if (virtual_size<=meta.virtual_size) virtual_size=meta.virtual_size;

       // if virtual size was changed, write it to main file
       if (meta.virtual_size!=virtual_size)
       {
          meta.virtual_size=virtual_size;
          updated_main_meta = meta;
          main_needs_update = true;
       }
    }
    else // new or interrupted initial creation
    {
       if (virtual_size <= 0) { printf("You must provide virtual file size for new storage file.\n"); return 1; }
    }

    if (calculate_file_count(virtual_size, split_size, &max_files) != 0)
    {
       printf("Your settings would result in more than %i storage files. Quit\n", MAX_SPLIT_FILES);
       return 1;
    }
    offset_block_size = split_size / DATA_BLOCK_SIZE * sizeof(off_t);

    if ((uintmax_t)(header_size + offset_block_size) > SIZE_MAX)
    {
       printf("Requested split size needs an index larger than this system can map.\n");
       return 1;
    }

    char storage_file_path[4096];

    for (int i=0; i<max_files; i++)
    {
       memset(storage_file_path,0,sizeof(storage_file_path));
        if (segment_path(storage_file_path, sizeof(storage_file_path), storage_file, i) != 0)
        {
           printf("storage file path is too long\n");
           return 1;
        }

       // Missing committed segments indicate storage loss. Only initial
       // creation and newly added resize segments may create files.
       bool segment_created = false;
       bool allow_create = main_created || i >= previous_max_files;
       files[i] = open_storage(storage_file_path, allow_create, &segment_created);
       if (files[i] == NULL)
       {
          printf("cannot open storage segment %s: %s\n", storage_file_path, strerror(errno));
          return 1;
       }
       if (!segment_created)
       {
          struct metaStruct meta = {};

          // check version and other parameters
           if (read_metadata(files[i], &meta) != 0)
          {
             printf("cannot read header metadata from file %s\n", storage_file_path);
             return 1;
          }
          if (meta.version != format_version)
          {
             printf("The existing storage file %s is using incompatible data format version %lli. Current version is %lli. This is an error.\n", storage_file_path, (long long)meta.version, (long long)format_version);
             return 1;
          }

          if (meta.split_size!=split_size)
          {
             printf("The existing storage file %s was created using split size of %lli. But you requested split size of %lli. This is an error. Use the same split size.\n", storage_file_path, (long long)meta.split_size/1024/1024, (long long)split_size/1024/1024);
             return 1;
          }

          if (meta.virtual_size!=virtual_size)
          {
             meta.virtual_size=virtual_size;
              if (write_metadata(files[i], &meta) != 0)
             {
                printf("cannot update header metadata for new virtual size in file %s\n", storage_file_path);
                return 1;
             }
          }

          // calculate new last_block_offsets after index of offsets
           if (fseeko(files[i], 0, SEEK_END) != 0)
           {
              printf("cannot seek to end of storage file %s\n", storage_file_path);
              return 1;
           }
            last_block_offsets[i] = recover_last_block_offset(
               ftello(files[i]), header_size + offset_block_size);
       }
       else // initialize a new segment
       {
          if (virtual_size <= 0) { printf("You must provide virtual file size for new storage file.\n"); return 1; }

          // write full header (empty)
           if (fwrite(header,sizeof(header),1,files[i]) != 1)
           {
              printf("cannot write header to %s\n", storage_file_path);
              return 1;
           }

          // write banner to header
           if (fseeko(files[i], 0, SEEK_SET) != 0 ||
               fwrite(format_banner, strlen(format_banner), 1, files[i]) != 1)
           {
              printf("cannot write banner to %s\n", storage_file_path);
              return 1;
           }

          // write version to header
          struct metaStruct meta = {version: format_version, split_size: split_size, virtual_size: virtual_size};
           if (write_metadata(files[i], &meta) != 0)
          {
             printf("cannot write to %s\n", storage_file_path);
             return 1;
          }

           last_block_offsets[i] = header_size + offset_block_size;
           if (fseeko(files[i],last_block_offsets[i] - 1, SEEK_SET) != 0 ||
               fwrite("\0",1,1,files[i]) != 1 || fflush(files[i]) != 0)
           {
              printf("cannot initialize index in %s\n", storage_file_path);
              return 1;
           }
        }

        if (map_index(files[i], header_size + offset_block_size, &indexes[i]) != 0)
        {
           printf("cannot map index from %s: %s\n", storage_file_path, strerror(errno));
           return 1;
        }
        if (validate_index(i) != 0)
        {
           printf("storage segment %s contains an invalid block index\n", storage_file_path);
           return 1;
        }
    }

    // During growth, commit the authoritative main metadata only after all
    // required segments have been created and validated.
    if (main_created)
    {
       struct metaStruct meta = {version: format_version, split_size: split_size, virtual_size: virtual_size};
       if (fseeko(mainfile, 0, SEEK_SET) != 0 ||
           fwrite(header, sizeof(header), 1, mainfile) != 1 ||
           fseeko(mainfile, 0, SEEK_SET) != 0 ||
           fwrite(format_banner, strlen(format_banner), 1, mainfile) != 1 ||
           write_metadata(mainfile, &meta) != 0)
       {
          printf("cannot initialize main metadata file %s\n", storage_file);
          return 1;
       }
    }
    if (main_needs_update && write_metadata(mainfile, &updated_main_meta) != 0)
    {
       printf("cannot update header metadata for new virtual size in file %s\n", storage_file);
       return 1;
    }
    if (futimens(fileno(mainfile), NULL) != 0)
    {
       printf("cannot update storage timestamps: %s\n", strerror(errno));
       return 1;
    }
    if (dynfilefs_fsync(dynfilefs_path, 0, NULL) != 0)
    {
       printf("cannot synchronize storage files: %s\n", strerror(errno));
       return 1;
    }
    if ((main_created || max_files > previous_max_files) && sync_parent_directory(storage_file) != 0)
    {
       printf("cannot synchronize storage directory: %s\n", strerror(errno));
       return 1;
    }

    // The following line ensures that the process is not killed by systemd
    // on shutdown, it is necessary to keep process running if root filesystem
    // is mounted using dynfilefs. Proper end of the process is umount, not kill.
    argv[0][0] = '@';

    // Pass frontend options through while consuming dynfilefs-specific options.
    char *fuse_argv[6] = {argv[0], mount_dir, NULL, NULL, NULL, NULL};
    int fuse_argc = 2;

    if (fuse_options != NULL)
    {
       fuse_argv[fuse_argc++] = "-o";
       fuse_argv[fuse_argc++] = fuse_options;
    }

    if (debug) // or maybe two parameters, debug
    {
       fuse_argv[fuse_argc++] = "-d";
    }

    return fuse_main(fuse_argc, fuse_argv, &dynfilefs_oper, NULL);
}

# dynfilefs

`dynfilefs` exposes dynamically allocated block storage as a regular file through
FUSE2. The resulting `virtual.dat` can be used with loop devices, filesystem
tools, and disk-image utilities.

This project is a compatibility-focused fork of
[DynFileFS](https://github.com/Tomas-M/dynfilefs). It uses the upstream version
number and preserves the DynFileFS format 400 on-disk layout. The inherited
on-disk banner is intentionally unchanged so existing storage remains readable
and writable by both dynfilefs and DynFileFS 4.04.

The commands are `dynfilefs` and `mount.dynfilefs`. The `dynblk` command is
reserved for the independent [kernel block-device project](https://github.com/minios-linux/dynblk);
this FUSE package installs no `dynblk` or `mount.dynblk` aliases.

The format-400 on-disk banner and existing data remain unchanged. Debian package
relationships replace only the published FUSE `dynblk` versions 4.5.0-1 and
4.5.1-1; they do not conflict with the new format-1 snapshot packages.
Historical tags and release assets retain their original names.

## Requirements

- Linux with FUSE2 support
- `libfuse2` for native dynamically linked builds
- A loop-capable kernel when `virtual.dat` is mounted as a block image

Release Debian packages are native amd64 builds produced in an Ubuntu 18.04
environment and use the system FUSE2 library. Static release binaries are
i686/musl builds intended for initrd use; running them on amd64 requires kernel
IA32 emulation. Static builds are smoke-tested in an Ubuntu 18.04 userland with
the stock 4.15 kernel baseline.

## Usage

```text
dynfilefs -f storage_file -m mount_dir [-s size_MB] [-p split_size_MB] [-d]
```

- `-f`, `--file`: base path for metadata and storage segments.
- `-m`, `--mountdir`: empty directory where FUSE exposes `virtual.dat`.
- `-s`, `--size`: virtual image size in MB. A larger value grows existing
  storage; a `+` prefix grows it by the specified amount.
- `-p`, `--split`: maximum data size in MB per storage segment.
- `-d`: run in the foreground with debug output.
- `-o size=N,split=N`: mount-helper form of the size and split options.

Example:

```sh
sudo install -d /var/lib/dynfilefs /mnt/dynfilefs /mnt/image
sudo dynfilefs -f /var/lib/dynfilefs/changes.dat -s 1024 -m /mnt/dynfilefs
sudo mke2fs -F /mnt/dynfilefs/virtual.dat
sudo mount -o loop /mnt/dynfilefs/virtual.dat /mnt/image
```

Example `/etc/fstab` entries:

```fstab
/var/lib/dynfilefs/changes.dat /mnt/dynfilefs dynfilefs size=1024,split=1000 0 0
/mnt/dynfilefs/virtual.dat /mnt/image auto loop 0 0
```

## Build

```sh
./autogen.sh
./configure
make -j"$(nproc)"
make check
```

Build a native Debian package with:

```sh
dpkg-buildpackage -b -us -uc
```

Reproducible static i686/musl build instructions are in
[`buildroot/README.md`](buildroot/README.md). Static binaries are not stored in
the source repository; verified binaries and checksums are published with
[GitHub releases](https://github.com/minios-linux/dynfilefs/releases).

## License

dynfilefs is distributed under the GNU General Public License, version 2 or later.
See [`LICENSE`](LICENSE). Original DynFileFS authorship is retained in the
source and on-disk compatibility banner.

include $(sort $(wildcard $(BR2_EXTERNAL_DYNFILEFS_PATH)/package/*/*.mk))

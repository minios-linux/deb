################################################################################
#
# dynfilefs
#
################################################################################

DYNFILEFS_VERSION = 4.5.1
DYNFILEFS_SITE = $(BR2_EXTERNAL_DYNFILEFS_PATH)/..
DYNFILEFS_SITE_METHOD = local
DYNFILEFS_LICENSE = GPL-2.0+
DYNFILEFS_LICENSE_FILES = LICENSE
DYNFILEFS_DEPENDENCIES = libfuse
DYNFILEFS_AUTORECONF = YES
DYNFILEFS_CONF_ENV = LDFLAGS="$(TARGET_LDFLAGS) -static"

$(eval $(autotools-package))

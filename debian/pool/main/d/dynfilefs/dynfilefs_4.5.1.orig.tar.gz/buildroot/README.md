# Static build

Release binaries are static i686/musl executables built with Buildroot
2025.02.16. The external tree builds the current checkout directly; it does
not download an unpinned branch or masquerade as another package.

```sh
curl -fLO https://buildroot.org/downloads/buildroot-2025.02.16.tar.gz
printf '%s  %s\n' \
  9dbc803fe020926cb1518c149466709576d19b94d4f806d8eb7ff354f3f16414 \
  buildroot-2025.02.16.tar.gz | sha256sum -c -
tar -xzf buildroot-2025.02.16.tar.gz
cd buildroot-2025.02.16
patch -p1 < /path/to/dynfilefs/buildroot/0001-libfuse-enable-static-build.patch
make BR2_EXTERNAL=/path/to/dynfilefs/buildroot dynfilefs_defconfig
make
```

The resulting executable is
`output/target/usr/sbin/dynfilefs`. Validate that the deliverable is static and
not UPX-packed:

```sh
file output/target/usr/sbin/dynfilefs
readelf -l output/target/usr/sbin/dynfilefs
strings output/target/usr/sbin/dynfilefs | grep -q UPX && exit 1 || true
```

Static binaries are not stored in the source repository. Tag builds publish
the verified executable and its checksum as GitHub release assets.

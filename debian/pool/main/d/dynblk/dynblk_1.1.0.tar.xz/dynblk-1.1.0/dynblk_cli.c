// SPDX-License-Identifier: GPL-2.0-or-later
#define _GNU_SOURCE
#include "dynblk_check.h"
#include "dynblk_common.h"
#include "dynblk_uapi.h"

#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define CONTROL "/dev/dynblk-control"
#define DEVICE_PREFIX "/dev/dynblk"
#define DEFAULT_SIZE (16ULL << 30)
#define DEFAULT_PART_SIZE (4000ULL << 20)
#define MIN_PART_SIZE (1ULL << 20)

static int error_message(const char *message)
{
	fprintf(stderr, "dynblk: %s\n", message);
	return 1;
}
static int system_error(const char *context)
{
	char message[512];
	snprintf(message, sizeof(message), "%s: %s", context, strerror(errno));
	return error_message(message);
}

static void usage(FILE *stream)
{
	fputs("Usage:\n"
	      "  dynblk create PATH [--size SIZE] [--compression CODEC] [--part-size SIZE] [--map-memory-mb N] [--module FILE] [--execute]\n"
	      "  dynblk load PATH [--map-memory-mb N] [--module FILE] [--execute]\n"
	      "  dynblk status /dev/dynblkN [--json]\n"
	      "  dynblk grow /dev/dynblkN SIZE [--execute]\n"
	      "  dynblk unload /dev/dynblkN [--execute]\n"
	      "  dynblk inspect PATH --metadata-only [--json]\n"
	      "  dynblk check PATH [--json]\n"
	      "\n--map-memory-mb overrides the automatic mapping budget (~25% of RAM after 64-MiB low-memory normalization; max 4096 MiB).\n"
	      "Device management only: no mkfs, mount, fsck or filesystem resize.\n",
	      stream);
}

static bool help_arg(const char *arg)
{
	return !strcmp(arg, "-h") || !strcmp(arg, "--help");
}

static int parse_error(const char *message)
{
	if (message)
		fprintf(stderr, "dynblk: %s\n", message);
	usage(stderr);
	return 2;
}
static void json_string(const char *text)
{
	const unsigned char *p = (const unsigned char *)text;
	putchar('"');
	for (; *p; p++) {
		switch (*p) {
		case '"': fputs("\\\"", stdout); break;
		case '\\': fputs("\\\\", stdout); break;
		case '\b': fputs("\\b", stdout); break;
		case '\f': fputs("\\f", stdout); break;
		case '\n': fputs("\\n", stdout); break;
		case '\r': fputs("\\r", stdout); break;
		case '\t': fputs("\\t", stdout); break;
		default:
			if (*p < 0x20)
				printf("\\u%04x", *p);
			else
				putchar(*p);
		}
	}
	putchar('"');
}

static bool device_index(const char *path, unsigned int *index)
{
	const char *p;
	char *end;
	unsigned long value;

	if (!path || strncmp(path, DEVICE_PREFIX, strlen(DEVICE_PREFIX)))
		return false;
	p = path + strlen(DEVICE_PREFIX);
	if (!*p)
		return false;
	errno = 0;
	value = strtoul(p, &end, 10);
	if (errno || *end || value >= DYNBLK_MAX_DEVICES)
		return false;
	if (index)
		*index = (unsigned int)value;
	return true;
}

static bool module_loaded(void)
{
	struct stat st;
	return !lstat("/sys/module/dynblk", &st);
}
static int run_program_internal(char *const argv[], bool quiet)
{
	pid_t pid;
	int status;
	pid = fork();
	if (pid < 0)
		return system_error("fork");
	if (!pid) {
		if (quiet) {
			int nullfd = open("/dev/null", O_WRONLY | O_CLOEXEC);
			if (nullfd >= 0) {
				dup2(nullfd, STDERR_FILENO);
				close(nullfd);
			}
		}
		clearenv();
		setenv("PATH", "/usr/sbin:/usr/bin:/sbin:/bin", 1);
		setenv("LC_ALL", "C", 1);
		execvp(argv[0], argv);
		if (!quiet)
			perror(argv[0]);
		_exit(127);
	}
	if (waitpid(pid, &status, 0) < 0)
		return system_error("waitpid");
	if (!WIFEXITED(status) || WEXITSTATUS(status)) {
		char message[256];
		if (quiet)
			return 1;
		snprintf(message, sizeof(message), "%s failed%s%s", argv[0],
			 WIFEXITED(status) ? " with exit " : "",
			 WIFEXITED(status) ? "status" : "");
		return error_message(message);
	}
	return 0;
}

static int run_program(char *const argv[])
{
	return run_program_internal(argv, false);
}

static int read_status(const char *device, struct dynblk_status *status,
		       bool writable, int *fd_out)
{
	struct stat st;
	char context[320];
	int fd = open(device, (writable ? O_RDWR : O_RDONLY) |
			     O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
	if (fd < 0) {
		snprintf(context, sizeof(context), "open %s", device);
		return system_error(context);
	}
	if (fstat(fd, &st) || !S_ISBLK(st.st_mode)) {
		close(fd);
		return error_message("status requires a block device");
	}
	if (ioctl(fd, DYNBLK_GET, status)) {
		close(fd);
		return system_error("DYNBLK_GET");
	}
	if (fd_out)
		*fd_out = fd;
	else
		close(fd);
	return 0;
}

static int validate_status(struct dynblk_status *status, char codec[DYNBLK_CODEC_MAX])
{
	char error[256];
	_Static_assert(sizeof(struct dynblk_status) == 128, "dynblk status ABI");
	if (status->version != DYNBLK_ABI_VERSION || status->flags & ~1U ||
	    status->block_size != DYNBLK_BLOCK_SIZE || status->max_parts != DYNBLK_MAX_PARTS ||
	    status->tree_height != DYNBLK_TREE_HEIGHT ||
	    status->compression_region_bytes != DYNBLK_COMPRESSION_REGION ||
	    status->max_capacity != DYNBLK_MAX_CAPACITY ||
	    dynblk_codec_field(status->algorithm, codec, error, sizeof(error)))
		return error_message("unsupported dynblk status ABI");
	return 0;
}

static int ensure_module(const char *module)
{
	char *modprobe[] = { "modprobe", "dynblk", NULL };
	char *insmod[] = { "insmod", (char *)module, NULL };
	int ret;

	if (module_loaded())
		return 0;
	ret = run_program(module ? insmod : modprobe);
	if (ret)
		return ret;
	if (!module_loaded())
		return error_message("module loader returned success but dynblk is not loaded");
	return 0;
}

static void unload_module_if_new(bool loaded_before)
{
	char *command[] = { "rmmod", "dynblk", NULL };

	if (!loaded_before)
		run_program_internal(command, true);
}

static int open_control(void)
{
	struct stat st;
	unsigned int attempt;
	int fd = -1;

	for (attempt = 0; attempt < 20; attempt++) {
		fd = open(CONTROL, O_RDWR | O_NOFOLLOW | O_CLOEXEC);
		if (fd >= 0)
			break;
		if (errno != ENOENT && errno != ENODEV)
			break;
		usleep(50000);
	}
	if (fd < 0) {
		system_error("open /dev/dynblk-control");
		return -1;
	}
	if (fstat(fd, &st) || !S_ISCHR(st.st_mode)) {
		close(fd);
		error_message("/dev/dynblk-control is not a character device");
		return -1;
	}
	return fd;
}

static void print_status(const char *device, const struct dynblk_status *status,
			 const char *codec, bool json)
{
	char uuid[37];
	dynblk_uuid_string(status->uuid, uuid);
	if (json) {
		printf("{\"abi_version\":%u,\"active_parts\":%u,\"block_size\":%u,"
		       "\"capacity_bytes\":%" PRIu64 ",\"compression\":", status->version,
		       status->active_parts, status->block_size, (uint64_t)status->capacity);
		json_string(codec);
		printf(",\"compression_region_bytes\":%" PRIu64 ",\"device\":\"%s\","
		       "\"fenced\":%s,\"flags\":%u,\"generation\":%" PRIu64,
		       (uint64_t)status->compression_region_bytes, device,
		       status->flags & 1 ? "true" : "false", status->flags,
		       (uint64_t)status->generation);
		printf(",\"map_memory_bytes\":%" PRIu64 ",\"max_capacity_bytes\":%" PRIu64
		       ",\"max_parts\":%u,\"original_bytes\":%" PRIu64,
		       (uint64_t)status->map_memory_bytes, (uint64_t)status->max_capacity,
		       status->max_parts, (uint64_t)status->original_bytes);
		printf(",\"part_limit_bytes\":%" PRIu64 ",\"physical_bytes\":%" PRIu64
		       ",\"stored_bytes\":%" PRIu64 ",\"tree_height\":%u,\"uuid\":",
		       (uint64_t)status->part_limit, (uint64_t)status->physical_bytes,
		       (uint64_t)status->stored_bytes, status->tree_height);
		json_string(uuid);
		puts("}");
		return;
	}
	printf("abi_version: %u\nflags: %u\nuuid: %s\ncompression: %s\n"
	       "capacity_bytes: %" PRIu64 "\noriginal_bytes: %" PRIu64 "\n"
	       "stored_bytes: %" PRIu64 "\nphysical_bytes: %" PRIu64 "\n"
	       "generation: %" PRIu64 "\npart_limit_bytes: %" PRIu64 "\n"
	       "active_parts: %u\nblock_size: %u\nmax_parts: %u\ntree_height: %u\n"
	       "map_memory_bytes: %" PRIu64 "\nmax_capacity_bytes: %" PRIu64 "\n"
	       "compression_region_bytes: %" PRIu64 "\nfenced: %s\ndevice: %s\n",
	       status->version, status->flags, uuid, codec, (uint64_t)status->capacity,
	       (uint64_t)status->original_bytes, (uint64_t)status->stored_bytes,
	       (uint64_t)status->physical_bytes, (uint64_t)status->generation,
	       (uint64_t)status->part_limit, status->active_parts, status->block_size,
	       status->max_parts, status->tree_height, (uint64_t)status->map_memory_bytes,
	       (uint64_t)status->max_capacity, (uint64_t)status->compression_region_bytes,
	       status->flags & 1 ? "true" : "false", device);
}

static int command_status(int argc, char **argv)
{
	struct dynblk_status status;
	char codec[DYNBLK_CODEC_MAX];
	bool json = false;

	if (argc == 2 && !strcmp(argv[1], "--json"))
		json = true;
	else if (argc != 1)
		return parse_error("invalid status arguments");
	if (!device_index(argv[0], NULL))
		return parse_error("status requires /dev/dynblkN");
	if (read_status(argv[0], &status, false, NULL) || validate_status(&status, codec))
		return 1;
	print_status(argv[0], &status, codec, json);
	return 0;
}
static void print_inspection(const struct dynblk_inspection *r, bool json)
{
	char uuid[37];
	dynblk_uuid_string(r->uuid, uuid);
	if (json) {
		printf("{\"active_parts\":%u,\"capacity_bytes\":%" PRIu64 ",\"compression\":",
		       r->active_parts, r->capacity);
		json_string(r->compression);
		printf(",\"format\":1,\"fully_validated\":%s,\"generation\":%" PRIu64
		       ",\"incarnation\":%" PRIu64 ",\"mapped_blocks\":%" PRIu64,
		       r->fully_validated ? "true" : "false", r->generation,
		       r->incarnation, r->mapped_blocks);
		printf(",\"part_limit_bytes\":%" PRIu64 ",\"path\":", r->part_limit);
		json_string(r->path);
		printf(",\"physical_bytes\":%" PRIu64 ",\"present_parts\":%u,"
		       "\"primary_physical_bytes\":%" PRIu64 ",\"root_repair_needed\":%s,"
		       "\"tree_height\":4,\"tree_pages\":%u,\"uuid\":",
		       r->physical_bytes, r->present_parts, r->primary_bytes,
		       r->root_repair_needed ? "true" : "false", r->tree_pages);
		json_string(uuid);
		printf(",\"valid_root_copies\":%u", r->valid_roots);
		if (r->fully_validated) {
			printf(",\"validation\":\"passed\",\"validation_scope\":\"selected-live-state\","
			       "\"verified_blobs\":%" PRIu64 ",\"verified_live_bytes\":%" PRIu64
			       ",\"verified_mapping_count\":%" PRIu64 ",\"verified_stored_bytes\":%" PRIu64
			       ",\"verified_tree_pages\":%" PRIu64,
			       r->verified_blobs, r->verified_live_bytes, r->verified_mapping_count,
			       r->verified_stored_bytes, r->verified_tree_pages);
		} else {
			fputs(",\"inspection_scope\":\"headers-roots-part-geometry\","
			      "\"warning\":\"Tree, transaction contents and payloads not validated; kernel load performs full validation.\"", stdout);
		}
		puts("}");
		return;
	}
	printf("path: %s\nformat: 1\nuuid: %s\ncompression: %s\n"
	       "part_limit_bytes: %" PRIu64 "\nprimary_physical_bytes: %" PRIu64
	       "\nincarnation: %" PRIu64 "\ncapacity_bytes: %" PRIu64
	       "\ngeneration: %" PRIu64 "\nmapped_blocks: %" PRIu64
	       "\ntree_pages: %u\ntree_height: 4\nactive_parts: %u\npresent_parts: %u\n"
	       "physical_bytes: %" PRIu64 "\nvalid_root_copies: %u\nroot_repair_needed: %s\n"
	       "fully_validated: %s\n",
	       r->path, uuid, r->compression, r->part_limit, r->primary_bytes,
	       r->incarnation, r->capacity, r->generation, r->mapped_blocks,
	       r->tree_pages, r->active_parts, r->present_parts, r->physical_bytes,
	       r->valid_roots, r->root_repair_needed ? "true" : "false",
	       r->fully_validated ? "true" : "false");
	if (r->fully_validated)
		printf("validation: passed\nvalidation_scope: selected-live-state\n"
		       "verified_live_bytes: %" PRIu64 "\nverified_blobs: %" PRIu64
		       "\nverified_stored_bytes: %" PRIu64 "\nverified_tree_pages: %" PRIu64
		       "\nverified_mapping_count: %" PRIu64 "\n",
		       r->verified_live_bytes, r->verified_blobs, r->verified_stored_bytes,
		       r->verified_tree_pages, r->verified_mapping_count);
	else
		puts("inspection_scope: headers-roots-part-geometry\n"
		     "warning: Tree, transaction contents and payloads not validated; kernel load performs full validation.");
}

static int command_inspect(int argc, char **argv, bool full)
{
	struct dynblk_inspection result;
	char error[512];
	bool json = false, metadata = false;
	int i;
	if (argc < 1)
		return parse_error("missing volume path");
	for (i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--json")) json = true;
		else if (!strcmp(argv[i], "--metadata-only")) metadata = true;
		else return parse_error("invalid inspect/check option");
	}
	if ((!full && !metadata) || (full && metadata))
		return parse_error(full ? "check does not accept --metadata-only" :
				   "inspect requires --metadata-only");
	if (dynblk_inspect_volume(argv[0], full, &result, error, sizeof(error)))
		return error_message(error);
	print_inspection(&result, json);
	return 0;
}
static int volume_basename(const char *path, char directory[4096])
{
	const char *slash = strrchr(path, '/');
	size_t length;
	if (!slash || strcmp(slash + 1, "volume000.db"))
		return error_message("volume path must end in volume000.db");
	length = (size_t)(slash - path);
	if (!length)
		length = 1;
	if (length >= 4096)
		return error_message("volume path too long");
	memcpy(directory, path, length);
	directory[length] = 0;
	return 0;
}

static int validate_volume_path(const char *path, bool create)
{
	char error[512], directory[4096], sibling[4096];
	struct stat st;
	unsigned int i;
	if (volume_basename(path, directory))
		return 1;
	if (dynblk_safe_path(path, create, error, sizeof(error)))
		return error_message(error);
	if (!create)
		return 0;
	for (i = 0; i < DYNBLK_MAX_PARTS; i++) {
		int length = snprintf(sibling, sizeof(sibling), "%s/volume%03u.db", directory, i);
		if (length < 0 || (size_t)length >= sizeof(sibling))
			return error_message("volume namespace path too long");
		if (!lstat(sibling, &st) || errno != ENOENT)
			return error_message("create requires an unused volume namespace; existing part preserved");
	}
	return 0;
}

static int validate_module(const char *path)
{
	char error[512];
	const char *base;
	if (!path)
		return 0;
	base = strrchr(path, '/');
	if (!base || strcmp(base + 1, "dynblk.ko"))
		return error_message("--module must name an existing dynblk.ko");
	if (dynblk_safe_path(path, false, error, sizeof(error)))
		return error_message(error);
	return 0;
}

static int parse_map_memory(const char *text, uint32_t *value)
{
	char *end;
	unsigned long parsed;

	errno = 0;
	parsed = strtoul(text, &end, 10);
	if (errno || !*text || *end || !parsed || parsed > DYNBLK_MAX_MAP_MEMORY_MB)
		return parse_error("--map-memory-mb must be an integer from 1 to 4096");
	*value = (uint32_t)parsed;
	return 0;
}

static int execute_attach(const char *path, const char *module, bool create,
			  uint64_t size, uint64_t part_size, const char *codec,
			  uint32_t map_memory_mb)
{
	struct dynblk_attach request = {
		.version = DYNBLK_ABI_VERSION,
		.flags = create ? DYNBLK_ATTACH_CREATE : 0,
		.device = -1,
		.map_memory_mb = map_memory_mb,
	};
	struct dynblk_detach detach = { .version = DYNBLK_ABI_VERSION };
	struct dynblk_status status;
	char device[64], actual_codec[DYNBLK_CODEC_MAX];
	bool loaded_before = module_loaded();
	int fd, result = 1;

	if (strlen(path) >= sizeof(request.path))
		return error_message("volume path is too long");
	memcpy(request.path, path, strlen(path) + 1);
	if (create) {
		request.size_bytes = size;
		request.part_limit_bytes = part_size;
		if (strlen(codec) >= sizeof(request.algorithm))
			return error_message("compression name is too long");
		memcpy(request.algorithm, codec, strlen(codec) + 1);
	}
	if (ensure_module(module))
		return 1;
	fd = open_control();
	if (fd < 0) {
		unload_module_if_new(loaded_before);
		return 1;
	}
	if (ioctl(fd, DYNBLK_ATTACH, &request)) {
		int saved = errno;
		close(fd);
		unload_module_if_new(loaded_before);
		errno = saved;
		return system_error("DYNBLK_ATTACH");
	}
	snprintf(device, sizeof(device), DEVICE_PREFIX "%d", request.device);
	if (read_status(device, &status, false, NULL) || validate_status(&status, actual_codec))
		goto rollback;
	if (create && (status.capacity != size || status.part_limit != part_size ||
		       strcmp(actual_codec, codec))) {
		error_message("attached device does not match requested create parameters");
		goto rollback;
	}
	close(fd);
	puts(device);
	return 0;

rollback:
	detach.device = (uint32_t)request.device;
	detach.cookie = request.cookie;
	if (ioctl(fd, DYNBLK_DETACH, &detach))
		system_error("rollback DYNBLK_DETACH");
	close(fd);
	unload_module_if_new(loaded_before);
	return result;
}

static int command_attach(int argc, char **argv, bool create)
{
	const char *path, *module = NULL, *codec = "none";
	uint64_t size = DEFAULT_SIZE, part_size = DEFAULT_PART_SIZE;
	uint32_t map_memory_mb = DYNBLK_DEFAULT_MAP_MEMORY_MB;
	bool execute = false;
	char error[256];
	int i;

	if (argc < 1)
		return parse_error("missing volume path");
	path = argv[0];
	for (i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--execute")) execute = true;
		else if (!strcmp(argv[i], "--module") && i + 1 < argc) module = argv[++i];
		else if (!strcmp(argv[i], "--map-memory-mb") && i + 1 < argc) {
			if (parse_map_memory(argv[++i], &map_memory_mb)) return 2;
		} else if (create && !strcmp(argv[i], "--size") && i + 1 < argc) {
			if (dynblk_parse_size(argv[++i], &size, error, sizeof(error))) return parse_error(error);
		} else if (create && !strcmp(argv[i], "--part-size") && i + 1 < argc) {
			if (dynblk_parse_size(argv[++i], &part_size, error, sizeof(error))) return parse_error(error);
		} else if (create && !strcmp(argv[i], "--compression") && i + 1 < argc) codec = argv[++i];
		else return parse_error(create ? "invalid create option" : "invalid load option");
	}
	if (validate_volume_path(path, create) || validate_module(module))
		return 1;
	if (create && !dynblk_codec_name(codec))
		return parse_error("unsupported create codec");
	if (create && (dynblk_aligned_size(size, DB_BLOCK, DYNBLK_MAX_CAPACITY, error, sizeof(error)) ||
			 dynblk_aligned_size(part_size, MIN_PART_SIZE, DEFAULT_PART_SIZE, error, sizeof(error))))
		return parse_error(error);
	if (execute && geteuid() != 0)
		return error_message("mutations require root and --execute");
	if (!execute) {
		char map_budget[32];

		if (map_memory_mb)
			snprintf(map_budget, sizeof(map_budget), "%u", map_memory_mb);
		else
			strcpy(map_budget, "auto");
		if (create)
			printf("DRY RUN: ensure dynblk module; DYNBLK_ATTACH path=\"%s\" create=1 size_bytes=%" PRIu64
			       " algorithm=%s part_limit_bytes=%" PRIu64 " map_memory_mb=%s; next free /dev/dynblkN\n",
			       path, size, codec, part_size, map_budget);
		else
			printf("DRY RUN: ensure dynblk module; DYNBLK_ATTACH path=\"%s\" map_memory_mb=%s; next free /dev/dynblkN\n",
			       path, map_budget);
		return 0;
	}
	return execute_attach(path, module, create, size, part_size, codec, map_memory_mb);
}

static int command_grow(int argc, char **argv)
{
	struct dynblk_status status;
	uint64_t size;
	bool execute = false;
	char error[256], codec[DYNBLK_CODEC_MAX];
	int fd;

	if (argc == 3 && !strcmp(argv[2], "--execute")) execute = true;
	else if (argc != 2) return parse_error("invalid grow arguments");
	if (!device_index(argv[0], NULL)) return parse_error("grow requires /dev/dynblkN");
	if (dynblk_parse_size(argv[1], &size, error, sizeof(error)) ||
	    dynblk_aligned_size(size, DB_BLOCK, DYNBLK_MAX_CAPACITY, error, sizeof(error)))
		return parse_error(error);
	if (!execute) {
		printf("DRY RUN: DYNBLK_GROW %s absolute capacity %" PRIu64
		       " bytes; no filesystem resize\n", argv[0], size);
		return 0;
	}
	if (geteuid() != 0) return error_message("mutations require root and --execute");
	fd = -1;
	if (read_status(argv[0], &status, true, &fd) || validate_status(&status, codec)) {
		if (fd >= 0) close(fd);
		return 1;
	}
	if (ioctl(fd, DYNBLK_GROW, &size)) {
		close(fd);
		return system_error("DYNBLK_GROW");
	}
	close(fd);
	return 0;
}

static int command_unload(int argc, char **argv)
{
	struct dynblk_detach request = { .version = DYNBLK_ABI_VERSION };
	struct dynblk_status status;
	char codec[DYNBLK_CODEC_MAX];
	uint64_t cookie = 0;
	bool execute = false;
	unsigned int index, attempt;
	int device_fd = -1, fd;

	if (argc == 2 && !strcmp(argv[1], "--execute")) execute = true;
	else if (argc != 1) return parse_error("invalid unload arguments");
	if (!device_index(argv[0], &index)) return parse_error("unload requires /dev/dynblkN");
	if (!execute) {
		printf("DRY RUN: DYNBLK_DETACH %s; no unmount or filesystem operations\n", argv[0]);
		return 0;
	}
	if (geteuid() != 0) return error_message("mutations require root and --execute");
	if (read_status(argv[0], &status, false, &device_fd) || validate_status(&status, codec)) {
		if (device_fd >= 0) close(device_fd);
		return 1;
	}
	if (ioctl(device_fd, DYNBLK_COOKIE, &cookie)) {
		int saved = errno;
		close(device_fd);
		errno = saved;
		return system_error("DYNBLK_COOKIE");
	}
	if (!cookie) {
		close(device_fd);
		return error_message("dynblk device returned an invalid attachment cookie");
	}
	close(device_fd);
	fd = open_control();
	if (fd < 0)
		return 1;
	request.device = index;
	request.cookie = cookie;
	for (attempt = 0; attempt < 10; attempt++) {
		if (!ioctl(fd, DYNBLK_DETACH, &request)) {
			close(fd);
			return 0;
		}
		if (errno != EBUSY)
			break;
		usleep(100000);
	}
	{
		int saved = errno;
		close(fd);
		errno = saved;
	}
	return system_error("DYNBLK_DETACH");
}

int main(int argc, char **argv)
{
	const char *command;
	if (argc == 2 && help_arg(argv[1])) {
		usage(stdout);
		return 0;
	}
	if (argc < 2)
		return parse_error("missing command");
	command = argv[1];
	if (argc >= 3 && help_arg(argv[2])) {
		usage(stdout);
		return 0;
	}
	if (!strcmp(command, "create"))
		return command_attach(argc - 2, argv + 2, true);
	if (!strcmp(command, "load"))
		return command_attach(argc - 2, argv + 2, false);
	if (!strcmp(command, "status"))
		return command_status(argc - 2, argv + 2);
	if (!strcmp(command, "grow"))
		return command_grow(argc - 2, argv + 2);
	if (!strcmp(command, "unload"))
		return command_unload(argc - 2, argv + 2);
	if (!strcmp(command, "inspect"))
		return command_inspect(argc - 2, argv + 2, false);
	if (!strcmp(command, "check"))
		return command_inspect(argc - 2, argv + 2, true);
	return parse_error("unknown command");
}

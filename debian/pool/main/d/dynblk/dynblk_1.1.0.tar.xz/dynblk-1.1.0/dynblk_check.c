// SPDX-License-Identifier: GPL-2.0-or-later
#define _GNU_SOURCE
#include "dynblk_check.h"
#include "dynblk_common.h"
#include "lzo/decompress.h"

#ifndef DYNBLK_NO_DYNAMIC_CODECS
#include <dlfcn.h>
#endif
#include <endian.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#ifndef DYNBLK_NO_DYNAMIC_CODECS
#include <zlib.h>
#endif

struct part_state {
	int fd;
	uint64_t length;
	uint16_t *refs;
	size_t refs_count;
	uint64_t *intervals;
	size_t interval_count, interval_capacity;
};

struct root_info {
	uint8_t raw[DB_BLOCK];
	uint64_t generation, capacity, mappings;
	uint32_t tree_pages;
	struct dynblk_pointer tree, transaction;
	uint64_t incarnations[DB_PARTS];
};
struct volume_state {
	struct part_state parts[DB_PARTS];
	uint8_t uuid[16];
	char algorithm[16];
	uint64_t limit;
	struct root_info selected;
	uint64_t *metadata;
	size_t metadata_slots, metadata_count;
	uint64_t used_parts;
};

struct mapping_value {
	uint64_t location, version;
	uint32_t length, stored_crc, original_crc, flags;
	uint32_t decoded_length, decoded_offset;
};

struct transaction_change {
	uint64_t logical;
	uint8_t raw[40];
	bool matched;
};

_Static_assert((DB_METADATA_SLOTS & (DB_METADATA_SLOTS - 1)) == 0,
	       "metadata hash table must be power-of-two sized");
_Static_assert(DB_METADATA_SLOTS >= 2U * (DB_MAX_NODES + 1U),
	       "metadata hash table must stay at or below 50 percent load");

static int fail(char *error, size_t size, const char *format, ...)
{
	va_list args;
	if (error && size) {
		va_start(args, format);
		vsnprintf(error, size, format, args);
		va_end(args);
	}
	return -1;
}

static uint32_t get32(const void *data)
{
	uint32_t value;
	memcpy(&value, data, sizeof(value));
	return le32toh(value);
}
static uint64_t get64(const void *data)
{
	uint64_t value;
	memcpy(&value, data, sizeof(value));
	return le64toh(value);
}

static bool zero_bytes(const uint8_t *data, size_t length)
{
	size_t i;
	for (i = 0; i < length; i++)
		if (data[i])
			return false;
	return true;
}

static uint32_t dynblk_crc32(const void *buffer, size_t length)
{
	static uint32_t table[256];
	static bool ready;
	const uint8_t *data = buffer;
	uint32_t crc = ~0U;
	size_t i;

	if (!ready) {
		uint32_t n;
		for (n = 0; n < 256; n++) {
			uint32_t value = n;
			unsigned bit;
			for (bit = 0; bit < 8; bit++)
				value = (value >> 1) ^ (0xedb88320U & (0U - (value & 1U)));
			table[n] = value;
		}
		ready = true;
	}
	for (i = 0; i < length; i++)
		crc = table[(crc ^ data[i]) & 0xffU] ^ (crc >> 8);
	return crc ^ ~0U;
}

static uint32_t page_crc(const uint8_t page[DB_BLOCK])
{
	return dynblk_crc32(page, DB_BLOCK - 4);
}

static bool uuid_zero(const uint8_t uuid[16])
{
	return zero_bytes(uuid, 16);
}

void dynblk_uuid_string(const uint8_t uuid[16], char out[37])
{
	snprintf(out, 37,
		 "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
		 uuid[0], uuid[1], uuid[2], uuid[3], uuid[4], uuid[5], uuid[6], uuid[7],
		 uuid[8], uuid[9], uuid[10], uuid[11], uuid[12], uuid[13], uuid[14], uuid[15]);
}

static struct dynblk_pointer read_pointer(const uint8_t *data)
{
	struct dynblk_pointer pointer = {
		.location = get64(data), .generation = get64(data + 8),
		.crc = get32(data + 16), .reserved = get32(data + 20)
	};
	return pointer;
}
static int pread_exact(int fd, void *buffer, size_t length, uint64_t offset,
		       char *error, size_t error_size)
{
	ssize_t got = pread(fd, buffer, length, (off_t)offset);
	if (got < 0)
		return fail(error, error_size, "read at %llu: %s",
			(unsigned long long)offset, strerror(errno));
	if ((size_t)got != length)
		return fail(error, error_size, "short read at %llu",
			(unsigned long long)offset);
	return 0;
}

static int read_page(int fd, uint64_t offset, uint8_t page[DB_BLOCK],
		     char *error, size_t error_size)
{
	if (pread_exact(fd, page, DB_BLOCK, offset, error, error_size))
		return -1;
	if (page_crc(page) != get32(page + DB_BLOCK - 4))
		return fail(error, error_size, "short metadata page or CRC mismatch at offset %llu",
			(unsigned long long)offset);
	return 0;
}

static int pointer_shape(const struct dynblk_pointer *pointer, uint64_t generation,
			 uint64_t limit, char *error, size_t error_size)
{
	uint32_t part = pointer->location >> 32;
	uint32_t offset = pointer->location;
	if (!pointer->location) {
		if (pointer->generation || pointer->crc || pointer->reserved)
			return fail(error, error_size, "malformed root metadata pointer");
		return 0;
	}
	if (pointer->reserved || !pointer->generation || pointer->generation > generation ||
	    part >= DB_PARTS || offset % DB_BLOCK ||
	    offset < (part ? DB_BLOCK : 3 * DB_BLOCK) || (uint64_t)offset + DB_BLOCK > limit)
		return fail(error, error_size, "malformed root metadata pointer");
	return 0;
}
static int parse_root(const uint8_t page[DB_BLOCK], const uint8_t uuid[16],
		      uint64_t incarnation, uint64_t limit, struct root_info *root,
		      char *error, size_t error_size)
{
	uint32_t i, height;
	memcpy(root->raw, page, DB_BLOCK);
	if (memcmp(page, "DBROOT01", 8) || memcmp(page + 8, uuid, 16))
		return fail(error, error_size, "checksum-valid malformed root");
	root->generation = get64(page + 24);
	root->capacity = get64(page + 32);
	root->tree = read_pointer(page + 40);
	root->transaction = read_pointer(page + 64);
	root->mappings = get64(page + 88);
	root->tree_pages = get32(page + 96);
	height = get32(page + 100);
	for (i = 0; i < DB_PARTS; i++)
		root->incarnations[i] = get64(page + 104 + i * 8);
	if (!root->generation || root->capacity < DB_BLOCK ||
	    root->capacity > (512ULL << 30) || root->capacity % DB_BLOCK ||
	    root->mappings > root->capacity / DB_BLOCK || root->tree_pages > DB_MAX_NODES ||
	    height != 4 || !!root->mappings != !!root->tree.location ||
	    !!root->tree_pages != !!root->tree.location || root->incarnations[0] != incarnation ||
	    !zero_bytes(page + 616, 3476))
		return fail(error, error_size, "checksum-valid malformed root");
	if (root->generation == 1 && (root->mappings || root->transaction.location))
		return fail(error, error_size, "checksum-valid malformed root");
	if (root->generation == 1)
		for (i = 1; i < DB_PARTS; i++)
			if (root->incarnations[i])
				return fail(error, error_size, "checksum-valid malformed root");
	if (root->generation > 1 &&
	    (!root->transaction.location || root->transaction.generation != root->generation))
		return fail(error, error_size, "checksum-valid malformed root");
	if (root->mappings && (root->tree_pages < 4 ||
	    root->tree_pages > root->mappings * 4 || root->tree_pages > DB_MAX_NODES))
		return fail(error, error_size, "checksum-valid malformed root");
	if (root->tree.location && root->tree.location == root->transaction.location)
		return fail(error, error_size, "checksum-valid malformed root");
	if (pointer_shape(&root->tree, root->generation, limit, error, error_size) ||
	    pointer_shape(&root->transaction, root->generation, limit, error, error_size))
		return -1;
	return 0;
}

static void close_volume(struct volume_state *volume)
{
	uint32_t i;
	for (i = 0; i < DB_PARTS; i++) {
		if (volume->parts[i].fd >= 0)
			close(volume->parts[i].fd);
		free(volume->parts[i].refs);
		free(volume->parts[i].intervals);
	}
	free(volume->metadata);
}

static int open_part(const char *path, struct part_state *part,
		     char *error, size_t error_size)
{
	struct stat st;
	part->fd = open(path, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC | O_NOATIME);
	if (part->fd < 0)
		return fail(error, error_size, "%s: %s", path, strerror(errno));
	if (fstat(part->fd, &st) || !S_ISREG(st.st_mode) || st.st_nlink != 1 ||
	    st.st_uid != 0 || (st.st_mode & 0022))
		return fail(error, error_size, "unsafe backing file: %s", path);
	if (flock(part->fd, LOCK_SH | LOCK_NB))
		return fail(error, error_size, "backing file lock unavailable: %s", path);
	part->length = (uint64_t)st.st_size;
	return 0;
}
static int header_fields(const uint8_t page[DB_BLOCK], uint32_t expected_part,
			 const uint8_t uuid[16], uint64_t limit, const uint8_t algorithm[16],
			 uint64_t *incarnation, char *error, size_t error_size)
{
	if (memcmp(page, "DBPART01", 8) || memcmp(page + 8, uuid, 16) ||
	    !get64(page + 24) || get32(page + 32) != expected_part || get32(page + 36) != 1 ||
	    get64(page + 40) != limit || memcmp(page + 48, algorithm, 16) ||
	    !zero_bytes(page + 64, 4028))
		return fail(error, error_size, "invalid sibling header, incarnation or geometry: part %u",
			expected_part);
	*incarnation = get64(page + 24);
	return 0;
}

static int root_actual_extent(const struct volume_state *volume,
			      const struct dynblk_pointer *pointer,
			      char *error, size_t error_size)
{
	uint32_t part, offset;
	if (!pointer->location)
		return 0;
	part = pointer->location >> 32;
	offset = pointer->location;
	if (!volume->selected.incarnations[part] || volume->parts[part].fd < 0 ||
	    (uint64_t)offset + DB_BLOCK > volume->parts[part].length)
		return fail(error, error_size, "root pointer outside active part geometry");
	return 0;
}

static int open_volume(const char *path, struct volume_state *volume,
		       struct dynblk_inspection *result, char *error, size_t error_size)
{
	uint8_t page[DB_BLOCK], algorithm_field[16];
	struct root_info roots[2];
	bool valid[2] = { false, false };
	const char *base;
	char sibling[4096];
	uint64_t incarnation;
	uint32_t i, valid_count = 0;
	ssize_t got;
	memset(volume, 0, sizeof(*volume));
	for (i = 0; i < DB_PARTS; i++)
		volume->parts[i].fd = -1;
	base = strrchr(path, '/');
	if (!base || strcmp(base + 1, "volume000.db"))
		return fail(error, error_size, "volume path must end in volume000.db");
	if (dynblk_safe_path(path, false, error, error_size) ||
	    open_part(path, &volume->parts[0], error, error_size))
		return -1;
	if (read_page(volume->parts[0].fd, 0, page, error, error_size))
		return -1;
	if (memcmp(page, "DBPART01", 8) || get32(page + 36) != 1 || get32(page + 32) ||
	    !get64(page + 24) || uuid_zero(page + 8) || !zero_bytes(page + 64, 4028))
		return fail(error, error_size, "unsupported or malformed self-contained part header");
	memcpy(volume->uuid, page + 8, 16);
	incarnation = get64(page + 24);
	volume->limit = get64(page + 40);
	memcpy(algorithm_field, page + 48, 16);
	if (dynblk_aligned_size(volume->limit, DB_MIN_PART_LIMIT, DB_DEFAULT_PART_LIMIT,
				error, error_size) ||
	    dynblk_codec_field(algorithm_field, volume->algorithm, error, error_size))
		return -1;
	if (volume->parts[0].length < DB_BLOCK || volume->parts[0].length > volume->limit)
		return fail(error, error_size, "invalid primary part length");
	for (i = 0; i < 2; i++) {
		got = pread(volume->parts[0].fd, page, DB_BLOCK, (off_t)((i + 1) * DB_BLOCK));
		if (got < 0)
			return fail(error, error_size, "root read: %s", strerror(errno));
		if (got != DB_BLOCK || page_crc(page) != get32(page + DB_BLOCK - 4))
			continue;
		if (parse_root(page, volume->uuid, incarnation, volume->limit,
			       &roots[i], error, error_size))
			return -1;
		valid[i] = true;
		valid_count++;
	}
	if (!valid_count)
		return fail(error, error_size, "no checksum-valid root");
	if (valid[0] && valid[1]) {
		uint64_t a = roots[0].generation, b = roots[1].generation;
		if ((a == b && memcmp(roots[0].raw, roots[1].raw, DB_BLOCK)) ||
		    (a > b ? a - b : b - a) > 1)
			return fail(error, error_size, "inconsistent root generations or contents");
	}
	if (valid[1] && (!valid[0] || roots[1].generation > roots[0].generation))
		volume->selected = roots[1];
	else
		volume->selected = roots[0];
	for (i = 1; i < DB_PARTS; i++) {
		struct stat st;
		uint8_t sibling_page[DB_BLOCK];
		uint64_t sibling_incarnation = 0;
		int length = snprintf(sibling, sizeof(sibling), "%.*s/volume%03u.db",
			(int)(base - path), path, i);
		if (length < 0 || (size_t)length >= sizeof(sibling))
			return fail(error, error_size, "sibling path too long");
		if (lstat(sibling, &st)) {
			if (errno == ENOENT) {
				if (volume->selected.incarnations[i])
					return fail(error, error_size, "missing active part %u", i);
				continue;
			}
			return fail(error, error_size, "%s: %s", sibling, strerror(errno));
		}
		if (dynblk_safe_path(sibling, false, error, error_size) ||
		    open_part(sibling, &volume->parts[i], error, error_size) ||
		    read_page(volume->parts[i].fd, 0, sibling_page, error, error_size) ||
		    header_fields(sibling_page, i, volume->uuid, volume->limit, algorithm_field,
				  &sibling_incarnation, error, error_size))
			return -1;
		if ((volume->selected.incarnations[i] &&
		     sibling_incarnation != volume->selected.incarnations[i]) ||
		    volume->parts[i].length < DB_BLOCK || volume->parts[i].length > volume->limit)
			return fail(error, error_size,
				"invalid sibling header, incarnation or geometry: part %u", i);
	}
	if (root_actual_extent(volume, &volume->selected.tree, error, error_size) ||
	    root_actual_extent(volume, &volume->selected.transaction, error, error_size))
		return -1;
	memset(result, 0, sizeof(*result));
	if (strlen(path) >= sizeof(result->path))
		return fail(error, error_size, "volume path too long");
	strcpy(result->path, path);
	memcpy(result->uuid, volume->uuid, 16);
	strcpy(result->compression, volume->algorithm);
	result->part_limit = volume->limit;
	result->primary_bytes = volume->parts[0].length;
	result->incarnation = incarnation;
	result->capacity = volume->selected.capacity;
	result->generation = volume->selected.generation;
	result->mapped_blocks = volume->selected.mappings;
	result->tree_pages = volume->selected.tree_pages;
	result->valid_roots = valid_count;
	result->root_repair_needed = valid_count != 2 ||
		(valid[0] && valid[1] && memcmp(roots[0].raw, roots[1].raw, DB_BLOCK));
	for (i = 0; i < DB_PARTS; i++) {
		if (volume->selected.incarnations[i])
			result->active_parts++;
		if (volume->parts[i].fd >= 0) {
			result->present_parts++;
			result->physical_bytes += volume->parts[i].length;
		}
	}
	return 0;
}

static struct mapping_value read_value(const uint8_t raw[40])
{
	struct mapping_value value = {
		.location = get64(raw), .version = get64(raw + 8),
		.length = get32(raw + 16), .stored_crc = get32(raw + 20),
		.original_crc = get32(raw + 24), .flags = get32(raw + 28),
		.decoded_length = get32(raw + 32), .decoded_offset = get32(raw + 36)
	};
	return value;
}
static int prepare_full(struct volume_state *volume, char *error, size_t error_size)
{
	uint32_t i;
	volume->metadata_slots = DB_METADATA_SLOTS;
	volume->metadata = calloc(volume->metadata_slots, sizeof(*volume->metadata));
	if (!volume->metadata)
		return fail(error, error_size, "cannot complete validation: memory exhausted");
	volume->used_parts = 1;
	for (i = 0; i < DB_PARTS; i++) {
		struct part_state *part = &volume->parts[i];
		size_t fixed, page;
		if (!volume->selected.incarnations[i])
			continue;
		if (part->fd < 0)
			return fail(error, error_size, "missing active part %u", i);
		part->refs_count = (part->length + DB_BLOCK - 1) / DB_BLOCK;
		part->refs = calloc(part->refs_count, sizeof(*part->refs));
		if (!part->refs)
			return fail(error, error_size, "cannot complete validation: memory exhausted");
		fixed = i ? 1 : 3;
		if (fixed > part->refs_count)
			fixed = part->refs_count;
		for (page = 0; page < fixed; page++)
			part->refs[page] = UINT16_MAX;
	}
	return 0;
}

static int extent(struct volume_state *volume, uint64_t location, uint32_t length,
		  uint32_t *part_number, uint32_t *offset, char *error, size_t error_size)
{
	uint32_t part = location >> 32, start = location;
	if (!location || part >= DB_PARTS || !volume->selected.incarnations[part] ||
	    volume->parts[part].fd < 0 || !length || length > DB_REGION ||
	    start < (part ? DB_BLOCK : 3 * DB_BLOCK) ||
	    (uint64_t)start + length > volume->limit ||
	    (uint64_t)start + length > volume->parts[part].length)
		return fail(error, error_size, "reference outside active part extent");
	volume->used_parts |= 1ULL << part;
	*part_number = part;
	*offset = start;
	return 0;
}
static size_t hash_location(uint64_t value, size_t mask)
{
	value ^= value >> 33;
	value *= 0xff51afd7ed558ccdULL;
	value ^= value >> 33;
	return (size_t)value & mask;
}

static int metadata_insert(struct volume_state *volume, uint64_t location,
			   char *error, size_t error_size)
{
	size_t mask = volume->metadata_slots - 1;
	size_t slot = hash_location(location, mask), probes = 0;
	if (volume->metadata_count >= DB_MAX_NODES + 1)
		return fail(error, error_size, "metadata resource ceiling exceeded");
	while (volume->metadata[slot]) {
		if (volume->metadata[slot] == location)
			return fail(error, error_size, "metadata alias or cycle");
		if (++probes >= volume->metadata_slots)
			return fail(error, error_size, "metadata hash table exhausted");
		slot = (slot + 1) & mask;
	}
	volume->metadata[slot] = location;
	volume->metadata_count++;
	return 0;
}

static int metadata_page(struct volume_state *volume, struct dynblk_pointer pointer,
			 uint64_t parent_generation, bool mark, uint8_t page[DB_BLOCK],
			 char *error, size_t error_size)
{
	uint32_t part, offset;
	if (extent(volume, pointer.location, DB_BLOCK, &part, &offset, error, error_size))
		return -1;
	if (pointer.reserved || offset % DB_BLOCK || !pointer.generation ||
	    pointer.generation > parent_generation)
		return fail(error, error_size, "invalid metadata pointer");
	if (mark) {
		if (volume->parts[part].refs[offset / DB_BLOCK] ||
		    metadata_insert(volume, pointer.location, error, error_size))
			return fail(error, error_size, "metadata alias or cycle");
		volume->parts[part].refs[offset / DB_BLOCK] = UINT16_MAX;
	}
	if (read_page(volume->parts[part].fd, offset, page, error, error_size))
		return -1;
	if (get64(page + 24) != pointer.generation || get32(page + 4092) != pointer.crc)
		return fail(error, error_size, "metadata pointer generation/CRC mismatch");
	if (memcmp(page + 8, volume->uuid, 16))
		return fail(error, error_size, "foreign metadata UUID");
	return 0;
}

static int value_fields(struct volume_state *volume, const uint8_t raw[40],
			uint64_t logical, uint64_t max_generation,
			struct mapping_value *value, char *error, size_t error_size)
{
	uint32_t part, offset;
	*value = read_value(raw);
	if (!value->location) {
		if (!zero_bytes(raw, 40))
			return fail(error, error_size, "nonzero null mapping");
		return 0;
	}
	if (extent(volume, value->location, value->length, &part, &offset, error, error_size))
		return -1;
	if (logical >= volume->selected.capacity / DB_BLOCK || !value->version ||
	    value->version > max_generation || value->flags > 1 ||
	    (value->decoded_length != DB_BLOCK && value->decoded_length != DB_REGION) ||
	    value->decoded_offset % DB_BLOCK ||
	    value->decoded_offset > value->decoded_length - DB_BLOCK)
		return fail(error, error_size, "invalid mapping value");
	if (!value->flags && (value->length != DB_BLOCK || value->decoded_length != DB_BLOCK ||
	    value->decoded_offset))
		return fail(error, error_size, "invalid mapping value");
	if (value->flags && (!strcmp(volume->algorithm, "none") ||
	    value->length >= value->decoded_length ||
	    value->decoded_offset != (value->decoded_length == DB_REGION ?
		(logical % 16) * DB_BLOCK : 0)))
		return fail(error, error_size, "invalid mapping value");
	return 0;
}
struct pending_node {
	struct dynblk_pointer pointer;
	uint32_t level;
	uint64_t base, parent_generation;
};

typedef int (*leaf_callback)(struct volume_state *, uint64_t, const uint8_t *,
			     void *, char *, size_t);

static int walk_leaves(struct volume_state *volume, bool mark, leaf_callback callback,
		       void *opaque, char *error, size_t error_size)
{
	struct pending_node pending[512];
	size_t depth = 0;
	uint64_t maps = 0;
	uint32_t pages = 0;
	if (volume->selected.tree.location)
		pending[depth++] = (struct pending_node) {
			volume->selected.tree, 3, 0, volume->selected.generation
		};
	while (depth) {
		struct pending_node current = pending[--depth];
		uint8_t page[DB_BLOCK];
		uint64_t version, base;
		uint32_t level, count, present = 0, i, end;
		if (current.level >= 4 || current.base >= volume->selected.capacity / DB_BLOCK)
			return fail(error, error_size, "invalid tree depth/base");
		if (metadata_page(volume, current.pointer, current.parent_generation,
				  mark, page, error, error_size))
			return -1;
		version = get64(page + 24);
		base = get64(page + 32);
		level = get32(page + 40);
		count = get32(page + 44);
		if (memcmp(page, "DBTREE01", 8) || base != current.base || level != current.level ||
		    !zero_bytes(page + 48, 16) || !count || count > (level ? 128U : 64U))
			return fail(error, error_size, "invalid tree node identity/count");
		pages++;
		if (pages > volume->selected.tree_pages)
			return fail(error, error_size, "tree page count exceeds root");
		if (level) {
			struct pending_node children[128];
			uint32_t child_count = 0;
			for (i = 0; i < 128; i++) {
				struct dynblk_pointer child = read_pointer(page + 64 + 24 * i);
				if (!child.location) {
					if (child.generation || child.crc || child.reserved)
						return fail(error, error_size, "nonzero null tree edge");
					continue;
				}
				present++;
				children[child_count++] = (struct pending_node) {
					child, level - 1,
					base + ((uint64_t)i << (6 + 7 * (level - 1))), version
				};
			}
			if (depth + child_count > sizeof(pending) / sizeof(pending[0]))
				return fail(error, error_size, "tree traversal resource ceiling exceeded");
			while (child_count)
				pending[depth++] = children[--child_count];
			end = 64 + 128 * 24;
		} else {
			for (i = 0; i < 64; i++) {
				struct mapping_value value;
				const uint8_t *raw = page + 64 + 40 * i;
				if (value_fields(volume, raw, base + i, version,
						 &value, error, error_size))
					return -1;
				if (value.location)
					present++;
			}
			maps += present;
			if (maps > volume->selected.mappings)
				return fail(error, error_size, "mapping count exceeds root");
			end = 64 + 64 * 40;
			if (callback && callback(volume, base, page, opaque, error, error_size))
				return -1;
		}
		if (count != present || !zero_bytes(page + end, 4092 - end))
			return fail(error, error_size, "tree count or unused padding mismatch");
	}
	if (pages != volume->selected.tree_pages || maps != volume->selected.mappings)
		return fail(error, error_size, "root/tree mapping or page count mismatch");
	return 0;
}
struct transaction_state {
	struct transaction_change changes[32];
	uint32_t count;
};

static int transaction_leaf(struct volume_state *volume, uint64_t base,
			    const uint8_t *page, void *opaque,
			    char *error, size_t error_size)
{
	struct transaction_state *state = opaque;
	uint32_t i;
	(void)volume;
	(void)error;
	(void)error_size;
	for (i = 0; i < state->count; i++) {
		uint64_t logical = state->changes[i].logical;
		if (logical < base || logical >= base + 64)
			continue;
		if (memcmp(state->changes[i].raw, page + 64 + (logical - base) * 40, 40))
			return fail(error, error_size, "transaction differs from selected tree");
		state->changes[i].matched = true;
	}
	return 0;
}

static int validate_transaction(struct volume_state *volume, struct transaction_state *state,
				char *error, size_t error_size)
{
	uint8_t page[DB_BLOCK];
	uint64_t version, previous, capacity, last = 0;
	uint32_t count, reserved, i;
	memset(state, 0, sizeof(*state));
	if (!volume->selected.transaction.location)
		return 0;
	if (metadata_page(volume, volume->selected.transaction, volume->selected.generation,
			  true, page, error, error_size))
		return -1;
	if (memcmp(page, "DBTXN001", 8))
		return fail(error, error_size, "invalid rooted transaction");
	version = get64(page + 24);
	previous = get64(page + 32);
	capacity = get64(page + 40);
	count = get32(page + 48);
	reserved = get32(page + 52);
	if (version != volume->selected.generation || previous != version - 1 ||
	    capacity != volume->selected.capacity || count > 32 || reserved ||
	    !zero_bytes(page + 56 + count * 48, 4092 - (56 + count * 48)))
		return fail(error, error_size, "invalid rooted transaction");
	state->count = count;
	for (i = 0; i < count; i++) {
		struct mapping_value value;
		uint64_t logical = get64(page + 56 + i * 48);
		const uint8_t *raw = page + 64 + i * 48;
		if ((i && logical <= last) || logical >= volume->selected.capacity / DB_BLOCK ||
		    value_fields(volume, raw, logical, version, &value, error, error_size))
			return fail(error, error_size, "invalid transaction ordering/version");
		if (value.location && value.version != version)
			return fail(error, error_size, "invalid transaction ordering/version");
		state->changes[i].logical = logical;
		memcpy(state->changes[i].raw, raw, 40);
		last = logical;
	}
	if (walk_leaves(volume, true, transaction_leaf, state, error, error_size))
		return -1;
	for (i = 0; i < count; i++)
		if (!state->changes[i].matched && !zero_bytes(state->changes[i].raw, 40))
			return fail(error, error_size, "transaction mapping absent from tree");
	return 0;
}

static int add_interval(struct part_state *part, uint32_t start, uint32_t length,
			char *error, size_t error_size)
{
	uint64_t packed;
	if (part->interval_count == part->interval_capacity) {
		size_t capacity = part->interval_capacity ? part->interval_capacity * 2 : 1024;
		uint64_t *new_intervals = realloc(part->intervals, capacity * sizeof(*new_intervals));
		if (!new_intervals)
			return fail(error, error_size, "cannot complete validation: memory exhausted");
		part->intervals = new_intervals;
		part->interval_capacity = capacity;
	}
	/* length may be exactly 65536, so reserve 17 low bits. */
	packed = ((uint64_t)start << 17) | length;
	part->intervals[part->interval_count++] = packed;
	return 0;
}

#ifndef DYNBLK_NO_DYNAMIC_CODECS
static int load_symbol(void *handle, const char *codec, const char *name, void **symbol,
		       char *error, size_t error_size)
{
	const char *message;
	dlerror();
	*symbol = dlsym(handle, name);
	message = dlerror();
	if (message || !*symbol)
		return fail(error, error_size, "cannot validate %s: missing decoder symbol %s",
			    codec, name);
	return 0;
}

static void *load_decoder_library(const char *codec, const char *soname,
				  char *error, size_t error_size)
{
	void *handle = dlopen(soname, RTLD_NOW | RTLD_LOCAL);
	if (!handle)
		fail(error, error_size, "cannot validate %s: decoder library %s is unavailable",
		     codec, soname);
	return handle;
}

static int decode_lz4(const char *codec, const uint8_t *input, uint32_t input_length,
		      uint8_t *output, uint32_t expected, char *error, size_t error_size)
{
	typedef int (*decode_fn)(const char *, char *, int, int);
	static void *handle;
	static decode_fn decode;
	int length;
	if (!decode) {
		if (!handle)
			handle = load_decoder_library(codec, "liblz4.so.1", error, error_size);
		if (!handle || load_symbol(handle, codec, "LZ4_decompress_safe",
					   (void **)&decode, error, error_size))
			return -1;
	}
	length = decode((const char *)input, (char *)output, (int)input_length, (int)expected);
	if (length != (int)expected)
		return fail(error, error_size, "invalid %s payload or decoded length", codec);
	return 0;
}

static int decode_zstd(const uint8_t *input, uint32_t input_length, uint8_t *output,
		       uint32_t expected, char *error, size_t error_size)
{
	typedef size_t (*frame_fn)(const void *, size_t);
	typedef size_t (*decode_fn)(void *, size_t, const void *, size_t);
	typedef unsigned (*error_fn)(size_t);
	static void *handle;
	static frame_fn frame_size;
	static decode_fn decode;
	static error_fn is_error;
	size_t frame, length;
	if (!decode) {
		if (!handle)
			handle = load_decoder_library("zstd", "libzstd.so.1", error, error_size);
		if (!handle ||
		    load_symbol(handle, "zstd", "ZSTD_findFrameCompressedSize",
				(void **)&frame_size, error, error_size) ||
		    load_symbol(handle, "zstd", "ZSTD_decompress",
				(void **)&decode, error, error_size) ||
		    load_symbol(handle, "zstd", "ZSTD_isError",
				(void **)&is_error, error, error_size))
			return -1;
	}
	frame = frame_size(input, input_length);
	if (is_error(frame) || frame != input_length)
		return fail(error, error_size, "invalid zstd frame extent");
	length = decode(output, expected, input, input_length);
	if (is_error(length) || length != expected)
		return fail(error, error_size, "invalid zstd payload or decoded length");
	return 0;
}

static int decode_deflate(const uint8_t *input, uint32_t input_length, uint8_t *output,
			  uint32_t expected, char *error, size_t error_size)
{
	typedef int (*init_fn)(z_streamp, int, const char *, int);
	typedef int (*inflate_fn)(z_streamp, int);
	typedef int (*end_fn)(z_streamp);
	typedef const char *(*version_fn)(void);
	static void *handle;
	static init_fn init;
	static inflate_fn inflate_run;
	static end_fn end;
	static version_fn version;
	z_stream stream = { 0 };
	int status, end_status;
	if (!inflate_run) {
		if (!handle)
			handle = load_decoder_library("deflate", "libz.so.1", error, error_size);
		if (!handle ||
		    load_symbol(handle, "deflate", "inflateInit2_", (void **)&init, error, error_size) ||
		    load_symbol(handle, "deflate", "inflate", (void **)&inflate_run, error, error_size) ||
		    load_symbol(handle, "deflate", "inflateEnd", (void **)&end, error, error_size) ||
		    load_symbol(handle, "deflate", "zlibVersion", (void **)&version, error, error_size))
			return -1;
	}
	stream.next_in = (Bytef *)input;
	stream.avail_in = input_length;
	stream.next_out = output;
	stream.avail_out = expected;
	if (init(&stream, -11, version(), sizeof(stream)) != Z_OK)
		return fail(error, error_size, "cannot initialize raw deflate decoder");
	status = inflate_run(&stream, Z_FINISH);
	end_status = end(&stream);
	if (end_status != Z_OK || status != Z_STREAM_END || stream.total_out != expected ||
	    stream.avail_in != 0 || stream.avail_out != 0)
		return fail(error, error_size, "invalid raw deflate stream or decoded length");
	return 0;
}
#endif

static int decode_payload(const char *algorithm, const uint8_t *input, uint32_t input_length,
			  uint8_t *output, uint32_t expected,
			  char *error, size_t error_size)
{
	if (!input_length || input_length >= expected ||
	    (expected != DB_BLOCK && expected != DB_REGION))
		return fail(error, error_size, "invalid compressed buffer bounds");
#ifndef DYNBLK_NO_DYNAMIC_CODECS
	if (!strcmp(algorithm, "lz4") || !strcmp(algorithm, "lz4hc"))
		return decode_lz4(algorithm, input, input_length, output, expected, error, error_size);
	if (!strcmp(algorithm, "zstd"))
		return decode_zstd(input, input_length, output, expected, error, error_size);
#else
	if (!strcmp(algorithm, "lz4") || !strcmp(algorithm, "lz4hc") ||
	    !strcmp(algorithm, "zstd") || !strcmp(algorithm, "deflate"))
		return fail(error, error_size,
			"cannot validate %s: optional decoder is not included in the initrd build",
			algorithm);
#endif
	if (!strcmp(algorithm, "lzo") || !strcmp(algorithm, "lzo-rle")) {
		size_t length = expected;
		if (dynblk_lzo1x_decompress_safe(input, input_length, output, &length) ||
		    length != expected)
			return fail(error, error_size, "invalid %s payload or decoded length", algorithm);
		return 0;
	}
#ifndef DYNBLK_NO_DYNAMIC_CODECS
	if (!strcmp(algorithm, "deflate"))
		return decode_deflate(input, input_length, output, expected, error, error_size);
#endif
	if (!strcmp(algorithm, "842"))
		return fail(error, error_size,
			"cannot validate 842: no qualified userspace decoder");
	return fail(error, error_size, "cannot validate %s: decoder unavailable", algorithm);
}

struct payload_state {
	uint64_t region;
	bool region_valid, shared_valid;
	struct mapping_value shared;
	uint8_t shared_data[DB_REGION];
	uint64_t blobs, stored, seen;
};

static bool same_blob(const struct mapping_value *a, const struct mapping_value *b)
{
	return a->location == b->location && a->version == b->version &&
	       a->length == b->length && a->stored_crc == b->stored_crc &&
	       a->flags == b->flags && a->decoded_length == b->decoded_length;
}
static int payload_leaf(struct volume_state *volume, uint64_t base,
			const uint8_t *page, void *opaque,
			char *error, size_t error_size)
{
	struct payload_state *state = opaque;
	uint32_t i;
	for (i = 0; i < 64; i++) {
		struct mapping_value value = read_value(page + 64 + 40 * i);
		uint64_t logical = base + i, region = logical / 16;
		uint32_t part, start, first_page, last_page, index;
		uint8_t encoded[DB_REGION], decoded[DB_REGION];
		const uint8_t *logical_data;
		if (!value.location)
			continue;
		if (!state->region_valid || state->region != region) {
			state->region = region;
			state->region_valid = true;
			state->shared_valid = false;
		}
		if (extent(volume, value.location, value.length, &part, &start,
			   error, error_size))
			return -1;
		first_page = start / DB_BLOCK;
		last_page = (start + value.length - 1) / DB_BLOCK;
		for (index = first_page; index <= last_page; index++) {
			if (volume->parts[part].refs[index] >= UINT16_MAX - 1)
				return fail(error, error_size,
					"metadata/payload overlap or page reference overflow");
			volume->parts[part].refs[index]++;
		}
		if (value.decoded_length == DB_REGION && state->shared_valid) {
			if (!same_blob(&value, &state->shared))
				return fail(error, error_size,
					"inconsistent shared blob within logical region");
			logical_data = state->shared_data;
		} else {
			if (state->blobs >= DB_MAX_BLOBS)
				return fail(error, error_size,
					"cannot complete validation: unique-blob resource ceiling exceeded");
			if (pread_exact(volume->parts[part].fd, encoded, value.length, start,
					error, error_size))
				return -1;
			if (dynblk_crc32(encoded, value.length) != value.stored_crc)
				return fail(error, error_size, "stored payload CRC mismatch or short read");
			if (value.flags) {
				if (decode_payload(volume->algorithm, encoded, value.length,
						   decoded, value.decoded_length, error, error_size))
					return -1;
				logical_data = decoded;
			} else {
				memcpy(decoded, encoded, value.length);
				logical_data = decoded;
			}
			if (add_interval(&volume->parts[part], start, value.length,
					 error, error_size))
				return -1;
			state->blobs++;
			state->stored += value.length;
			if (value.decoded_length == DB_REGION) {
				state->shared = value;
				memcpy(state->shared_data, logical_data, DB_REGION);
				state->shared_valid = true;
				logical_data = state->shared_data;
			}
		}
		if (dynblk_crc32(logical_data + value.decoded_offset, DB_BLOCK) !=
		    value.original_crc)
			return fail(error, error_size, "logical payload CRC mismatch");
		state->seen++;
	}
	return 0;
}

static int compare_u64(const void *left, const void *right)
{
	uint64_t a = *(const uint64_t *)left, b = *(const uint64_t *)right;
	return a < b ? -1 : a > b;
}

static int validate_intervals(struct volume_state *volume, char *error, size_t error_size)
{
	uint32_t part;
	for (part = 0; part < DB_PARTS; part++) {
		struct part_state *state = &volume->parts[part];
		uint64_t end = 0;
		size_t i;
		qsort(state->intervals, state->interval_count, sizeof(*state->intervals), compare_u64);
		for (i = 0; i < state->interval_count; i++) {
			uint64_t start = state->intervals[i] >> 17;
			uint32_t length = state->intervals[i] & 0x1ffffU;
			if (start < end)
				return fail(error, error_size, "overlapping distinct payload blobs");
			end = start + length;
		}
	}
	return 0;
}

static int full_validate(struct volume_state *volume, struct dynblk_inspection *result,
			 char *error, size_t error_size)
{
	struct transaction_state transaction;
	struct payload_state payload = { 0 };
	uint64_t expected_parts = 0;
	uint32_t i;
	if (prepare_full(volume, error, error_size) ||
	    validate_transaction(volume, &transaction, error, error_size))
		return -1;
	if (walk_leaves(volume, false, payload_leaf, &payload, error, error_size) ||
	    validate_intervals(volume, error, error_size))
		return -1;
	for (i = 0; i < DB_PARTS; i++)
		if (volume->selected.incarnations[i])
			expected_parts |= 1ULL << i;
	if (volume->used_parts != expected_parts)
		return fail(error, error_size, "active part set differs from reachable references");
	if (payload.seen != volume->selected.mappings)
		return fail(error, error_size, "root/tree mapping or page count mismatch");
	result->verified_live_bytes = payload.seen * DB_BLOCK;
	result->verified_blobs = payload.blobs;
	result->verified_stored_bytes = payload.stored;
	result->verified_tree_pages = volume->selected.tree_pages;
	result->verified_mapping_count = payload.seen;
	result->fully_validated = true;
	return 0;
}

int dynblk_inspect_volume(const char *path, bool full, struct dynblk_inspection *result,
			 char *error, size_t error_size)
{
	struct volume_state volume;
	int status;
	if (open_volume(path, &volume, result, error, error_size)) {
		close_volume(&volume);
		return -1;
	}
	status = full ? full_validate(&volume, result, error, error_size) : 0;
	close_volume(&volume);
	return status;
}

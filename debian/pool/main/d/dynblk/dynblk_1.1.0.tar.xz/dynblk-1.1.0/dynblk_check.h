/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DYNBLK_CHECK_H
#define DYNBLK_CHECK_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define DB_BLOCK 4096U
#define DB_REGION 65536U
#define DB_PARTS 64U
#define DB_DEFAULT_PART_LIMIT (4000ULL << 20)
#define DB_MIN_PART_LIMIT (1ULL << 20)
#define DB_MAX_NODES 2113665U
#define DB_METADATA_SLOTS (1U << 23)
#define DB_MAX_BLOBS ((512ULL << 30) / DB_BLOCK)

struct dynblk_pointer {
	uint64_t location;
	uint64_t generation;
	uint32_t crc;
	uint32_t reserved;
};

struct dynblk_inspection {
	char path[4096];
	uint8_t uuid[16];
	char compression[16];
	uint64_t part_limit;
	uint64_t primary_bytes;
	uint64_t incarnation;
	uint64_t capacity;
	uint64_t generation;
	uint64_t mapped_blocks;
	uint32_t tree_pages;
	uint32_t active_parts;
	uint32_t present_parts;
	uint64_t physical_bytes;
	uint32_t valid_roots;
	bool root_repair_needed;
	bool fully_validated;
	uint64_t verified_live_bytes;
	uint64_t verified_blobs;
	uint64_t verified_stored_bytes;
	uint64_t verified_tree_pages;
	uint64_t verified_mapping_count;
};

int dynblk_inspect_volume(const char *path, bool full,
			 struct dynblk_inspection *result, char *error, size_t error_size);
void dynblk_uuid_string(const uint8_t uuid[16], char out[37]);

#endif

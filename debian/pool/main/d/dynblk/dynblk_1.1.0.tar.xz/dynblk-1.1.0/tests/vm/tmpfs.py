"""Tmpfs backing tests, run only inside the disposable driver-test guest."""
import errno
import fcntl
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess

assert 'dynblk_disposable_acceptance=1' in Path('/proc/cmdline').read_text()
assert Path('/back').is_mount()
ROOT = Path('/back/tmpfs-cases')
ROOT.mkdir()
CLI = '/usr/sbin/dynblk'


def run(*args, ok=True):
    result = subprocess.run(list(map(str, args)), capture_output=True, text=True, timeout=60)
    if ok and result.returncode:
        raise AssertionError((args, result.returncode, result.stdout, result.stderr))
    return result


def ctl(*args):
    return run(CLI, *args).stdout.strip()


def usage(folder):
    return sum(p.stat().st_blocks * 512 for p in folder.iterdir())


run('mount', '-t', 'tmpfs', '-o', 'size=32m,nr_inodes=4096', 'tmpfs', ROOT)
for fmt, codec in (('dynblk', 'lz4'), ('vmdk', 'none')):
    for cache in ('writeback', 'writethrough', 'unsafe'):
        folder = ROOT / (fmt + '-' + cache)
        folder.mkdir()
        path = folder / ('disk.vmdk' if fmt == 'vmdk' else 'volume000.db')
        dev = ctl('create', path, '--format', fmt, '--compression', codec,
                  '--cache', cache, '--size', '64MiB', '--module', '/cli/dynblk.ko', '--execute')
        payload = os.urandom(2 << 20)
        with open(dev, 'r+b', buffering=0) as disk:
            assert disk.write(payload) == len(payload)
            disk.seek(4 << 20)
            assert disk.write(b'S' * 65536) == 65536
            os.fsync(disk.fileno())
            before = usage(folder)
            fcntl.ioctl(disk.fileno(), 0x1277, struct.pack('=QQ', 0, 2 << 20))
            os.fsync(disk.fileno())
            if cache == 'unsafe':
                assert usage(folder) == before
            else:
                assert usage(folder) < before
            disk.seek(4 << 20)
            assert disk.read(65536) == b'S' * 65536
        ctl('grow', dev, '96MiB', '--execute')
        with open(dev, 'r+b', buffering=0) as disk:
            disk.seek(80 << 20)
            disk.write(b'G' * 4096)
            os.fsync(disk.fileno())
        if cache == 'unsafe':
            assert run(CLI, 'reclaim', dev, '--execute', '--json', ok=False).returncode
        else:
            reclaimed = json.loads(ctl('reclaim', dev, '--execute', '--json'))
            assert reclaimed['complete'], reclaimed
        ctl('unload', dev, '--execute')
        assert json.loads(ctl('check', path, '--json'))['fully_validated']
        dev = ctl('load', path, '--read-only', '--cache', cache, '--execute')
        with open(dev, 'rb', buffering=0) as disk:
            assert disk.read(65536) == bytes(65536)
            disk.seek(4 << 20)
            assert disk.read(65536) == b'S' * 65536
            disk.seek(80 << 20)
            assert disk.read(4096) == b'G' * 4096
        ctl('unload', dev, '--execute')
        for direct in ('none', 'directsync'):
            assert run(CLI, 'load', path, '--cache', direct, '--execute', ok=False).returncode
        shutil.rmtree(folder)
        print('PASS tmpfs I/O, flush, discard, growth, reload, read-only and cache policy', fmt, cache, flush=True)

    # Exhaust backing storage, then release space and reopen the committed data.
    folder = ROOT / ('full-' + fmt)
    folder.mkdir()
    path = folder / ('disk.vmdk' if fmt == 'vmdk' else 'volume000.db')
    dev = ctl('create', path, '--format', fmt, '--compression', 'none',
              '--size', '64MiB', '--cache', 'writethrough', '--execute')
    with open(dev, 'r+b', buffering=0) as disk:
        disk.write(b'K' * 65536)
        os.fsync(disk.fileno())
    ballast = ROOT / 'ballast'
    with ballast.open('wb', buffering=0) as output:
        try:
            while True:
                output.write(bytes(4096))
        except OSError as error:
            assert error.errno == errno.ENOSPC
    try:
        with open(dev, 'r+b', buffering=0) as disk:
            disk.seek(8 << 20)
            disk.write(os.urandom(65536))
            os.fsync(disk.fileno())
    except OSError as error:
        assert error.errno in (errno.ENOSPC, errno.EIO, errno.ENOMEM)
    else:
        raise AssertionError('write unexpectedly succeeded on full tmpfs')
    ballast.unlink()
    run(CLI, 'unload', dev, '--execute', ok=False)
    assert not Path('/sys/block', Path(dev).name).exists()
    dev = ctl('load', path, '--execute')
    with open(dev, 'rb', buffering=0) as disk:
        assert disk.read(65536) == b'K' * 65536
    ctl('unload', dev, '--execute')
    assert json.loads(ctl('check', path, '--json'))['fully_validated']
    shutil.rmtree(folder)
    print('PASS tmpfs ENOSPC and committed-data recovery', fmt, flush=True)

run('umount', ROOT)
print('DYNBLK TMPFS PASS', flush=True)

/* Extracted admission functions and queue initializer; no real VFS or devices. */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <linux/fs.h>
#include <linux/magic.h>

typedef uint32_t u32;
typedef uint64_t u64;
#define SECTOR_SHIFT 9
#define BLK_FEAT_WRITE_CACHE 1
#define BLK_FEAT_FUA 2
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define ERR_PTR(error) ((void *)(intptr_t)(error))
#define PTR_ERR(ptr) ((int)(intptr_t)(ptr))
#define IS_ERR(ptr) ((uintptr_t)(ptr) >= (uintptr_t)-4095)
#define file_inode(f) (&(f)->inode)
#define mnt_idmap(mnt) (mnt)

struct queue_limits {
    u32 logical_block_size, physical_block_size, max_hw_sectors, max_segments;
    u32 max_hw_discard_sectors, max_discard_sectors, discard_granularity, features;
};
struct block_device_operations { int unused; };
static const struct block_device_operations operations = {};
static const struct block_device_operations lower_operations = {};
struct gendisk { const struct block_device_operations *fops; };
struct block_device { struct gendisk *bd_disk; u32 logical, physical, alignment; };
struct file_system_type { const char *name; };
struct super_block {
    struct file_system_type *s_type;
    struct block_device *s_bdev;
    u64 s_magic, s_maxbytes;
    unsigned long s_blocksize;
};
struct fileattr { u32 flags; bool flags_valid; };
struct dentry { struct fileattr attributes; int attr_error, xattr_result; u32 ntfs_flags; };
struct path { struct dentry *dentry; void *mnt; };
struct inode { struct super_block *i_sb; };
struct file { struct inode inode; struct path f_path; };
static u32 attr_calls, xattr_calls, block_queries;

static u32 bdev_logical_block_size(struct block_device *bdev)
{
    block_queries++;
    return bdev->logical;
}
static u32 bdev_physical_block_size(struct block_device *bdev)
{
    block_queries++;
    return bdev->physical;
}
static u32 bdev_alignment_offset(struct block_device *bdev)
{
    block_queries++;
    return bdev->alignment;
}
static int vfs_fileattr_get(struct dentry *dentry, struct fileattr *fa)
{
    attr_calls++;
    /* flags_valid is an input selector, not only an output validity bit. */
    assert(fa->flags_valid);
    if (dentry->attr_error) return dentry->attr_error;
    *fa = dentry->attributes;
    return 0;
}
static int vfs_getxattr(void *idmap, struct dentry *dentry, const char *name,
                        void *out, size_t size)
{
    (void)idmap;
    xattr_calls++;
    assert(!strcmp(name, "system.ntfs_attrib") && size == sizeof(u32));
    if (dentry->xattr_result == sizeof(u32)) memcpy(out, &dentry->ntfs_flags, size);
    return dentry->xattr_result;
}

struct crypto_comp { int unused; };
struct dynblk_device {
    u64 part_limit;
    struct crypto_comp *codec;
    char codec_name[16];
};
static struct crypto_comp transform;
static char requested_codec[16];
static unsigned int codec_calls;
static int codec_error;
static void strscpy(char *dst, const char *src, size_t size)
{
    assert(strlen(src) < size);
    strcpy(dst, src);
}
static struct crypto_comp *crypto_alloc_comp(const char *name, u32 type, u32 mask)
{
    assert(!type && !mask);
    codec_calls++;
    strscpy(requested_codec, name, sizeof(requested_codec));
    if (codec_error) return ERR_PTR(codec_error);
    return !strcmp(name, "842") ? ERR_PTR(-ENOENT) : &transform;
}

#include "admission.inc"

static struct dynblk_device device = { .part_limit = DB_DEFAULT_PART_LIMIT };
#define geometry(...) geometry(&device, ##__VA_ARGS__)
#define setup_codec(...) setup_codec(&device, ##__VA_ARGS__)
#define part_limit device.part_limit
#define codec device.codec
#define codec_name device.codec_name

int main(void)
{
    assert(tested_limits.max_hw_discard_sectors == DB_IO >> SECTOR_SHIFT);
    assert(tested_limits.max_hw_discard_sectors != 0);
    assert(tested_limits.discard_granularity == DB_BLOCK);
    assert(tested_limits.logical_block_size == DB_BLOCK);
    assert((tested_limits.features & (BLK_FEAT_WRITE_CACHE | BLK_FEAT_FUA)) ==
           (BLK_FEAT_WRITE_CACHE | BLK_FEAT_FUA));
    puts("PASS production queue advertises a nonzero 128KiB hardware discard limit");

    struct file_system_type type = { .name = "btrfs" };
    struct super_block sb = {
        .s_type = &type, .s_magic = BTRFS_SUPER_MAGIC,
        .s_maxbytes = DB_DEFAULT_PART_LIMIT, .s_blocksize = DB_BLOCK,
    };
    assert(geometry(&sb) && !block_queries);
    /* No member geometry may be consulted, even if s_bdev is non-NULL. */
    sb.s_bdev = (void *)(uintptr_t)1;
    assert(geometry(&sb) && !block_queries);
    sb.s_magic++;
    assert(!geometry(&sb) && !block_queries);
    sb.s_magic = BTRFS_SUPER_MAGIC;
    sb.s_blocksize = 512;
    assert(!geometry(&sb) && !block_queries);
    sb.s_blocksize = DB_BLOCK;
    sb.s_maxbytes = part_limit - 1;
    assert(!geometry(&sb) && !block_queries);
    part_limit = 12ULL << 20;
    sb.s_maxbytes = part_limit;
    assert(geometry(&sb) && !block_queries);
    puts("PASS Btrfs name/magic/4KiB/cap contract without any s_bdev dereference");

    struct gendisk lower = { .fops = &lower_operations };
    struct block_device bdev = { .bd_disk = &lower, .logical = 512, .physical = 4096 };
    const char * const names[] = { "ext4", "ext2", "vfat", "exfat", "ntfs3" };
    sb.s_bdev = &bdev;
    for (u32 i = 0; i < ARRAY_SIZE(names); i++) {
        type.name = names[i];
        assert(geometry(&sb));
        sb.s_bdev = NULL;
        assert(!geometry(&sb));
        sb.s_bdev = &bdev;
    }
    type.name = "ext4";
    sb.s_blocksize = 512;
    assert(!geometry(&sb));
    sb.s_blocksize = DB_BLOCK;
    bdev.alignment = 512;
    assert(!geometry(&sb));
    bdev.alignment = 0;
    lower.fops = &operations;
    assert(!geometry(&sb));
    lower.fops = &lower_operations;
    type.name = "tmpfs";
    assert(!geometry(&sb));
    puts("PASS conventional backing geometry remains restrictive and rejects direct stacking");

    struct dentry de = { .attributes = { .flags_valid = true }, .xattr_result = sizeof(u32) };
    struct file f = { .inode = { .i_sb = &sb }, .f_path = { .dentry = &de } };
    type.name = "btrfs";
    u32 btrfs_denials[] = { FS_NOCOW_FL, FS_IMMUTABLE_FL, FS_APPEND_FL };
    assert(!backing_attributes(&f) && attr_calls == 1 && !xattr_calls);
    de.attributes.flags = FS_COMPR_FL;
    assert(!backing_attributes(&f));
    for (u32 i = 0; i < ARRAY_SIZE(btrfs_denials); i++) {
        de.attributes.flags = btrfs_denials[i];
        assert(backing_attributes(&f) == -EOPNOTSUPP);
    }
    de.attributes.flags = 0;
    de.attributes.flags_valid = false;
    assert(backing_attributes(&f) == -EOPNOTSUPP);
    de.attributes.flags_valid = true;
    de.attr_error = -EIO;
    assert(backing_attributes(&f) == -EIO);
    de.attr_error = -EOPNOTSUPP;
    assert(backing_attributes(&f) == -EOPNOTSUPP);
    de.attr_error = 0;
    assert(!xattr_calls);
    puts("PASS Btrfs flag selector, NOCOW/immutable/append rejection, failed/invalid flag queries");

    type.name = "ntfs3";
    assert(!backing_attributes(&f) && xattr_calls == 1);
    u32 ntfs_denials[] = { FS_COMPR_FL, FS_ENCRYPT_FL, FS_IMMUTABLE_FL, FS_APPEND_FL };
    for (u32 i = 0; i < ARRAY_SIZE(ntfs_denials); i++) {
        de.attributes.flags = ntfs_denials[i];
        assert(backing_attributes(&f) == -EOPNOTSUPP && xattr_calls == 1);
    }
    de.attributes.flags = 0;
    de.attributes.flags_valid = false;
    assert(backing_attributes(&f) == -EOPNOTSUPP && xattr_calls == 1);
    de.attributes.flags_valid = true;
    de.attr_error = -ENOTTY;
    assert(backing_attributes(&f) == -ENOTTY && xattr_calls == 1);
    de.attr_error = 0;
    u32 ntfs_bits[] = { 0x200, 0x400, 0x800, 0x1000, 0x4000 };
    for (u32 i = 0; i < ARRAY_SIZE(ntfs_bits); i++) {
        de.ntfs_flags = ntfs_bits[i];
        assert(backing_attributes(&f) == -EOPNOTSUPP);
    }
    de.ntfs_flags = 0;
    de.xattr_result = -ENODATA;
    assert(backing_attributes(&f) == -ENODATA);
    de.xattr_result = 2;
    assert(backing_attributes(&f) == -EOPNOTSUPP);
    de.xattr_result = sizeof(u32);
    assert(!backing_attributes(&f));
    type.name = "ext4";
    de.attr_error = -EIO;
    assert(!backing_attributes(&f));
    puts("PASS ntfs3 compression/encryption/immutable/append prechecks and conservative NTFS attribute checks");

    const char * const codecs[] = { "lz4", "lz4hc", "lzo", "lzo-rle", "zstd", "deflate" };
    assert(!setup_codec("none") && !codec && !codec_calls);
    for (u32 i = 0; i < ARRAY_SIZE(codecs); i++) {
        memset(codec_name, 0, sizeof(codec_name));
        assert(!setup_codec(codecs[i]) && codec == &transform);
        assert(!strcmp(codec_name, codecs[i]) && !strcmp(requested_codec, codecs[i]));
    }
    assert(codec_calls == ARRAY_SIZE(codecs));
    assert(setup_codec("lzorle") == -EINVAL && codec_calls == ARRAY_SIZE(codecs));
    assert(setup_codec("842") == -ENOENT && !codec);
    codec_error = -ENOMEM;
    assert(setup_codec("lz4") == -ENOMEM && !codec);
    puts("PASS all six codec dispatch names including lz4hc; unavailable/error providers never substitute");
    return 0;
}

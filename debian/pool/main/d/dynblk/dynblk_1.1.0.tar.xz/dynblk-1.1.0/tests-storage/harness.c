/* Source-extracted storage engine; VFS/xarray/crypto adapters, not a kernel VM. */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <zlib.h>

#include "../dynblk_uapi.h"

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#define __packed __attribute__((packed))
#define U16_MAX UINT16_MAX
#define U32_MAX UINT32_MAX
#define U64_MAX UINT64_MAX
#define cpu_to_le16(x) ((u16)(x))
#define cpu_to_le32(x) ((u32)(x))
#define cpu_to_le64(x) ((u64)(x))
#define le16_to_cpu(x) ((u16)(x))
#define le32_to_cpu(x) ((u32)(x))
#define le64_to_cpu(x) ((u64)(x))
#define DIV_ROUND_UP(x,y) (((x)+(y)-1)/(y))
#define DIV_ROUND_UP_ULL(x,y) DIV_ROUND_UP(x,y)
#define BIT_ULL(x) (UINT64_C(1) << (x))
#define min(x,y) ((x)<(y)?(x):(y))
#define max(x,y) ((x)>(y)?(x):(y))
#define min_t(type,x,y) min((type)(x),(type)(y))
#define round_down(x,y) ((x) & ~((__typeof__(x))(y)-1))
#define GFP_NOIO 0
#define cond_resched() ((void)0)
#define DEFINE_MUTEX(x) int x __attribute__((unused))
#define DEFINE_XARRAY(x) struct xarray x = {0}
struct mutex { int unused; };
struct gendisk;
struct blk_mq_tag_set { int unused; };
struct workqueue_struct;
#define xa_for_each(x,index,chunk) \
    for ((index)=0; (index)<(x)->end; (index)++) \
        if (((chunk)=(x)->slots[index]) != NULL)
#define file_inode(f) (&(f)->inode)
#define i_size_read(i) ((i)->size)
#define get_zeroed_page(gfp) ((unsigned long)calloc(1,4096))
#define free_page(p) free((void *)(p))
#define kzalloc(n,gfp) calloc(1,(n))
#define kcalloc(n,s,gfp) calloc((n),(s))
#define kfree(p) free(p)
#define WARN_ON_ONCE(x) ((void)(x))

struct xarray { void **slots; u64 end, capacity; };
struct inode { u64 size; };
struct file;
struct path { struct file *file; };
struct file {
    struct inode inode;
    struct path f_path;
    u8 *bytes, *durable;
    u64 space, durable_size;
    bool exists, durable_exists;
    u64 incarnation;
};
struct cred { int dummy; };
struct crypto_comp { int dummy; };
struct kstatfs { long f_bsize; u64 f_bavail; };
static u64 host_free = 64ULL << 30;
static int vfs_statfs(struct path *path, struct kstatfs *st)
{
    (void)path;
    st->f_bsize=4096; st->f_bavail=host_free/4096;
    return 0;
}
static const struct cred *override_creds(const struct cred *cred) { return cred; }
static void revert_creds(const struct cred *cred) { (void)cred; }
static struct file files[64];
static int fault_at, event_count, fault_mode, torn_bytes;
static bool fault_injected;
static unsigned int tree_writes, decompressions, creations, removals;
static u64 write_bytes;
struct dynblk_device;
static int open_part(struct dynblk_device *dev, u32 id, bool exclusive);
static int remove_part(struct dynblk_device *dev, u32 id);

static void xa_init(struct xarray *x)
{
    x->slots=NULL; x->end=x->capacity=0;
}
static void xa_destroy(struct xarray *x)
{
    free(x->slots); x->slots=NULL; x->end=x->capacity=0;
}
static void *xa_load(struct xarray *x, u64 index)
{
    return index < x->capacity ? x->slots[index] : NULL;
}
static int xa_insert(struct xarray *x, u64 index, void *p, int gfp)
{
    (void)gfp;
    if (index >= x->capacity) {
        u64 capacity=x->capacity ? x->capacity : 16;
        while (capacity <= index) capacity*=2;
        void **slots=realloc(x->slots, capacity*sizeof(*slots));
        assert(slots);
        memset(slots+x->capacity,0,(capacity-x->capacity)*sizeof(*slots));
        x->slots=slots; x->capacity=capacity;
    }
    assert(!x->slots[index]);
    x->slots[index]=p;
    if (index>=x->end) x->end=index+1;
    return 0;
}
static void xa_erase(struct xarray *x, u64 index)
{
    if (index < x->capacity) x->slots[index]=NULL;
}
static void *memchr_inv(const void *p, int c, size_t n)
{
    for (size_t i=0; i<n; i++)
        if (((const u8 *)p)[i] != c) return (void *)p+i;
    return NULL;
}
static u32 crc32_le(u32 seed, const void *p, size_t n)
{
    return (u32)crc32(seed ^ ~0U, p, n) ^ ~0U;
}
static bool inject(void)
{
    if (!fault_at || ++event_count!=fault_at) return false;
    fault_injected=true;
    return true;
}
static void ensure(struct file *f, u64 length)
{
    assert(length < 64 * 1024 * 1024);
    if (length <= f->space) return;
    u64 size = DIV_ROUND_UP(length, 65536) * 65536;
    f->bytes = realloc(f->bytes, size);
    f->durable = realloc(f->durable, size);
    assert(f->bytes && f->durable);
    memset(f->bytes + f->space, 0, size - f->space);
    memset(f->durable + f->space, 0, size - f->space);
    f->space = size;
}
static ssize_t kernel_write(struct file *f, const void *p, size_t n, loff_t *pos)
{
    bool fail = inject();
    write_bytes += n;
    if (n==4096 && !memcmp(p,"DBTREE01",8)) tree_writes++;
    ensure(f, *pos + n);
    if (fail) {
        if (fault_mode) {
            size_t k = min(n, (size_t)torn_bytes);
            memcpy(f->durable + *pos, p, k);
            if (k && (u64)*pos+k > f->durable_size) f->durable_size = *pos+k;
        }
        return -EIO;
    }
    memcpy(f->bytes + *pos, p, n);
    *pos += n;
    if ((u64)*pos > f->inode.size) f->inode.size = *pos;
    return n;
}
static ssize_t kernel_read(struct file *f, void *p, size_t n, loff_t *pos)
{
    if ((u64)*pos >= f->inode.size) return 0;
    n = min(n, f->inode.size - *pos);
    memcpy(p, f->bytes + *pos, n);
    *pos += n;
    return n;
}
static int vfs_fsync(struct file *f, int ignored)
{
    (void)ignored;
    bool fail = inject();
    if (!fail || fault_mode) {
        memcpy(f->durable, f->bytes, f->inode.size);
        f->durable_size = f->inode.size;
        f->durable_exists = f->exists;
    }
    return fail ? -EIO : 0;
}
static int vfs_truncate(struct path *path, u64 len)
{
    if (inject()) return -EIO;
    assert(len <= path->file->inode.size);
    path->file->inode.size = len;
    return 0;
}
extern int LZ4_compress_default(const char *, char *, int, int);
extern int LZ4_decompress_safe(const char *, char *, int, int);
static int crypto_comp_compress(struct crypto_comp *tfm, const void *src,
                               u32 len, void *dst, u32 *out)
{
    (void)tfm;
    int n = LZ4_compress_default(src, dst, len, *out);
    if (n <= 0) return -EIO;
    *out = n;
    return 0;
}
static int crypto_comp_decompress(struct crypto_comp *tfm, const void *src,
                                 u32 len, void *dst, u32 *out)
{
    (void)tfm;
    decompressions++;
    int n = LZ4_decompress_safe(src, dst, len, *out);
    if (n < 0) return -EIO;
    *out = n;
    return 0;
}

#include "production.inc"

static struct dynblk_device device;
static struct dynblk_device *dev = &device;

static int open_part(struct dynblk_device *dev, u32 id, bool exclusive)
{
    struct file *f = &files[id];
    if (dev->parts[id].file) return 0;
    if (exclusive && f->exists) return -EEXIST;
    if (!exclusive && !f->exists) return -ENOENT;
    if (exclusive) {
        creations++;
        f->exists = true;
        f->incarnation++;
        ensure(f, DB_BLOCK);
        memset(f->bytes, 0, DB_BLOCK);
        f->inode.size = DB_BLOCK;
        assert(!vfs_fsync(f, 0));
    }
    dev->parts[id].file = f;
    dev->parts[id].incarnation = f->incarnation;
    dev->parts[id].ref_counts = calloc(DIV_ROUND_UP(DB_PAGES(dev), DB_REF_CHUNK), sizeof(u16));
    assert(dev->parts[id].ref_counts);
    assert(!ref_reserve(&dev->parts[id],0,id ? 1 : 3));
    ref_set(&dev->parts[id],0,DB_BUSY);
    if (!id) { ref_set(&dev->parts[id],1,DB_BUSY); ref_set(&dev->parts[id],2,DB_BUSY); }
    dev->parts[id].hint = id ? 1 : 3;
    f->f_path.file = f;
    return 0;
}
static int remove_part(struct dynblk_device *dev, u32 id)
{
    if (inject()) return -EIO;
    removals++;
    files[id].exists = files[id].durable_exists = false;
    files[id].inode.size = files[id].durable_size = 0;
    refs_destroy(&dev->parts[id]);
    memset(&dev->parts[id], 0, sizeof(dev->parts[id]));
    xa_init(&dev->parts[id].refs);
    return 0;
}

#define open_part(...) open_part(dev, ##__VA_ARGS__)
#define remove_part(...) remove_part(dev, ##__VA_ARGS__)
#define file_io(...) file_io(dev, ##__VA_ARGS__)
#define page_io(...) page_io(dev, ##__VA_ARGS__)
#define map_slot(...) map_slot(dev, ##__VA_ARGS__)
#define reserve_map(...) reserve_map(dev, ##__VA_ARGS__)
#define allocate(...) allocate(dev, ##__VA_ARGS__)
#define release_page(...) release_page(dev, ##__VA_ARGS__)
#define valid_value(...) valid_value(dev, ##__VA_ARGS__)
#define value_charge(...) value_charge(dev, ##__VA_ARGS__)
#define payload_refs(...) payload_refs(dev, ##__VA_ARGS__)
#define read_value(...) read_value(dev, ##__VA_ARGS__)
#define read_map_value(...) read_map_value(dev, ##__VA_ARGS__)
#define sync_parts(...) sync_parts(dev, ##__VA_ARGS__)
#define publish_root(...) publish_root(dev, ##__VA_ARGS__)
#define trim_parts(...) trim_parts(dev, ##__VA_ARGS__)
#define active_location(...) active_location(dev, ##__VA_ARGS__)
#define valid_pointer(...) valid_pointer(dev, ##__VA_ARGS__)
#define make_pointer(...) make_pointer(dev, ##__VA_ARGS__)
#define read_node(...) read_node(dev, ##__VA_ARGS__)
#define tree_pointer(...) tree_pointer(dev, ##__VA_ARGS__)
#define dirty_path(...) dirty_path(dev, ##__VA_ARGS__)
#define write_tree(...) write_tree(dev, ##__VA_ARGS__)
#define prune_map(...) prune_map(dev, ##__VA_ARGS__)
#define working_room(...) working_room(dev, ##__VA_ARGS__)
#define flush_payload(...) flush_payload(dev, ##__VA_ARGS__)
#define prepare_payload(...) prepare_payload(dev, ##__VA_ARGS__)
#define region_estimate(...) region_estimate(dev, ##__VA_ARGS__)
#define region_account(...) region_account(dev, ##__VA_ARGS__)
#define commit_staged(...) commit_staged(dev, ##__VA_ARGS__)
#define collect_part(...) collect_part(dev, ##__VA_ARGS__)
#define valid_root(...) valid_root(dev, ##__VA_ARGS__)
#define mark_metadata(...) mark_metadata(dev, ##__VA_ARGS__)
#define recover_tree(...) recover_tree(dev, ##__VA_ARGS__)
#define recover(...) recover(dev, ##__VA_ARGS__)

#define map_compressed(v) (!!((v)->meta & DB_MAP_COMPRESSED))
#define map_decoded_length(v) (((v)->meta & DB_MAP_REGION) ? DB_REGION : DB_BLOCK)
#define map_decoded_offset(v) (((v)->meta & DB_MAP_REGION) ? ((v)->meta & DB_MAP_OFFSET_MASK) * DB_BLOCK : 0U)

static void reset_ram(void)
{
    for (u32 i=0; i<dev->mapping.end; i++) { free(dev->mapping.slots[i]); dev->mapping.slots[i]=NULL; }
    xa_destroy(&dev->mapping); xa_init(&dev->mapping);
    for (u32 i=0; i<DB_PARTS; i++) refs_destroy(&dev->parts[i]);
    memset(dev->parts, 0, sizeof(dev->parts));
    for (u32 i=0; i<DB_PARTS; i++) xa_init(&dev->parts[i].refs);
    dev->generation = dev->capacity = dev->mapped_blocks = dev->stored_bytes = dev->map_chunks = 0;
    dev->tree_pages = 0;
    memset(dev->tree_index,0,DB_INTERNAL_NODES*sizeof(*dev->tree_index));
    dev->cached_blob.location=0;
    dev->gc_node=DB_NO_NODE;
    dev->fenced = dev->collecting = false;
    dev->avoid_part = -1;
    dev->stage.count = 0;
    dev->stage.nr_dirty=dev->stage.nr_allocations=0;
    fault_at = event_count = 0;
    fault_injected=false;
}
static void fresh(bool compressed)
{
    reset_ram();
    for (u32 i=0; i<DB_PARTS; i++) {
        free(files[i].bytes); free(files[i].durable);
    }
    memset(files, 0, sizeof(files));
    memset(dev->root, 0, DB_BLOCK);
    memset(dev->volume_uuid, 0x57, 16);
    memset(dev->codec_name, 0, 16);
    strcpy(dev->codec_name, compressed ? "lz4" : "none");
    dev->codec = compressed ? (void *)1 : NULL;
    dev->map_memory_mb = 256;
    host_free=64ULL<<30;
    dev->part_limit=1ULL<<20;
    assert(valid_part_limit(dev->part_limit));
    assert(!open_part(0, true));
    dev->directory = &files[0];
    dev->generation = 1;
    dev->capacity = 16ULL << 30;
    memcpy(dev->root->magic, "DBROOT01", 8);
    memcpy(dev->root->uuid, dev->volume_uuid, 16);
    dev->root->generation = dev->generation;
    dev->root->capacity = dev->capacity;
    dev->root->tree_height=DB_HEIGHT;
    active_location(0);
    assert(!publish_root());
}
static int reboot(void)
{
    reset_ram();
    for (u32 i=0; i<DB_PARTS; i++) {
        struct file *f = &files[i];
        f->exists = f->durable_exists;
        f->inode.size = f->durable_size;
        if (f->durable_size) memcpy(f->bytes, f->durable, f->durable_size);
    }
    assert(!open_part(0, false));
    return recover();
}
static int write_blocks(u32 first, u32 count, u8 byte)
{
    dev->stage.count = count;
    for (u32 i=0; i<count; i++) dev->stage.logical[i] = first+i;
    memset(dev->raw, byte, count*DB_BLOCK);
    return commit_staged(dev->capacity);
}
static void check_blocks(u32 first, u32 count, u8 byte)
{
    for (u32 i=0; i<count; i++) {
        assert(!read_map_value(map_slot(first+i), dev->raw));
        assert(!memchr_inv(dev->raw, byte, DB_BLOCK));
    }
}

static u64 physical_total(void)
{
    u64 bytes=0;
    for (u32 i=0; i<DB_PARTS; i++) {
        assert(files[i].inode.size<=dev->part_limit);
        if (files[i].exists) bytes+=files[i].inode.size;
    }
    return bytes;
}

static void check_accounting(void)
{
    u64 refs[DB_PARTS]={0}, live[DB_PARTS]={0}, total=0, maps=0;
    u32 meta[DB_PARTS]={0}, gc[DB_PARTS]={0}, nodes=0;
    for (u32 index=0; index<dev->mapping.end; index++) {
        struct db_map_chunk *chunk=dev->mapping.slots[index];
        if (!chunk) continue;
        for (u32 i=0; i<DB_MAP_CHUNK; i++) {
            struct db_map_value *value=&chunk->values[i];
            if (!value->location) continue;
            u32 id=part_id(value->location);
            refs[id]++; maps++;
            live[id]+=value_charge((u64)index*DB_MAP_CHUNK+i,value);
        }
        for (u32 group=0; group<DB_MAP_CHUNK; group+=DB_SUBBLOCKS) {
            u32 pages[DB_PARTS];
            region_estimate((u64)index*DB_MAP_CHUNK+group,pages);
            for (u32 id=0; id<DB_PARTS; id++) gc[id]+=pages[id];
        }
        for (u32 leaf=0; leaf<2; leaf++) {
            struct db_pointer *pointer=&chunk->leaf[leaf];
            if (!pointer->location) continue;
            u32 id=part_id(pointer->location);
            refs[id]++; meta[id]++; nodes++;
            assert(ref_get(&dev->parts[id],(u32)pointer->location/DB_BLOCK)==DB_BUSY);
        }
    }
    for (u32 i=0; i<DB_INTERNAL_NODES; i++) {
        if (!dev->tree_index[i].location) continue;
        u32 id=part_id(dev->tree_index[i].location);
        refs[id]++; meta[id]++; nodes++;
        assert(ref_get(&dev->parts[id],(u32)dev->tree_index[i].location/DB_BLOCK)==DB_BUSY);
    }
    if (dev->root->transaction.location) {
        u32 id=part_id(dev->root->transaction.location);
        refs[id]++; meta[id]++;
    }
    assert(maps==dev->mapped_blocks && nodes==dev->tree_pages);
    for (u32 i=0; i<DB_PARTS; i++) {
        assert(refs[i]==dev->parts[i].live_refs && live[i]==dev->parts[i].live_bytes &&
               meta[i]==dev->parts[i].meta_pages && gc[i]==dev->parts[i].gc_pages);
        assert((!i || !!refs[i])==!!dev->root->incarnations[i]);
        total+=live[i];
    }
    assert(total==dev->stored_bytes);
}

static void fill_random(void *buffer, u32 bytes, u32 seed)
{
    u8 *p=buffer;
    for (u32 i=0; i<bytes; i++) {
        seed^=seed<<13; seed^=seed>>17; seed^=seed<<5;
        p[i]=seed;
    }
}
int main(void)
{
    dev->root = calloc(1, DB_BLOCK); dev->other_root = calloc(1, DB_BLOCK);
    dev->header = malloc(DB_BLOCK); dev->transaction = malloc(DB_BLOCK);
    dev->tree_stack=calloc(DB_HEIGHT,sizeof(*dev->tree_stack));
    dev->tree_index=calloc(DB_INTERNAL_NODES,sizeof(*dev->tree_index));
    xa_init(&dev->mapping);
    for (u32 i=0; i<DB_PARTS; i++) xa_init(&dev->parts[i].refs);
    dev->raw = malloc(DB_IO); dev->packed = malloc(DB_REGION); dev->scratch = malloc(2*DB_REGION);
    dev->decoded=malloc(DB_REGION);
    assert(sizeof(*dev->root)==4096 && sizeof(*dev->tree_stack)==4096 &&
           sizeof(*dev->transaction)==4096 && sizeof(struct db_header)==4096 &&
           sizeof(struct db_map_value)==28 && sizeof(struct db_map_chunk)<=DB_BLOCK &&
           sizeof(struct dynblk_status)==128 && sizeof(struct dynblk_attach)==4152 &&
           sizeof(struct dynblk_detach)==16 && DYNBLK_GET==0x8080d700UL &&
           DYNBLK_ATTACH==0xd038d702UL && DYNBLK_DETACH==0x4010d703UL &&
           DYNBLK_COOKIE==0x8008d704UL);

    reset_ram();
    dev->map_memory_mb=1;
    for (u32 i=0; i<256; i++)
        assert(!reserve_map((u64)i*DB_MAP_CHUNK));
    assert(dev->map_chunks==256);
    assert(reserve_map((u64)256*DB_MAP_CHUNK)==-ENOSPC);
    reset_ram();
    puts("PASS 1MiB mapping budget covers exactly 128MiB dense logical space");

    {
        struct db_part p={0};
        xa_init(&p.refs);
        p.ref_counts=calloc(2,sizeof(*p.ref_counts));
        assert(p.ref_counts);
        assert(!ref_reserve(&p,DB_REF_CHUNK,1));
        assert(xa_load(&p.refs,1) && !p.ref_counts[1]);
        ref_set(&p,DB_REF_CHUNK,1);
        assert(p.ref_counts[1]==1 && xa_load(&p.refs,1));
        ref_clear(&p,DB_REF_CHUNK);
        assert(!p.ref_counts[1] && !xa_load(&p.refs,1));
        refs_destroy(&p);
    }
    puts("PASS empty lazy reference-counter chunks are reclaimed immediately");

    for (int compressed=0; compressed<2; compressed++) {
        fresh(compressed);
        assert(files[0].inode.size == 12288 && !files[1].exists);
        assert(!write_blocks(0, 32, 0x41));
        if (compressed) assert(dev->stored_bytes < DB_BLOCK);
        u64 peak = files[0].inode.size;
        for (int i=0; i<100; i++) {
            assert(!write_blocks(0, 32, 0x42+(i%20)));
            check_blocks(0, 32, 0x42+(i%20));
            if (files[0].inode.size > peak) peak = files[0].inode.size;
            if (!(i%10)) assert(!reboot());
        }
        assert(peak < 2*DB_IO + 16*DB_BLOCK);
        assert(!write_blocks(1, 30, 0));
        assert(dev->mapped_blocks==2);
        assert(!reboot());
        check_blocks(1, 30, 0);
        assert(!write_blocks(0, 32, 0));
        assert(!dev->mapped_blocks && !dev->map_chunks);
        assert(!reboot());
        dev->stage.count=0;
        assert(!commit_staged(32ULL<<30));
        assert(!reboot() && dev->capacity==(32ULL<<30));
    }
    puts("PASS raw/LZ4 region COW, overwrite reuse, shared-page discard, empty map, grow, recovery");

    unsigned int trials=0, injected_trials=0;
    for (int compressed=0; compressed<2; compressed++)
      for (int mode=0; mode<2; mode++)
        for (int cut=0; cut<=4096; cut+=512)
          for (int event=1; event<=24; event++)
           for (int scenario=0; scenario<4; scenario++)
            for (int erase=0; erase<2; erase++) {
            fresh(compressed);
            u32 first=scenario==0?0:scenario==1?63:scenario==2?8191:1048575;
            assert(!write_blocks(first, 32, 0x31));
            assert(!write_blocks(20000,16,0x19));
            fault_at=event; event_count=0; fault_mode=mode; torn_bytes=cut;
            u8 replacement=erase?0:0x72;
            int ret = write_blocks(first, 32, replacement);
            if (ret) assert(dev->fenced);
            assert(fault_injected==(ret<0));
            injected_trials+=fault_injected;
            assert(!reboot());
            assert(!read_map_value(map_slot(first), dev->raw));
            u8 expected = ((u8 *)dev->raw)[0];
            assert(expected==0x31 || expected==replacement);
            if (!ret) assert(expected==replacement);
            check_blocks(first, 32, expected);
            check_blocks(20000,16,0x19);
            assert(!write_blocks(first, 32, 0x56));
            assert(!reboot());
            check_blocks(first, 32, 0x56);
            check_blocks(20000,16,0x19);
            trials++;
          }
    printf("PASS %u write/discard fault-matrix trials (%u injected failures), all tree boundaries and reuse/reattach\n",
           trials,injected_trials);

    unsigned int partial_trials=0, partial_injected=0;
    for (int mode=0; mode<2; mode++)
      for (int cut=0; cut<=4096; cut+=512)
        for (int event=1; event<=20; event++)
          for (int erase=0; erase<2; erase++) {
            fresh(true);
            assert(!write_blocks(0,16,0x31));
            fault_at=event; event_count=0; fault_mode=mode; torn_bytes=cut;
            int ret=write_blocks(5,1,erase?0:0x72);
            partial_injected+=fault_injected;
            assert(fault_injected==(ret<0));
            assert(!reboot());
            assert(!read_map_value(map_slot(5),dev->raw));
            u8 expected=((u8 *)dev->raw)[0];
            assert(expected==0x31 || expected==(erase?0:0x72));
            if (!ret) assert(expected==(erase?0:0x72));
            check_blocks(0,5,0x31); check_blocks(6,10,0x31);
            check_blocks(5,1,expected);
            assert(!write_blocks(5,1,0x56));
            assert(!reboot());
            check_blocks(0,5,0x31); check_blocks(6,10,0x31); check_blocks(5,1,0x56);
            partial_trials++;
          }
    printf("PASS %u partial-group overwrite/discard crash trials (%u injected failures)\n",
           partial_trials,partial_injected);

    fresh(false);
    assert(!write_blocks(0, 32, 0x41));
    u64 loc=le64_to_cpu(map_slot(0)->location);
    files[part_id(loc)].durable[(u32)loc] ^= 1;
    assert(reboot()==-EUCLEAN);
    puts("PASS committed payload corruption rejects");

    fresh(false);
    for (u32 i=0; i<320; i+=32) assert(!write_blocks(i,32,0x67));
    assert(dev->tree_pages==8);
    for (u32 i=0; i<256; i+=32) assert(!write_blocks(i,32,0));
    u64 before=dev->generation;
    assert(!collect_part());
    assert(dev->generation>before && dev->parts[1].file);
    assert(!reboot());
    check_blocks(256,64,0x67);
    check_blocks(0,256,0);
    for (u32 i=256; i<320; i+=32) assert(!write_blocks(i,32,0));
    dev->stage.count=0;
    dev->avoid_part=1;
    assert(!commit_staged(dev->capacity));
    dev->avoid_part=-1;
    /* A tree-only transaction also relocates cold nodes before retirement. */
    dev->collecting=true; dev->avoid_part=1;
    for (u32 i=0; i<DB_NODES; i++) {
        struct db_pointer *pointer=tree_pointer(i);
        if (!pointer || !pointer->location || part_id(pointer->location)!=1) continue;
        dev->gc_node=i; assert(!commit_staged(dev->capacity));
    }
    dev->gc_node=DB_NO_NODE; dev->collecting=false; dev->avoid_part=-1;
    assert(!files[1].exists);
    assert(!reboot());
    puts("PASS multi-leaf radix, automatic live relocation, lazy part and retirement");

    fresh(false);
    dev->avoid_part=0;
    assert(!write_blocks(0,1,0x23));
    dev->avoid_part=-1;
    assert(dev->root->incarnations[1]);
    files[1].durable_exists=false;
    assert(reboot()==-EUCLEAN);
    puts("PASS missing active part rejects");

    fresh(true);
    dev->stage.count=32;
    u8 *expected=malloc(DB_IO);
    assert(expected);
    memset(expected,0x51,DB_IO);
    u32 rng=0x137f938b;
    for (u32 i=DB_BLOCK; i<2*DB_BLOCK; i++) {
        rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
        expected[i]=rng;
    }
    memcpy(dev->raw,expected,DB_IO);
    for (u32 i=0; i<32; i++) dev->stage.logical[i]=i;
    assert(!commit_staged(dev->capacity));
    assert(map_compressed(map_slot(1)) && map_decoded_length(map_slot(1))==DB_REGION);
    assert(!reboot());
    for (u32 i=0; i<32; i++) {
        assert(!read_map_value(map_slot(i),dev->raw));
        assert(!memcmp(dev->raw,expected+i*DB_BLOCK,DB_BLOCK));
    }
    assert(!write_blocks(0,1,0));
    assert(!write_blocks(2,30,0));
    assert(!reboot());
    assert(!read_map_value(map_slot(1),dev->raw));
    assert(!memcmp(dev->raw,expected+DB_BLOCK,DB_BLOCK));
    assert(!write_blocks(1,1,0));
    assert(!reboot() && !dev->mapped_blocks);
    free(expected);
    puts("PASS mixed-entropy 64KiB group with surviving subblock after discard");

    fresh(false);
    assert(!write_blocks(0,1,0x35));
    host_free=0;
    assert(write_blocks(0,1,0x36)==-ENOSPC && dev->fenced);
    host_free=64ULL<<30;
    assert(!reboot());
    check_blocks(0,1,0x35);
    puts("PASS physical workspace admission ENOSPC preserves committed mapping");

    fresh(false);
    assert(!write_blocks(0,1,0x35));
    struct db_root old_root=*dev->root;
    /* Interrupt after durable A, leaving valid previous B. */
    fault_at=10; event_count=0; fault_mode=0; torn_bytes=0;
    assert(write_blocks(0,1,0x36)<0);
    struct db_root *selected=(void *)(files[0].durable+DB_BLOCK);
    assert(selected->generation==old_root.generation+1);
    assert(!memcmp(files[0].durable+2*DB_BLOCK,&old_root,DB_BLOCK));
    loc=selected->tree.location;
    files[part_id(loc)].durable[(u32)loc+100]^=1;
    assert(reboot()==-EUCLEAN);
    puts("PASS damaged selected tree rejects rather than stale-root fallback");

    unsigned int gc_injected=0;
    for (int event=1; event<=28; event++) {
        fresh(false);
        for (u32 i=0; i<320; i+=32) assert(!write_blocks(i,32,0x67));
        for (u32 i=0; i<256; i+=32) assert(!write_blocks(i,32,0));
        assert(!open_part(1,true));
        fault_at=event; event_count=0; fault_mode=1; torn_bytes=512;
        int gc_ret=collect_part();
        if (fault_injected) assert(gc_ret<0);
        gc_injected+=fault_injected;
        assert(!reboot());
        check_blocks(256,64,0x67);
        check_blocks(0,256,0);
    }
    printf("PASS 28 collection fault-matrix trials (%u injected failures), live/discarded data preserved\n",gc_injected);

    fresh(true);
    assert(!write_blocks(0,16,0x29));
    struct db_map_value original_group=*map_slot(0);
    for (u32 i=0; i<16; i++) {
        assert(map_same_blob(map_slot(i),&original_group));
        assert(map_decoded_length(map_slot(i))==DB_REGION && map_decoded_offset(map_slot(i))==i*DB_BLOCK);
    }
    assert(dev->stored_bytes==map_length(&original_group));
    dev->cached_blob.location=0; decompressions=0;
    check_blocks(0,16,0x29);
    assert(decompressions==1);
    tree_writes=0; write_bytes=0;
    assert(!write_blocks(5,1,0x49));
    assert(tree_writes==4 && write_bytes<=DB_BLOCK*8);
    assert(map_decoded_length(map_slot(5))==DB_BLOCK && !map_decoded_offset(map_slot(5)));
    for (u32 i=0; i<16; i++)
        if (i!=5) assert(map_same_blob(map_slot(i),&original_group));
    assert(dev->stored_bytes==map_length(&original_group)+map_length(map_slot(5)));
    check_accounting();
    assert(!reboot());
    for (u32 i=0; i<16; i++) check_blocks(i,1,i==5?0x49:0x29);
    assert(!write_blocks(0,5,0));
    assert(!write_blocks(6,10,0));
    assert(dev->stored_bytes==map_length(map_slot(5)));
    check_accounting();
    assert(!reboot());
    check_blocks(5,1,0x49);
    puts("PASS 64KiB sharing, single-decode cache, independent 4KiB overwrite and unique blob accounting");

    fresh(true);
    dev->stage.count=16;
    memset(dev->raw,0x43,DB_REGION); memset(dev->raw,0,DB_BLOCK);
    for (u32 i=0; i<16; i++) dev->stage.logical[i]=i;
    assert(!commit_staged(dev->capacity));
    assert(!map_slot(0)->location && map_decoded_length(map_slot(1))==DB_REGION);
    assert(dev->stored_bytes==map_length(map_slot(1)));
    assert(!reboot());
    check_blocks(0,1,0); check_blocks(1,15,0x43);
    puts("PASS zero first subblock stays unmapped inside a shared compression group");

    fresh(true);
    dev->stage.count=1; dev->stage.logical[0]=1;
    fill_random(dev->raw,DB_BLOCK,0x71933511);
    u32 raw_crc=checksum(dev->raw,DB_BLOCK);
    assert(!commit_staged(dev->capacity));
    assert(!map_compressed(map_slot(1)) && map_decoded_length(map_slot(1))==DB_BLOCK);
    assert(!reboot()); assert(!read_map_value(map_slot(1),dev->raw));
    assert(checksum(dev->raw,DB_BLOCK)==raw_crc);
    puts("PASS incompressible independent 4KiB raw fallback");

    fresh(true);
    dev->stage.count=2; dev->stage.logical[0]=1; dev->stage.logical[1]=2;
    memset(dev->raw,0x25,DB_BLOCK);
    fill_random(dev->raw+DB_BLOCK,DB_BLOCK,0x71491125);
    raw_crc=checksum(dev->raw+DB_BLOCK,DB_BLOCK);
    assert(!commit_staged(dev->capacity));
    assert(!map_compressed(map_slot(2)) && ((u32)map_slot(2)->location)%DB_BLOCK);
    assert(!write_blocks(1,1,0));
    assert(!reboot());
    assert(!read_map_value(map_slot(2),dev->raw) && checksum(dev->raw,DB_BLOCK)==raw_crc);
    assert(!write_blocks(2,1,0));
    assert(!reboot() && !dev->mapped_blocks);
    puts("PASS packed raw fallback crossing two allocation pages survives neighboring discard");

    fresh(true);
    assert(!write_blocks(0,16,0x31));
    struct db_value invalid; map_to_disk(map_slot(0), &invalid);
    decompressions=0;
    invalid.length=U32_MAX;
    assert(read_value(&invalid,dev->raw)==-EUCLEAN);
    map_to_disk(map_slot(0), &invalid); invalid.decoded_length=U32_MAX;
    assert(read_value(&invalid,dev->raw)==-EUCLEAN);
    map_to_disk(map_slot(0), &invalid); invalid.decoded_offset=DB_REGION;
    assert(read_value(&invalid,dev->raw)==-EUCLEAN);
    map_to_disk(map_slot(0), &invalid); invalid.version=U64_MAX;
    assert(read_value(&invalid,dev->raw)==-EUCLEAN);
    assert(!decompressions);
    assert(!valid_part_limit(DB_MIN_PART_LIMIT-DB_BLOCK));
    assert(valid_part_limit(DB_MIN_PART_LIMIT) && valid_part_limit(DB_DEFAULT_PART_LIMIT));
    assert(!valid_part_limit(DB_DEFAULT_PART_LIMIT+DB_BLOCK) && !valid_part_limit(DB_MIN_PART_LIMIT+1));
    puts("PASS malformed blob lengths/offsets/versions reject before decode, part-cap bounds");

    fresh(false);
    /* Cold mappings populate many leaves and all internal levels. */
    for (u32 i=0; i<128; i++) assert(!write_blocks(i*64,1,0x15));
    assert(dev->tree_pages>128);
    struct db_pointer cold=*tree_pointer(node_index(0,127*64));
    tree_writes=0; write_bytes=0;
    assert(!write_blocks(0,1,0x51));
    assert(tree_writes==4 && write_bytes==8*DB_BLOCK);
    assert(!memcmp(&cold,tree_pointer(node_index(0,127*64)),sizeof(cold)));
    tree_writes=0;
    assert(!write_blocks(8191,32,0x61));
    assert(tree_writes<=7);
    dev->stage.count=0; tree_writes=0;
    assert(!commit_staged(DB_LIMIT));
    assert(tree_writes==0);
    assert(!write_blocks(DB_LIMIT/DB_BLOCK-1,1,0x73));
    assert(!reboot());
    check_blocks(DB_LIMIT/DB_BLOCK-1,1,0x73);
    check_blocks(127*64,1,0x15);
    check_blocks(8191,32,0x61);
    check_accounting();
    puts("PASS constant dirty-path write bound with cold leaves, parent boundary, grow and 512GiB top index");

    fresh(false);
    dev->stage.count=0; assert(!commit_staged(DB_LIMIT));
    for (u32 pass=0; pass<3; pass++) {
        dev->stage.count=32;
        for (u32 i=0; i<32; i++) dev->stage.logical[i]=(u64)i<<20;
        memset(dev->raw,0x64+pass,DB_IO);
        tree_writes=0;
        assert(!commit_staged(dev->capacity));
        assert(tree_writes==97 && dev->stage.nr_dirty==97);
        assert(!reboot());
        for (u32 i=0; i<32; i++) check_blocks(i<<20,1,0x64+pass);
        check_accounting();
    }
    puts("PASS worst-case 32 scattered mappings: 97 dirty nodes, every root branch, rollover and reuse");

    fresh(false);
    unsigned int created_before=creations, removed_before=removals;
    for (u32 i=0; i<768; i+=32) assert(!write_blocks(i,32,0x41));
    assert(creations>=created_before+3);
    assert(physical_total()>2*dev->part_limit);
    assert(!reboot());
    check_blocks(0,768,0x41);
    for (u32 i=0; i<640; i+=32) {
        assert(!write_blocks(i,32,0));
        assert(!collect_part());
    }
    for (u32 i=0; i<4; i++) assert(!collect_part());
    assert(removals>removed_before);
    assert(!reboot());
    check_blocks(0,640,0); check_blocks(640,128,0x41);
    for (u32 i=0; i<768; i+=32) assert(!write_blocks(i,32,0x62));
    assert(!reboot()); check_blocks(0,768,0x62);
    check_accounting();
    puts("PASS real 1MiB capped rollover, discard/collection, part removal/recreation and cap enforcement");

    fresh(true);
    /* Pin a cold leaf on part 0 while its payload lives elsewhere. */
    dev->avoid_part=0;
    assert(!write_blocks(0,16,0x38));
    dev->avoid_part=-1;
    dev->gc_node=node_index(0,0); dev->stage.count=0;
    assert(!commit_staged(dev->capacity)); dev->gc_node=DB_NO_NODE;
    assert(part_id(tree_pointer(node_index(0,0))->location)==0);
    for (u32 i=64; i<384; i+=32) {
        dev->avoid_part=1;
        assert(!write_blocks(i,32,0x57));
        dev->avoid_part=-1;
    }
    for (u32 i=64; i<384; i+=32) assert(!write_blocks(i,32,0));
    /* Add unreachable durable tail to model reclaimable post-crash allocation. */
    struct file *f0=&files[0];
    ensure(f0,dev->part_limit/2);
    f0->inode.size=dev->part_limit/2;
    assert(!vfs_fsync(f0,0));
    assert(!collect_part());
    assert(part_id(tree_pointer(node_index(0,0))->location)!=0);
    assert(!reboot()); check_blocks(0,16,0x38);
    check_accounting();
    puts("PASS automatic cold tree-node evacuation independent of victim payload ownership");

    fresh(true);
    for (u32 i=0; i<1536; i+=16) assert(!write_blocks(i,16,0x33));
    for (u32 i=0; i<1536; i+=16) assert(!write_blocks(i,1,0x44));
    u64 bytes_before_gc=dev->stored_bytes;
    assert(!collect_part());
    assert(dev->stored_bytes==bytes_before_gc);
    assert(!reboot());
    for (u32 i=0; i<1536; i+=16) {
        check_blocks(i,1,0x44); check_blocks(i+1,15,0x33);
    }
    check_accounting();
    puts("PASS GC preserves partially overwritten shared blobs without encoded-byte inflation");

    fresh(true);
    for (u32 i=0; i<1536; i+=16) assert(!write_blocks(i,16,0x33));
    u64 stable_generation=dev->generation;
    for (u32 i=0; i<8; i++) assert(!collect_part());
    assert(dev->generation==stable_generation);
    assert(!reboot()); stable_generation=dev->generation;
    for (u32 i=0; i<8; i++) assert(!collect_part());
    assert(dev->generation==stable_generation);
    puts("PASS no GC churn on already packed compressed regions, including after recovery");

    fresh(false);
    assert(!write_blocks(0,1,0x25));
    struct db_pointer previous_leaf=*tree_pointer(node_index(0,0));
    u8 stale_page[DB_BLOCK];
    memcpy(stale_page,files[part_id(previous_leaf.location)].durable+(u32)previous_leaf.location,DB_BLOCK);
    assert(!write_blocks(0,1,0x26));
    struct db_pointer current_leaf=*tree_pointer(node_index(0,0));
    memcpy(files[part_id(current_leaf.location)].durable+(u32)current_leaf.location,stale_page,DB_BLOCK);
    assert(reboot()==-EUCLEAN);
    puts("PASS checksum-valid stale leaf cannot satisfy a newer generation/CRC-bound edge");

    fresh(false);
    assert(!write_blocks(0,1,0x25));
    loc=dev->root->tree.location;
    struct db_node *cycle=(void *)(files[part_id(loc)].durable+(u32)loc);
    cycle->children[0]=dev->root->tree;
    seal(cycle);
    dev->root->tree.crc=cycle->crc;
    seal(dev->root);
    memcpy(files[0].durable+DB_BLOCK,dev->root,DB_BLOCK);
    memcpy(files[0].durable+2*DB_BLOCK,dev->root,DB_BLOCK);
    assert(reboot()==-EUCLEAN);
    puts("PASS valid-CRC tree alias/cycle rejected without recovery writes");

    fresh(true);
    u8 *mirror=calloc(1024,DB_BLOCK);
    assert(mirror);
    rng=0x1833d37b;
    for (u32 step=0; step<1200; step++) {
        rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
        u32 blocks=step%3==0?16:step%3==1?1:32;
        u32 first=rng%(1024-blocks+1);
        if (!(step%4)) first=round_down(first,DB_SUBBLOCKS);
        assert(!collect_part());
        dev->stage.count=blocks;
        for (u32 i=0; i<blocks; i++) dev->stage.logical[i]=first+i;
        if (!(step%11)) fill_random(dev->raw,blocks*DB_BLOCK,rng);
        else memset(dev->raw,step%5 ? (step%251)+1 : 0,blocks*DB_BLOCK);
        memcpy(mirror+first*DB_BLOCK,dev->raw,blocks*DB_BLOCK);
        tree_writes=0;
        assert(!commit_staged(dev->capacity) && tree_writes<=7);
        if (!(step%25)) {
            check_accounting();
            assert(!reboot());
            for (u32 i=0; i<1024; i++) {
                assert(!read_map_value(map_slot(i),dev->raw));
                assert(!memcmp(dev->raw,mirror+i*DB_BLOCK,DB_BLOCK));
            }
        }
        assert(physical_total()<16*dev->part_limit);
    }
    assert(!reboot()); check_accounting();
    for (u32 i=0; i<1024; i++) {
        assert(!read_map_value(map_slot(i),dev->raw));
        assert(!memcmp(dev->raw,mirror+i*DB_BLOCK,DB_BLOCK));
    }
    free(mirror);
    puts("PASS 1200 mixed-size/entropy overwrite-discard operations with GC, accounting, bounded storage and reattach");

    fresh(false);
    dev->generation=U64_MAX; dev->stage.count=0;
    assert(commit_staged(dev->capacity)==-EIO && dev->fenced);
    puts("PASS generation exhaustion fences without wrapping publication");
    reset_ram();
    for (u32 i=0; i<DB_PARTS; i++) { free(files[i].bytes); free(files[i].durable); }
    free(dev->root); free(dev->other_root); free(dev->header); free(dev->transaction);
    free(dev->raw); free(dev->packed); free(dev->scratch); free(dev->decoded); free(dev->tree_index); free(dev->tree_stack);
    return 0;
}

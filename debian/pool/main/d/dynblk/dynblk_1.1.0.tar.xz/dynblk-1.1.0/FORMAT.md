# Dynblk Self-Contained Format 1

Format 1 for Linux 6.12 uses 4096-byte metadata pages. No alternate reader or
migration path is defined. Containers must be opened only by software that
implements this format revision.

## Geometry And Namespace

A control attachment names an absolute private `.../volume000.db` path. Create
exclusively creates a new volume; load opens an existing one without overriding
stored geometry. Create capacity defaults to 17179869184 (16 GiB), is a positive
4096 multiple, and has maximum 549755813888 (512 GiB). The create-time part cap
applies to EVERY part: positive 4096 multiple from 1048576 (1 MiB) through
4194304000 (4000 MiB), default 4000 MiB. The cap includes header, roots, tree
nodes, transactions and payload; there is no online part-cap change or clamping.

Only volume000.db exists initially: 12288 bytes, header plus two root pages.
Sibling parts volume001.db through volume063.db are created on demand. Every
part is self-contained binary storage; no JSON, external manifest, journal file,
or userspace compactor. Small caps permit genuine rollover/GC testing without
changing any block/tree/allocation constants. Virtual capacity is thin, not a
promise of RAM, host free space or writable bytes.

Logical blocks and COW overwrite granularity are 4096 bytes. Compression regions
are aligned 65536-byte logical ranges (16 subblocks). Payload packing allocations
are at most 65536 bytes, rounded to 4096; never round each compressed subblock
separately. Maximum block request is 131072 bytes (32 logical blocks).

## Compression

`algorithm` selects `none` (create default), `lz4`, `lz4hc`, `lzo`, `lzo-rle`,
`zstd`, `deflate`, or `842`. Existing headers supply it; explicit conflicts fail.
Names are exact kernel crypto provider names. Unavailable transforms fail rather
than substitute. In particular, 842 is disabled in the 6.12.107 build target.
No private codec or zcomp backend is copied. The driver uses exported synchronous
crypto_comp APIs; zcomp itself is private in Linux 6.12.

With compression enabled, any complete aligned 64 KiB range present in one
incoming write is compressed as one blob. Each nonzero 4 KiB subblock has its own
mapping, decoded offset and original checksum, referencing that blob. A partial
write compresses only its submitted 4 KiB blocks, without reading or rewriting
neighboring subblocks. A 64 KiB blob remains immutable while any member survives.
All-zero subblocks are unmapped, including zeros inside a newly compressed group.
If group compression is not smaller, fallback is individual 4 KiB records;
subsequent subblocks may still compress individually. With `none`, all nonzero
records remain raw 4 KiB, never raw 64 KiB blobs.

One worker-local decoded-blob cache avoids decompressing a shared blob sixteen
times during sequential reads. Its key includes location, version, encoded CRC,
length, decoded length and flags. Full encoded CRC is checked before decode;
each returned 4 KiB slice is checked against its own original CRC. Cache state
is invalidated on successful publication and recovery. Scratch/decode buffers
are preallocated (128 KiB/64 KiB); malformed lengths cannot drive allocations.

## Binary Layouts

All disk integers are little endian. Reserved bytes, unused entries and null
pointers are all zero. IEEE CRC32 is `crc32_le(~0U, data, length) ^ ~0U`, matching
zlib.crc32. Every metadata page has its CRC at 4092 over bytes 0..4091. CRCs are
not authentication or rollback protection against restoration of an entire old
volume. Locations are u64: high 32 bits part ID, low 32 bits byte offset. Zero
is null; metadata locations are 4096 aligned. Payload locations may be unaligned.
Part 0 payload/tree/transaction offsets start at 12288; other parts start at 4096.

All C structures are packed and have build-time size assertions.

### Part Header

At offset 0 in every part, 4096 bytes, `<8s16sQIIQ16s4028sI`:

| Offset | Bytes | Field |
| --- | --- | --- |
| 0 | 8 | magic `DBPART01` |
| 8 | 16 | volume UUID |
| 24 | 8 | nonzero random incarnation, newly chosen on exclusive recreation |
| 32 | 4 | part ID, 0..63 |
| 36 | 4 | format = 1 |
| 40 | 8 | common part limit, including all metadata |
| 48 | 16 | algorithm name, NUL padded |
| 64 | 4028 | reserved |
| 4092 | 4 | CRC |

Part 0's header is immutable, not duplicated. Damage there fails attachment.
Existing siblings, including inactive candidates, must have complete matching
headers and fit their cap. Foreign/partial headers are preserved and reject;
ownership is not guessed. Missing inactive siblings are normal, not created on
attach. A valid inactive same-volume candidate can be reclaimed after recovery.

### Metadata Pointer

24 bytes, `<QQII`: location u64, expected generation u64, expected page CRC u32,
reserved u32. A null pointer is all 24 zero bytes. A present pointer has nonzero
generation and valid metadata location. Every edge binds BOTH generation and
CRC, so an old checksum-valid page at a reused address cannot masquerade as the
expected child. The root's transaction pointer binds its publishing generation;
the tree pointer may be older after a capacity-only transaction.

### Root

Identical 4096-byte copies in part 0 at offsets 4096 (A) and 8192 (B):

| Offset | Bytes | Field |
| --- | --- | --- |
| 0 | 8 | magic `DBROOT01` |
| 8 | 16 | UUID |
| 24 | 8 | generation, initially 1 |
| 32 | 8 | virtual capacity bytes |
| 40 | 24 | tree root metadata pointer |
| 64 | 24 | transaction metadata pointer |
| 88 | 8 | live logical mapping count |
| 96 | 4 | current reachable tree page count |
| 100 | 4 | tree height = 4 |
| 104 | 512 | 64 incarnation u64 values; precisely active parts, including part 0 |
| 616 | 3476 | reserved |
| 4092 | 4 | CRC |

Initial root: null tree/transaction, zero mappings/tree pages, only incarnation[0]
set. Later roots always name a transaction, even for an empty map. Missing active
parts or mismatching incarnations are corruption, never unallocated zero ranges.

### Mapping Value

40 bytes, `<QQIIIIII`:

| Offset | Bytes | Field |
| --- | --- | --- |
| 0 | 8 | payload location |
| 8 | 8 | blob version (publishing generation) |
| 16 | 4 | encoded length |
| 20 | 4 | encoded CRC over the complete blob |
| 24 | 4 | original CRC over this logical 4096-byte block |
| 28 | 4 | flags: 0 raw, 1 compressed |
| 32 | 4 | decoded length: 4096 or 65536 |
| 36 | 4 | decoded offset of this subblock |

Raw: length=decoded length=4096, offset=0. Compressed: 1 <= encoded length <
decoded length. For 4096 decoded bytes, offset=0; for 65536, offset must equal
`(logical_block % 16)*4096`. Blob version is nonzero and at most the containing
leaf generation. An absent mapping is all 40 zero bytes. Shared 64 KiB mappings
within a logical region must agree on location, version, encoded length/CRC,
decoded length and flags. There is at most one shared blob per logical region;
independent 4 KiB replacements may coexist with its surviving members.

### Radix Node

4096 bytes: prefix `<8s16sQQII16s` (64 bytes), body[4028], CRC u32.
Prefix fields: magic `DBTREE01`, UUID, generation, base logical block index,
level u32 (0 leaf through 3 root), nonzero entry count u32, reserved[16].

Level 0 body starts with 64 mapping values (2560 bytes); remaining 1468 bytes
are zero. Slot i represents base+i. Higher levels start with 128 metadata
pointers (3072 bytes); remaining 956 bytes are zero. Child i has level-1 and base
`base + i * 2^(6+7*(level-1))`. Node span is `2^(6+7*level)` logical blocks.
Count equals the number of nonnull values/pointers, not a high-water slot.
Empty nodes are omitted, with null parent edges. Entries beyond capacity are
zero. Child generation is at most parent generation; pointer generation/CRC
must exactly match the child page. Root node always has level 3 and base 0.

The 512 GiB maximum uses the complete height-4 address space: 2097152 leaves,
16384 level-1 nodes, 128 level-2 nodes and one level-3 node, at most 2113665 tree
pages. No recursive depth, index or payload length is obtained unchecked from disk.

### Transaction

4096 bytes. Prefix `<8s16sQQQII` (56 bytes): magic `DBTXN001`, UUID, generation,
previous generation, resulting capacity, count u32 (0..32), reserved u32.
Then 32 entries of 48 bytes: logical u64 plus mapping value[40]; entries start
at 56, padding[2500] starts at 1592, CRC at 4092. Entries strictly increase and
unused entries are zero. All-zero values delete mappings. The tree already
includes these effects; recovery checks every entry against it. Capacity-only
and tree-GC-only transactions may have zero entries. No unreferenced log tail is
replayed and no historical transaction chain is needed for recovery.

## COW Publication

1. Reserve sparse RAM leaf slots. Stage at most 32 mappings and new packed payload
   allocations, never overwriting current reachable bytes.
2. Rewrite only dirty leaves and their ancestor paths, children first, plus one
   transaction page. Unchanged nodes remain referenced in place. Delete empty
   paths instead of serializing empty leaves.
3. Fsync materialized parts. New-part header/file and pinned-parent creation
   barriers have already completed before any pointer can be published.
4. Write root A and fsync part 0; then write identical root B and fsync part 0.
5. Publish RAM accounting and release superseded payload/node/transaction page
   references ONLY after BOTH root barriers. Before that, both histories stay
   allocated. Any I/O error fences mutations and flushes until reattachment.

A one-block update writes at most four tree pages, one transaction and two roots,
not the full mapping table. A contiguous 128 KiB request touches at most two
leaves and at most seven tree pages. The defensive staging bound is 128 dirty
nodes for arbitrary 32-entry batches. Growth with no mapping change writes no
tree nodes. There is no full-map serialization or full-RAM-map sweep per commit.

Recovery selects the highest valid root; inconsistent equal generations,
generation gaps above one between valid roots, and checksum-valid malformed
roots reject. It validates the entire selected tree, transaction, all active
incarnations, encoded payloads and logical checksums. Node aliases/cycles and
metadata/payload page aliases reject. Damaged selected data does NOT trigger
stale-root fallback. Only after complete validation does recovery republish the
selected root to BOTH slots, separately fsynced, before reuse or truncation.

## Allocation And Collection

Page reference counts cover current tree/transaction pages and all live payload
members, including shared-blob and packed-page sharing. Old references remain
reserved during publication. Stored-byte accounting charges a shared encoded
blob once to its first surviving logical member, not sixteen times.

Before each nonempty write/discard, synchronous automatic GC may choose one part
with at least 256 KiB non-header file span and predicted compacted physical bytes
<=75% of that span. The prediction simulates the collector's per-region packing,
including blob deduplication, 64 KiB allocation boundaries and 4 KiB rounding,
then adds current tree/transaction pages. It is updated only for changed logical
regions and rebuilt during recovery. Encoded-byte density alone is NOT used:
unavoidable padding must not cause repeated evacuation of already compact parts.
It evacuates live payload by complete logical regions,
preserving encoded bytes and sharing; it does not inflate a compressed group
into sixteen independently recompressed records. It then relocates cold tree
nodes with bounded dirty-path transactions, and the latest transaction if needed.
The victim is excluded from all allocations during evacuation. Unreferenced
tails are truncated and empty nonzero parts unlinked only after dual-root
publication; removal fsyncs the pinned parent. Root/header pages in part 0 stay.
GC is synchronous and may delay requests, but never rewrites the whole map on
each relocation. A surviving subblock retains its complete shared encoded blob.

The last two part IDs are withheld from ordinary payload allocation for tree/GC
workspace. Ordinary transactions also require vfs_statfs available bytes >=
`L + 2*131072 + 2*129*4096 + 2*65*C`, where L is the largest predicted compacted
part footprint capped at part_limit, and C is positive f_bsize, at most 32 MiB.
GC may consume that headroom. This is conservative admission, not fallocate or
a quota/filesystem reservation; external space consumers and host errors can
still exhaust it. ENOSPC fences honestly, without zero substitution or an
unbounded GC retry loop. Even discard/grow may fail headroom admission.

## Block ABI

Loading the module registers the root-only `/dev/dynblk-control` misc device but
does not attach storage. ATTACH creates or loads one format-1 volume and allocates
the lowest free block name in the `/dev/dynblk0` through `/dev/dynblk255` numeric
namespace; the global fixed-tree-index memory budget may reject attachment before
all names are used. Independent volumes may coexist. DETACH removes exactly one
whole disk. Attached devices pin the module, so ordinary module removal succeeds
only after all devices detach. Whole-disk and partition opens are counted; DETACH
returns EBUSY while either is open. Fenced devices are still detachable: teardown
may skip/abandon final sync, after which authoritative recovery is required on the
next attach.

Each `/dev/dynblkN` supports READ/WRITE/FLUSH/PREFLUSH/FUA and 4096-aligned
DISCARD. Partition scanning is enabled: ordinary MBR/GPT bytes stored in the
logical address space produce kernel partition devices such as `/dev/dynblk0p1`.
Dynblk-private GET/GROW ioctls are accepted only on the whole disk. NOWAIT,
polling, atomic requests, online codec/cap changes and upper-filesystem resize
are unsupported. Each device has one ordered reclaim-capable worker, 128 blk-mq
tags and a maximum 128 KiB request; workers and mutation ioctls use NOIO context.

The queue advertises `max_hw_discard_sectors=256` (128 KiB) and
`discard_granularity=4096`. Linux 6.12 derives the software discard limit from the hardware limit;
setting only max_discard_sectors leaves discard disabled during queue validation.
BLKDISCARD must exercise REQ_OP_DISCARD, not a zero-write workaround. Queue
advertisement and real block ioctl dispatch are separate from storage-engine
discard tests.

GET `_IOR(0xd7,0,struct dynblk_status)` = **0x8080d700**, 128 bytes,
`=II16s16sQQQQQQIIIIQQQ`:

| Offset | Field |
| --- | --- |
| 0 | version u32 = 1 |
| 4 | flags u32, bit 0 fenced |
| 8 | UUID[16] |
| 24 | algorithm[16] |
| 40 | capacity bytes u64 |
| 48 | original live logical bytes u64 = mappings*4096 |
| 56 | uniquely retained encoded blob bytes u64, including raw fallback |
| 64 | physical bytes u64 = sum file lengths, NOT allocated host sectors |
| 72 | generation u64 |
| 80 | actual common part limit u64 |
| 88 | active part count u32 |
| 92 | logical block size u32 = 4096 |
| 96 | max part count u32 = 64 |
| 100 | tree height u32 = 4 (not a checkpoint period) |
| 104 | resident mapping-leaf plus tree-pointer index bytes u64 |
| 112 | maximum virtual capacity u64 = 549755813888 |
| 120 | compression region bytes u64 = 65536 |

GROW `_IOW(0xd7,1,__u64)` = **0x4008d701**, pointer to absolute native u64
capacity. Requires initial-namespace CAP_SYS_ADMIN and writable whole-disk open.
Equal is a no-op unless fenced; shrink/unaligned/over-limit rejects. No upper
filesystem resize. Unknown block commands return ENOTTY.

Control ABI version 1 uses fixed-layout, pointer-free request structures so the
same ioctl contract is usable by 32- and 64-bit userspace. ATTACH
`_IOWR(0xd7,2,struct dynblk_attach)` = **0xd038d702** carries flags, requested
create geometry/codec, sparse-map budget and a NUL-terminated absolute path; the
kernel returns both the allocated device index and a random nonzero 64-bit
attachment cookie. A load request must leave create-only fields and input cookie
zero. Whole-disk COOKIE `_IOR(0xd7,4,__u64)` = **0x8008d704** exposes the current
attachment cookie. DETACH `_IOW(0xd7,3,struct dynblk_detach)` = **0x4010d703**
carries device index plus cookie; the kernel validates both together under the
device registry lock, so reuse of a lowest-free index cannot detach a replacement
volume. ATTACH and DETACH require CAP_SYS_ADMIN in the initial user namespace.

## Lower Filesystem Admission

Initial-user-namespace root controller; regular single-link root-owned backing
files with no untrusted write access; exclusive cooperative flock. Every ancestor
and the pinned parent must be root-owned, non-idmapped and resolved without
symlinks or dot components. Root-group-writable directories are trusted, and a
root-owned world-writable ancestor is accepted only when it is a sticky directory;
the final backing file itself may not be world-writable. Before create, the kernel
checks the pinned parent under captured credentials and requires every conventional
part name `volume000.db` through `volume063.db` to be absent; part 0 is then opened
with O_CREAT|O_EXCL. Captured credentials govern lazy creation/removal/truncation.
Outside writers, renames/remounts and indirect storage dependency on dynblk are
forbidden. FAT/exFAT ownership/masks must comply.

Accepted conventional names: ext4, ext2, vfat, exfat, ntfs3. Local s_bdev is required; host
block B and lower logical/physical sectors L/P are 512..4096, 4096%B=0,
B%L=B%P=0, alignment offset=0, and stored limit <= filesystem s_maxbytes.
Availability of an ext2 module is an environment matter, not a format condition.
On kernels with `CONFIG_EXT2_FS` unset and `CONFIG_EXT4_USE_FOR_EXT2=y`, an
ext2-formatted filesystem is handled by the ext4 driver; this is not native ext2
driver support. FAT, exFAT and ext2 are non-journaled, so their allocation and
directory durability remain properties of the lower filesystem and storage.

ntfs3 requires vfs_fileattr_get with flags_valid=true as its input selector and
a valid flags result. FS_COMPR_FL (including native/WOF compression),
FS_ENCRYPT_FL, FS_IMMUTABLE_FL and FS_APPEND_FL reject. A successful four-byte
`system.ntfs_attrib` query is additionally required; sparse/reparse/compressed/
offline/encrypted bits (mask 0x5e00) reject conservatively. Both checks apply to
backing files and the destination parent. Existing files are inspected with
O_PATH BEFORE any writable open; dentry_open then uses that same pinned inode
path, not a reopened filename followed by a late comparison. The parent is
rechecked before each exclusive creation; new files are checked before writing
their headers. This prevents inherited compression and avoids writable-open
conversion of external compression on kernels which implement that path.

The pinned 6.12.107 target uses ntfs_file_fsync, not the older generic_file_fsync
assignment, and CONFIG_NTFS3_LZX_XPRESS is unset. Those target details do not
replace the pre-open checks. References: Linux v6.12.107
[ntfs3/file.c](https://git.kernel.org/pub/scm/linux/kernel/git/stable/linux.git/tree/fs/ntfs3/file.c?h=v6.12.107),
[ntfs3/xattr.c](https://git.kernel.org/pub/scm/linux/kernel/git/stable/linux.git/tree/fs/ntfs3/xattr.c?h=v6.12.107),
[ext2/file.c](https://github.com/torvalds/linux/blob/v6.12/fs/ext2/file.c).

Btrfs has a DISTINCT buffered-VFS/COW/fsync admission contract. It requires the
exact filesystem name btrfs, BTRFS_SUPER_MAGIC, s_blocksize=4096, and s_maxbytes
>= the part limit. Its branch never dereferences s_bdev: an anonymous superblock
created through set_anon_super_fc normally has no generic backing block device.
The parent and every part must pass vfs_fileattr_get with flags_valid=true and
a valid flags result, rejecting FS_NOCOW_FL, FS_IMMUTABLE_FL and FS_APPEND_FL.
The same O_PATH-before-write and new-file-before-header checks apply. Native
Btrfs compression is allowed; NOCOW is not.

This contract relies on Btrfs preserving previously committed logical file bytes
and making buffered file/directory changes durable through vfs_fsync. It does
not assert hardware 4 KiB atomicity or validate every physical member's geometry.
There is no exported generic interface here to inspect Btrfs' private fs_devices
list. Consequently, SINGLE-DEVICE-ONLY IS NOT ENFORCED by the kernel driver.
The supported Btrfs scope is an operator-provisioned single-device filesystem.
Multidevice configurations are not detected or rejected by dynblk. Avoid degraded
operation, device-topology changes, backing-file attribute changes, and any
underlying dependency on dynblk while a volume is attached.

## Memory And Validation

The on-disk leaf remains 64 × 40-byte mapping values, but runtime representation
is independent of that layout. One sparse 4096-byte runtime allocation covers 128
logical blocks and stores compact 28-byte values plus the two corresponding
on-disk leaf pointers. Dense mappings therefore cost 8 MiB per GiB of mapped
logical data: fully mapped 16 GiB needs 128 MiB, 32 GiB needs 256 MiB and the
512 GiB format ceiling needs 4096 MiB of mapping chunks. `map_memory_mb=0` means
an automatic budget of approximately 25% of RAM: the kernel-reported usable
memory is rounded up to the next 64-MiB boundary first, compensating the normal
reserved-memory gap on 512-MiB/1-GiB-class systems, then capped at 4096 MiB. An
explicit attach value may select 1..4096 MiB. Recovery also obeys this ceiling: an
existing volume requiring more resident mapping chunks fails attachment with ENOSPC.
The fixed dense tree-pointer index stores only the 16,513
level-1..3 nodes, using 396,312 bytes per attachment. Level-0 pointers are sparse
and resident with their runtime mapping chunks. The module parameter
`tree_index_budget_mb`, default 4, remains a global admission ceiling for the
fixed internal indexes and admits ten attached devices at the default value.

Per-part page-reference counters are sparse as well. A 4096-byte `u16` counter
chunk covers 2048 physical pages, or 8 MiB of backing space, and is materialized
only when that range contains reserved/live pages. A small occupancy table (500
`u16` counters, 1000 bytes, for a default 4000-MiB part) tracks the number of
nonzero entries in each counter chunk, so a chunk is reclaimed immediately when
its final reference is cleared instead of requiring a full post-commit scan.
Other bounded scratch, request, VFS, XArray and allocator overhead is additional. Recovery still traverses and checks the full live tree and
payload; attachment is not O(1).

The full userspace checker admits at most 2113665 tree pages plus one transaction
page. Its metadata identity table has 2^23 slots, is compile-time constrained to
at most 50% load at that ceiling, and linear probing is explicitly bounded so a
malformed or future oversized input cannot turn table saturation into an infinite
loop.

The source tree includes userspace, storage/admission and VM tests. Source-level
harnesses substitute selected kernel interfaces and therefore do not by themselves
exercise real VFS, blk-mq, filesystem, codec-provider or power-loss behavior.
Use the VM scenarios under `tests/vm/` when validating those integration paths.

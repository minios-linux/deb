/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DYNBLK_UAPI_H
#define DYNBLK_UAPI_H

#include <linux/ioctl.h>
#include <linux/types.h>

#define DYNBLK_ABI_VERSION 1U
#define DYNBLK_BLOCK_SIZE 4096U
#define DYNBLK_MAX_PARTS 64U
#define DYNBLK_TREE_HEIGHT 4U
#define DYNBLK_COMPRESSION_REGION 65536ULL
#define DYNBLK_MAX_CAPACITY (128ULL << 30)

struct dynblk_status {
	__u32 version, flags;
	__u8 uuid[16], algorithm[16];
	__u64 capacity, original_bytes, stored_bytes, physical_bytes;
	__u64 generation, part_limit;
	__u32 active_parts, block_size, max_parts, tree_height;
	__u64 map_memory_bytes, max_capacity, compression_region_bytes;
};

#define DYNBLK_GET _IOR(0xd7, 0, struct dynblk_status)
#define DYNBLK_GROW _IOW(0xd7, 1, __u64)

#endif

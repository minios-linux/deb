/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DYNBLK_UAPI_H
#define DYNBLK_UAPI_H

#include <linux/ioctl.h>
#include <linux/types.h>

#define DYNBLK_ABI_VERSION 1U
#define DYNBLK_BLOCK_SIZE 4096U
#define DYNBLK_MAX_PARTS 64U
#define DYNBLK_TREE_HEIGHT 4U
#define DYNBLK_COMPRESSION_REGION 65536ULL
#define DYNBLK_MAX_CAPACITY (512ULL << 30)
#define DYNBLK_MAX_DEVICES 256U
#define DYNBLK_PATH_MAX 4096U
#define DYNBLK_CODEC_MAX 16U
#define DYNBLK_ATTACH_CREATE 1U
#define DYNBLK_DEFAULT_MAP_MEMORY_MB 256U
#define DYNBLK_MAX_MAP_MEMORY_MB 8192U

struct dynblk_status {
	__u32 version, flags;
	__u8 uuid[16], algorithm[16];
	__u64 capacity, original_bytes, stored_bytes, physical_bytes;
	__u64 generation, part_limit;
	__u32 active_parts, block_size, max_parts, tree_height;
	__u64 map_memory_bytes, max_capacity, compression_region_bytes;
};

struct dynblk_attach {
	__u32 version, flags;
	__s32 device;
	__u32 map_memory_mb;
	__u64 size_bytes, part_limit_bytes, cookie;
	__u8 algorithm[DYNBLK_CODEC_MAX];
	__u8 path[DYNBLK_PATH_MAX];
};

struct dynblk_detach {
	__u32 version, device;
	__u64 cookie;
};

#define DYNBLK_GET _IOR(0xd7, 0, struct dynblk_status)
#define DYNBLK_GROW _IOW(0xd7, 1, __u64)
#define DYNBLK_ATTACH _IOWR(0xd7, 2, struct dynblk_attach)
#define DYNBLK_DETACH _IOW(0xd7, 3, struct dynblk_detach)
#define DYNBLK_COOKIE _IOR(0xd7, 4, __u64)

#endif

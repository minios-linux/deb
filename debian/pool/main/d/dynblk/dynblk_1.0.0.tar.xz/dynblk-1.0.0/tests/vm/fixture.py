"""VM-only fixture/ABI assertions, not a dynblk management implementation."""
import fcntl
import os
import struct
import sys
import uuid
import zlib

assert "dynblk_disposable_acceptance=1" in open("/proc/cmdline").read()
if sys.argv[1] == "create":
    volume = uuid.uuid4().bytes
    segments = [(uuid.uuid4().bytes, 12288), (uuid.uuid4().bytes, 192 * 1024**2 + 4096)]
    journal = (uuid.uuid4().bytes, 4000 * 1024**2)
    files = [("/back/meta", 1, bytes(16), 0, 0),
             ("/back/seg0", 2, segments[0][0], 0, segments[0][1]),
             ("/back/journal0", 3, journal[0], 0, journal[1])]
    for path, kind, identity, index, limit in files:
        header = bytearray(4096)
        struct.pack_into("<8sII16s16sIIQQ", header, 0, b"DYNBLK01", 1,
                         kind, volume, identity, index, 2,
                         160 * 1024**2 if kind == 1 else 0, limit)
        if kind == 1:
            struct.pack_into("<I", header, 72, 1)
            for n, (identity, length) in enumerate(segments):
                struct.pack_into("<16sQ", header, 128 + n * 24, identity, length)
            struct.pack_into("<16sQ", header, 1664, *journal)
        struct.pack_into("<I", header, 4092, zlib.crc32(header[:4092]))
        with open(path, "xb") as stream:
            stream.write(header)
            stream.flush()
            os.fsync(stream.fileno())
    fd = os.open("/back", os.O_DIRECTORY)
    os.fsync(fd)
    os.close(fd)
elif sys.argv[1] == "status":
    with open("/dev/dynblk-control", "rb", buffering=0) as stream:
        data = bytearray(64)
        fcntl.ioctl(stream, 0x8040D700, data)
        fields = struct.unpack("<IIQQQQIIQQ", data)
        print("DYNBLK STATUS", fields, flush=True)
        assert fields[0] == 1 and fields[1] == 0
        assert fields[2] == 160 * 1024**2
        assert fields[6] == sum(os.path.exists(path) for path in ("/back/seg0", "/back/seg1"))
        assert fields[7] == 4096
        assert fields[8] % 12288 == 0 and 0 <= fields[8] <= fields[9]
        assert fields[9] == ((4000 * 1024**2 - 4096) // 12288) * 12288
else:
    raise ValueError("unknown fixture command")

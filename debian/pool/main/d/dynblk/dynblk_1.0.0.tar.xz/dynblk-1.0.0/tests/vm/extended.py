"""Disposable VM acceptance for the sole lazy format-1 implementation."""
import concurrent.futures
import errno
import fcntl
import hashlib
import json
import mmap
import os
from pathlib import Path
import shutil
import struct
import subprocess
import threading
import time
import traceback
import zlib

assert "dynblk_extended=1" in Path("/proc/cmdline").read_text()
ROOT = Path("/back")
CLI = "/usr/sbin/dynblk"
DEVICE = "/dev/dynblk0"
B = 4096
SLOT = 12288
MIB = 1024**2
results = {}


def command(*args, success=True):
    print("RUN", *args, flush=True)
    result = subprocess.run(list(map(str, args)), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    print(result.stdout, end="", flush=True)
    print(result.stderr, end="", flush=True)
    assert (result.returncode == 0) == success, (args, result.returncode)
    return result.stdout


def cli(*args, success=True):
    return command(CLI, *args, success=success)


def durable(path, content):
    temporary = str(path) + ".new"
    with open(temporary, "w") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    fd = os.open(Path(path).parent, os.O_DIRECTORY)
    os.fsync(fd)
    os.close(fd)


def record(name, value=True):
    results[name] = value
    durable(ROOT / "results.json", json.dumps(results, indent=2))
    print("PASS", name, value, flush=True)


def config(manifest):
    value = json.loads(manifest.read_text())
    assert set(value) == {"format", "metadata", "segments", "journals"}
    assert value["format"] == "dynblk-1"
    for name in [value["metadata"], *value["segments"], *value["journals"]]:
        assert not Path(name).is_absolute() and ".." not in Path(name).parts
    return value


def inventory(volume):
    files = sorted(volume.rglob("*"))
    assert not any(path.is_symlink() for path in files)
    return {str(path.relative_to(volume)): path.stat().st_size for path in files if path.is_file()}


def hashes(volume):
    assert not Path("/sys/module/dynblk").exists(), "never copy/hash attached backing storage"
    return {name: hashlib.sha256((volume / name).read_bytes()).hexdigest() for name in inventory(volume)}


def selected_files(manifest):
    c = config(manifest)
    return [c["metadata"], *c["segments"], *c["journals"]]


def initial_four(manifest):
    c = config(manifest)
    expected = {manifest.name, c["metadata"], c["segments"][0], c["journals"][0]}
    actual = inventory(manifest.parent)
    assert set(actual) == expected, actual
    assert all(actual[name] == B for name in expected - {manifest.name})
    return actual


def create(name, capacity, data_count=3, data_limit=32768, journal_count=3, journal_limit=B + 10 * SLOT):
    volume = ROOT / name
    args = ("create", volume, "--size", capacity, "--segments", data_count,
            "--segment-limit", data_limit, "--metadata-segments", journal_count,
            "--metadata-segment-limit", journal_limit)
    cli(*args)
    assert not volume.exists()
    cli(*args, "--execute")
    manifest = volume / "volume.json"
    c = config(manifest)
    assert len(c["segments"]) == data_count and len(c["journals"]) == journal_count
    initial_four(manifest)
    before = hashes(volume)
    cli("inspect", manifest)
    assert hashes(volume) == before, "inspect materialized or modified storage"
    return manifest


def kernel_parameters(manifest):
    c = config(manifest)
    return ["metadata=" + str(manifest.parent / c["metadata"]),
            "segments=" + ",".join(str(manifest.parent / name) for name in c["segments"]),
            "journals=" + ",".join(str(manifest.parent / name) for name in c["journals"])]


def load(manifest, budget=None):
    args = ["load", manifest, "--module", "/cli/dynblk.ko", "--execute"]
    if budget is not None:
        args += ["--map-memory-mb", budget]
    cli(*args)
    for _ in range(100):
        if Path(DEVICE).exists() and Path("/dev/dynblk-control").exists():
            return
        time.sleep(.01)
    raise AssertionError("missing device nodes")


def unload():
    cli("unload", "--execute")
    assert not Path("/sys/module/dynblk").exists()


def status():
    value = json.loads(cli("status"))
    assert value["version"] == 1
    assert value["journal_used_bytes"] % SLOT == 0
    assert 0 <= value["journal_used_bytes"] <= value["journal_limit_bytes"]
    return value


def identity(manifest):
    raw = bytearray(6616)
    with open("/dev/dynblk-control", "rb", buffering=0) as stream:
        fcntl.ioctl(stream, 0x99D8D702, raw)
    version, flags, volume, major, minor, inode, reserved, made, journals_made, journals_reserved = struct.unpack_from("=II16sIIQIIII", raw)
    c = config(manifest)
    assert version == 1 and not flags & ~1
    assert reserved == len(c["segments"]) and journals_reserved == len(c["journals"])
    assert made == sum((manifest.parent / name).exists() for name in c["segments"])
    assert journals_made == sum((manifest.parent / name).exists() for name in c["journals"])
    assert 1 <= made <= reserved <= 64 and 1 <= journals_made <= journals_reserved <= 100
    assert not any(raw[56 + reserved * 40:2616]) and not any(raw[2616 + journals_reserved * 40:])
    entries = [struct.unpack_from("=16sQQII", raw, 56 + i * 40) for i in range(reserved)]
    journal_entries = [struct.unpack_from("=16sQQII", raw, 2616 + i * 40) for i in range(journals_reserved)]
    for names, values in ((c["segments"], entries), (c["journals"], journal_entries)):
        for name, entry in zip(names, values):
            path = manifest.parent / name
            if path.exists():
                info = path.stat()
                assert entry[2:] == (info.st_ino, os.major(info.st_dev), os.minor(info.st_dev))
            else:
                assert entry[2:] == (0, 0, 0)
    return {"volume": volume, "data_reserved": reserved, "data_materialized": made,
            "journals_reserved": journals_reserved, "journals_materialized": journals_made,
            "data_entries": entries}


def direct(offset, data=None, length=B, dsync=False):
    fd = os.open(DEVICE, os.O_RDWR | os.O_DIRECT | (os.O_DSYNC if dsync else 0))
    buffer = mmap.mmap(-1, len(data) if data is not None else length)
    try:
        if data is not None:
            buffer[:] = data
            assert os.pwrite(fd, buffer, offset) == len(data)
        else:
            assert os.preadv(fd, [buffer], offset) == length
            return buffer[:]
    finally:
        buffer.close()
        os.close(fd)


def flush():
    fd = os.open(DEVICE, os.O_RDWR)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def io_failure(action):
    try:
        action()
    except OSError as exc:
        assert exc.errno in (errno.EIO, errno.ENOSPC, errno.EFBIG), exc
        print("EXPECTED IO FAILURE", repr(exc), flush=True)
        return exc.errno
    raise AssertionError("IO unexpectedly succeeded")


def bounds(manifest):
    c = config(manifest)
    header = (manifest.parent / c["metadata"]).read_bytes()
    assert len(header) == B and header[:12] == b"DYNBLK01\x01\x00\x00\x00"
    assert struct.unpack_from("<I", header, 52)[0] == len(c["segments"])
    assert struct.unpack_from("<I", header, 72)[0] == len(c["journals"])
    for key, kind, base in (("segments", 2, 128), ("journals", 3, 1664)):
        for i, name in enumerate(c[key]):
            uid, limit = struct.unpack_from("<16sQ", header, base + i * 24)
            path = manifest.parent / name
            if not path.exists():
                continue
            assert B <= path.stat().st_size <= limit
            with open(path, "rb") as stream:
                data = stream.read(B)
            assert data[:12] == b"DYNBLK01\x01\x00\x00\x00"
            assert struct.unpack_from("<I", data, 12)[0] == kind
            assert data[16:32] == header[16:32] and data[32:48] == uid
            assert struct.unpack_from("<II", data, 48) == (i, len(c["segments"]))
            assert struct.unpack_from("<Q", data, 64)[0] == limit
            assert zlib.crc32(data[:4092]) == struct.unpack_from("<I", data, 4092)[0]


def default_16g(lower, label):
    volume = lower / "default-16g"
    cli("create", volume, "--size", "16GiB", "--execute")
    manifest = volume / "volume.json"
    actual = initial_four(manifest)
    c = config(manifest)
    header = (volume / c["metadata"]).read_bytes()
    assert len(c["segments"]) == 5
    for base, names in ((128, c["segments"]), (1664, c["journals"])):
        for index in range(len(names)):
            assert struct.unpack_from("<Q", header, base + 24 * index + 16)[0] == 4000 * MIB
    before = hashes(volume)
    cli("inspect", volume)
    assert hashes(volume) == before
    load(manifest)
    assert inventory(volume) == actual
    assert status()["capacity_bytes"] == 16 * 1024 * MIB
    assert status()["physical_limit_bytes"] == 5 * (4000 * MIB - B)
    for offset, size in ((0, 128 * 1024), (512, 512), (16 * 1024 * MIB - B, B)):
        assert direct(offset, length=size) == bytes(size)
        direct(offset, bytes(size), dsync=True)
    flush()
    assert status()["allocated_blocks"] == status()["journal_records"] == 0
    assert inventory(volume) == actual
    state = identity(manifest)
    assert state["data_materialized"] == state["journals_materialized"] == 1
    unload()
    cli("inspect", manifest)
    assert hashes(volume) == before
    record("initial_16g_four_files_and_zero_io_" + label,
           {"files": actual, "data_reserve": len(c["segments"]), "journal_reserve": len(c["journals"]),
            "file_limit": 4000 * MIB, "logical_capacity": 16 * 1024 * MIB, "userspace_service_started": False})


def allocation_boundaries(lower, label):
    manifest = create(lower / "boundaries", MIB, 3, 32768, 3, B + 10 * SLOT)
    volume, c = manifest.parent, config(manifest)
    load(manifest)
    for index in range(7):
        direct(index * B, bytes([index + 1]) * B, dsync=True)
    seven = inventory(volume)
    assert seven[c["segments"][0]] == 32768 and len(seven) == 4
    direct(7 * B, b"\x08" * B, dsync=True)
    eight = inventory(volume)
    assert eight[c["segments"][1]] == 2 * B and len(eight) == 5
    direct(8 * B, b"\x09" * B, dsync=True)
    assert not (volume / c["journals"][1]).exists()
    direct(9 * B, b"\x0a" * B, dsync=True)
    ten = inventory(volume)
    assert len(ten) == 6 and ten[c["journals"][0]] == B + 10 * SLOT
    assert ten[c["journals"][1]] == B + SLOT
    for index in range(10, 21):
        direct(index * B, bytes([index + 1]) * B, dsync=True)
    flush()
    assert all((volume / name).stat().st_size == 32768 for name in c["segments"])
    report = status()
    assert report["allocated_blocks"] == 21 and report["journal_records"] == 23
    assert report["segment_count"] == 3 and report["physical_limit_bytes"] == 21 * B
    bounds(manifest)
    materialized = identity(manifest)
    assert materialized["journals_materialized"] == 3
    unload()
    before = hashes(volume)
    load(manifest)
    assert set(inventory(volume)) == set(before)
    for index in range(21):
        assert direct(index * B) == bytes([index + 1]) * B
    direct(100 * B, bytes(B), dsync=True)
    assert not status()["write_fenced"]
    io_failure(lambda: direct(0, b"X" * (22 * B)))
    assert status()["write_fenced"]
    io_failure(lambda: direct(100 * B, bytes(B), dsync=True))
    unload()
    assert hashes(volume) == before
    record("automatic_data_and_link_boundaries_" + label,
           {"files_after_7_maps": seven, "files_after_8_maps": eight, "files_after_10_maps": ten,
            "data_file_max": 32768, "journal_file_max": B + 10 * SLOT,
            "maps": 21, "link_records": 2, "no_add_command": True})


def fixture_header(manifest, key, index, payload=b""):
    c = config(manifest)
    root = (manifest.parent / c["metadata"]).read_bytes()
    base, kind = (128, 2) if key == "segments" else (1664, 3)
    uid, limit = struct.unpack_from("<16sQ", root, base + index * 24)
    data = bytearray(B)
    struct.pack_into("<8sII16s16sIIQQ", data, 0, b"DYNBLK01", 1, kind, root[16:32], uid,
                     index, len(c["segments"]), 0, limit)
    struct.pack_into("<I", data, 4092, zlib.crc32(data[:4092]))
    path = manifest.parent / c[key][index]
    with open(path, "xb") as stream:
        stream.write(data + payload)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_DIRECTORY)
    os.fsync(fd)
    os.close(fd)
    return path


def link_slot(manifest, target, generation):
    c = config(manifest)
    root = (manifest.parent / c["metadata"]).read_bytes()
    uid, limit = struct.unpack_from("<16sQ", root, 1664 + target * 24)
    record_bytes = bytearray(64)
    struct.pack_into("<QIIQQ16s", record_bytes, 0, generation, 4, target, limit, 0, uid)
    struct.pack_into("<I", record_bytes, 60, zlib.crc32(record_bytes[:60]))
    data = bytearray(B)
    struct.pack_into("<8s16sQQI", data, 0, b"DBTXN001", root[16:32], generation, generation, 1)
    data[64:128] = record_bytes
    crc = zlib.crc32(data[:4092])
    struct.pack_into("<I", data, 4092, crc)
    output = bytes(data)
    for copy in (1, 2):
        witness = bytearray(B)
        struct.pack_into("<8s16sQQII", witness, 0, b"DBCMT001", root[16:32], generation, generation, crc, copy)
        struct.pack_into("<I", witness, 4092, zlib.crc32(witness[:4092]))
        output += witness
    return output


def rejected_storage(manifest, label):
    before = hashes(manifest.parent)
    cli("inspect", manifest, success=False)
    assert hashes(manifest.parent) == before
    cli("load", manifest, "--module", "/cli/dynblk.ko", "--execute", success=False)
    command("insmod", "/cli/dynblk.ko", *kernel_parameters(manifest), success=False)
    assert not Path("/sys/module/dynblk").exists() and not Path("/sys/class/block/dynblk0").exists()
    assert hashes(manifest.parent) == before, "rejected storage was repaired/recreated"
    record(label)


def recovery_fixtures():
    manifest = create("recovery-base", MIB, 8, 8192, 8, B + 2 * SLOT)
    c, volume = config(manifest), manifest.parent
    load(manifest)
    for index in range(3):
        direct(index * B, bytes([65 + index]) * B, dsync=True)
    assert status()["journal_records"] == 5
    unload()
    baseline = hashes(volume)
    assert len(baseline) == 8
    load(manifest)
    unload()
    assert hashes(volume) == baseline
    record("unused_missing_reserves_load_without_creation")

    for kind in ("missing_mapped_data", "missing_linked_empty_journal", "partial_data_header", "partial_journal_header",
                 "data_gap", "journal_gap", "wrong_data_uuid", "old_data_crc", "earlier_repair_later_corruption"):
        copy = ROOT / kind
        shutil.copytree(volume, copy)
        m = copy / "volume.json"
        if kind == "missing_mapped_data":
            (copy / c["segments"][2]).unlink()
        elif kind == "missing_linked_empty_journal":
            with open(copy / c["journals"][2], "ab") as stream:
                stream.write(link_slot(m, 3, 6))
        elif kind == "partial_data_header":
            (copy / c["segments"][3]).write_bytes(b"partial" * 100)
        elif kind == "partial_journal_header":
            (copy / c["journals"][3]).write_bytes(b"partial" * 100)
        elif kind == "data_gap":
            fixture_header(m, "segments", 4)
        elif kind == "journal_gap":
            fixture_header(m, "journals", 4)
        elif kind == "wrong_data_uuid":
            path = copy / c["segments"][2]
            data = bytearray(path.read_bytes())
            data[32] ^= 1
            struct.pack_into("<I", data, 4092, zlib.crc32(data[:4092]))
            path.write_bytes(data)
        else:
            path = copy / c["journals"][0]
            data = bytearray(path.read_bytes())
            if kind == "old_data_crc":
                data[B + 100] ^= 1
            else:
                data[2 * B + 4092] ^= 1
                latest = copy / c["journals"][2]
                bad = bytearray(latest.read_bytes())
                bad[B + 100] ^= 1
                latest.write_bytes(bad)
            path.write_bytes(data)
        rejected_storage(m, "reject_" + kind)

    for cut in (2048, B + 2048, 2 * B + 2048):
        copy = ROOT / ("link-tear-" + str(cut))
        shutil.copytree(volume, copy)
        m = copy / "volume.json"
        candidate = fixture_header(m, "journals", 3)
        original_inode = candidate.stat().st_ino
        expected = hashes(copy)
        slot = link_slot(m, 3, 6)
        old = (copy / c["journals"][2]).read_bytes()
        (copy / c["journals"][2]).write_bytes(old + slot[:cut])
        torn = hashes(copy)
        report = json.loads(cli("inspect", m))
        assert report["pending_recovery"] and hashes(copy) == torn
        load(m)
        for index in range(3):
            assert direct(index * B) == bytes([65 + index]) * B
        unload()
        if cut > 2 * B:
            expected[c["journals"][2]] = hashlib.sha256(old + slot).hexdigest()
        assert hashes(copy) == expected
        assert candidate.stat().st_ino == original_inode
        load(m)
        direct(3 * B, b"D" * B, dsync=True)
        assert candidate.stat().st_ino == original_inode
        assert direct(3 * B) == b"D" * B
        unload()
        record("recover_interrupted_link_" + str(cut), {"new_journal_reused": True, "link_was_committed": cut > 2 * B})

    copy = ROOT / "data-orphan"
    shutil.copytree(volume, copy)
    m = copy / "volume.json"
    candidate = fixture_header(m, "segments", 3, b"U" * B)
    inode = candidate.stat().st_ino
    before = hashes(copy)
    cli("inspect", m)
    assert hashes(copy) == before
    load(m)
    assert direct(3 * B) == bytes(B), "orphan payload exposed without MAP"
    direct(3 * B, b"D" * B, dsync=True)
    assert candidate.stat().st_ino == inode and direct(3 * B) == b"D" * B
    unload()
    load(m)
    assert direct(3 * B) == b"D" * B
    unload()
    record("orphan_data_reused_by_full_overwrite")

    with open(volume / c["metadata"], "rb") as locked:
        fcntl.flock(locked, fcntl.LOCK_SH | fcntl.LOCK_NB)
        command("insmod", "/cli/dynblk.ko", *kernel_parameters(manifest), success=False)
    before = hashes(volume)
    os.chmod(volume, 0o777)
    try:
        command("insmod", "/cli/dynblk.ko", *kernel_parameters(manifest), success=False)
    finally:
        os.chmod(volume, 0o700)
    assert hashes(volume) == before
    load(manifest)
    unload()
    record("parent_ownership_and_flock_guards")


def backing_enospc():
    manifest = create("backingfull", 64 * MIB, 2, 64 * MIB, 4, 4 * MIB)
    load(manifest)
    direct(0, b"P" * B, dsync=True)
    filler = ROOT / "filler"
    fd = os.open(filler, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    failed = None
    try:
        allocated, chunk = 0, 64 * MIB
        while chunk >= MIB:
            try:
                os.posix_fallocate(fd, allocated, chunk)
                allocated += chunk
            except OSError as exc:
                if exc.errno != errno.ENOSPC:
                    raise
                chunk //= 4
        os.ftruncate(fd, allocated - 2 * MIB)
        os.fsync(fd)
        for offset in range(128 * 1024, 32 * MIB, 128 * 1024):
            try:
                direct(offset, b"Q" * (128 * 1024), dsync=True)
            except OSError as exc:
                failed = exc
                break
    finally:
        os.close(fd)
        filler.unlink()
    assert failed is not None and failed.errno in (errno.EIO, errno.ENOSPC)
    assert status()["write_fenced"] and direct(0) == b"P" * B
    unload()
    load(manifest)
    assert not status()["write_fenced"] and direct(0) == b"P" * B
    unload()
    record("backing_enospc_recovery", str(failed))


def memory_budget():
    manifest = create("memory", 64 * 1024 * MIB, 2, 8 * MIB, 4, 4 * MIB)
    command("insmod", "/cli/dynblk.ko", *kernel_parameters(manifest), "map_memory_mb=1")
    for index in range(256):
        direct(index * 2 * MIB, bytes([index % 255 + 1]) * B, dsync=True)
    io_failure(lambda: direct(512 * MIB, b"Z" * B))
    assert status()["write_fenced"] and status()["allocated_blocks"] == 256
    unload()
    load(manifest)
    direct(512 * MIB, b"Z" * B, dsync=True)
    unload()
    before = hashes(manifest.parent)
    command("insmod", "/cli/dynblk.ko", *kernel_parameters(manifest), "map_memory_mb=1", success=False)
    assert hashes(manifest.parent) == before
    load(manifest)
    assert direct(512 * MIB) == b"Z" * B and status()["capacity_bytes"] == 64 * 1024 * MIB
    unload()
    record("mapping_budget_and_64gib_logical_capacity")


def concurrency():
    manifest = create("concurrent", 8 * MIB, 64, 65536, 32, B + 32 * SLOT)
    load(manifest)
    barrier = threading.Barrier(192)
    stop, maximum = threading.Event(), [0]
    def sample():
        while not stop.is_set():
            maximum[0] = max(maximum[0], sum(map(int, Path("/sys/class/block/dynblk0/inflight").read_text().split())))
            time.sleep(.001)
    def writer(index):
        barrier.wait(timeout=30)
        for turn in range(4):
            direct((index * 4 + turn) * B, bytes([index + 1]) * B)
    sampler = threading.Thread(target=sample)
    sampler.start()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=192) as pool:
            list(pool.map(writer, range(192)))
    finally:
        stop.set()
        sampler.join()
    flush()
    state = identity(manifest)
    assert state["data_materialized"] == 52 and state["journals_materialized"] > 1
    assert status()["allocated_blocks"] == 768 and not status()["write_fenced"]
    bounds(manifest)
    unload()
    load(manifest)
    for index in range(192):
        for turn in range(4):
            assert direct((index * 4 + turn) * B) == bytes([index + 1]) * B
    unload()
    record("concurrent_kernel_materialization", {"threads": 192, "writes": 768, "max_inflight": maximum[0],
                                                "data_files": state["data_materialized"], "journal_files": state["journals_materialized"]})


def observe_compact(manifest):
    before = manifest.read_bytes()
    seen, errors = {before}, []
    stop, ready = threading.Event(), threading.Event()
    existing, prepared = set(manifest.parent.rglob("*")), [False]
    def watch():
        try:
            while not stop.is_set():
                raw = manifest.read_bytes()
                assert set(json.loads(raw)) == {"format", "metadata", "segments", "journals"}
                seen.add(raw)
                if raw == before and set(manifest.parent.rglob("*")) > existing:
                    prepared[0] = True
                ready.set()
                time.sleep(.001)
        except BaseException as exc:
            errors.append(exc)
            ready.set()
    thread = threading.Thread(target=watch)
    thread.start()
    try:
        assert ready.wait(10)
        cli("compact", manifest, "--execute")
    finally:
        stop.set()
        thread.join()
    if errors:
        raise errors[0]
    after = manifest.read_bytes()
    seen.add(after)
    assert before != after and seen == {before, after}
    return {"preparation_observed": prepared[0], "complete_json_states": 2}


def compaction():
    manifest = create("compact-full", MIB, 4, 16384, 3, B + 2 * SLOT)
    c, volume = config(manifest), manifest.parent
    offsets = [5 * B, B, 9 * B]
    load(manifest)
    for index, offset in enumerate(offsets):
        direct(offset, bytes([index + 1]) * B, dsync=True)
    cli("grow", 2 * MIB, "--execute")
    assert status()["journal_used_bytes"] == status()["journal_limit_bytes"] == 6 * SLOT
    expected = hashlib.sha256(direct(0, length=2 * MIB)).hexdigest()
    ids = identity(manifest)
    unload()
    durable(volume / "old-selection.json", manifest.read_text())
    durable(volume / "unrelated.txt", "must not change\n")
    before = hashes(volume)
    cli("compact", manifest, "--dry-run")
    assert hashes(volume) == before
    load(manifest)
    cli("compact", manifest, "--execute", success=False)
    unload()
    assert hashes(volume) == before
    for name in [c["metadata"], c["journals"][0], c["segments"][0]]:
        with open(volume / name, "rb") as locked:
            fcntl.flock(locked, fcntl.LOCK_SH | fcntl.LOCK_NB)
            cli("compact", manifest, "--execute", success=False)
        assert hashes(volume) == before
    record("compact_dry_run_loaded_and_lock_guards")
    ro = Path("/compact-ro")
    ro.mkdir()
    command("mount", "--bind", volume, ro)
    try:
        command("mount", "-o", "remount,bind,ro", ro)
        cli("compact", ro, "--execute", success=False)
    finally:
        command("umount", ro)
    assert hashes(volume) == before
    record("compact_readonly_preserves_inputs")
    visibility = observe_compact(manifest)
    after, nc = hashes(volume), config(manifest)
    assert all(after[name] == value for name, value in before.items() if name != manifest.name)
    assert nc["segments"] == c["segments"]
    assert set(after) - set(before) == {nc["metadata"], nc["journals"][0]}
    assert all(not (volume / name).exists() for name in nc["segments"][1:] + nc["journals"][1:])
    report = json.loads(cli("inspect", manifest))
    assert report["journal_used_bytes"] == SLOT and report["journal_limit_bytes"] == 6 * SLOT
    for selected in (volume / "old-selection.json", manifest):
        cli("inspect", selected)
        load(selected)
        current = identity(selected)
        assert current["volume"] == ids["volume"] and current["data_entries"] == ids["data_entries"]
        assert hashlib.sha256(direct(0, length=2 * MIB)).hexdigest() == expected
        unload()
    record("compact_creates_only_needed_files", {"before_slots": 6, "after_slots": 1, "new_files": sorted(set(after) - set(before)),
                                               "payload_sha256": expected, "visibility": visibility})
    load(manifest)
    cli("grow", 3 * MIB, "--execute")
    direct(20 * B, b"Z" * B, dsync=True)
    assert (volume / nc["segments"][1]).stat().st_size == 2 * B
    assert direct(20 * B) == b"Z" * B
    cli("grow", 4 * MIB, "--execute")
    assert status()["journal_used_bytes"] == 6 * SLOT
    for index, offset in enumerate(offsets):
        assert direct(offset) == bytes([index + 1]) * B
    unload()
    final = hashes(volume)
    assert all(final[name] == before[name] for name in [c["metadata"], *c["journals"], "unrelated.txt", "old-selection.json"])
    record("compact_restores_lazy_rollover_and_grow_budget")


def ext4_size():
    sb = direct(0)[1024:2048]
    assert struct.unpack_from("<H", sb, 0x38)[0] == 0xEF53
    blocks = struct.unpack_from("<I", sb, 4)[0]
    if struct.unpack_from("<I", sb, 0x60)[0] & 0x80:
        blocks |= struct.unpack_from("<I", sb, 0x150)[0] << 32
    return blocks * (1024 << struct.unpack_from("<I", sb, 0x18)[0])


def portability():
    manifest = create("portable", 64 * MIB, 16, 4 * MIB, 64, B + 32 * SLOT)
    volume = manifest.parent
    load(manifest)
    command("mkfs.ext4", "-b", "4096", "-E", "nodiscard,lazy_itable_init=0,lazy_journal_init=0", DEVICE)
    command("mount", "-t", "ext4", "-o", "nodiscard", DEVICE, "/mnt")
    data = os.urandom(12 * MIB)
    with open("/mnt/payload", "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    upper_uuid = command("blkid", "-s", "UUID", "-o", "value", DEVICE).strip()
    manifest_bytes = manifest.read_bytes()
    names = set(inventory(volume))
    cli("compact", manifest, "--execute", success=False)
    assert manifest.read_bytes() == manifest_bytes and set(inventory(volume)) == names
    command("umount", "/mnt")
    unload()
    record("compact_refuses_mounted_volume")
    before = hashes(volume)
    observe_compact(manifest)
    after = hashes(volume)
    assert all(after[name] == value for name, value in before.items() if name != manifest.name)
    c = config(manifest)
    original = json.loads(cli("inspect", manifest))
    expected = hashlib.sha256(data).hexdigest()
    manifest_bytes = manifest.read_bytes()
    loops, mounts = [], []
    try:
        for fs in ("vfat", "exfat"):
            image = ROOT / (fs + "-lower.img")
            with open(image, "xb") as stream:
                stream.truncate(8 * 1024 * MIB)
            loop = command("losetup", "--find", "--show", "--sector-size", "512", image).strip()
            loops.append(loop)
            assert command("blockdev", "--getss", loop).strip() == "512"
            assert command("blockdev", "--getpbsz", loop).strip() == "512"
            if fs == "vfat":
                command("mkfs.vfat", "-F", "32", "-S", "512", loop)
            else:
                command("mkfs.exfat", "-s", "512", loop)
            lower = Path("/lower-" + fs)
            lower.mkdir()
            command("mount", "-t", fs, "-o", "uid=0,gid=0,fmask=0077,dmask=0077", loop, lower)
            mounts.append(lower)
            default_16g(lower, fs)
            allocation_boundaries(lower, fs)
            source_hashes = hashes(volume)
            missing = set(c["segments"] + c["journals"]) - set(source_hashes)
            assert missing, "fixture has no absent reserve to exercise"
            target = lower / "portable"
            shutil.copytree(volume, target, copy_function=shutil.copyfile)
            for path in target.rglob("*"):
                if path.is_file():
                    with open(path, "rb") as stream:
                        os.fsync(stream.fileno())
            for directory in sorted([target, *(p for p in target.rglob("*") if p.is_dir())], key=lambda p: len(p.parts), reverse=True):
                fd = os.open(directory, os.O_DIRECTORY)
                os.fsync(fd)
                os.close(fd)
            fd = os.open(lower, os.O_DIRECTORY)
            os.fsync(fd)
            os.close(fd)
            assert hashes(target) == source_hashes
            assert (target / "volume.json").read_bytes() == manifest_bytes
            assert all(not (target / name).exists() for name in missing)
            current = target / "volume.json"
            cli("inspect", current)
            assert hashes(target) == source_hashes
            volume.rename(volume.with_name("detached-source"))
            load(current)
            assert set(inventory(target)) == set(source_hashes)
            command("mount", "-t", "ext4", "-o", "nodiscard", DEVICE, "/mnt")
            assert hashlib.sha256(Path("/mnt/payload").read_bytes()).hexdigest() == expected
            assert command("blkid", "-s", "UUID", "-o", "value", DEVICE).strip() == upper_uuid
            extra = os.urandom(4 * MIB)
            with open("/mnt/" + fs, "wb") as stream:
                stream.write(extra)
                stream.flush()
                os.fsync(stream.fileno())
            bounds(current)
            command("umount", "/mnt")
            unload()
            report = json.loads(cli("inspect", current))
            assert report["volume_uuid"] == original["volume_uuid"]
            load(current)
            command("mount", "-t", "ext4", "-o", "nodiscard", DEVICE, "/mnt")
            assert Path("/mnt/" + fs).read_bytes() == extra
            assert hashlib.sha256(Path("/mnt/payload").read_bytes()).hexdigest() == expected
            command("umount", "/mnt")
            unload()
            record("portable_existing_files_and_lazy_continuation_" + fs,
                   {"copied_files": len(source_hashes), "absent_reserved_paths": len(missing), "copied_file_hashes": source_hashes,
                    "volume_uuid": original["volume_uuid"], "upper_uuid": upper_uuid, "payload_sha256": expected,
                    "materialized_data": sum((target / name).exists() for name in c["segments"]),
                    "materialized_journals": sum((target / name).exists() for name in c["journals"])})
            volume = target
    finally:
        if not Path("/sys/module/dynblk").exists():
            for lower in reversed(mounts):
                command("umount", lower)
            for loop in reversed(loops):
                command("losetup", "-d", loop)


def fat_upper():
    manifest = create("fat-upper", 64 * MIB, 4, 32 * MIB, 8, B + 64 * SLOT)
    load(manifest)
    command("mkfs.vfat", "-F", "32", "-S", "512", DEVICE)
    command("mount", "-t", "vfat", DEVICE, "/mnt")
    data = os.urandom(2 * MIB)
    with open("/mnt/PAYLOAD.BIN", "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    command("sync")
    bpb = direct(0, length=512)
    assert struct.unpack_from("<I", bpb, 0x20)[0] * struct.unpack_from("<H", bpb, 0x0B)[0] == 64 * MIB
    cli("grow", 80 * MIB, "--execute")
    assert status()["capacity_bytes"] == 80 * MIB and direct(0, length=512) == bpb
    command("umount", "/mnt")
    command("fsck.vfat", "-n", DEVICE)
    unload()
    load(manifest)
    assert direct(0, length=512)[0x0B:0x40] == bpb[0x0B:0x40]
    command("mount", "-t", "vfat", DEVICE, "/mnt")
    assert Path("/mnt/PAYLOAD.BIN").read_bytes() == data
    command("umount", "/mnt")
    unload()
    record("generic_fat_upper_growth_without_resize")


def payload_ok():
    assert hashlib.sha256(Path("/mnt/payload").read_bytes()).hexdigest() == (ROOT / "payload.sha256").read_text()


def lifecycle():
    manifest = create("lifecycle", 64 * MIB, 32, 4 * MIB, 64, B + 32 * SLOT)
    load(manifest)
    command("mkfs.ext4", "-b", "4096", "-E", "nodiscard,lazy_itable_init=0,lazy_journal_init=0", DEVICE)
    command("mount", "-t", "ext4", "-o", "nodiscard", DEVICE, "/mnt")
    cli("unload", "--execute", success=False)
    data = os.urandom(8 * MIB)
    with open("/mnt/payload", "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    durable(ROOT / "payload.sha256", hashlib.sha256(data).hexdigest())
    command("sync")
    assert ext4_size() == 64 * MIB
    old_stat = os.statvfs("/mnt").f_blocks
    cli("grow", 96 * MIB, "--execute")
    assert status()["capacity_bytes"] == 96 * MIB and ext4_size() == 64 * MIB
    assert os.statvfs("/mnt").f_blocks == old_stat
    records = status()["journal_records"]
    cli("grow", 96 * MIB, "--execute")
    assert status()["journal_records"] == records
    command("resize2fs", DEVICE)
    command("sync")
    assert ext4_size() == 96 * MIB
    payload_ok()
    command("umount", "/mnt")
    unload()
    load(manifest)
    command("e2fsck", "-fn", DEVICE)
    command("mount", "-t", "ext4", "-o", "nodiscard", DEVICE, "/mnt")
    payload_ok()
    record("generic_ext4_growth_external_resize_and_reload")
    command("sh", "-c", "dmesg > /back/dmesg-before-cut.txt")
    durable(ROOT / "phase", "ack")
    command("sync")
    print("DYNBLK ACK CUT READY", flush=True)
    while True:
        time.sleep(3600)


def recovery(phase):
    manifest = ROOT / "lifecycle/volume.json"
    load(manifest)
    capacity = status()["capacity_bytes"]
    assert capacity >= 96 * MIB
    command("mount", "-t", "ext4", "-o", "nodiscard", DEVICE, "/mnt")
    assert ext4_size() == 96 * MIB
    payload_ok()
    if phase == "ack":
        assert capacity == 96 * MIB
        record("acknowledged_growth_crash_recovery")
        durable(ROOT / "phase", "growth")
        durable(ROOT / "growth-ack", str(capacity))
        print("DYNBLK GROWTH CUT READY", flush=True)
        while True:
            capacity += 4 * MIB
            cli("grow", capacity, "--execute")
            assert ext4_size() == 96 * MIB
            flush()
            durable(ROOT / "growth-ack", str(capacity))
            with open("/mnt/churn", "wb") as stream:
                stream.write(os.urandom(MIB))
                stream.flush()
                os.fsync(stream.fileno())
            print("DYNBLK GROWTH CUT READY", flush=True)
            time.sleep(.05)
    acknowledged = int((ROOT / "growth-ack").read_text())
    assert capacity >= acknowledged
    command("resize2fs", DEVICE)
    command("sync")
    payload_ok()
    command("umount", "/mnt")
    unload()
    record("growth_crash_recovery", {"capacity": capacity, "acknowledged": acknowledged})
    command("sh", "-c", "dmesg > /back/dmesg-recovery.txt")
    lazy_crash()


def lazy_crash():
    manifest = create("lazy-crash", 4 * MIB, 32, 32768, 100, B + 4 * SLOT)
    c = config(manifest)
    durable(ROOT / "lazy-root.sha256", hashlib.sha256((manifest.parent / c["metadata"]).read_bytes()).hexdigest())
    load(manifest)
    durable(ROOT / "phase", "lazy")
    for index in range(224):
        direct(index * B, bytes([index % 255 + 1]) * B, dsync=True)
        flush()
        durable(ROOT / "lazy-ack", str(index + 1))
        if index >= 9:
            print("DYNBLK LAZY CUT READY", flush=True)
        time.sleep(.1)
    raise AssertionError("Testo did not cut while lazy IO was running")


def recover_lazy():
    manifest = ROOT / "lazy-crash/volume.json"
    c = config(manifest)
    acknowledged = int((ROOT / "lazy-ack").read_text())
    assert 10 <= acknowledged < 224
    names = set(inventory(manifest.parent))
    cli("inspect", manifest)
    assert set(inventory(manifest.parent)) == names
    load(manifest)
    assert set(inventory(manifest.parent)) == names, "load recreated a missing file"
    state = status()
    assert acknowledged <= state["allocated_blocks"] <= acknowledged + 1
    assert state["capacity_bytes"] == 4 * MIB
    for index in range(acknowledged):
        assert direct(index * B) == bytes([index % 255 + 1]) * B
    bounds(manifest)
    unload()
    assert hashlib.sha256((manifest.parent / c["metadata"]).read_bytes()).hexdigest() == (ROOT / "lazy-root.sha256").read_text()
    record("lazy_creation_and_link_crash_recovery", {"acknowledged_maps": acknowledged, "replayed_maps": state["allocated_blocks"],
                                                   "existing_files": inventory(manifest.parent)})
    command("sh", "-c", "dmesg > /back/dmesg-lazy.txt")
    compact_crash()


def compact_crash():
    manifest = create("compact-crash", 2 * MIB, 2, 4 * MIB, 16, 65536)
    volume = manifest.parent
    load(manifest)
    for index in range(64):
        direct((63 - index) * B, bytes([index + 1]) * B, dsync=True)
    expected = b"".join(bytes([64 - index]) * B for index in range(64))
    assert direct(0, length=len(expected)) == expected
    unload()
    durable(volume / "unrelated.txt", "must survive compaction\n")
    protected = hashes(volume)
    protected.pop("volume.json")
    original = json.loads(cli("inspect", manifest))
    checkpoint = {"protected": protected, "volume_uuid": original["volume_uuid"],
                  "payload_sha256": hashlib.sha256(expected).hexdigest(), "previous": config(manifest),
                  "selected": config(manifest), "completed": 0, "preparation_observed": False}
    durable(ROOT / "compact-checkpoint", json.dumps(checkpoint))
    durable(ROOT / "phase", "compaction")
    while True:
        previous = config(manifest)
        observation = observe_compact(manifest)
        selected = config(manifest)
        probe = volume / "observed-old.json"
        durable(probe, json.dumps(previous))
        old_report = json.loads(cli("inspect", probe))
        new_report = json.loads(cli("inspect", manifest))
        assert old_report["volume_uuid"] == new_report["volume_uuid"] == original["volume_uuid"]
        assert new_report["allocated_blocks"] == 64 and new_report["journal_generations"] == 2
        current = hashes(volume)
        assert all(current[name] == value for name, value in protected.items())
        assert not any((volume / name).exists() for name in selected["journals"][1:])
        for name in [selected["metadata"], selected["journals"][0]]:
            protected[name] = current[name]
        checkpoint.update(previous=previous, selected=selected, completed=checkpoint["completed"] + 1,
                          preparation_observed=checkpoint["preparation_observed"] or observation["preparation_observed"])
        durable(ROOT / "compact-checkpoint", json.dumps(checkpoint))
        if checkpoint["preparation_observed"]:
            print("DYNBLK COMPACT CUT READY", flush=True)
        time.sleep(.05)


def recover_compact():
    manifest = ROOT / "compact-crash/volume.json"
    checkpoint = json.loads((ROOT / "compact-checkpoint").read_text())
    assert checkpoint["completed"] >= 1 and checkpoint["preparation_observed"]
    current = hashes(manifest.parent)
    assert all(current[name] == value for name, value in checkpoint["protected"].items())
    selected = config(manifest)
    for label in ("previous", "selected", "current"):
        probe = manifest.parent / ("recovery-" + label + ".json")
        durable(probe, json.dumps(selected if label == "current" else checkpoint[label]))
        report = json.loads(cli("inspect", probe))
        assert report["volume_uuid"] == checkpoint["volume_uuid"] and not report["pending_recovery"]
        names = set(inventory(manifest.parent))
        load(probe)
        assert set(inventory(manifest.parent)) == names
        assert hashlib.sha256(direct(0, length=64 * B)).hexdigest() == checkpoint["payload_sha256"]
        unload()
    record("lazy_compaction_crash_atomic_selection", {"completed_before_cut": checkpoint["completed"],
                                                     "selected_equals_checkpoint": selected == checkpoint["selected"],
                                                     "protected_files": len(checkpoint["protected"]), "no_reserved_files_created_on_load": True})
    command("sh", "-c", "dmesg > /back/dmesg-compaction.txt")
    command("sync")
    print("DYNBLK EXTENDED PASS", flush=True)


try:
    if (ROOT / "phase").exists():
        results = json.loads((ROOT / "results.json").read_text())
        phase = (ROOT / "phase").read_text()
        if phase == "compaction":
            recover_compact()
        elif phase == "lazy":
            recover_lazy()
        else:
            recovery(phase)
    else:
        choices = cli("--help").split("{", 1)[1].split("}", 1)[0].split(",")
        assert set(choices) == {"create", "inspect", "load", "unload", "status", "grow", "compact"}
        assert "--filesystem" not in cli("grow", "--help")
        record("sole_lazy_generic_interface", choices)
        default_16g(ROOT, "ext4")
        allocation_boundaries(ROOT, "ext4")
        recovery_fixtures()
        backing_enospc()
        memory_budget()
        concurrency()
        compaction()
        portability()
        fat_upper()
        lifecycle()
except BaseException:
    traceback.print_exc()
    command("sh", "-c", "dmesg > /back/dmesg-failure.txt")
    command("sync")
    print("DYNBLK FAIL extended", flush=True)
    raise

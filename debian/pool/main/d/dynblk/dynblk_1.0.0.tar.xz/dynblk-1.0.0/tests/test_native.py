import ctypes
import json
import os
from pathlib import Path
import re
import shutil
import stat
import struct
import subprocess
import tempfile
import unittest
import zlib

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "dynblk"
INITRD_CLI = ROOT / "dynblk-initrd"
VALUE = struct.Struct("<QQIIIIII")
POINTER = struct.Struct("<QQII")
BLOCK = 4096
REGION = 65536


def seal(page):
    struct.pack_into("<I", page, 4092, zlib.crc32(page[:4092]))
    return page


def library(name):
    try:
        return ctypes.CDLL(name)
    except OSError as error:
        raise RuntimeError("test library unavailable: " + name) from error


def compress(algorithm, data):
    if algorithm == "deflate":
        encoder = zlib.compressobj(wbits=-11)
        return encoder.compress(data) + encoder.flush()
    if algorithm in ("lzo", "lzo-rle"):
        lib = ctypes.CDLL(str(ROOT / "lzo/test-codec.so"))
    else:
        lib = library({"lz4": "liblz4.so.1", "lz4hc": "liblz4.so.1",
                       "zstd": "libzstd.so.1"}[algorithm])
    output = ctypes.create_string_buffer(131072)
    if algorithm in ("lz4", "lz4hc"):
        fn = lib.LZ4_compress_default if algorithm == "lz4" else lib.LZ4_compress_HC
        fn.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int] + (
            [ctypes.c_int] if algorithm == "lz4hc" else [])
        fn.restype = ctypes.c_int
        length = fn(data, output, len(data), len(output), *([9] if algorithm == "lz4hc" else []))
    elif algorithm == "zstd":
        fn = lib.ZSTD_compress
        fn.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p,
                       ctypes.c_size_t, ctypes.c_int]
        fn.restype = ctypes.c_size_t
        length = fn(output, len(output), data, len(data), 3)
    else:
        fn = lib.lzorle1x_1_compress if algorithm == "lzo-rle" else lib.lzo1x_1_compress
        fn.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p,
                       ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p]
        fn.restype = ctypes.c_int
        length_out = ctypes.c_size_t(len(output))
        result = fn(data, len(data), output, ctypes.byref(length_out),
                    ctypes.create_string_buffer(1 << 20))
        if result:
            raise AssertionError(result)
        length = length_out.value
    return output.raw[:length]
class Volume:
    def __init__(self, algorithm="none", capacity=16 << 30):
        self.algorithm = algorithm
        self.capacity = capacity
        self.uuid = bytes(range(16))
        self.data = bytearray(12288)
        self.values = {}
        self.nodes = {}
        self.generation = 2
        self.transaction_changes = None

    def payload(self, logical, raw, group=False, encoded=None):
        location = len(self.data)
        output = len(raw)
        flags = self.algorithm != "none"
        encoded = encoded if encoded is not None else (compress(self.algorithm, raw) if flags else raw)
        self.data.extend(encoded)
        members = output // BLOCK if group else 1
        for i in range(members):
            original = zlib.crc32(raw[i * BLOCK:(i + 1) * BLOCK])
            self.values[logical + i] = (location, 2, len(encoded), zlib.crc32(encoded),
                                         original, int(flags), output, i * BLOCK)
        return location

    def page(self, page):
        self.data.extend(bytes(-len(self.data) % BLOCK))
        location = len(self.data)
        self.data.extend(seal(page))
        return location, struct.unpack_from("<Q", page, 24)[0], zlib.crc32(page[:4092]), 0
    def finish(self):
        layer = {}
        for base in sorted({logical // 64 * 64 for logical in self.values}):
            node = bytearray(BLOCK)
            entries = {logical: value for logical, value in self.values.items()
                       if base <= logical < base + 64}
            struct.pack_into("<8s16sQQII", node, 0, b"DBTREE01", self.uuid,
                             2, base, 0, len(entries))
            for logical, value in entries.items():
                VALUE.pack_into(node, 64 + (logical - base) * 40, *value)
            layer[base] = self.page(node)
            self.nodes[(0, base)] = layer[base][0]
        for level in range(1, 4):
            next_layer = {}
            span = 1 << (6 + 7 * level)
            for base in sorted({base // span * span for base in layer}):
                entries = {child: pointer for child, pointer in layer.items()
                           if base <= child < base + span}
                node = bytearray(BLOCK)
                struct.pack_into("<8s16sQQII", node, 0, b"DBTREE01", self.uuid,
                                 2, base, level, len(entries))
                for child, pointer in entries.items():
                    index = (child - base) >> (6 + 7 * (level - 1))
                    POINTER.pack_into(node, 64 + index * 24, *pointer)
                next_layer[base] = self.page(node)
                self.nodes[(level, base)] = next_layer[base][0]
            layer = next_layer
        changes = (self.transaction_changes if self.transaction_changes is not None
                   else dict(list(sorted(self.values.items()))[:32]))
        txn = bytearray(BLOCK)
        struct.pack_into("<8s16sQQQII", txn, 0, b"DBTXN001", self.uuid,
                         self.generation, self.generation - 1, self.capacity,
                         len(changes), 0)
        for i, (logical, value) in enumerate(sorted(changes.items())):
            struct.pack_into("<Q", txn, 56 + i * 48, logical)
            VALUE.pack_into(txn, 64 + i * 48, *value)
        self.txn = self.page(txn)
        header = bytearray(BLOCK)
        struct.pack_into("<8s16sQIIQ16s", header, 0, b"DBPART01", self.uuid,
                         42, 0, 1, 4000 << 20, self.algorithm.encode())
        self.data[:BLOCK] = seal(header)
        root = bytearray(BLOCK)
        struct.pack_into("<8s16sQQ", root, 0, b"DBROOT01", self.uuid,
                         self.generation, self.capacity)
        if layer:
            POINTER.pack_into(root, 40, *layer[0])
        POINTER.pack_into(root, 64, *self.txn)
        struct.pack_into("<QIIQ", root, 88, len(self.values), len(self.nodes), 4, 42)
        self.data[BLOCK:2 * BLOCK] = seal(root)
        self.data[2 * BLOCK:3 * BLOCK] = root

    def write(self, path):
        path.write_bytes(self.data)
        path.chmod(0o600)
class NativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sudo = shutil.which("sudo")
        cls.can_root = bool(cls.sudo and subprocess.run(
            [cls.sudo, "-n", "true"], stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL).returncode == 0)

    def run_cli(self, *args, root=False, expected=0):
        command = [str(CLI), *args]
        if root:
            if not self.can_root:
                self.skipTest("passwordless sudo is unavailable")
            command = [self.sudo, "-n", *command]
        result = subprocess.run(command, text=True, capture_output=True)
        self.assertEqual(result.returncode, expected, (command, result.stdout, result.stderr))
        return result

    def root_volume(self, volume):
        if not self.can_root:
            self.skipTest("passwordless sudo is unavailable")
        name = f"dynblk-native-test-{os.getpid()}-{id(self)}"
        root = Path("/var/lib") / name
        subprocess.run([self.sudo, "-n", "rm", "-rf", str(root)], check=True)
        subprocess.run([self.sudo, "-n", "install", "-d", "-m", "0700",
                        "-o", str(os.getuid()), "-g", str(os.getgid()), str(root)], check=True)
        self.addCleanup(subprocess.run, [self.sudo, "-n", "rm", "-rf", str(root)])
        path = root / "volume000.db"
        volume.write(path)
        subprocess.run([self.sudo, "-n", "chown", "-R", "0:0", str(root)], check=True)
        subprocess.run([self.sudo, "-n", "chmod", "0755", str(root)], check=True)
        subprocess.run([self.sudo, "-n", "chmod", "0644", str(path)], check=True)
        return path
    def test_help_and_obsolete_commands(self):
        result = self.run_cli("--help")
        self.assertIn("Device management only", result.stdout)
        for command in ("mount", "format", "resize", "compact", "add-segment"):
            self.run_cli(command, "/mnt/test", expected=2)

    def test_codec_libraries_are_optional_and_initrd_binary_is_static(self):
        dynamic = subprocess.run(["readelf", "-d", str(CLI)], text=True,
                                 capture_output=True, check=True).stdout
        self.assertIn("libc.so.6", dynamic)
        for library in ("liblz4", "libzstd", "liblzo", "libz.so"):
            self.assertNotIn(library, dynamic)
        program_headers = subprocess.run(["readelf", "-l", str(INITRD_CLI)], text=True,
                                         capture_output=True, check=True).stdout
        self.assertNotIn("Requesting program interpreter", program_headers)
        result = subprocess.run([str(INITRD_CLI), "--help"], text=True,
                                capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Device management only", result.stdout)
        result = subprocess.run([str(INITRD_CLI), "grow", "/dev/dynblk0", "32GiB"],
                                text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("no filesystem resize", result.stdout)

    def test_dry_grow_and_unload_need_no_device(self):
        self.assertIn("no filesystem resize", self.run_cli(
            "grow", "/dev/dynblk17", "512GiB").stdout)
        self.assertIn("no unmount", self.run_cli(
            "unload", "/dev/dynblk17").stdout)
        self.run_cli("grow", "/dev/other", "32GiB", expected=2)
        self.run_cli("grow", "/dev/dynblk256", "32GiB", expected=2)
        self.run_cli("grow", "/dev/dynblk0p1", "32GiB", expected=2)
        self.run_cli("grow", "/dev/dynblk0", "31", expected=2)

    def test_unsafe_detached_paths_fail_before_parsing(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "volume000.db"
            path.write_bytes(b"x" * 12288)
            result = self.run_cli("check", str(path), "--json", expected=1)
            self.assertIn("path must be root-owned", result.stderr)
        self.run_cli("check", "/var/lib/../lib/volume000.db", expected=1)

    def test_root_controlled_runtime_path_is_accepted(self):
        if not self.can_root:
            self.skipTest("passwordless sudo is unavailable")
        root = Path("/tmp") / f"dynblk-runtime-test-{os.getpid()}-{id(self)}"
        subprocess.run([self.sudo, "-n", "install", "-d", "-m", "0775",
                        "-o", "0", "-g", "0", str(root)], check=True)
        self.addCleanup(subprocess.run, [self.sudo, "-n", "rm", "-rf", str(root)])

        result = self.run_cli("create", str(root / "volume000.db"),
                              "--size", "16GiB")

        self.assertIn("DRY RUN", result.stdout)

    def test_world_writable_non_sticky_ancestor_is_rejected(self):
        if not self.can_root:
            self.skipTest("passwordless sudo is unavailable")
        root = Path("/tmp") / f"dynblk-unsafe-test-{os.getpid()}-{id(self)}"
        subprocess.run([self.sudo, "-n", "install", "-d", "-m", "0777",
                        "-o", "0", "-g", "0", str(root)], check=True)
        self.addCleanup(subprocess.run, [self.sudo, "-n", "rm", "-rf", str(root)])

        result = self.run_cli("create", str(root / "volume000.db"), expected=1)

        self.assertIn("not writable by untrusted users", result.stderr)

    def test_all_codecs_and_metadata_inspect(self):
        for algorithm in ("none", "lz4", "lz4hc", "lzo", "lzo-rle", "zstd", "deflate"):
            volume = Volume(algorithm)
            if algorithm == "none":
                for logical in range(16):
                    volume.payload(logical, bytes([65 + logical]) * BLOCK)
            else:
                volume.payload(0, b"A" * REGION, group=True)
                volume.payload(3, b"B" * BLOCK)
                del volume.values[5]
            volume.finish()
            path = self.root_volume(volume)
            checked = json.loads(self.run_cli("check", str(path), "--json", root=True).stdout)
            self.assertTrue(checked["fully_validated"])
            self.assertEqual(checked["compression"], algorithm)
            self.assertEqual(checked["verified_mapping_count"], 16 if algorithm == "none" else 15)
            inspected = json.loads(self.run_cli(
                "inspect", str(path), "--metadata-only", "--json", root=True).stdout)
            self.assertFalse(inspected["fully_validated"])
            self.assertEqual(inspected["compression"], algorithm)
    def test_payload_and_tree_corruption_rejected(self):
        for kind in ("payload", "tree"):
            volume = Volume()
            payload = volume.payload(0, b"X" * BLOCK)
            volume.finish()
            offset = payload if kind == "payload" else volume.nodes[(0, 0)]
            volume.data[offset] ^= 1
            path = self.root_volume(volume)
            self.run_cli("check", str(path), "--json", root=True, expected=1)

    def test_cross_region_full_blob_alias_is_rejected(self):
        volume = Volume("lz4")
        volume.payload(0, b"A" * REGION, group=True)
        for i in range(16):
            volume.values[16 + i] = volume.values[i]
        volume.finish()
        path = self.root_volume(volume)
        result = self.run_cli("check", str(path), "--json", root=True, expected=1)
        self.assertIn("overlapping distinct payload blobs", result.stderr)

    def test_checker_preserves_file_metadata(self):
        volume = Volume("deflate")
        volume.payload(0, b"A" * REGION, group=True)
        volume.finish()
        path = self.root_volume(volume)
        old = 946684800000000000
        subprocess.run([self.sudo, "-n", "touch", "-a", "-m", "-d", "2000-01-01 UTC", str(path)], check=True)
        before = path.stat()
        self.run_cli("check", str(path), "--json", root=True)
        after = path.stat()
        self.assertEqual((before.st_size, before.st_atime_ns, before.st_mtime_ns),
                         (after.st_size, after.st_atime_ns, after.st_mtime_ns))
        self.assertLessEqual(after.st_atime_ns, old + 86400 * 10**9)

    def test_invalid_codec_and_create_bounds(self):
        self.assertIn("algorithm=842", self.run_cli(
            "create", "/var/lib/volume000.db", "--compression", "842").stdout)
        self.assertIn("size_bytes=549755813888", self.run_cli(
            "create", "/var/lib/volume000.db", "--size", "512GiB").stdout)
        self.assertIn("map_memory_mb=8192", self.run_cli(
            "create", "/var/lib/volume000.db", "--map-memory-mb", "8192").stdout)
        self.run_cli("create", "/var/lib/volume000.db", "--compression", "bogus", expected=2)
        self.run_cli("create", "/var/lib/volume000.db", "--size", "513GiB", expected=2)
        self.run_cli("create", "/var/lib/volume000.db", "--map-memory-mb", "8193", expected=2)
        self.run_cli("create", "/var/lib/volume000.db", "--part-size", "4001MiB", expected=2)

    def test_json_output_is_machine_parseable(self):
        volume = Volume()
        volume.payload(7, b"Q" * BLOCK)
        volume.finish()
        path = self.root_volume(volume)
        result = json.loads(self.run_cli("check", str(path), "--json", root=True).stdout)
        self.assertEqual(result["format"], 1)
        self.assertEqual(result["verified_mapping_count"], 1)
        self.assertEqual(result["validation_scope"], "selected-live-state")


class ReleaseMetadataTests(unittest.TestCase):
    def test_release_version_mirrors_match_changelog(self):
        changelog = (ROOT / "debian/changelog").read_text()
        match = re.search(r'^dynblk \(([^)]+)\)', changelog)
        self.assertIsNotNone(match)
        version = match.group(1)
        module_source = (ROOT / "dynblk.c").read_text()
        man_header = (ROOT / "debian/dynblk.8").read_text().splitlines()[0]
        self.assertIn('MODULE_VERSION("{}")'.format(version), module_source)
        self.assertIn('"Dynblk {}"'.format(version), man_header)


if __name__ == "__main__":
    unittest.main()

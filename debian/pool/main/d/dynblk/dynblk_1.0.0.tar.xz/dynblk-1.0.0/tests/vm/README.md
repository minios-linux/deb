# Dynblk VM Tests

The VM suite validates the kernel module and native CLI against real block,
filesystem and codec paths that cannot be covered by the source-level harnesses.
It is intended for disposable virtual machines and test disks only.

## Coverage

The scenarios cover:

- create, load, status, grow and per-device detach through the native CLI;
- fenced-device detach followed by authoritative recovery on reattach;
- stale attachment-cookie rejection after lowest-free device-number reuse;
- kernel-side rejection of create when any `volume000..063.db` sibling already exists;
- global fixed tree-index memory admission before numeric device slots are exhausted;
- simultaneous `dynblk0`/`dynblk1`, kernel partition scanning and partition I/O;
- thin virtual capacity through the 512 GiB format-1 tree ceiling;
- ext4, ext2-through-ext4, vfat, exfat, ntfs3 and single-device Btrfs backing;
- `none`, `lz4`, `lz4hc`, `lzo`, `lzo-rle`, `zstd` and `deflate` modes;
- COW overwrites, discard, lazy part creation, garbage collection and reload;
- detached offline checking and corruption rejection;
- lower-filesystem space exhaustion and recovery;
- clean reboot and hard power-cut recovery paths;
- Debian package installation, DKMS rebuild hooks, removal and reinstall;
- focused initramfs boot tests with the static dynblk CLI.

The large-data and power-cut scenarios are intentionally separate from the fast
functional matrix so they can be run only when that level of validation is
required.

## Requirements

The host needs matching Linux 6.12 headers/modules, QEMU/libvirt, GRUB tooling,
`xorriso`, `cpio`, BusyBox and Testo. Tests must
use newly created VM names and expendable virtual disks. The dynblk module must
not be loaded on the host by the builders.

## Running

Build the current module and userspace binary first. The general builder supports
only the current self-contained architecture; the historical baseline/extended
harnesses were removed rather than retained as misleading regression entrypoints.
Create a fresh output directory and run, for example:

```sh
make
make -C /usr/src/linux-headers-$(uname -r) M="$PWD" modules

bash tests/vm/build.sh ./dynblk.ko /tmp/dynblk-vm selfcontained
bash tests/vm/run.sh /tmp/dynblk-vm dynblk-test- selfcontained
```

`selfcontained` is also the default mode for both helpers. Focused checker and
large-data variants are selected with the additional `checker` or `large` argument
accepted by `build.sh`. Package and initramfs scenarios have their own `package.*`
and `initramfs.*` helpers in this directory.

Generated VM images, logs, screenshots and other run artifacts belong in the
chosen output directory and are not source-tree documentation.

## Safety

Do not run guest init scripts or workload entrypoints directly on the host. Do
not point test helpers at host storage containing useful data. Builders should
only copy already-built dynblk artifacts and required system tools into the test
image; formatting and mounting are performed inside the disposable guest.

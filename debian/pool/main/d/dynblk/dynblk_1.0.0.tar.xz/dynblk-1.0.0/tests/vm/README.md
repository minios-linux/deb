# Dynblk VM Tests

The VM suite validates the kernel module and native CLI against real block,
filesystem and codec paths that cannot be covered by the source-level harnesses.
It is intended for disposable virtual machines and test disks only.

## Coverage

The scenarios cover:

- create, load, status, grow and unload through the native CLI;
- ext4, ext2-through-ext4, vfat, exfat, ntfs3 and single-device Btrfs backing;
- `none`, `lz4`, `lz4hc`, `lzo`, `lzo-rle`, `zstd` and `deflate` modes;
- COW overwrites, discard, lazy part creation, garbage collection and reload;
- detached offline checking and corruption rejection;
- lower-filesystem space exhaustion and recovery;
- clean reboot and hard power-cut recovery paths;
- Debian package installation, DKMS rebuild hooks, removal and reinstall;
- focused initramfs boot tests with the static dynblk CLI.

The large-data and power-cut scenarios are intentionally separate from the fast
functional matrix so they can be run only when that level of validation is
required.

## Requirements

The host needs matching Linux 6.12 headers/modules, QEMU/libvirt, GRUB tooling,
`xorriso`, `cpio`, BusyBox and Testo. Tests must
use newly created VM names and expendable virtual disks. The dynblk module must
not be loaded on the host by the builders.

## Running

Build the current module and userspace binary first. Then create a fresh output
directory and use the builder/runner pair for the desired scenario. For example:

```sh
make
make -C /usr/src/linux-headers-$(uname -r) M="$PWD" modules

bash tests/vm/build.sh ./dynblk.ko /tmp/dynblk-vm selfcontained
bash tests/vm/run.sh /tmp/dynblk-vm dynblk-test- selfcontained
```

Focused checker and large-data variants are selected with the additional
`checker` or `large` argument accepted by `build.sh`. Package and initramfs
scenarios have their own `package.*` and `initramfs.*` helpers in this directory.

Generated VM images, logs, screenshots and other run artifacts belong in the
chosen output directory and are not source-tree documentation.

## Safety

Do not run guest init scripts or workload entrypoints directly on the host. Do
not point test helpers at host storage containing useful data. Builders should
only copy already-built dynblk artifacts and required system tools into the test
image; formatting and mounting are performed inside the disposable guest.

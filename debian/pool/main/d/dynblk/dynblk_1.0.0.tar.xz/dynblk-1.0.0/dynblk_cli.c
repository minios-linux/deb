// SPDX-License-Identifier: GPL-2.0-or-later
#define _GNU_SOURCE
#include "dynblk_check.h"
#include "dynblk_common.h"
#include "dynblk_uapi.h"

#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define DEVICE "/dev/dynblk0"
#define DEFAULT_SIZE (16ULL << 30)
#define DEFAULT_PART_SIZE (4000ULL << 20)
#define MIN_PART_SIZE (1ULL << 20)

static int error_message(const char *message)
{
	fprintf(stderr, "dynblk: %s\n", message);
	return 1;
}
static int system_error(const char *context)
{
	char message[512];
	snprintf(message, sizeof(message), "%s: %s", context, strerror(errno));
	return error_message(message);
}

static void usage(FILE *stream)
{
	fputs("Usage:\n"
	      "  dynblk create PATH [--size SIZE] [--compression CODEC] [--part-size SIZE] [--module FILE] [--execute]\n"
	      "  dynblk load PATH [--module FILE] [--execute]\n"
	      "  dynblk status /dev/dynblk0 [--json]\n"
	      "  dynblk grow /dev/dynblk0 SIZE [--execute]\n"
	      "  dynblk unload /dev/dynblk0 [--execute]\n"
	      "  dynblk inspect PATH --metadata-only [--json]\n"
	      "  dynblk check PATH [--json]\n"
	      "\nDevice management only: no mkfs, mount, fsck or filesystem resize.\n",
	      stream);
}

static bool help_arg(const char *arg)
{
	return !strcmp(arg, "-h") || !strcmp(arg, "--help");
}

static int parse_error(const char *message)
{
	if (message)
		fprintf(stderr, "dynblk: %s\n", message);
	usage(stderr);
	return 2;
}
static void json_string(const char *text)
{
	const unsigned char *p = (const unsigned char *)text;
	putchar('"');
	for (; *p; p++) {
		switch (*p) {
		case '"': fputs("\\\"", stdout); break;
		case '\\': fputs("\\\\", stdout); break;
		case '\b': fputs("\\b", stdout); break;
		case '\f': fputs("\\f", stdout); break;
		case '\n': fputs("\\n", stdout); break;
		case '\r': fputs("\\r", stdout); break;
		case '\t': fputs("\\t", stdout); break;
		default:
			if (*p < 0x20)
				printf("\\u%04x", *p);
			else
				putchar(*p);
		}
	}
	putchar('"');
}

static bool exact_device(const char *path)
{
	return path && !strcmp(path, DEVICE);
}

static bool module_loaded(void)
{
	struct stat st;
	return !lstat("/sys/module/dynblk", &st);
}
static int run_program_internal(char *const argv[], bool quiet)
{
	pid_t pid;
	int status;
	pid = fork();
	if (pid < 0)
		return system_error("fork");
	if (!pid) {
		if (quiet) {
			int nullfd = open("/dev/null", O_WRONLY | O_CLOEXEC);
			if (nullfd >= 0) {
				dup2(nullfd, STDERR_FILENO);
				close(nullfd);
			}
		}
		clearenv();
		setenv("PATH", "/usr/sbin:/usr/bin:/sbin:/bin", 1);
		setenv("LC_ALL", "C", 1);
		execvp(argv[0], argv);
		if (!quiet)
			perror(argv[0]);
		_exit(127);
	}
	if (waitpid(pid, &status, 0) < 0)
		return system_error("waitpid");
	if (!WIFEXITED(status) || WEXITSTATUS(status)) {
		char message[256];
		if (quiet)
			return 1;
		snprintf(message, sizeof(message), "%s failed%s%s", argv[0],
			 WIFEXITED(status) ? " with exit " : "",
			 WIFEXITED(status) ? "status" : "");
		return error_message(message);
	}
	return 0;
}

static int run_program(char *const argv[])
{
	return run_program_internal(argv, false);
}

static int read_status(struct dynblk_status *status, bool writable, int *fd_out)
{
	struct stat st;
	int fd = open(DEVICE, (writable ? O_RDWR : O_RDONLY) |
			   O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
	if (fd < 0)
		return system_error("open /dev/dynblk0");
	if (fstat(fd, &st) || !S_ISBLK(st.st_mode)) {
		close(fd);
		return error_message("status requires a block device");
	}
	if (ioctl(fd, DYNBLK_GET, status)) {
		close(fd);
		return system_error("DYNBLK_GET");
	}
	if (fd_out)
		*fd_out = fd;
	else
		close(fd);
	return 0;
}
static int validate_status(struct dynblk_status *status, char codec[16])
{
	char error[256];
	_Static_assert(sizeof(struct dynblk_status) == 128, "dynblk status ABI");
	if (status->version != DYNBLK_ABI_VERSION || status->flags & ~1U ||
	    status->block_size != DYNBLK_BLOCK_SIZE || status->max_parts != DYNBLK_MAX_PARTS ||
	    status->tree_height != DYNBLK_TREE_HEIGHT ||
	    status->compression_region_bytes != DYNBLK_COMPRESSION_REGION ||
	    status->max_capacity != DYNBLK_MAX_CAPACITY ||
	    dynblk_codec_field(status->algorithm, codec, error, sizeof(error)))
		return error_message("unsupported dynblk status ABI");
	return 0;
}

static int read_module_parameter(const char *name, char *value, size_t size)
{
	char filename[128];
	ssize_t length;
	int fd;

	if (snprintf(filename, sizeof(filename), "/sys/module/dynblk/parameters/%s", name) >=
	    (int)sizeof(filename))
		return error_message("module parameter name is too long");
	fd = open(filename, O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
	if (fd < 0)
		return system_error(filename);
	length = read(fd, value, size - 1);
	if (length < 0) {
		close(fd);
		return system_error(filename);
	}
	close(fd);
	if ((size_t)length == size - 1)
		return error_message("module parameter value is too long");
	while (length > 0 && (value[length - 1] == '\n' || value[length - 1] == '\r'))
		length--;
	value[length] = 0;
	return 0;
}

static int encode_module_path(const char *path, char **encoded);

static int verify_attachment(const char *path, bool create, uint64_t size,
			     uint64_t part_size, const char *codec)
{
	struct dynblk_status status;
	char attached[PATH_MAX * 2 + 8], actual_codec[16];
	char *encoded = NULL;
	int result = 1;

	if (!module_loaded())
		return error_message("module loader returned success but dynblk is not loaded");
	if (read_module_parameter("filename", attached, sizeof(attached)))
		return 1;
	if (encode_module_path(path, &encoded))
		return 1;
	if (strcmp(attached, path) && strcmp(attached, encoded)) {
		error_message("dynblk was loaded concurrently for a different backing path");
		goto out;
	}
	if (read_status(&status, false, NULL) || validate_status(&status, actual_codec))
		goto out;
	if (create && (status.capacity != size || status.part_limit != part_size ||
		       strcmp(actual_codec, codec))) {
		error_message("dynblk was loaded concurrently with different create parameters");
		goto out;
	}
	result = 0;
out:
	free(encoded);
	return result;
}

static void print_status(const struct dynblk_status *status, const char *codec, bool json)
{
	char uuid[37];
	dynblk_uuid_string(status->uuid, uuid);
	if (json) {
		printf("{\"abi_version\":%u,\"active_parts\":%u,\"block_size\":%u,"
		       "\"capacity_bytes\":%" PRIu64 ",\"compression\":", status->version,
		       status->active_parts, status->block_size, (uint64_t)status->capacity);
		json_string(codec);
		printf(",\"compression_region_bytes\":%" PRIu64 ",\"device\":\"%s\","
		       "\"fenced\":%s,\"flags\":%u,\"generation\":%" PRIu64,
		       (uint64_t)status->compression_region_bytes, DEVICE,
		       status->flags & 1 ? "true" : "false", status->flags,
		       (uint64_t)status->generation);
		printf(",\"map_memory_bytes\":%" PRIu64 ",\"max_capacity_bytes\":%" PRIu64
		       ",\"max_parts\":%u,\"original_bytes\":%" PRIu64,
		       (uint64_t)status->map_memory_bytes, (uint64_t)status->max_capacity,
		       status->max_parts, (uint64_t)status->original_bytes);
		printf(",\"part_limit_bytes\":%" PRIu64 ",\"physical_bytes\":%" PRIu64
		       ",\"stored_bytes\":%" PRIu64 ",\"tree_height\":%u,\"uuid\":",
		       (uint64_t)status->part_limit, (uint64_t)status->physical_bytes,
		       (uint64_t)status->stored_bytes, status->tree_height);
		json_string(uuid);
		puts("}");
		return;
	}
	printf("abi_version: %u\nflags: %u\nuuid: %s\ncompression: %s\n"
	       "capacity_bytes: %" PRIu64 "\noriginal_bytes: %" PRIu64 "\n"
	       "stored_bytes: %" PRIu64 "\nphysical_bytes: %" PRIu64 "\n"
	       "generation: %" PRIu64 "\npart_limit_bytes: %" PRIu64 "\n"
	       "active_parts: %u\nblock_size: %u\nmax_parts: %u\ntree_height: %u\n"
	       "map_memory_bytes: %" PRIu64 "\nmax_capacity_bytes: %" PRIu64 "\n"
	       "compression_region_bytes: %" PRIu64 "\nfenced: %s\ndevice: %s\n",
	       status->version, status->flags, uuid, codec, (uint64_t)status->capacity,
	       (uint64_t)status->original_bytes, (uint64_t)status->stored_bytes,
	       (uint64_t)status->physical_bytes, (uint64_t)status->generation,
	       (uint64_t)status->part_limit, status->active_parts, status->block_size,
	       status->max_parts, status->tree_height, (uint64_t)status->map_memory_bytes,
	       (uint64_t)status->max_capacity, (uint64_t)status->compression_region_bytes,
	       status->flags & 1 ? "true" : "false", DEVICE);
}

static int command_status(int argc, char **argv)
{
	struct dynblk_status status;
	char codec[16];
	bool json = false;
	if (argc == 2 && !strcmp(argv[1], "--json"))
		json = true;
	else if (argc != 1)
		return parse_error("invalid status arguments");
	if (!exact_device(argv[0]))
		return parse_error("status supports only /dev/dynblk0");
	if (read_status(&status, false, NULL) || validate_status(&status, codec))
		return 1;
	print_status(&status, codec, json);
	return 0;
}
static void print_inspection(const struct dynblk_inspection *r, bool json)
{
	char uuid[37];
	dynblk_uuid_string(r->uuid, uuid);
	if (json) {
		printf("{\"active_parts\":%u,\"capacity_bytes\":%" PRIu64 ",\"compression\":",
		       r->active_parts, r->capacity);
		json_string(r->compression);
		printf(",\"format\":1,\"fully_validated\":%s,\"generation\":%" PRIu64
		       ",\"incarnation\":%" PRIu64 ",\"mapped_blocks\":%" PRIu64,
		       r->fully_validated ? "true" : "false", r->generation,
		       r->incarnation, r->mapped_blocks);
		printf(",\"part_limit_bytes\":%" PRIu64 ",\"path\":", r->part_limit);
		json_string(r->path);
		printf(",\"physical_bytes\":%" PRIu64 ",\"present_parts\":%u,"
		       "\"primary_physical_bytes\":%" PRIu64 ",\"root_repair_needed\":%s,"
		       "\"tree_height\":4,\"tree_pages\":%u,\"uuid\":",
		       r->physical_bytes, r->present_parts, r->primary_bytes,
		       r->root_repair_needed ? "true" : "false", r->tree_pages);
		json_string(uuid);
		printf(",\"valid_root_copies\":%u", r->valid_roots);
		if (r->fully_validated) {
			printf(",\"validation\":\"passed\",\"validation_scope\":\"selected-live-state\","
			       "\"verified_blobs\":%" PRIu64 ",\"verified_live_bytes\":%" PRIu64
			       ",\"verified_mapping_count\":%" PRIu64 ",\"verified_stored_bytes\":%" PRIu64
			       ",\"verified_tree_pages\":%" PRIu64,
			       r->verified_blobs, r->verified_live_bytes, r->verified_mapping_count,
			       r->verified_stored_bytes, r->verified_tree_pages);
		} else {
			fputs(",\"inspection_scope\":\"headers-roots-part-geometry\","
			      "\"warning\":\"Tree, transaction contents and payloads not validated; kernel load performs full validation.\"", stdout);
		}
		puts("}");
		return;
	}
	printf("path: %s\nformat: 1\nuuid: %s\ncompression: %s\n"
	       "part_limit_bytes: %" PRIu64 "\nprimary_physical_bytes: %" PRIu64
	       "\nincarnation: %" PRIu64 "\ncapacity_bytes: %" PRIu64
	       "\ngeneration: %" PRIu64 "\nmapped_blocks: %" PRIu64
	       "\ntree_pages: %u\ntree_height: 4\nactive_parts: %u\npresent_parts: %u\n"
	       "physical_bytes: %" PRIu64 "\nvalid_root_copies: %u\nroot_repair_needed: %s\n"
	       "fully_validated: %s\n",
	       r->path, uuid, r->compression, r->part_limit, r->primary_bytes,
	       r->incarnation, r->capacity, r->generation, r->mapped_blocks,
	       r->tree_pages, r->active_parts, r->present_parts, r->physical_bytes,
	       r->valid_roots, r->root_repair_needed ? "true" : "false",
	       r->fully_validated ? "true" : "false");
	if (r->fully_validated)
		printf("validation: passed\nvalidation_scope: selected-live-state\n"
		       "verified_live_bytes: %" PRIu64 "\nverified_blobs: %" PRIu64
		       "\nverified_stored_bytes: %" PRIu64 "\nverified_tree_pages: %" PRIu64
		       "\nverified_mapping_count: %" PRIu64 "\n",
		       r->verified_live_bytes, r->verified_blobs, r->verified_stored_bytes,
		       r->verified_tree_pages, r->verified_mapping_count);
	else
		puts("inspection_scope: headers-roots-part-geometry\n"
		     "warning: Tree, transaction contents and payloads not validated; kernel load performs full validation.");
}

static int command_inspect(int argc, char **argv, bool full)
{
	struct dynblk_inspection result;
	char error[512];
	bool json = false, metadata = false;
	int i;
	if (argc < 1)
		return parse_error("missing volume path");
	for (i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--json")) json = true;
		else if (!strcmp(argv[i], "--metadata-only")) metadata = true;
		else return parse_error("invalid inspect/check option");
	}
	if ((!full && !metadata) || (full && metadata))
		return parse_error(full ? "check does not accept --metadata-only" :
				   "inspect requires --metadata-only");
	if (dynblk_inspect_volume(argv[0], full, &result, error, sizeof(error)))
		return error_message(error);
	print_inspection(&result, json);
	return 0;
}
static int volume_basename(const char *path, char directory[4096])
{
	const char *slash = strrchr(path, '/');
	size_t length;
	if (!slash || strcmp(slash + 1, "volume000.db"))
		return error_message("volume path must end in volume000.db");
	length = (size_t)(slash - path);
	if (!length)
		length = 1;
	if (length >= 4096)
		return error_message("volume path too long");
	memcpy(directory, path, length);
	directory[length] = 0;
	return 0;
}

static int validate_volume_path(const char *path, bool create)
{
	char error[512], directory[4096], sibling[4096];
	struct stat st;
	unsigned int i;
	if (volume_basename(path, directory))
		return 1;
	if (dynblk_safe_path(path, create, error, sizeof(error)))
		return error_message(error);
	if (!create)
		return 0;
	for (i = 0; i < DYNBLK_MAX_PARTS; i++) {
		int length = snprintf(sibling, sizeof(sibling), "%s/volume%03u.db", directory, i);
		if (length < 0 || (size_t)length >= sizeof(sibling))
			return error_message("volume namespace path too long");
		if (!lstat(sibling, &st) || errno != ENOENT)
			return error_message("create requires an unused volume namespace; existing part preserved");
	}
	return 0;
}

static int encode_module_path(const char *path, char **encoded)
{
	static const char hex[] = "0123456789abcdef";
	size_t i, length = strlen(path);

	if (length >= PATH_MAX)
		return error_message("volume path is too long");
	*encoded = malloc(4 + length * 2 + 1);
	if (!*encoded)
		return error_message("memory exhausted");
	memcpy(*encoded, "hex:", 4);
	for (i = 0; i < length; i++) {
		unsigned char byte = (unsigned char)path[i];
		(*encoded)[4 + i * 2] = hex[byte >> 4];
		(*encoded)[5 + i * 2] = hex[byte & 15];
	}
	(*encoded)[4 + length * 2] = 0;
	return 0;
}

static int module_parameter_path(const char *path, char **parameter)
{
	char *encoded = NULL;
	int length;

	if (encode_module_path(path, &encoded))
		return 1;
	length = snprintf(NULL, 0, "filename=%s", encoded);
	if (length < 0) {
		free(encoded);
		return error_message("cannot encode module parameter");
	}
	*parameter = malloc((size_t)length + 1);
	if (!*parameter) {
		free(encoded);
		return error_message("memory exhausted");
	}
	snprintf(*parameter, (size_t)length + 1, "filename=%s", encoded);
	free(encoded);
	return 0;
}
static int validate_module(const char *path)
{
	char error[512];
	const char *base;
	if (!path)
		return 0;
	base = strrchr(path, '/');
	if (!base || strcmp(base + 1, "dynblk.ko"))
		return error_message("--module must name an existing dynblk.ko");
	if (dynblk_safe_path(path, false, error, sizeof(error)))
		return error_message(error);
	return 0;
}

static int execute_attach(const char *path, const char *module, bool create,
			  uint64_t size, uint64_t part_size, const char *codec)
{
	char *filename = NULL, size_arg[64], part_arg[64], codec_arg[64];
	char *argv[10];
	int n = 0, result;
	if (module_loaded())
		return error_message("dynblk is already loaded; unload before attaching");
	if (module_parameter_path(path, &filename))
		return 1;
	if (module) {
		argv[n++] = "insmod";
		argv[n++] = (char *)module;
	} else {
		argv[n++] = "modprobe";
		argv[n++] = "dynblk";
	}
	argv[n++] = filename;
	if (create) {
		argv[n++] = "create=1";
		snprintf(size_arg, sizeof(size_arg), "size_bytes=%" PRIu64, size);
		snprintf(part_arg, sizeof(part_arg), "part_limit_bytes=%" PRIu64, part_size);
		snprintf(codec_arg, sizeof(codec_arg), "algorithm=%s", codec);
		argv[n++] = size_arg; argv[n++] = codec_arg; argv[n++] = part_arg;
	}
	argv[n] = NULL;
	result = run_program(argv);
	if (!result)
		result = verify_attachment(path, create, size, part_size, codec);
	free(filename);
	return result;
}
static int command_attach(int argc, char **argv, bool create)
{
	const char *path, *module = NULL, *codec = "none";
	uint64_t size = DEFAULT_SIZE, part_size = DEFAULT_PART_SIZE;
	bool execute = false;
	char error[256];
	int i;
	if (argc < 1)
		return parse_error("missing volume path");
	path = argv[0];
	for (i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--execute")) execute = true;
		else if (!strcmp(argv[i], "--module") && i + 1 < argc) module = argv[++i];
		else if (create && !strcmp(argv[i], "--size") && i + 1 < argc) {
			if (dynblk_parse_size(argv[++i], &size, error, sizeof(error))) return parse_error(error);
		} else if (create && !strcmp(argv[i], "--part-size") && i + 1 < argc) {
			if (dynblk_parse_size(argv[++i], &part_size, error, sizeof(error))) return parse_error(error);
		} else if (create && !strcmp(argv[i], "--compression") && i + 1 < argc) codec = argv[++i];
		else return parse_error(create ? "invalid create option" : "invalid load option");
	}
	if (validate_volume_path(path, create) || validate_module(module))
		return 1;
	if (create && !dynblk_codec_name(codec))
		return parse_error("unsupported create codec");
	if (create && (dynblk_aligned_size(size, DB_BLOCK, DYNBLK_MAX_CAPACITY, error, sizeof(error)) ||
			 dynblk_aligned_size(part_size, MIN_PART_SIZE, DEFAULT_PART_SIZE, error, sizeof(error))))
		return parse_error(error);
	if (execute && geteuid() != 0)
		return error_message("mutations require root and --execute");
	if (!execute) {
		const char *loader = module ? "insmod" : "modprobe";
		const char *target = module ? module : "dynblk";
		if (create)
			printf("DRY RUN: %s %s filename=\"%s\" create=1 size_bytes=%" PRIu64
			       " algorithm=%s part_limit_bytes=%" PRIu64 "\n",
			       loader, target, path, size, codec, part_size);
		else
			printf("DRY RUN: %s %s filename=\"%s\"\n", loader, target, path);
		return 0;
	}
	return execute_attach(path, module, create, size, part_size, codec);
}
static int command_grow(int argc, char **argv)
{
	struct dynblk_status status;
	uint64_t size;
	bool execute = false;
	char error[256], codec[16];
	int fd;
	if (argc == 3 && !strcmp(argv[2], "--execute")) execute = true;
	else if (argc != 2) return parse_error("invalid grow arguments");
	if (!exact_device(argv[0])) return parse_error("grow supports only /dev/dynblk0");
	if (dynblk_parse_size(argv[1], &size, error, sizeof(error)) ||
	    dynblk_aligned_size(size, DB_BLOCK, DYNBLK_MAX_CAPACITY, error, sizeof(error)))
		return parse_error(error);
	if (!execute) {
		printf("DRY RUN: DYNBLK_GROW %s absolute capacity %" PRIu64
		       " bytes; no filesystem resize\n", DEVICE, size);
		return 0;
	}
	if (geteuid() != 0) return error_message("mutations require root and --execute");
	fd = -1;
	if (read_status(&status, true, &fd) || validate_status(&status, codec)) {
		if (fd >= 0) close(fd);
		return 1;
	}
	if (ioctl(fd, DYNBLK_GROW, &size)) {
		close(fd);
		return system_error("DYNBLK_GROW");
	}
	close(fd);
	return 0;
}

static int command_unload(int argc, char **argv)
{
	struct dynblk_status status;
	char codec[16];
	bool execute = false;
	char *command[] = { "rmmod", "dynblk", NULL };
	unsigned int attempt;
	if (argc == 2 && !strcmp(argv[1], "--execute")) execute = true;
	else if (argc != 1) return parse_error("invalid unload arguments");
	if (!exact_device(argv[0])) return parse_error("unload supports only /dev/dynblk0");
	if (!execute) { puts("DRY RUN: rmmod dynblk (/dev/dynblk0); no unmount or filesystem operations"); return 0; }
	if (geteuid() != 0) return error_message("mutations require root and --execute");
	if (read_status(&status, false, NULL) || validate_status(&status, codec)) return 1;
	/* udev/blkid may briefly hold a freshly published block device.  Retry only
	 * ordinary unload; never force removal of a genuinely busy filesystem. */
	for (attempt = 0; attempt < 10; attempt++) {
		if (!run_program_internal(command, true) || !module_loaded())
			return 0;
		usleep(100000);
	}
	return run_program(command);
}
int main(int argc, char **argv)
{
	const char *command;
	if (argc == 2 && help_arg(argv[1])) {
		usage(stdout);
		return 0;
	}
	if (argc < 2)
		return parse_error("missing command");
	command = argv[1];
	if (argc >= 3 && help_arg(argv[2])) {
		usage(stdout);
		return 0;
	}
	if (!strcmp(command, "create"))
		return command_attach(argc - 2, argv + 2, true);
	if (!strcmp(command, "load"))
		return command_attach(argc - 2, argv + 2, false);
	if (!strcmp(command, "status"))
		return command_status(argc - 2, argv + 2);
	if (!strcmp(command, "grow"))
		return command_grow(argc - 2, argv + 2);
	if (!strcmp(command, "unload"))
		return command_unload(argc - 2, argv + 2);
	if (!strcmp(command, "inspect"))
		return command_inspect(argc - 2, argv + 2, false);
	if (!strcmp(command, "check"))
		return command_inspect(argc - 2, argv + 2, true);
	return parse_error("unknown command");
}

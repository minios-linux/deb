// SPDX-License-Identifier: GPL-2.0-or-later
/* Self-contained format 1. See FORMAT.md before changing ordering. */
#include <linux/blk-mq.h>
#include <linux/capability.h>
#include <linux/crc32.h>
#include <linux/cred.h>
#include <linux/crypto.h>
#include <linux/fileattr.h>
#include <linux/filelock.h>
#include <linux/fs.h>
#include <linux/highmem.h>
#include <linux/magic.h>
#include <linux/module.h>
#include <linux/mount.h>
#include <linux/namei.h>
#include <linux/random.h>
#include <linux/sched/mm.h>
#include <linux/slab.h>
#include <linux/statfs.h>
#include <linux/uaccess.h>
#include <linux/uuid.h>
#include <linux/vmalloc.h>
#include <linux/workqueue.h>
#include <linux/xarray.h>
#include <linux/xattr.h>

#include "dynblk_uapi.h"

#define DB_BLOCK 4096U
#define DB_PARTS 64U
#define DB_DEFAULT_PART_LIMIT (4000ULL << 20)
#define DB_MIN_PART_LIMIT (1ULL << 20)
#define DB_PAGES (part_limit / DB_BLOCK)
#define DB_LIMIT (128ULL << 30)
#define DB_BATCH 32U
#define DB_IO (DB_BATCH * DB_BLOCK)
#define DB_REGION (64U * 1024)
#define DB_SUBBLOCKS (DB_REGION / DB_BLOCK)
#define DB_CHUNK 64U
#define DB_FANOUT 128U
#define DB_HEIGHT 4U
#define DB_NODES (524288U + 4096U + 32U + 1U)
#define DB_DIRTY (DB_BATCH * DB_HEIGHT)
#define DB_NO_NODE U32_MAX
#define DB_BUSY U16_MAX

struct db_header {
	u8 magic[8], uuid[16];
	__le64 incarnation;
	__le32 part, format;
	__le64 limit;
	u8 algorithm[16], reserved[4028];
	__le32 crc;
} __packed;

struct db_pointer {
	__le64 location, generation;
	__le32 crc, reserved;
} __packed;

struct db_root {
	u8 magic[8], uuid[16];
	__le64 generation, capacity;
	struct db_pointer tree, transaction;
	__le64 mappings;
	__le32 tree_pages, tree_height;
	__le64 incarnations[DB_PARTS];
	u8 reserved[3476];
	__le32 crc;
} __packed;

struct db_value {
	__le64 location, version;
	__le32 length, stored_crc, original_crc, flags;
	__le32 decoded_length, decoded_offset;
} __packed;

struct db_entry {
	__le64 logical;
	struct db_value value;
} __packed;

struct db_node {
	u8 magic[8], uuid[16];
	__le64 generation, base;
	__le32 level, count;
	u8 reserved[16];
	union {
		struct db_value values[DB_CHUNK];
		struct db_pointer children[DB_FANOUT];
		u8 bytes[4028];
	};
	__le32 crc;
} __packed;

struct db_transaction {
	u8 magic[8], uuid[16];
	__le64 generation, previous, capacity;
	__le32 count, reserved;
	struct db_entry entries[DB_BATCH];
	u8 padding[2500];
	__le32 crc;
} __packed;

static char *filename, *algorithm;
static char *decoded_filename;
static const char *backing_filename;
static bool create;
static unsigned long long size_bytes = 16ULL << 30;
static unsigned long long part_limit_bytes;
static unsigned int map_memory_mb = 256;
module_param(filename, charp, 0400);
module_param(algorithm, charp, 0400);
module_param(create, bool, 0400);
module_param(size_bytes, ullong, 0400);
module_param(part_limit_bytes, ullong, 0400);
module_param(map_memory_mb, uint, 0400);
MODULE_PARM_DESC(filename, "Absolute path ending in /volume000.db, or CLI-safe hex:<path-bytes>");
MODULE_PARM_DESC(create, "Exclusively create a NEW volume; never overwrite");
MODULE_PARM_DESC(algorithm, "Stored codec: none,lz4,lz4hc,lzo,lzo-rle,zstd,deflate,842");
MODULE_PARM_DESC(part_limit_bytes, "Create-only part cap 1..4000MiB, default 4000MiB; attach must match if specified");
MODULE_PARM_DESC(size_bytes, "Initial virtual bytes, default 16GiB, max 128GiB");
MODULE_PARM_DESC(map_memory_mb, "Sparse leaf budget 1..2048 MiB, default 256");

static struct db_part {
	struct file *file;
	u16 *refs;
	u64 incarnation, live_bytes, live_refs;
	u32 meta_pages, gc_pages;
	u32 hint;
} parts[DB_PARTS];
static struct file *directory;
static const struct cred *creation_cred;
static struct crypto_comp *codec;
static char codec_name[16];
static u8 volume_uuid[16];
static DEFINE_XARRAY(mapping);
static DEFINE_MUTEX(state_lock);
static u64 generation, capacity, mapped_blocks, stored_bytes, map_chunks;
static u64 part_limit = DB_DEFAULT_PART_LIMIT;
static struct db_pointer *tree_index;
static u32 tree_pages;
static const u32 node_starts[DB_HEIGHT] = { 0, 524288, 528384, 528416 };
static bool fenced, collecting;
static int avoid_part = -1;
static struct db_root *root, *other_root;
static struct db_header *header;
static struct db_node *tree_stack;
static struct db_transaction *transaction;
static void *raw, *packed, *scratch, *decoded;
static struct db_value cached_blob;
static struct {
	u64 logical[DB_BATCH];
	struct db_value old[DB_BATCH];
	u32 count;
	bool relative[DB_BATCH];
	u64 allocations[DB_BATCH];
	u32 allocation_pages[DB_BATCH], nr_allocations;
	struct {
		u32 index;
		struct db_pointer old;
	} dirty[DB_DIRTY];
	u32 nr_dirty;
	u64 next_refs[DB_PARTS], next_live[DB_PARTS];
	u32 next_meta[DB_PARTS], next_gc[DB_PARTS];
} stage;
static u32 gc_node = DB_NO_NODE;
static struct gendisk *disk;
static struct blk_mq_tag_set tags;
static struct workqueue_struct *worker;

static int block_ioctl(struct block_device *bdev, blk_mode_t mode,
		       unsigned int cmd, unsigned long arg);
static const struct block_device_operations operations = {
	.owner = THIS_MODULE,
	.ioctl = block_ioctl,
};

static u32 checksum(const void *p, size_t len)
{
	return crc32_le(~0U, p, len) ^ ~0U;
}

static bool zero(const void *p, size_t len)
{
	return !memchr_inv(p, 0, len);
}

static void seal(void *page)
{
	*(__le32 *)(page + DB_BLOCK - 4) = cpu_to_le32(checksum(page, DB_BLOCK - 4));
}

static bool sealed(const void *page)
{
	return le32_to_cpu(*(__le32 *)(page + DB_BLOCK - 4)) ==
		checksum(page, DB_BLOCK - 4);
}

static bool valid_capacity(u64 bytes)
{
	return bytes && bytes <= DB_LIMIT && !(bytes % DB_BLOCK);
}

static bool valid_part_limit(u64 bytes)
{
	return bytes >= DB_MIN_PART_LIMIT && bytes <= DB_DEFAULT_PART_LIMIT &&
		!(bytes % DB_BLOCK);
}

static u32 part_id(u64 location)
{
	return location >> 32;
}

static u64 location_of(u32 id, u32 page)
{
	return (u64)id << 32 | (u64)page * DB_BLOCK;
}

static int file_io(struct file *f, void *buf, size_t len, u64 offset, bool write)
{
	loff_t pos = offset;
	ssize_t n;

	if (!f || offset > part_limit || len > part_limit - offset)
		return -EUCLEAN;
	if (write)
		n = kernel_write(f, buf, len, &pos);
	else
		n = kernel_read(f, buf, len, &pos);
	return n == len ? 0 : n < 0 ? n : -EIO;
}

static int page_io(u64 location, void *buf, bool write)
{
	u32 id = part_id(location), offset = (u32)location;

	if (!location || id >= DB_PARTS || offset % DB_BLOCK ||
	    offset < (id ? DB_BLOCK : 3 * DB_BLOCK))
		return -EUCLEAN;
	return file_io(parts[id].file, buf, DB_BLOCK, offset, write);
}

static bool geometry(struct super_block *sb)
{
	/* Btrfs owns member geometry and buffered COW/fsync, not a generic s_bdev. */
	if (!strcmp(sb->s_type->name, "btrfs"))
		return sb->s_magic == BTRFS_SUPER_MAGIC && sb->s_blocksize == DB_BLOCK &&
			sb->s_maxbytes >= part_limit;
	return (!strcmp(sb->s_type->name, "ext4") ||
		!strcmp(sb->s_type->name, "ext2") || !strcmp(sb->s_type->name, "ntfs3") ||
		!strcmp(sb->s_type->name, "vfat") || !strcmp(sb->s_type->name, "exfat")) &&
		sb->s_bdev && sb->s_maxbytes >= DB_MIN_PART_LIMIT &&
		sb->s_blocksize >= 512 && sb->s_blocksize <= DB_BLOCK &&
		!(DB_BLOCK % sb->s_blocksize) &&
		bdev_logical_block_size(sb->s_bdev) >= 512 &&
		bdev_logical_block_size(sb->s_bdev) <= DB_BLOCK &&
		!(sb->s_blocksize % bdev_logical_block_size(sb->s_bdev)) &&
		bdev_physical_block_size(sb->s_bdev) >= 512 &&
		bdev_physical_block_size(sb->s_bdev) <= DB_BLOCK &&
		!(sb->s_blocksize % bdev_physical_block_size(sb->s_bdev)) &&
		!bdev_alignment_offset(sb->s_bdev) && sb->s_bdev->bd_disk->fops != &operations;
}

/* O_PATH inspection avoids ntfs_file_open's writable WOF decompression path. */
static int backing_attributes(struct file *f)
{
	struct fileattr fa = { .flags_valid = true };
	bool btrfs = !strcmp(file_inode(f)->i_sb->s_type->name, "btrfs");
	u32 flags;
	int ret;

	if (!btrfs && strcmp(file_inode(f)->i_sb->s_type->name, "ntfs3"))
		return 0;
	ret = vfs_fileattr_get(f->f_path.dentry, &fa);
	if (ret)
		return ret;
	if (!fa.flags_valid || (fa.flags & (FS_IMMUTABLE_FL | FS_APPEND_FL)))
		return -EOPNOTSUPP;
	if (btrfs)
		return fa.flags & FS_NOCOW_FL ? -EOPNOTSUPP : 0;
	if (fa.flags & (FS_COMPR_FL | FS_ENCRYPT_FL))
		return -EOPNOTSUPP;
	ret = vfs_getxattr(mnt_idmap(f->f_path.mnt), f->f_path.dentry,
			  "system.ntfs_attrib", &flags, sizeof(flags));
	if (ret != sizeof(flags))
		return ret < 0 ? ret : -EOPNOTSUPP;
	/* Sparse, reparse (including WOF/dedup), compressed, offline, encrypted. */
	return flags & 0x5e00U ? -EOPNOTSUPP : 0;
}

static int backing_inode(struct file *f)
{
	struct inode *inode = file_inode(f);

	if (!S_ISREG(inode->i_mode) || inode->i_nlink != 1 ||
	    !uid_eq(inode->i_uid, GLOBAL_ROOT_UID) ||
	    inode->i_mode & (S_IWGRP | S_IWOTH) || is_idmapped_mnt(f->f_path.mnt) ||
	    !geometry(inode->i_sb) || i_size_read(inode) > part_limit)
		return -EINVAL;
	return backing_attributes(f);
}

static int admit(struct file *f)
{
	struct file_lock *lock;
	int ret;

	ret = backing_inode(f);
	if (ret)
		return ret;
	lock = locks_alloc_lock();
	if (!lock)
		return -ENOMEM;
	lock->c.flc_owner = f;
	lock->c.flc_file = f;
	lock->c.flc_flags = FL_FLOCK;
	lock->c.flc_type = F_WRLCK;
	lock->c.flc_pid = task_tgid_nr(current);
	lock->fl_start = 0;
	lock->fl_end = OFFSET_MAX;
	ret = locks_lock_file_wait(f, lock);
	locks_free_lock(lock);
	return ret;
}

static int hex_nibble(char value)
{
	if (value >= '0' && value <= '9')
		return value - '0';
	if (value >= 'a' && value <= 'f')
		return value - 'a' + 10;
	if (value >= 'A' && value <= 'F')
		return value - 'A' + 10;
	return -EINVAL;
}

static int prepare_backing_filename(void)
{
	const char *encoded;
	size_t length, i;

	backing_filename = filename;
	if (!filename || strncmp(filename, "hex:", 4))
		return 0;
	encoded = filename + 4;
	length = strlen(encoded);
	if (!length || (length & 1) || length / 2 >= PATH_MAX)
		return -EINVAL;
	decoded_filename = kmalloc(length / 2 + 1, GFP_KERNEL);
	if (!decoded_filename)
		return -ENOMEM;
	for (i = 0; i < length; i += 2) {
		int high = hex_nibble(encoded[i]);
		int low = hex_nibble(encoded[i + 1]);
		if (high < 0 || low < 0 || !(decoded_filename[i / 2] = (high << 4) | low)) {
			kfree(decoded_filename);
			decoded_filename = NULL;
			return -EINVAL;
		}
	}
	decoded_filename[length / 2] = 0;
	backing_filename = decoded_filename;
	return 0;
}

static int pin_directory(void)
{
	struct path path;
	char *parent, *slash, *p;
	int ret = -EINVAL;

	if (!backing_filename || backing_filename[0] != '/' || strlen(backing_filename) >= PATH_MAX)
		return -EINVAL;
	parent = kstrdup(backing_filename, GFP_KERNEL);
	if (!parent)
		return -ENOMEM;
	slash = strrchr(parent, '/');
	if (strcmp(slash + 1, "volume000.db"))
		goto out;
	for (p = parent; p <= slash; p++) {
		struct inode *inode;
		char saved;

		if (*p != '/')
			continue;
		if (p != parent && (p[-1] == '/' ||
		    (p[-1] == '.' && (p - parent == 1 || p[-2] == '/' ||
		    (p[-2] == '.' && (p - parent == 2 || p[-3] == '/'))))))
			goto out;
		saved = p == parent ? parent[1] : *p;
		if (p == parent)
			parent[1] = 0;
		else
			*p = 0;
		ret = kern_path(parent, LOOKUP_DIRECTORY | LOOKUP_NO_SYMLINKS, &path);
		if (p == parent)
			parent[1] = saved;
		else
			*p = saved;
		if (ret)
			goto out;
		inode = d_inode(path.dentry);
		ret = -EPERM;
		if (is_idmapped_mnt(path.mnt) || !uid_eq(inode->i_uid, GLOBAL_ROOT_UID) ||
		    inode->i_mode & (S_IWGRP | S_IWOTH)) {
			path_put(&path);
			goto out;
		}
		if (p == slash) {
			directory = dentry_open(&path, O_RDONLY | O_DIRECTORY, creation_cred);
			path_put(&path);
			if (IS_ERR(directory)) {
				ret = PTR_ERR(directory);
				directory = NULL;
				goto out;
			}
			ret = geometry(file_inode(directory)->i_sb) ? 0 : -EOPNOTSUPP;
			if (!ret)
				ret = backing_attributes(directory);
			break;
		}
		path_put(&path);
	}
out:
	kfree(parent);
	return ret;
}

static int setup_codec(const char *name)
{
	static const char * const names[] = {
		"none", "lz4", "lz4hc", "lzo", "lzo-rle", "zstd", "deflate", "842",
	};
	u32 i;

	for (i = 0; i < ARRAY_SIZE(names); i++)
		if (!strcmp(name, names[i]))
			break;
	if (i == ARRAY_SIZE(names))
		return -EINVAL;
	strscpy(codec_name, name, sizeof(codec_name));
	if (!i)
		return 0;
	codec = crypto_alloc_comp(name, 0, 0);
	if (IS_ERR(codec)) {
		int ret = PTR_ERR(codec);

		codec = NULL;
		return ret;
	}
	return 0;
}

static int open_part(u32 id, bool exclusive)
{
	struct db_header *h = header;
	struct db_part *p = &parts[id];
	const struct cred *old;
	char name[16];
	struct file *f;
	int ret;

	if (p->file)
		return 0;
	snprintf(name, sizeof(name), "volume%03u.db", id);
	old = override_creds(creation_cred);
	if (exclusive) {
		ret = backing_attributes(directory);
		f = ret ? ERR_PTR(ret) : file_open_root(&directory->f_path, name,
			O_RDWR | O_NOFOLLOW | O_LARGEFILE | O_CREAT | O_EXCL, 0600);
	} else {
		struct file *probe = file_open_root(&directory->f_path, name,
						  O_PATH | O_NOFOLLOW, 0);

		if (IS_ERR(probe)) {
			f = probe;
		} else {
			ret = backing_inode(probe);
			f = ret ? ERR_PTR(ret) : dentry_open(&probe->f_path,
				O_RDWR | O_LARGEFILE | O_NONBLOCK, creation_cred);
			filp_close(probe, NULL);
		}
	}
	revert_creds(old);
	if (IS_ERR(f))
		return PTR_ERR(f);
	ret = admit(f);
	if (ret)
		goto close;
	if (exclusive) {
		memset(h, 0, DB_BLOCK);
		memcpy(h->magic, "DBPART01", 8);
		memcpy(h->uuid, volume_uuid, 16);
		do {
			get_random_bytes(&p->incarnation, sizeof(p->incarnation));
		} while (!p->incarnation);
		h->incarnation = cpu_to_le64(p->incarnation);
		h->part = cpu_to_le32(id);
		h->format = cpu_to_le32(1);
		h->limit = cpu_to_le64(part_limit);
		memcpy(h->algorithm, codec_name, 16);
		seal(h);
		ret = file_io(f, h, DB_BLOCK, 0, true);
		if (!ret)
			ret = vfs_fsync(f, 0);
		if (!ret)
			ret = vfs_fsync(directory, 0);
	} else {
		ret = file_io(f, h, DB_BLOCK, 0, false);
		if (!ret && (!sealed(h) || memcmp(h->magic, "DBPART01", 8) ||
		    h->part != cpu_to_le32(id) || h->format != cpu_to_le32(1) ||
		    !valid_part_limit(le64_to_cpu(h->limit)) || !h->incarnation ||
		    zero(h->uuid, 16) || !zero(h->reserved, sizeof(h->reserved)) ||
		    !memchr(h->algorithm, 0, 16)))
			ret = -EUCLEAN;
		if (!ret && !id) {
			part_limit = le64_to_cpu(h->limit);
			memcpy(volume_uuid, h->uuid, 16);
			if ((part_limit_bytes && part_limit_bytes != part_limit) ||
			    (algorithm && strcmp(algorithm, h->algorithm)))
				ret = -EINVAL;
			else
				ret = setup_codec(h->algorithm);
		}
		if (!ret && (h->limit != cpu_to_le64(part_limit) ||
		    memcmp(h->uuid, volume_uuid, 16) ||
		    memcmp(h->algorithm, codec_name, 16)))
			ret = -EUCLEAN;
		p->incarnation = le64_to_cpu(h->incarnation);
	}
	if (ret)
		goto close;
	if (part_limit > file_inode(f)->i_sb->s_maxbytes ||
	    i_size_read(file_inode(f)) > part_limit) {
		ret = -EFBIG;
		goto close;
	}
	p->refs = kvcalloc(DB_PAGES, sizeof(*p->refs), GFP_NOIO);
	if (!p->refs) {
		ret = -ENOMEM;
		goto close;
	}
	p->refs[0] = DB_BUSY;
	if (!id)
		p->refs[1] = p->refs[2] = DB_BUSY;
	p->hint = id ? 1 : 3;
	p->file = f;
	return 0;
close:
	filp_close(f, NULL);
	return ret;
}

static struct db_value *map_slot(u64 logical)
{
	struct db_value *chunk = xa_load(&mapping, logical / DB_CHUNK);

	return chunk ? &chunk[logical % DB_CHUNK] : NULL;
}

static int reserve_map(u64 logical)
{
	void *chunk;
	int ret;

	if (map_slot(logical))
		return 0;
	if (map_chunks >= ((u64)map_memory_mb << 20) / DB_BLOCK)
		return -ENOSPC;
	chunk = (void *)get_zeroed_page(GFP_NOIO);
	if (!chunk)
		return -ENOMEM;
	ret = xa_insert(&mapping, logical / DB_CHUNK, chunk, GFP_NOIO);
	if (ret)
		free_page((unsigned long)chunk);
	else
		map_chunks++;
	return ret;
}

/* First fit with a wrapping hint. DB_BUSY reserves pages before publication. */
static int allocate(u32 count, bool metadata, u64 *location)
{
	u32 id, pass, max = metadata || collecting ? DB_PARTS : DB_PARTS - 2;
	int ret;

	for (pass = 0; pass < 2; pass++) {
		for (id = 0; id < max; id++) {
			struct db_part *p = &parts[id];
			u32 start, end, run = 0, page, lap;

			if (id == avoid_part || (!pass && !p->file) || (pass && p->file))
				continue;
			if (!p->file) {
				ret = open_part(id, true);
				if (ret)
					return ret;
			}
			for (lap = 0; lap < 2; lap++) {
				start = lap ? (id ? 1 : 3) : p->hint;
				end = DB_PAGES;
				run = 0;
				for (page = start; page < end; page++) {
					run = p->refs[page] ? 0 : run + 1;
					if (run != count)
						continue;
					start = page + 1 - count;
					for (run = start; run <= page; run++)
						p->refs[run] = DB_BUSY;
					p->hint = page + 1;
					*location = location_of(id, start);
					return 0;
				}
			}
		}
	}
	return -ENOSPC;
}

static void release_page(u64 location)
{
	struct db_part *p = &parts[part_id(location)];
	u32 page = (u32)location / DB_BLOCK;

	p->refs[page] = 0;
	p->hint = min(p->hint, page);
}

static bool valid_value(const struct db_value *v, u64 logical, u64 max_generation)
{
	u64 loc = le64_to_cpu(v->location), version = le64_to_cpu(v->version);
	u32 id = part_id(loc), len = le32_to_cpu(v->length);
	u32 output = le32_to_cpu(v->decoded_length), offset = le32_to_cpu(v->decoded_offset);
	u32 flags = le32_to_cpu(v->flags);

	if (!loc)
		return zero(v, sizeof(*v));
	if (id >= DB_PARTS || !version || version > max_generation || !len ||
	    len > DB_REGION || (u32)loc < (id ? DB_BLOCK : 3 * DB_BLOCK) ||
	    (u32)loc > part_limit - len || flags > 1 ||
	    (output != DB_BLOCK && output != DB_REGION) || offset % DB_BLOCK ||
	    offset > output - DB_BLOCK)
		return false;
	if (!flags)
		return len == DB_BLOCK && output == DB_BLOCK && !offset;
	return codec && len < output &&
		(output == DB_BLOCK ? !offset : offset == (logical % DB_SUBBLOCKS) * DB_BLOCK);
}

static bool same_blob(const struct db_value *a, const struct db_value *b)
{
	return a->location == b->location && a->version == b->version &&
		a->length == b->length && a->stored_crc == b->stored_crc &&
		a->decoded_length == b->decoded_length && a->flags == b->flags;
}

/* Shared 64KiB blobs are charged once, to their first surviving subblock. */
static u32 value_charge(u64 logical, const struct db_value *v)
{
	u64 first;

	if (!v || !v->location)
		return 0;
	if (le32_to_cpu(v->decoded_length) == DB_REGION) {
		for (first = round_down(logical, (u64)DB_SUBBLOCKS); first < logical; first++) {
			const struct db_value *other = map_slot(first);

			if (other && same_blob(other, v))
				return 0;
		}
	}
	return le32_to_cpu(v->length);
}

static int payload_refs(const struct db_value *value, bool add)
{
	u64 location = le64_to_cpu(value->location);
	u32 id = part_id(location), offset = (u32)location;
	u32 len = le32_to_cpu(value->length), page, last;
	struct db_part *p;

	if (!location)
		return zero(value, sizeof(*value)) ? 0 : -EUCLEAN;
	if (id >= DB_PARTS || !parts[id].file || !len || len > DB_REGION ||
	    offset < (id ? DB_BLOCK : 3 * DB_BLOCK) || offset > part_limit - len ||
	    offset + (u64)len > i_size_read(file_inode(parts[id].file)))
		return -EUCLEAN;
	p = &parts[id];
	last = (offset + len - 1) / DB_BLOCK;
	for (page = offset / DB_BLOCK; page <= last; page++) {
		if (add) {
			if (p->refs[page] >= DB_BUSY - 1)
				return -EUCLEAN;
			p->refs[page]++;
		} else {
			if (!p->refs[page] || p->refs[page] == DB_BUSY)
				return -EUCLEAN;
			if (!--p->refs[page])
				p->hint = min(p->hint, page);
		}
	}
	return 0;
}

static int read_value(const struct db_value *value, void *out)
{
	u64 location;
	u32 len, flags, outlen, offset;
	int ret;

	if (!value || !value->location) {
		memset(out, 0, DB_BLOCK);
		return value && !zero(value, sizeof(*value)) ? -EUCLEAN : 0;
	}
	location = le64_to_cpu(value->location);
	len = le32_to_cpu(value->length);
	flags = le32_to_cpu(value->flags);
	outlen = le32_to_cpu(value->decoded_length);
	offset = le32_to_cpu(value->decoded_offset);
	if (!valid_value(value, offset / DB_BLOCK, generation))
		return -EUCLEAN;
	if (!cached_blob.location || !same_blob(value, &cached_blob)) {
		cached_blob.location = 0;
		ret = file_io(parts[part_id(location)].file, scratch, len, (u32)location, false);
		if (ret)
			return ret;
		if (checksum(scratch, len) != le32_to_cpu(value->stored_crc))
			return -EUCLEAN;
		if (flags) {
			ret = crypto_comp_decompress(codec, scratch, len, decoded, &outlen);
			if (ret || outlen != le32_to_cpu(value->decoded_length))
				return -EUCLEAN;
		} else {
			memcpy(decoded, scratch, DB_BLOCK);
		}
		cached_blob = *value;
	}
	memcpy(out, decoded + offset, DB_BLOCK);
	return checksum(out, DB_BLOCK) == le32_to_cpu(value->original_crc) ? 0 : -EUCLEAN;
}

static int sync_parts(void)
{
	u32 id;
	int ret;

	if (fenced)
		return -EIO;
	for (id = 0; id < DB_PARTS; id++) {
		if (!parts[id].file)
			continue;
		ret = vfs_fsync(parts[id].file, 0);
		if (ret) {
			fenced = true;
			return ret;
		}
	}
	return 0;
}

/* Both durable publications are required before ANY old reference is freed. */
static int publish_root(void)
{
	u32 copy;
	int ret;

	seal(root);
	for (copy = 1; copy <= 2; copy++) {
		ret = file_io(parts[0].file, root, DB_BLOCK, copy * DB_BLOCK, true);
		if (!ret)
			ret = vfs_fsync(parts[0].file, 0);
		if (ret)
			return ret;
	}
	return 0;
}

static int remove_part(u32 id)
{
	struct db_part *p = &parts[id];
	struct inode *dir = file_inode(directory);
	struct dentry *dentry;
	const struct cred *old;
	char name[16];
	int ret;

	snprintf(name, sizeof(name), "volume%03u.db", id);
	old = override_creds(creation_cred);
	ret = mnt_want_write(directory->f_path.mnt);
	if (ret)
		goto out;
	inode_lock(dir);
	dentry = lookup_one_len(name, directory->f_path.dentry, strlen(name));
	if (IS_ERR(dentry)) {
		ret = PTR_ERR(dentry);
	} else {
		ret = d_inode(dentry) == file_inode(p->file) ?
			vfs_unlink(mnt_idmap(directory->f_path.mnt), dir, dentry, NULL) : -ESTALE;
		dput(dentry);
	}
	inode_unlock(dir);
	mnt_drop_write(directory->f_path.mnt);
	if (!ret)
		ret = vfs_fsync(directory, 0);
	if (!ret) {
		filp_close(p->file, NULL);
		kvfree(p->refs);
		memset(p, 0, sizeof(*p));
	}
out:
	revert_creds(old);
	return ret;
}

/* Root-selected references only; callers have already retired both old roots. */
static int trim_parts(void)
{
	u32 id;
	int ret;

	for (id = 0; id < DB_PARTS; id++) {
		struct db_part *p = &parts[id];
		u32 last;

		if (!p->file)
			continue;
		last = DIV_ROUND_UP_ULL(i_size_read(file_inode(p->file)), DB_BLOCK);
		while (last > (id ? 1 : 3) && !p->refs[last - 1])
			last--;
		if (id && last == 1) {
			if (root->incarnations[id])
				return -EUCLEAN;
			ret = remove_part(id);
		} else if (i_size_read(file_inode(p->file)) > (u64)last * DB_BLOCK) {
			const struct cred *old = override_creds(creation_cred);

			ret = vfs_truncate(&p->file->f_path, (u64)last * DB_BLOCK);
			if (!ret)
				ret = vfs_fsync(p->file, 0);
			revert_creds(old);
		} else {
			ret = 0;
		}
		if (ret)
			return ret;
		cond_resched();
	}
	return 0;
}

static void active_location(u64 location)
{
	u32 id = part_id(location);

	root->incarnations[id] = cpu_to_le64(parts[id].incarnation);
}

static u32 node_index(u32 level, u64 logical)
{
	return node_starts[level] + (logical >> (6 + 7 * level));
}

static u32 node_level(u32 index)
{
	u32 level = DB_HEIGHT - 1;

	while (level && index < node_starts[level])
		level--;
	return level;
}

static u64 node_base(u32 index)
{
	u32 level = node_level(index);

	return (u64)(index - node_starts[level]) << (6 + 7 * level);
}

static bool valid_pointer(const struct db_pointer *p)
{
	u64 location = le64_to_cpu(p->location);
	u32 id = part_id(location), offset = (u32)location;

	if (!location)
		return zero(p, sizeof(*p));
	return id < DB_PARTS && offset >= (id ? DB_BLOCK : 3 * DB_BLOCK) &&
		!(offset % DB_BLOCK) && offset <= part_limit - DB_BLOCK &&
		p->generation && !p->reserved;
}

static void make_pointer(struct db_pointer *p, u64 location, const void *page)
{
	memset(p, 0, sizeof(*p));
	p->location = cpu_to_le64(location);
	p->generation = cpu_to_le64(generation + 1);
	p->crc = *(__le32 *)(page + DB_BLOCK - 4);
}

static int read_node(const struct db_pointer *p, u32 level, u64 base,
		     u64 parent_generation, struct db_node *node)
{
	u32 i, count = 0;
	int ret;

	if (!valid_pointer(p) || !p->location ||
	    le64_to_cpu(p->generation) > parent_generation)
		return -EUCLEAN;
	ret = page_io(le64_to_cpu(p->location), node, false);
	if (ret)
		return ret;
	if (!sealed(node) || p->crc != node->crc || p->generation != node->generation ||
	    memcmp(node->magic, "DBTREE01", 8) || memcmp(node->uuid, volume_uuid, 16) ||
	    node->base != cpu_to_le64(base) || node->level != cpu_to_le32(level) ||
	    !zero(node->reserved, sizeof(node->reserved)))
		return -EUCLEAN;
	if (level) {
		for (i = 0; i < DB_FANOUT; i++) {
			struct db_pointer *child = &node->children[i];
			u64 logical = base + ((u64)i << (6 + 7 * (level - 1)));

			if (!valid_pointer(child) || (child->location &&
			    (logical >= capacity / DB_BLOCK ||
			     le64_to_cpu(child->generation) > le64_to_cpu(node->generation))))
				return -EUCLEAN;
			count += !!child->location;
		}
		i = sizeof(node->children);
	} else {
		for (i = 0; i < DB_CHUNK; i++) {
			struct db_value *v = &node->values[i];

			if (!valid_value(v, base + i, le64_to_cpu(node->generation)) ||
			    (v->location && base + i >= capacity / DB_BLOCK))
				return -EUCLEAN;
			count += !!v->location;
		}
		i = sizeof(node->values);
	}
	return count && count == le32_to_cpu(node->count) &&
		zero(node->bytes + i, sizeof(node->bytes) - i) ? 0 : -EUCLEAN;
}

static int dirty_path(u32 index)
{
	u32 level, i;
	u64 base;

	if (index >= DB_NODES)
		return -EUCLEAN;
	level = node_level(index);
	base = node_base(index);
	for (; level < DB_HEIGHT; level++) {
		index = node_index(level, base);
		for (i = 0; i < stage.nr_dirty; i++)
			if (stage.dirty[i].index == index)
				break;
		if (i != stage.nr_dirty)
			continue;
		if (i == DB_DIRTY)
			return -E2BIG;
		stage.dirty[i].index = index;
		stage.dirty[i].old = tree_index[index];
		stage.nr_dirty++;
	}
	return 0;
}

/* Build children first; only the dirty paths change in the resident pointer index. */
static int write_tree(void)
{
	struct db_node *node = &tree_stack[0];
	u32 level, d, i;
	int ret;

	for (level = 0; level < DB_HEIGHT; level++) {
		for (d = 0; d < stage.nr_dirty; d++) {
			u32 index = stage.dirty[d].index, count = 0;
			u64 base = node_base(index), location;
			struct db_pointer *p = &tree_index[index];

			if (node_level(index) != level)
				continue;
			if (p->location) {
				ret = read_node(p, level, base, generation, node);
				if (ret)
					return ret;
			}
			memset(node, 0, DB_BLOCK);
			memcpy(node->magic, "DBTREE01", 8);
			memcpy(node->uuid, volume_uuid, 16);
			node->generation = cpu_to_le64(generation + 1);
			node->base = cpu_to_le64(base);
			node->level = cpu_to_le32(level);
			if (level) {
				for (i = 0; i < DB_FANOUT; i++) {
					u64 logical = base + ((u64)i << (6 + 7 * (level - 1)));

					if (logical >= DB_LIMIT / DB_BLOCK)
						break;
					node->children[i] = tree_index[node_index(level - 1, logical)];
					count += !!node->children[i].location;
				}
			} else {
				struct db_value *values = map_slot(base);

				if (values)
					memcpy(node->values, values, sizeof(node->values));
				for (i = 0; i < DB_CHUNK; i++)
					count += !!node->values[i].location;
			}
			memset(p, 0, sizeof(*p));
			if (!count)
				continue;
			node->count = cpu_to_le32(count);
			seal(node);
			ret = allocate(1, true, &location);
			if (ret)
				return ret;
			ret = page_io(location, node, true);
			if (ret)
				return ret;
			make_pointer(p, location, node);
		}
	}
	return 0;
}

static void prune_map(void)
{
	u32 i;

	for (i = 0; i < stage.count; i++) {
		u64 index = stage.logical[i] / DB_CHUNK;
		void *chunk = xa_load(&mapping, index);

		if (!chunk || !zero(chunk, DB_BLOCK))
			continue;
		xa_erase(&mapping, index);
		free_page((unsigned long)chunk);
		map_chunks--;
	}
}

/* Leave host headroom for a victim and bounded dirty-path transactions. */
static int working_room(void)
{
	struct kstatfs st;
	u64 largest = 0, free_bytes, needed;
	u32 id;
	int ret;

	if (collecting)
		return 0;
	ret = vfs_statfs(&directory->f_path, &st);
	if (ret)
		return ret;
	if (st.f_bsize <= 0 || st.f_bsize > (1U << 25) ||
	    st.f_bavail > U64_MAX / st.f_bsize)
		return -EOVERFLOW;
	free_bytes = st.f_bavail * st.f_bsize;
	for (id = 0; id < DB_PARTS; id++)
		largest = max(largest, min_t(u64, part_limit,
			      ((u64)parts[id].gc_pages + parts[id].meta_pages) * DB_BLOCK));
	needed = largest + 2 * DB_IO +
		2 * (DB_DIRTY + 1) * DB_BLOCK +
		2 * (DB_PARTS + 1) * st.f_bsize;
	return free_bytes >= needed ? 0 : -ENOSPC;
}

static int flush_payload(u32 bytes)
{
	u64 location;
	u32 pages = DIV_ROUND_UP(bytes, DB_BLOCK), i;
	int ret;

	if (!bytes)
		return 0;
	if (bytes > DB_REGION || stage.nr_allocations == DB_BATCH)
		return -E2BIG;
	ret = allocate(pages, false, &location);
	if (ret)
		return ret;
	stage.allocations[stage.nr_allocations] = location;
	stage.allocation_pages[stage.nr_allocations++] = pages;
	ret = file_io(parts[part_id(location)].file, packed, pages * DB_BLOCK,
		      (u32)location, true);
	if (ret)
		return ret;
	for (i = 0; i < stage.count; i++) {
		struct db_value *v = &transaction->entries[i].value;

		if (!stage.relative[i])
			continue;
		v->location = cpu_to_le64(le64_to_cpu(v->location) + location);
		stage.relative[i] = false;
	}
	memset(packed, 0, DB_REGION);
	return 0;
}

static int prepare_payload(void)
{
	u32 i = 0, used = 0, j;
	int ret;

	memset(packed, 0, DB_REGION);
	memset(stage.relative, 0, sizeof(stage.relative));
	while (i < stage.count) {
		struct db_value blob = {};
		u32 n = 1, len = 2 * DB_REGION, output, crc;
		void *source = raw + i * DB_BLOCK;
		bool encoded = false;

		if (!collecting && codec && !(stage.logical[i] % DB_SUBBLOCKS) &&
		    stage.count - i >= DB_SUBBLOCKS) {
			for (j = 1; j < DB_SUBBLOCKS; j++)
				if (stage.logical[i + j] != stage.logical[i] + j)
					break;
			if (j == DB_SUBBLOCKS)
				n = DB_SUBBLOCKS;
		}
		if (zero(source, n * DB_BLOCK)) {
			i += n;
			continue;
		}
		output = n * DB_BLOCK;
		if (collecting) {
			blob = stage.old[i];
			/* A collection batch never splits a logical compression region. */
			for (j = 0; j < i; j++)
				if (transaction->entries[j].value.length && same_blob(&stage.old[j], &blob))
					break;
			if (j < i) {
				struct db_value *v = &transaction->entries[i].value;

				*v = transaction->entries[j].value;
				v->original_crc = blob.original_crc;
				v->decoded_offset = blob.decoded_offset;
				stage.relative[i] = stage.relative[j];
				i++;
				continue;
			}
			len = le32_to_cpu(blob.length);
			output = le32_to_cpu(blob.decoded_length);
			if (!valid_value(&blob, stage.logical[i], generation))
				return -EUCLEAN;
			ret = file_io(parts[part_id(le64_to_cpu(blob.location))].file,
				      scratch, len, (u32)le64_to_cpu(blob.location), false);
			if (ret)
				return ret;
			if (checksum(scratch, len) != le32_to_cpu(blob.stored_crc))
				return -EUCLEAN;
			source = scratch;
			encoded = !!blob.flags;
		} else if (codec) {
			ret = crypto_comp_compress(codec, source, output, scratch, &len);
			if (ret)
				return ret;
			if (!len)
				return -EIO;
			if (len < output) {
				source = scratch;
				encoded = true;
			} else {
				/* Raw fallback stays independently replaceable at 4KiB. */
				n = 1;
				len = output = DB_BLOCK;
			}
		} else {
			len = output = DB_BLOCK;
		}
		if (used + len > DB_REGION) {
			ret = flush_payload(used);
			if (ret)
				return ret;
			used = 0;
		}
		memcpy(packed + used, source, len);
		crc = checksum(packed + used, len);
		for (j = 0; j < n; j++) {
			struct db_value *v = &transaction->entries[i + j].value;
			void *block = raw + (i + j) * DB_BLOCK;

			if (zero(block, DB_BLOCK))
				continue;
			v->location = cpu_to_le64(used);
			v->version = cpu_to_le64(generation + 1);
			v->length = cpu_to_le32(len);
			v->stored_crc = cpu_to_le32(crc);
			v->original_crc = cpu_to_le32(checksum(block, DB_BLOCK));
			v->flags = cpu_to_le32(encoded);
			v->decoded_length = cpu_to_le32(output);
			v->decoded_offset = collecting ? blob.decoded_offset : cpu_to_le32(j * DB_BLOCK);
			stage.relative[i + j] = true;
		}
		used += len;
		i += n;
	}
	return flush_payload(used);
}

/* Predict the exact region-at-a-time packing performed by collection. */
static void region_estimate(u64 base, u32 pages[DB_PARTS])
{
	u32 used[DB_PARTS] = {}, id;
	u64 logical;

	memset(pages, 0, DB_PARTS * sizeof(*pages));
	for (logical = base; logical < base + DB_SUBBLOCKS; logical++) {
		const struct db_value *v = map_slot(logical);
		u32 bytes = value_charge(logical, v);

		if (!bytes)
			continue;
		id = part_id(le64_to_cpu(v->location));
		if (used[id] + bytes > DB_REGION) {
			pages[id] += DIV_ROUND_UP(used[id], DB_BLOCK);
			used[id] = 0;
		}
		used[id] += bytes;
	}
	for (id = 0; id < DB_PARTS; id++)
		pages[id] += DIV_ROUND_UP(used[id], DB_BLOCK);
}

static void region_account(bool add)
{
	u32 i, id, pages[DB_PARTS];
	u64 previous = U64_MAX;

	for (i = 0; i < stage.count; i++) {
		u64 base = round_down(stage.logical[i], (u64)DB_SUBBLOCKS), logical;

		if (base == previous)
			continue;
		previous = base;
		region_estimate(base, pages);
		for (id = 0; id < DB_PARTS; id++) {
			if (add)
				stage.next_gc[id] += pages[id];
			else
				stage.next_gc[id] -= pages[id];
		}
		for (logical = base; logical < base + DB_SUBBLOCKS; logical++) {
			const struct db_value *v = map_slot(logical);
			u32 charge = value_charge(logical, v), id;

			if (!charge)
				continue;
			id = part_id(le64_to_cpu(v->location));
			if (add)
				stage.next_live[id] += charge;
			else
				stage.next_live[id] -= charge;
		}
	}
}

/* RAM staging is private under state_lock; no global map serialization occurs. */
static int commit_staged(u64 new_capacity)
{
	u64 new_transaction, old_mapped = mapped_blocks;
	u32 i, j, new_tree_pages = tree_pages;
	int ret;

	if (fenced || generation == U64_MAX) {
		fenced = true;
		return -EIO;
	}
	if (stage.count > DB_BATCH || !valid_capacity(new_capacity) || new_capacity < capacity)
		return -EINVAL;
	for (i = 0; i < stage.count; i++)
		if (stage.logical[i] >= capacity / DB_BLOCK ||
		    (i && stage.logical[i] <= stage.logical[i - 1]))
			return -EINVAL;
	ret = working_room();
	if (ret)
		goto fail_committed;
	memcpy(other_root, root, DB_BLOCK);
	stage.nr_allocations = stage.nr_dirty = 0;
	for (i = 0; i < DB_PARTS; i++) {
		stage.next_refs[i] = parts[i].live_refs;
		stage.next_meta[i] = parts[i].meta_pages;
		stage.next_gc[i] = parts[i].gc_pages;
		stage.next_live[i] = parts[i].live_bytes;
	}
	memset(transaction, 0, DB_BLOCK);
	memcpy(transaction->magic, "DBTXN001", 8);
	memcpy(transaction->uuid, volume_uuid, 16);
	transaction->generation = cpu_to_le64(generation + 1);
	transaction->previous = cpu_to_le64(generation);
	transaction->capacity = cpu_to_le64(new_capacity);
	transaction->count = cpu_to_le32(stage.count);
	for (i = 0; i < stage.count; i++) {
		transaction->entries[i].logical = cpu_to_le64(stage.logical[i]);
		memset(&stage.old[i], 0, sizeof(stage.old[i]));
		if (map_slot(stage.logical[i]))
			stage.old[i] = *map_slot(stage.logical[i]);
		if (!zero(raw + i * DB_BLOCK, DB_BLOCK)) {
			ret = reserve_map(stage.logical[i]);
			if (ret)
				goto fail_unstaged;
		}
	}
	ret = prepare_payload();
	if (ret)
		goto fail_unstaged;
	region_account(false);
	for (i = 0; i < stage.count; i++) {
		struct db_value *v = &transaction->entries[i].value;

		mapped_blocks += !!v->location;
		mapped_blocks -= !!stage.old[i].location;
		if (stage.old[i].location)
			stage.next_refs[part_id(le64_to_cpu(stage.old[i].location))]--;
		if (v->location)
			stage.next_refs[part_id(le64_to_cpu(v->location))]++;
		if (map_slot(stage.logical[i]))
			*map_slot(stage.logical[i]) = *v;
	}
	region_account(true);
	for (i = 0; i < stage.count; i++) {
		ret = dirty_path(node_index(0, stage.logical[i]));
		if (ret)
			goto fail;
	}
	if (gc_node != DB_NO_NODE) {
		ret = dirty_path(gc_node);
		if (ret)
			goto fail;
	}
	ret = write_tree();
	if (ret)
		goto fail;
	for (i = 0; i < stage.nr_dirty; i++) {
		u64 old = le64_to_cpu(stage.dirty[i].old.location);
		u64 new = le64_to_cpu(tree_index[stage.dirty[i].index].location);

		if (old) {
			stage.next_refs[part_id(old)]--;
			stage.next_meta[part_id(old)]--;
			new_tree_pages--;
		}
		if (new) {
			stage.next_refs[part_id(new)]++;
			stage.next_meta[part_id(new)]++;
			new_tree_pages++;
		}
	}
	ret = allocate(1, true, &new_transaction);
	if (ret)
		goto fail;
	seal(transaction);
	ret = page_io(new_transaction, transaction, true);
	if (ret)
		goto fail;
	if (root->transaction.location) {
		i = part_id(le64_to_cpu(root->transaction.location));
		stage.next_refs[i]--;
		stage.next_meta[i]--;
	}
	stage.next_refs[part_id(new_transaction)]++;
	stage.next_meta[part_id(new_transaction)]++;
	root->generation = cpu_to_le64(generation + 1);
	root->capacity = cpu_to_le64(new_capacity);
	root->mappings = cpu_to_le64(mapped_blocks);
	root->tree_pages = cpu_to_le32(new_tree_pages);
	root->tree_height = cpu_to_le32(DB_HEIGHT);
	root->tree = tree_index[DB_NODES - 1];
	make_pointer(&root->transaction, new_transaction, transaction);
	for (i = 0; i < DB_PARTS; i++)
		root->incarnations[i] = !i || stage.next_refs[i] ?
			cpu_to_le64(parts[i].incarnation) : 0;
	ret = sync_parts();
	if (!ret)
		ret = publish_root();
	if (ret)
		goto fail;
	/* Both fallback roots now name the new tree. Only now can old pages be reused. */
	generation++;
	capacity = new_capacity;
	tree_pages = new_tree_pages;
	cached_blob.location = 0;
	for (i = 0; i < stage.nr_allocations; i++)
		for (j = 0; j < stage.allocation_pages[i]; j++)
			release_page(stage.allocations[i] + j * DB_BLOCK);
	for (i = 0; i < stage.count; i++) {
		ret = payload_refs(&transaction->entries[i].value, true);
		if (!ret)
			ret = payload_refs(&stage.old[i], false);
		if (ret)
			goto fail_committed;
	}
	for (i = 0; i < stage.nr_dirty; i++)
		if (stage.dirty[i].old.location)
			release_page(le64_to_cpu(stage.dirty[i].old.location));
	if (other_root->transaction.location)
		release_page(le64_to_cpu(other_root->transaction.location));
	stored_bytes = 0;
	for (i = 0; i < DB_PARTS; i++) {
		parts[i].live_refs = stage.next_refs[i];
		parts[i].meta_pages = stage.next_meta[i];
		parts[i].gc_pages = stage.next_gc[i];
		parts[i].live_bytes = stage.next_live[i];
		stored_bytes += stage.next_live[i];
	}
	prune_map();
	ret = trim_parts();
	if (ret)
		goto fail_committed;
	return 0;
fail:
	for (i = 0; i < stage.nr_dirty; i++)
		tree_index[stage.dirty[i].index] = stage.dirty[i].old;
	for (i = 0; i < stage.count; i++)
		if (map_slot(stage.logical[i]))
			*map_slot(stage.logical[i]) = stage.old[i];
	mapped_blocks = old_mapped;
	memcpy(root, other_root, DB_BLOCK);
fail_unstaged:
	prune_map();
fail_committed:
	fenced = true;
	return ret;
}

/* Collect a victim into other parts, using the same durable COW path as writes. */
static int collect_part(void)
{
	u64 best = U64_MAX;
	u32 id, victim = DB_PARTS, group, i;
	unsigned long index;
	struct db_value *chunk;
	int ret = 0;

	for (id = 0; id < DB_PARTS; id++) {
		struct db_part *p = &parts[id];
		u64 span, useful;

		if (!p->file || !p->live_refs)
			continue;
		span = i_size_read(file_inode(p->file)) - (id ? DB_BLOCK : 3 * DB_BLOCK);
		/* Encoded density alone mistakes unavoidable page padding for garbage. */
		useful = ((u64)p->gc_pages + p->meta_pages) * DB_BLOCK;
		if (span < 2 * DB_IO || useful > span * 3 / 4 || useful >= best)
			continue;
		best = useful;
		victim = id;
	}
	if (victim == DB_PARTS)
		return 0;
	collecting = true;
	avoid_part = victim;
	xa_for_each(&mapping, index, chunk) {
		for (group = 0; group < DB_CHUNK; group += DB_SUBBLOCKS) {
			stage.count = 0;
			for (i = 0; i < DB_SUBBLOCKS; i++) {
				u64 logical = (u64)index * DB_CHUNK + group + i;
				struct db_value *v = map_slot(logical);

				if (!v || !v->location || part_id(le64_to_cpu(v->location)) != victim)
					continue;
				ret = read_value(v, raw + stage.count * DB_BLOCK);
				if (ret)
					goto out;
				stage.logical[stage.count++] = logical;
			}
			if (!stage.count)
				continue;
			ret = commit_staged(capacity);
			if (ret)
				goto out;
		}
		cond_resched();
	}
	/* Payload evacuation alone does not move cold tree nodes on the victim. */
	stage.count = 0;
	for (i = 0; i < DB_NODES; i++) {
		if (!tree_index[i].location || part_id(le64_to_cpu(tree_index[i].location)) != victim)
			continue;
		gc_node = i;
		ret = commit_staged(capacity);
		if (ret)
			goto out;
		cond_resched();
	}
	gc_node = DB_NO_NODE;
	if (part_id(le64_to_cpu(root->transaction.location)) == victim)
		ret = commit_staged(capacity);
out:
	stage.count = 0;
	gc_node = DB_NO_NODE;
	avoid_part = -1;
	collecting = false;
	return ret;
}

static int valid_root(struct db_root *r)
{
	u64 gen = le64_to_cpu(r->generation), maps = le64_to_cpu(r->mappings);
	u32 pages = le32_to_cpu(r->tree_pages);

	if (!sealed(r))
		return 0;
	if (memcmp(r->magic, "DBROOT01", 8) || memcmp(r->uuid, volume_uuid, 16) ||
	    !gen || !valid_capacity(le64_to_cpu(r->capacity)) ||
	    maps > le64_to_cpu(r->capacity) / DB_BLOCK ||
	    pages > DB_NODES || !!pages != !!r->tree.location ||
	    !!maps != !!pages || r->tree_height != cpu_to_le32(DB_HEIGHT) ||
	    !valid_pointer(&r->tree) || !valid_pointer(&r->transaction) ||
	    le64_to_cpu(r->tree.generation) > gen ||
	    r->incarnations[0] != cpu_to_le64(parts[0].incarnation) ||
	    !zero(r->reserved, sizeof(r->reserved)) ||
	    (gen == 1 && (maps || r->transaction.location)) ||
	    (gen > 1 && (!r->transaction.location || r->transaction.generation != r->generation)))
		return -EUCLEAN;
	return 1;
}

static int mark_metadata(u64 location)
{
	u32 id = part_id(location), offset = (u32)location;
	struct db_part *p;

	if (!location || id >= DB_PARTS || offset % DB_BLOCK ||
	    offset < (id ? DB_BLOCK : 3 * DB_BLOCK) || offset > part_limit - DB_BLOCK ||
	    !root->incarnations[id] || !parts[id].file)
		return -EUCLEAN;
	p = &parts[id];
	if (p->refs[offset / DB_BLOCK] ||
	    (u64)offset + DB_BLOCK > i_size_read(file_inode(p->file)))
		return -EUCLEAN;
	p->refs[offset / DB_BLOCK] = DB_BUSY;
	p->live_refs++;
	p->meta_pages++;
	return 0;
}

/* Four bounded recursion frames, each with its own preallocated page buffer. */
static int recover_tree(const struct db_pointer *p, u32 level, u64 base,
			u64 parent_generation)
{
	struct db_node *node;
	u32 index, i;
	int ret;

	if (level >= DB_HEIGHT || base >= capacity / DB_BLOCK)
		return -EUCLEAN;
	index = node_index(level, base);
	if (index >= DB_NODES || tree_index[index].location)
		return -EUCLEAN;
	node = &tree_stack[level];
	ret = mark_metadata(le64_to_cpu(p->location));
	if (!ret)
		ret = read_node(p, level, base, parent_generation, node);
	if (ret)
		return ret;
	tree_index[index] = *p;
	tree_pages++;
	if (level) {
		for (i = 0; i < DB_FANOUT; i++) {
			if (!node->children[i].location)
				continue;
			ret = recover_tree(&node->children[i], level - 1,
				base + ((u64)i << (6 + 7 * (level - 1))),
				le64_to_cpu(node->generation));
			if (ret)
				return ret;
		}
	} else {
		ret = reserve_map(base);
		if (ret)
			return ret;
		memcpy(map_slot(base), node->values, sizeof(node->values));
		mapped_blocks += le32_to_cpu(node->count);
	}
	cond_resched();
	return 0;
}

static int recover(void)
{
	u32 id, i, count, pages[DB_PARTS];
	unsigned long index;
	struct db_value *chunk;
	int ret, a, b;

	memset(root, 0, DB_BLOCK);
	memset(other_root, 0, DB_BLOCK);
	cached_blob.location = 0;
	/* Short root pages are torn, but real read errors are not discarded. */
	for (i = 1; i <= 2; i++) {
		loff_t pos = i * DB_BLOCK;
		ssize_t n = kernel_read(parts[0].file, i == 1 ? root : other_root, DB_BLOCK, &pos);

		if (n < 0)
			return n;
	}
	a = valid_root(root);
	b = valid_root(other_root);
	if (a < 0 || b < 0 || (!a && !b))
		return -EUCLEAN;
	if (a && b && root->generation == other_root->generation &&
	    memcmp(root, other_root, DB_BLOCK))
		return -EUCLEAN;
	if (a && b) {
		u64 ga = le64_to_cpu(root->generation), gb = le64_to_cpu(other_root->generation);

		if ((ga > gb ? ga - gb : gb - ga) > 1)
			return -EUCLEAN;
	}
	if (!a || (b && le64_to_cpu(other_root->generation) > le64_to_cpu(root->generation)))
		memcpy(root, other_root, DB_BLOCK);
	generation = le64_to_cpu(root->generation);
	capacity = le64_to_cpu(root->capacity);
	for (id = 1; id < DB_PARTS; id++) {
		ret = open_part(id, false);
		if (ret == -ENOENT && !root->incarnations[id])
			continue;
		if (ret)
			return ret == -ENOENT ? -EUCLEAN : ret;
		if (root->incarnations[id] &&
		    root->incarnations[id] != cpu_to_le64(parts[id].incarnation))
			return -EUCLEAN;
	}
	if (root->transaction.location) {
		ret = mark_metadata(le64_to_cpu(root->transaction.location));
		if (ret)
			return ret;
	}
	if (root->tree.location) {
		ret = recover_tree(&root->tree, DB_HEIGHT - 1, 0, generation);
		if (ret)
			return ret;
	}
	if (tree_pages != le32_to_cpu(root->tree_pages) ||
	    mapped_blocks != le64_to_cpu(root->mappings))
		return -EUCLEAN;
	/* All tree pages are marked before any payload can claim a shared page. */
	xa_for_each(&mapping, index, chunk) {
		for (i = 0; i < DB_CHUNK; i++) {
			u64 logical = (u64)index * DB_CHUNK + i;
			u32 charge, j;

			if (!chunk[i].location)
				continue;
			id = part_id(le64_to_cpu(chunk[i].location));
			if (!root->incarnations[id])
				return -EUCLEAN;
			if (le32_to_cpu(chunk[i].decoded_length) == DB_REGION) {
				for (j = round_down(i, DB_SUBBLOCKS); j < i; j++)
					if (le32_to_cpu(chunk[j].decoded_length) == DB_REGION &&
					    !same_blob(&chunk[j], &chunk[i]))
						return -EUCLEAN;
			}
			ret = payload_refs(&chunk[i], true);
			if (!ret)
				ret = read_value(&chunk[i], raw);
			if (ret)
				return ret;
			charge = value_charge(logical, &chunk[i]);
			stored_bytes += charge;
			parts[id].live_bytes += charge;
			parts[id].live_refs++;
		}
		for (i = 0; i < DB_CHUNK; i += DB_SUBBLOCKS) {
			region_estimate((u64)index * DB_CHUNK + i, pages);
			for (id = 0; id < DB_PARTS; id++)
				parts[id].gc_pages += pages[id];
		}
		cond_resched();
	}
	for (id = 0; id < DB_PARTS; id++)
		if ((!id || !!parts[id].live_refs) != !!root->incarnations[id])
			return -EUCLEAN;
	if (root->transaction.location) {
		ret = page_io(le64_to_cpu(root->transaction.location), transaction, false);
		if (ret)
			return ret;
		count = le32_to_cpu(transaction->count);
		if (!sealed(transaction) || transaction->crc != root->transaction.crc ||
		    memcmp(transaction->magic, "DBTXN001", 8) ||
		    memcmp(transaction->uuid, volume_uuid, 16) ||
		    transaction->generation != root->generation ||
		    le64_to_cpu(transaction->previous) != generation - 1 ||
		    transaction->capacity != root->capacity || count > DB_BATCH ||
		    transaction->reserved || !zero(transaction->padding, sizeof(transaction->padding)) ||
		    !zero(&transaction->entries[count], (DB_BATCH - count) * sizeof(struct db_entry)))
			return -EUCLEAN;
		for (i = 0; i < count; i++) {
			struct db_entry *e = &transaction->entries[i];
			u64 logical = le64_to_cpu(e->logical);
			struct db_value *v = map_slot(logical);

			if (logical >= capacity / DB_BLOCK ||
			    (i && logical <= le64_to_cpu(transaction->entries[i - 1].logical)) ||
			    (e->value.location && e->value.version != root->generation) ||
			    (v ? memcmp(v, &e->value, sizeof(*v)) : !zero(&e->value, sizeof(e->value))))
				return -EUCLEAN;
		}
	}
	/* No disk modifications occur until every selected reference has validated. */
	ret = publish_root();
	if (!ret)
		ret = trim_parts();
	return ret;
}

struct db_request {
	struct work_struct work;
};

static void request_copy(struct request *rq, bool to_request)
{
	struct req_iterator iter;
	struct bio_vec bv;
	u32 copied = 0;

	rq_for_each_segment(bv, rq, iter) {
		u32 done = 0;

		while (done < bv.bv_len) {
			u32 offset = bv.bv_offset + done, within = offset % PAGE_SIZE;
			u32 len = min_t(u32, bv.bv_len - done, PAGE_SIZE - within);
			void *mapped = kmap_local_page(nth_page(bv.bv_page, offset / PAGE_SIZE));

			if (to_request)
				memcpy(mapped + within, raw + copied, len);
			else
				memcpy(raw + copied, mapped + within, len);
			kunmap_local(mapped);
			done += len;
			copied += len;
		}
	}
}

static int transfer(struct request *rq)
{
	u64 pos = (u64)blk_rq_pos(rq) << SECTOR_SHIFT;
	u32 len = blk_rq_bytes(rq), i;
	unsigned int op = req_op(rq);
	int ret;

	if (rq->cmd_flags & (REQ_NOWAIT | REQ_POLLED | REQ_ATOMIC))
		return -EOPNOTSUPP;
	if (op == REQ_OP_FLUSH)
		return len ? -EINVAL : sync_parts();
	if (op != REQ_OP_READ && op != REQ_OP_WRITE && op != REQ_OP_DISCARD)
		return -EOPNOTSUPP;
	if (blk_rq_pos(rq) > capacity >> SECTOR_SHIFT || pos > capacity ||
	    len > capacity - pos || len > DB_IO || pos % DB_BLOCK || len % DB_BLOCK)
		return -EIO;
	if (op != REQ_OP_READ && fenced)
		return -EIO;
	if (rq->cmd_flags & REQ_PREFLUSH) {
		ret = sync_parts();
		if (ret)
			return ret;
	}
	if (op == REQ_OP_READ) {
		for (i = 0; i < len / DB_BLOCK; i++) {
			ret = read_value(map_slot(pos / DB_BLOCK + i), raw + i * DB_BLOCK);
			if (ret)
				return ret;
		}
		request_copy(rq, true);
		return 0;
	}
	if (!len)
		return sync_parts();
	ret = collect_part();
	if (ret)
		return ret;
	stage.count = len / DB_BLOCK;
	for (i = 0; i < stage.count; i++)
		stage.logical[i] = pos / DB_BLOCK + i;
	if (op == REQ_OP_DISCARD)
		memset(raw, 0, len);
	else
		request_copy(rq, false);
	return commit_staged(capacity);
}

static void process_request(struct work_struct *work)
{
	struct db_request *pdu = container_of(work, struct db_request, work);
	struct request *rq = blk_mq_rq_from_pdu(pdu);
	unsigned int noio = memalloc_noio_save();
	int ret;

	mutex_lock(&state_lock);
	ret = transfer(rq);
	/* Integrity failures also fence mutations; they never synthesize zero data. */
	if (ret && (req_op(rq) != REQ_OP_READ || ret == -EUCLEAN || ret == -EIO))
		fenced = true;
	mutex_unlock(&state_lock);
	memalloc_noio_restore(noio);
	blk_mq_end_request(rq, errno_to_blk_status(ret));
}

static blk_status_t queue_request(struct blk_mq_hw_ctx *hctx,
				 const struct blk_mq_queue_data *bd)
{
	struct db_request *pdu = blk_mq_rq_to_pdu(bd->rq);

	blk_mq_start_request(bd->rq);
	queue_work(worker, &pdu->work);
	return BLK_STS_OK;
}

static int init_request(struct blk_mq_tag_set *set, struct request *rq,
			unsigned int hctx, unsigned int node)
{
	struct db_request *pdu = blk_mq_rq_to_pdu(rq);

	INIT_WORK(&pdu->work, process_request);
	return 0;
}

static enum blk_eh_timer_return request_timeout(struct request *rq)
{
	return BLK_EH_RESET_TIMER;
}

static const struct blk_mq_ops mq_ops = {
	.queue_rq = queue_request,
	.init_request = init_request,
	.timeout = request_timeout,
};

static int block_ioctl(struct block_device *bdev, blk_mode_t mode,
		       unsigned int cmd, unsigned long arg)
{
	struct dynblk_status status = {};
	u64 bytes = 0;
	u32 id;
	unsigned int noio;
	int ret = 0;

	if (cmd != DYNBLK_GET && cmd != DYNBLK_GROW)
		return -ENOTTY;
	if (cmd == DYNBLK_GROW) {
		if (!ns_capable(&init_user_ns, CAP_SYS_ADMIN) || !(mode & BLK_OPEN_WRITE))
			return -EPERM;
		if (copy_from_user(&bytes, (void __user *)arg, sizeof(bytes)))
			return -EFAULT;
	}
	noio = memalloc_noio_save();
	mutex_lock(&state_lock);
	if (cmd == DYNBLK_GET) {
		status.version = 1;
		status.flags = fenced ? 1 : 0;
		memcpy(status.uuid, volume_uuid, 16);
		memcpy(status.algorithm, codec_name, 16);
		status.capacity = capacity;
		status.original_bytes = mapped_blocks * DB_BLOCK;
		status.stored_bytes = stored_bytes;
		status.generation = generation;
		status.part_limit = part_limit;
		status.block_size = DB_BLOCK;
		status.max_parts = DB_PARTS;
		status.tree_height = DB_HEIGHT;
		status.map_memory_bytes = map_chunks * DB_BLOCK + DB_NODES * sizeof(*tree_index);
		status.compression_region_bytes = DB_REGION;
		status.max_capacity = DB_LIMIT;
		for (id = 0; id < DB_PARTS; id++) {
			status.active_parts += !!root->incarnations[id];
			if (parts[id].file)
				status.physical_bytes += i_size_read(file_inode(parts[id].file));
		}
	} else if (fenced) {
		ret = -EIO;
	} else if (!valid_capacity(bytes) || bytes < capacity) {
		ret = -EINVAL;
	} else if (bytes != capacity) {
		stage.count = 0;
		ret = commit_staged(bytes);
		/* A post-publication trim error cannot undo a committed growth. */
		set_capacity_and_notify(disk, capacity >> SECTOR_SHIFT);
	}
	mutex_unlock(&state_lock);
	memalloc_noio_restore(noio);
	if (!ret && cmd == DYNBLK_GET &&
	    copy_to_user((void __user *)arg, &status, sizeof(status)))
		ret = -EFAULT;
	return ret;
}

static void close_storage(void)
{
	u32 id;
	unsigned long index;
	void *chunk;

	for (id = 0; id < DB_PARTS; id++) {
		if (parts[id].file)
			filp_close(parts[id].file, NULL);
		kvfree(parts[id].refs);
	}
	if (directory)
		filp_close(directory, NULL);
	if (creation_cred)
		put_cred(creation_cred);
	if (codec)
		crypto_free_comp(codec);
	xa_for_each(&mapping, index, chunk)
		free_page((unsigned long)chunk);
	xa_destroy(&mapping);
	kvfree(tree_index);
	kfree(root);
	kfree(other_root);
	kfree(header);
	kvfree(tree_stack);
	kfree(transaction);
	kvfree(raw);
	kvfree(packed);
	kvfree(scratch);
	kvfree(decoded);
	kfree(decoded_filename);
	decoded_filename = NULL;
	backing_filename = NULL;
}

static int __init dynblk_init(void)
{
	struct queue_limits limits = {
		.logical_block_size = DB_BLOCK,
		.physical_block_size = DB_BLOCK,
		.max_hw_sectors = DB_IO >> SECTOR_SHIFT,
		.max_segments = DB_IO / 512,
		.max_hw_discard_sectors = DB_IO >> SECTOR_SHIFT,
		.discard_granularity = DB_BLOCK,
		.features = BLK_FEAT_WRITE_CACHE | BLK_FEAT_FUA,
	};
	int ret;
	unsigned int noio;

	BUILD_BUG_ON(sizeof(struct db_header) != DB_BLOCK);
	BUILD_BUG_ON(sizeof(struct db_root) != DB_BLOCK);
	BUILD_BUG_ON(sizeof(struct db_pointer) != 24);
	BUILD_BUG_ON(sizeof(struct db_value) != 40);
	BUILD_BUG_ON(sizeof(struct db_entry) != 48);
	BUILD_BUG_ON(sizeof(struct db_node) != DB_BLOCK);
	BUILD_BUG_ON(sizeof(struct db_transaction) != DB_BLOCK);
	BUILD_BUG_ON(sizeof(struct dynblk_status) != 128);
	if (!IS_ENABLED(CONFIG_FILE_LOCKING) || PAGE_SIZE != DB_BLOCK ||
	    !map_memory_mb || map_memory_mb > 2048 ||
	    (part_limit_bytes && !valid_part_limit(part_limit_bytes)) ||
	    (create && !valid_capacity(size_bytes)))
		return -EINVAL;
	if (!uid_eq(current_fsuid(), GLOBAL_ROOT_UID) || current_user_ns() != &init_user_ns)
		return -EPERM;
	ret = prepare_backing_filename();
	if (ret)
		return ret;
	creation_cred = get_current_cred();
	ret = -ENOMEM;
	root = kzalloc(DB_BLOCK, GFP_KERNEL);
	other_root = kzalloc(DB_BLOCK, GFP_KERNEL);
	header = kmalloc(DB_BLOCK, GFP_KERNEL);
	tree_stack = kvcalloc(DB_HEIGHT, sizeof(*tree_stack), GFP_KERNEL);
	transaction = kmalloc(DB_BLOCK, GFP_KERNEL);
	raw = kvzalloc(DB_IO, GFP_KERNEL);
	packed = kvzalloc(DB_REGION, GFP_KERNEL);
	scratch = kvzalloc(2 * DB_REGION, GFP_KERNEL);
	decoded = kvzalloc(DB_REGION, GFP_KERNEL);
	tree_index = kvcalloc(DB_NODES, sizeof(*tree_index), GFP_KERNEL);
	if (!root || !other_root || !header || !transaction || !raw ||
	    !packed || !scratch || !decoded || !tree_index || !tree_stack)
		goto fail_storage;
	if (create)
		part_limit = part_limit_bytes ?: DB_DEFAULT_PART_LIMIT;
	ret = pin_directory();
	if (ret)
		goto fail_storage;
	if (create) {
		if (part_limit > file_inode(directory)->i_sb->s_maxbytes) {
			ret = -EFBIG;
			goto fail_storage;
		}
		ret = setup_codec(algorithm ?: "none");
		if (ret)
			goto fail_storage;
		generate_random_uuid(volume_uuid);
	}
	noio = memalloc_noio_save();
	ret = open_part(0, create);
	if (!ret && create) {
		generation = 1;
		capacity = size_bytes;
		memcpy(root->magic, "DBROOT01", 8);
		memcpy(root->uuid, volume_uuid, 16);
		root->generation = cpu_to_le64(generation);
		root->capacity = cpu_to_le64(capacity);
		root->tree_height = cpu_to_le32(DB_HEIGHT);
		active_location(0);
		ret = publish_root();
	} else if (!ret) {
		ret = recover();
	}
	memalloc_noio_restore(noio);
	if (ret)
		goto fail_storage;
	worker = alloc_ordered_workqueue("dynblk", WQ_MEM_RECLAIM);
	if (!worker) {
		ret = -ENOMEM;
		goto fail_storage;
	}
	tags.ops = &mq_ops;
	tags.nr_hw_queues = 1;
	tags.queue_depth = 128;
	tags.numa_node = NUMA_NO_NODE;
	tags.cmd_size = sizeof(struct db_request);
	tags.flags = BLK_MQ_F_SHOULD_MERGE;
	ret = blk_mq_alloc_tag_set(&tags);
	if (ret)
		goto fail_worker;
	disk = blk_mq_alloc_disk(&tags, &limits, NULL);
	if (IS_ERR(disk)) {
		ret = PTR_ERR(disk);
		goto fail_tags;
	}
	disk->fops = &operations;
	disk->flags |= GENHD_FL_NO_PART;
	strscpy(disk->disk_name, "dynblk0", DISK_NAME_LEN);
	set_capacity(disk, capacity >> SECTOR_SHIFT);
	ret = add_disk(disk);
	if (ret)
		goto fail_disk;
	pr_info("dynblk: format 1, %llu bytes, %s, COW radix tree / 64KiB regions\n",
		capacity, codec_name);
	return 0;
fail_disk:
	put_disk(disk);
fail_tags:
	blk_mq_free_tag_set(&tags);
fail_worker:
	destroy_workqueue(worker);
fail_storage:
	pr_err("dynblk: attachment failed: %d; partial files preserved\n", ret);
	close_storage();
	return ret;
}

static void __exit dynblk_exit(void)
{
	del_gendisk(disk);
	flush_workqueue(worker);
	if (sync_parts())
		pr_err("dynblk: fenced or final sync failed; validate on reattach\n");
	put_disk(disk);
	blk_mq_free_tag_set(&tags);
	destroy_workqueue(worker);
	close_storage();
}

module_init(dynblk_init);
module_exit(dynblk_exit);
MODULE_LICENSE("GPL");
MODULE_VERSION("1.0.0");
MODULE_DESCRIPTION("Self-contained COW compressed file-backed block device");

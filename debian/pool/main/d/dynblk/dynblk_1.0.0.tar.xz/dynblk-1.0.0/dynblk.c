// SPDX-License-Identifier: GPL-2.0-or-later
/* Self-contained format 1. See FORMAT.md before changing ordering. */
#include <linux/blk-mq.h>
#include <linux/capability.h>
#include <linux/crc32.h>
#include <linux/cred.h>
#include <linux/crypto.h>
#include <linux/fileattr.h>
#include <linux/filelock.h>
#include <linux/fs.h>
#include <linux/highmem.h>
#include <linux/magic.h>
#include <linux/miscdevice.h>
#include <linux/idr.h>
#include <linux/module.h>
#include <linux/mount.h>
#include <linux/namei.h>
#include <linux/random.h>
#include <linux/sched/mm.h>
#include <linux/slab.h>
#include <linux/statfs.h>
#include <linux/uaccess.h>
#include <linux/uuid.h>
#include <linux/vmalloc.h>
#include <linux/workqueue.h>
#include <linux/xarray.h>
#include <linux/xattr.h>

#include "dynblk_uapi.h"

#define DB_BLOCK 4096U
#define DB_PARTS 64U
#define DB_DEFAULT_PART_LIMIT (4000ULL << 20)
#define DB_MIN_PART_LIMIT (1ULL << 20)
#define DB_PAGES(dev) ((dev)->part_limit / DB_BLOCK)
#define DB_LIMIT DYNBLK_MAX_CAPACITY
#define DB_BATCH 32U
#define DB_IO (DB_BATCH * DB_BLOCK)
#define DB_REGION (64U * 1024)
#define DB_SUBBLOCKS (DB_REGION / DB_BLOCK)
#define DB_CHUNK 64U
#define DB_FANOUT 128U
#define DB_HEIGHT 4U
#define DB_NODES (2097152U + 16384U + 128U + 1U)
#define DB_DIRTY (DB_BATCH * DB_HEIGHT)
#define DB_NO_NODE U32_MAX
#define DB_BUSY U16_MAX

struct db_header {
	u8 magic[8], uuid[16];
	__le64 incarnation;
	__le32 part, format;
	__le64 limit;
	u8 algorithm[16], reserved[4028];
	__le32 crc;
} __packed;

struct db_pointer {
	__le64 location, generation;
	__le32 crc, reserved;
} __packed;

struct db_root {
	u8 magic[8], uuid[16];
	__le64 generation, capacity;
	struct db_pointer tree, transaction;
	__le64 mappings;
	__le32 tree_pages, tree_height;
	__le64 incarnations[DB_PARTS];
	u8 reserved[3476];
	__le32 crc;
} __packed;

struct db_value {
	__le64 location, version;
	__le32 length, stored_crc, original_crc, flags;
	__le32 decoded_length, decoded_offset;
} __packed;

struct db_entry {
	__le64 logical;
	struct db_value value;
} __packed;

struct db_node {
	u8 magic[8], uuid[16];
	__le64 generation, base;
	__le32 level, count;
	u8 reserved[16];
	union {
		struct db_value values[DB_CHUNK];
		struct db_pointer children[DB_FANOUT];
		u8 bytes[4028];
	};
	__le32 crc;
} __packed;

struct db_transaction {
	u8 magic[8], uuid[16];
	__le64 generation, previous, capacity;
	__le32 count, reserved;
	struct db_entry entries[DB_BATCH];
	u8 padding[2500];
	__le32 crc;
} __packed;

struct db_part {
	struct file *file;
	u16 *refs;
	u64 incarnation, live_bytes, live_refs;
	u32 meta_pages, gc_pages;
	u32 hint;
};

struct dynblk_stage {
	u64 logical[DB_BATCH];
	struct db_value old[DB_BATCH];
	u32 count;
	bool relative[DB_BATCH];
	u64 allocations[DB_BATCH];
	u32 allocation_pages[DB_BATCH], nr_allocations;
	struct {
		u32 index;
		struct db_pointer old;
	} dirty[DB_DIRTY];
	u32 nr_dirty;
	u64 next_refs[DB_PARTS], next_live[DB_PARTS];
	u32 next_meta[DB_PARTS], next_gc[DB_PARTS];
};

struct dynblk_device {
	int index;
	bool creating, detaching, index_budget_reserved;
	unsigned int map_memory_mb, openers;
	u64 cookie;
	char *backing_filename;
	struct file *directory;
	const struct cred *creation_cred;
	struct crypto_comp *codec;
	char codec_name[DYNBLK_CODEC_MAX];
	u8 volume_uuid[16];
	struct xarray mapping;
	struct mutex state_lock, lifecycle_lock;
	u64 generation, capacity, mapped_blocks, stored_bytes, map_chunks;
	u64 part_limit;
	struct db_pointer *tree_index;
	u32 tree_pages;
	bool fenced, collecting;
	int avoid_part;
	struct db_root *root, *other_root;
	struct db_header *header;
	struct db_node *tree_stack;
	struct db_transaction *transaction;
	void *raw, *packed, *scratch, *decoded;
	struct db_value cached_blob;
	struct db_part parts[DB_PARTS];
	struct dynblk_stage stage;
	u32 gc_node;
	struct gendisk *disk;
	struct blk_mq_tag_set tags;
	struct workqueue_struct *worker;
};

static const u32 node_starts[DB_HEIGHT] = { 0, 2097152, 2113536, 2113664 };
static DEFINE_MUTEX(devices_lock);
static DEFINE_IDA(device_ids);
static struct dynblk_device *devices[DYNBLK_MAX_DEVICES];
static unsigned int tree_index_budget_mb = 512;
static u64 tree_index_bytes;
module_param(tree_index_budget_mb, uint, 0444);
MODULE_PARM_DESC(tree_index_budget_mb,
	"Global fixed tree-index admission budget in MiB, default 512");

static int block_open(struct gendisk *disk, blk_mode_t mode);
static void block_release(struct gendisk *disk);
static int block_ioctl(struct block_device *bdev, blk_mode_t mode,
		       unsigned int cmd, unsigned long arg);
static const struct block_device_operations operations = {
	.owner = THIS_MODULE,
	.open = block_open,
	.release = block_release,
	.ioctl = block_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = block_ioctl,
#endif
};

static u32 checksum(const void *p, size_t len)
{
	return crc32_le(~0U, p, len) ^ ~0U;
}

static bool zero(const void *p, size_t len)
{
	return !memchr_inv(p, 0, len);
}

static void seal(void *page)
{
	*(__le32 *)(page + DB_BLOCK - 4) = cpu_to_le32(checksum(page, DB_BLOCK - 4));
}

static bool sealed(const void *page)
{
	return le32_to_cpu(*(__le32 *)(page + DB_BLOCK - 4)) ==
		checksum(page, DB_BLOCK - 4);
}

static bool valid_capacity(u64 bytes)
{
	return bytes && bytes <= DB_LIMIT && !(bytes % DB_BLOCK);
}

static int reserve_tree_index_budget(struct dynblk_device *dev)
{
	u64 bytes = (u64)DB_NODES * sizeof(*dev->tree_index);
	u64 budget = (u64)tree_index_budget_mb << 20;
	int ret = 0;

	mutex_lock(&devices_lock);
	if (tree_index_bytes > budget || bytes > budget - tree_index_bytes)
		ret = -ENOMEM;
	else {
		tree_index_bytes += bytes;
		dev->index_budget_reserved = true;
	}
	mutex_unlock(&devices_lock);
	return ret;
}

static void release_tree_index_budget(struct dynblk_device *dev)
{
	u64 bytes = (u64)DB_NODES * sizeof(*dev->tree_index);

	if (!dev->index_budget_reserved)
		return;
	mutex_lock(&devices_lock);
	WARN_ON_ONCE(tree_index_bytes < bytes);
	if (tree_index_bytes >= bytes)
		tree_index_bytes -= bytes;
	dev->index_budget_reserved = false;
	mutex_unlock(&devices_lock);
}

static bool valid_part_limit(u64 bytes)
{
	return bytes >= DB_MIN_PART_LIMIT && bytes <= DB_DEFAULT_PART_LIMIT &&
		!(bytes % DB_BLOCK);
}

static u32 part_id(u64 location)
{
	return location >> 32;
}

static u64 location_of(u32 id, u32 page)
{
	return (u64)id << 32 | (u64)page * DB_BLOCK;
}

static int file_io(struct dynblk_device *dev, struct file *f, void *buf, size_t len, u64 offset, bool write)
{
	loff_t pos = offset;
	ssize_t n;

	if (!f || offset > dev->part_limit || len > dev->part_limit - offset)
		return -EUCLEAN;
	if (write)
		n = kernel_write(f, buf, len, &pos);
	else
		n = kernel_read(f, buf, len, &pos);
	return n == len ? 0 : n < 0 ? n : -EIO;
}

static int page_io(struct dynblk_device *dev, u64 location, void *buf, bool write)
{
	u32 id = part_id(location), offset = (u32)location;

	if (!location || id >= DB_PARTS || offset % DB_BLOCK ||
	    offset < (id ? DB_BLOCK : 3 * DB_BLOCK))
		return -EUCLEAN;
	return file_io(dev, dev->parts[id].file, buf, DB_BLOCK, offset, write);
}

static bool geometry(struct dynblk_device *dev, struct super_block *sb)
{
	/* Btrfs owns member geometry and buffered COW/fsync, not a generic s_bdev. */
	if (!strcmp(sb->s_type->name, "btrfs"))
		return sb->s_magic == BTRFS_SUPER_MAGIC && sb->s_blocksize == DB_BLOCK &&
			sb->s_maxbytes >= dev->part_limit;
	return (!strcmp(sb->s_type->name, "ext4") ||
		!strcmp(sb->s_type->name, "ext2") || !strcmp(sb->s_type->name, "ntfs3") ||
		!strcmp(sb->s_type->name, "vfat") || !strcmp(sb->s_type->name, "exfat")) &&
		sb->s_bdev && sb->s_maxbytes >= DB_MIN_PART_LIMIT &&
		sb->s_blocksize >= 512 && sb->s_blocksize <= DB_BLOCK &&
		!(DB_BLOCK % sb->s_blocksize) &&
		bdev_logical_block_size(sb->s_bdev) >= 512 &&
		bdev_logical_block_size(sb->s_bdev) <= DB_BLOCK &&
		!(sb->s_blocksize % bdev_logical_block_size(sb->s_bdev)) &&
		bdev_physical_block_size(sb->s_bdev) >= 512 &&
		bdev_physical_block_size(sb->s_bdev) <= DB_BLOCK &&
		!(sb->s_blocksize % bdev_physical_block_size(sb->s_bdev)) &&
		!bdev_alignment_offset(sb->s_bdev) && sb->s_bdev->bd_disk->fops != &operations;
}

/* O_PATH inspection avoids ntfs_file_open's writable WOF decompression path. */
static int backing_attributes(struct file *f)
{
	struct fileattr fa = { .flags_valid = true };
	bool btrfs = !strcmp(file_inode(f)->i_sb->s_type->name, "btrfs");
	u32 flags;
	int ret;

	if (!btrfs && strcmp(file_inode(f)->i_sb->s_type->name, "ntfs3"))
		return 0;
	ret = vfs_fileattr_get(f->f_path.dentry, &fa);
	if (ret)
		return ret;
	if (!fa.flags_valid || (fa.flags & (FS_IMMUTABLE_FL | FS_APPEND_FL)))
		return -EOPNOTSUPP;
	if (btrfs)
		return fa.flags & FS_NOCOW_FL ? -EOPNOTSUPP : 0;
	if (fa.flags & (FS_COMPR_FL | FS_ENCRYPT_FL))
		return -EOPNOTSUPP;
	ret = vfs_getxattr(mnt_idmap(f->f_path.mnt), f->f_path.dentry,
			  "system.ntfs_attrib", &flags, sizeof(flags));
	if (ret != sizeof(flags))
		return ret < 0 ? ret : -EOPNOTSUPP;
	/* Sparse, reparse (including WOF/dedup), compressed, offline, encrypted. */
	return flags & 0x5e00U ? -EOPNOTSUPP : 0;
}

static int backing_inode(struct dynblk_device *dev, struct file *f)
{
	struct inode *inode = file_inode(f);

	if (!S_ISREG(inode->i_mode) || inode->i_nlink != 1 ||
	    !uid_eq(inode->i_uid, GLOBAL_ROOT_UID) ||
	    inode->i_mode & (S_IWGRP | S_IWOTH) || is_idmapped_mnt(f->f_path.mnt) ||
	    !geometry(dev, inode->i_sb) || i_size_read(inode) > dev->part_limit)
		return -EINVAL;
	return backing_attributes(f);
}

static int admit(struct dynblk_device *dev, struct file *f)
{
	struct file_lock *lock;
	int ret;

	ret = backing_inode(dev, f);
	if (ret)
		return ret;
	lock = locks_alloc_lock();
	if (!lock)
		return -ENOMEM;
	lock->c.flc_owner = f;
	lock->c.flc_file = f;
	lock->c.flc_flags = FL_FLOCK;
	lock->c.flc_type = F_WRLCK;
	lock->c.flc_pid = task_tgid_nr(current);
	lock->fl_start = 0;
	lock->fl_end = OFFSET_MAX;
	ret = locks_lock_file_wait(f, lock);
	locks_free_lock(lock);
	return ret;
}

static bool trusted_backing_directory(const struct inode *inode)
{
	umode_t mode = inode->i_mode;

	if (!uid_eq(inode->i_uid, GLOBAL_ROOT_UID))
		return false;
	if ((mode & S_IWGRP) && !gid_eq(inode->i_gid, GLOBAL_ROOT_GID))
		return false;
	if ((mode & S_IWOTH) && !(mode & S_ISVTX))
		return false;
	return true;
}

static int pin_directory(struct dynblk_device *dev)
{
	struct path path;
	char *parent, *slash, *p;
	int ret = -EINVAL;

	if (!dev->backing_filename || dev->backing_filename[0] != '/' || strlen(dev->backing_filename) >= PATH_MAX)
		return -EINVAL;
	parent = kstrdup(dev->backing_filename, GFP_KERNEL);
	if (!parent)
		return -ENOMEM;
	slash = strrchr(parent, '/');
	if (strcmp(slash + 1, "volume000.db"))
		goto out;
	for (p = parent; p <= slash; p++) {
		struct inode *inode;
		char saved;

		if (*p != '/')
			continue;
		if (p != parent && (p[-1] == '/' ||
		    (p[-1] == '.' && (p - parent == 1 || p[-2] == '/' ||
		    (p[-2] == '.' && (p - parent == 2 || p[-3] == '/'))))))
			goto out;
		saved = p == parent ? parent[1] : *p;
		if (p == parent)
			parent[1] = 0;
		else
			*p = 0;
		ret = kern_path(parent, LOOKUP_DIRECTORY | LOOKUP_NO_SYMLINKS, &path);
		if (p == parent)
			parent[1] = saved;
		else
			*p = saved;
		if (ret)
			goto out;
		inode = d_inode(path.dentry);
		ret = -EPERM;
		if (is_idmapped_mnt(path.mnt) || !trusted_backing_directory(inode)) {
			path_put(&path);
			goto out;
		}
		if (p == slash) {
			dev->directory = dentry_open(&path, O_RDONLY | O_DIRECTORY, dev->creation_cred);
			path_put(&path);
			if (IS_ERR(dev->directory)) {
				ret = PTR_ERR(dev->directory);
				dev->directory = NULL;
				goto out;
			}
			ret = geometry(dev, file_inode(dev->directory)->i_sb) ? 0 : -EOPNOTSUPP;
			if (!ret)
				ret = backing_attributes(dev->directory);
			break;
		}
		path_put(&path);
	}
out:
	kfree(parent);
	return ret;
}

static int require_unused_namespace(struct dynblk_device *dev, u32 first)
{
	const struct cred *old;
	u32 id;
	int ret = 0;

	old = override_creds(dev->creation_cred);
	for (id = first; id < DB_PARTS; id++) {
		char name[16];
		struct file *probe;

		snprintf(name, sizeof(name), "volume%03u.db", id);
		probe = file_open_root(&dev->directory->f_path, name, O_PATH | O_NOFOLLOW, 0);
		if (!IS_ERR(probe)) {
			filp_close(probe, NULL);
			ret = -EEXIST;
			break;
		}
		ret = PTR_ERR(probe);
		if (ret == -ENOENT) {
			ret = 0;
			continue;
		}
		break;
	}
	revert_creds(old);
	return ret;
}

static int setup_codec(struct dynblk_device *dev, const char *name)
{
	static const char * const names[] = {
		"none", "lz4", "lz4hc", "lzo", "lzo-rle", "zstd", "deflate", "842",
	};
	u32 i;

	for (i = 0; i < ARRAY_SIZE(names); i++)
		if (!strcmp(name, names[i]))
			break;
	if (i == ARRAY_SIZE(names))
		return -EINVAL;
	strscpy(dev->codec_name, name, sizeof(dev->codec_name));
	if (!i)
		return 0;
	dev->codec = crypto_alloc_comp(name, 0, 0);
	if (IS_ERR(dev->codec)) {
		int ret = PTR_ERR(dev->codec);

		dev->codec = NULL;
		return ret;
	}
	return 0;
}

static int open_part(struct dynblk_device *dev, u32 id, bool exclusive)
{
	struct db_header *h = dev->header;
	struct db_part *p = &dev->parts[id];
	const struct cred *old;
	char name[16];
	struct file *f;
	int ret;

	if (p->file)
		return 0;
	snprintf(name, sizeof(name), "volume%03u.db", id);
	old = override_creds(dev->creation_cred);
	if (exclusive) {
		ret = backing_attributes(dev->directory);
		f = ret ? ERR_PTR(ret) : file_open_root(&dev->directory->f_path, name,
			O_RDWR | O_NOFOLLOW | O_LARGEFILE | O_CREAT | O_EXCL, 0600);
	} else {
		struct file *probe = file_open_root(&dev->directory->f_path, name,
						  O_PATH | O_NOFOLLOW, 0);

		if (IS_ERR(probe)) {
			f = probe;
		} else {
			ret = backing_inode(dev, probe);
			f = ret ? ERR_PTR(ret) : dentry_open(&probe->f_path,
				O_RDWR | O_LARGEFILE | O_NONBLOCK, dev->creation_cred);
			filp_close(probe, NULL);
		}
	}
	revert_creds(old);
	if (IS_ERR(f))
		return PTR_ERR(f);
	ret = admit(dev, f);
	if (ret)
		goto close;
	if (exclusive) {
		memset(h, 0, DB_BLOCK);
		memcpy(h->magic, "DBPART01", 8);
		memcpy(h->uuid, dev->volume_uuid, 16);
		do {
			get_random_bytes(&p->incarnation, sizeof(p->incarnation));
		} while (!p->incarnation);
		h->incarnation = cpu_to_le64(p->incarnation);
		h->part = cpu_to_le32(id);
		h->format = cpu_to_le32(1);
		h->limit = cpu_to_le64(dev->part_limit);
		memcpy(h->algorithm, dev->codec_name, 16);
		seal(h);
		ret = file_io(dev, f, h, DB_BLOCK, 0, true);
		if (!ret)
			ret = vfs_fsync(f, 0);
		if (!ret)
			ret = vfs_fsync(dev->directory, 0);
	} else {
		ret = file_io(dev, f, h, DB_BLOCK, 0, false);
		if (!ret && (!sealed(h) || memcmp(h->magic, "DBPART01", 8) ||
		    h->part != cpu_to_le32(id) || h->format != cpu_to_le32(1) ||
		    !valid_part_limit(le64_to_cpu(h->limit)) || !h->incarnation ||
		    zero(h->uuid, 16) || !zero(h->reserved, sizeof(h->reserved)) ||
		    !memchr(h->algorithm, 0, 16)))
			ret = -EUCLEAN;
		if (!ret && !id) {
			dev->part_limit = le64_to_cpu(h->limit);
			memcpy(dev->volume_uuid, h->uuid, 16);
			ret = setup_codec(dev, h->algorithm);
		}
		if (!ret && (h->limit != cpu_to_le64(dev->part_limit) ||
		    memcmp(h->uuid, dev->volume_uuid, 16) ||
		    memcmp(h->algorithm, dev->codec_name, 16)))
			ret = -EUCLEAN;
		p->incarnation = le64_to_cpu(h->incarnation);
	}
	if (ret)
		goto close;
	if (dev->part_limit > file_inode(f)->i_sb->s_maxbytes ||
	    i_size_read(file_inode(f)) > dev->part_limit) {
		ret = -EFBIG;
		goto close;
	}
	p->refs = kvcalloc(DB_PAGES(dev), sizeof(*p->refs), GFP_NOIO);
	if (!p->refs) {
		ret = -ENOMEM;
		goto close;
	}
	p->refs[0] = DB_BUSY;
	if (!id)
		p->refs[1] = p->refs[2] = DB_BUSY;
	p->hint = id ? 1 : 3;
	p->file = f;
	return 0;
close:
	filp_close(f, NULL);
	return ret;
}

static struct db_value *map_slot(struct dynblk_device *dev, u64 logical)
{
	struct db_value *chunk = xa_load(&dev->mapping, logical / DB_CHUNK);

	return chunk ? &chunk[logical % DB_CHUNK] : NULL;
}

static int reserve_map(struct dynblk_device *dev, u64 logical)
{
	void *chunk;
	int ret;

	if (map_slot(dev, logical))
		return 0;
	if (dev->map_chunks >= ((u64)dev->map_memory_mb << 20) / DB_BLOCK)
		return -ENOSPC;
	chunk = (void *)get_zeroed_page(GFP_NOIO);
	if (!chunk)
		return -ENOMEM;
	ret = xa_insert(&dev->mapping, logical / DB_CHUNK, chunk, GFP_NOIO);
	if (ret)
		free_page((unsigned long)chunk);
	else
		dev->map_chunks++;
	return ret;
}

/* First fit with a wrapping hint. DB_BUSY reserves pages before publication. */
static int allocate(struct dynblk_device *dev, u32 count, bool metadata, u64 *location)
{
	u32 id, pass, max = metadata || dev->collecting ? DB_PARTS : DB_PARTS - 2;
	int ret;

	for (pass = 0; pass < 2; pass++) {
		for (id = 0; id < max; id++) {
			struct db_part *p = &dev->parts[id];
			u32 start, end, run = 0, page, lap;

			if (id == dev->avoid_part || (!pass && !p->file) || (pass && p->file))
				continue;
			if (!p->file) {
				ret = open_part(dev, id, true);
				if (ret)
					return ret;
			}
			for (lap = 0; lap < 2; lap++) {
				start = lap ? (id ? 1 : 3) : p->hint;
				end = DB_PAGES(dev);
				run = 0;
				for (page = start; page < end; page++) {
					run = p->refs[page] ? 0 : run + 1;
					if (run != count)
						continue;
					start = page + 1 - count;
					for (run = start; run <= page; run++)
						p->refs[run] = DB_BUSY;
					p->hint = page + 1;
					*location = location_of(id, start);
					return 0;
				}
			}
		}
	}
	return -ENOSPC;
}

static void release_page(struct dynblk_device *dev, u64 location)
{
	struct db_part *p = &dev->parts[part_id(location)];
	u32 page = (u32)location / DB_BLOCK;

	p->refs[page] = 0;
	p->hint = min(p->hint, page);
}

static bool valid_value(struct dynblk_device *dev, const struct db_value *v, u64 logical, u64 max_generation)
{
	u64 loc = le64_to_cpu(v->location), version = le64_to_cpu(v->version);
	u32 id = part_id(loc), len = le32_to_cpu(v->length);
	u32 output = le32_to_cpu(v->decoded_length), offset = le32_to_cpu(v->decoded_offset);
	u32 flags = le32_to_cpu(v->flags);

	if (!loc)
		return zero(v, sizeof(*v));
	if (id >= DB_PARTS || !version || version > max_generation || !len ||
	    len > DB_REGION || (u32)loc < (id ? DB_BLOCK : 3 * DB_BLOCK) ||
	    (u32)loc > dev->part_limit - len || flags > 1 ||
	    (output != DB_BLOCK && output != DB_REGION) || offset % DB_BLOCK ||
	    offset > output - DB_BLOCK)
		return false;
	if (!flags)
		return len == DB_BLOCK && output == DB_BLOCK && !offset;
	return dev->codec && len < output &&
		(output == DB_BLOCK ? !offset : offset == (logical % DB_SUBBLOCKS) * DB_BLOCK);
}

static bool same_blob(const struct db_value *a, const struct db_value *b)
{
	return a->location == b->location && a->version == b->version &&
		a->length == b->length && a->stored_crc == b->stored_crc &&
		a->decoded_length == b->decoded_length && a->flags == b->flags;
}

/* Shared 64KiB blobs are charged once, to their first surviving subblock. */
static u32 value_charge(struct dynblk_device *dev, u64 logical, const struct db_value *v)
{
	u64 first;

	if (!v || !v->location)
		return 0;
	if (le32_to_cpu(v->decoded_length) == DB_REGION) {
		for (first = round_down(logical, (u64)DB_SUBBLOCKS); first < logical; first++) {
			const struct db_value *other = map_slot(dev, first);

			if (other && same_blob(other, v))
				return 0;
		}
	}
	return le32_to_cpu(v->length);
}

static int payload_refs(struct dynblk_device *dev, const struct db_value *value, bool add)
{
	u64 location = le64_to_cpu(value->location);
	u32 id = part_id(location), offset = (u32)location;
	u32 len = le32_to_cpu(value->length), page, last;
	struct db_part *p;

	if (!location)
		return zero(value, sizeof(*value)) ? 0 : -EUCLEAN;
	if (id >= DB_PARTS || !dev->parts[id].file || !len || len > DB_REGION ||
	    offset < (id ? DB_BLOCK : 3 * DB_BLOCK) || offset > dev->part_limit - len ||
	    offset + (u64)len > i_size_read(file_inode(dev->parts[id].file)))
		return -EUCLEAN;
	p = &dev->parts[id];
	last = (offset + len - 1) / DB_BLOCK;
	for (page = offset / DB_BLOCK; page <= last; page++) {
		if (add) {
			if (p->refs[page] >= DB_BUSY - 1)
				return -EUCLEAN;
			p->refs[page]++;
		} else {
			if (!p->refs[page] || p->refs[page] == DB_BUSY)
				return -EUCLEAN;
			if (!--p->refs[page])
				p->hint = min(p->hint, page);
		}
	}
	return 0;
}

static int read_value(struct dynblk_device *dev, const struct db_value *value, void *out)
{
	u64 location;
	u32 len, flags, outlen, offset;
	int ret;

	if (!value || !value->location) {
		memset(out, 0, DB_BLOCK);
		return value && !zero(value, sizeof(*value)) ? -EUCLEAN : 0;
	}
	location = le64_to_cpu(value->location);
	len = le32_to_cpu(value->length);
	flags = le32_to_cpu(value->flags);
	outlen = le32_to_cpu(value->decoded_length);
	offset = le32_to_cpu(value->decoded_offset);
	if (!valid_value(dev, value, offset / DB_BLOCK, dev->generation))
		return -EUCLEAN;
	if (!dev->cached_blob.location || !same_blob(value, &dev->cached_blob)) {
		dev->cached_blob.location = 0;
		ret = file_io(dev, dev->parts[part_id(location)].file, dev->scratch, len, (u32)location, false);
		if (ret)
			return ret;
		if (checksum(dev->scratch, len) != le32_to_cpu(value->stored_crc))
			return -EUCLEAN;
		if (flags) {
			ret = crypto_comp_decompress(dev->codec, dev->scratch, len, dev->decoded, &outlen);
			if (ret || outlen != le32_to_cpu(value->decoded_length))
				return -EUCLEAN;
		} else {
			memcpy(dev->decoded, dev->scratch, DB_BLOCK);
		}
		dev->cached_blob = *value;
	}
	memcpy(out, dev->decoded + offset, DB_BLOCK);
	return checksum(out, DB_BLOCK) == le32_to_cpu(value->original_crc) ? 0 : -EUCLEAN;
}

static int sync_parts(struct dynblk_device *dev)
{
	u32 id;
	int ret;

	if (dev->fenced)
		return -EIO;
	for (id = 0; id < DB_PARTS; id++) {
		if (!dev->parts[id].file)
			continue;
		ret = vfs_fsync(dev->parts[id].file, 0);
		if (ret) {
			dev->fenced = true;
			return ret;
		}
	}
	return 0;
}

/* Both durable publications are required before ANY old reference is freed. */
static int publish_root(struct dynblk_device *dev)
{
	u32 copy;
	int ret;

	seal(dev->root);
	for (copy = 1; copy <= 2; copy++) {
		ret = file_io(dev, dev->parts[0].file, dev->root, DB_BLOCK, copy * DB_BLOCK, true);
		if (!ret)
			ret = vfs_fsync(dev->parts[0].file, 0);
		if (ret)
			return ret;
	}
	return 0;
}

static int remove_part(struct dynblk_device *dev, u32 id)
{
	struct db_part *p = &dev->parts[id];
	struct inode *dir = file_inode(dev->directory);
	struct dentry *dentry;
	const struct cred *old;
	char name[16];
	int ret;

	snprintf(name, sizeof(name), "volume%03u.db", id);
	old = override_creds(dev->creation_cred);
	ret = mnt_want_write(dev->directory->f_path.mnt);
	if (ret)
		goto out;
	inode_lock(dir);
	dentry = lookup_one_len(name, dev->directory->f_path.dentry, strlen(name));
	if (IS_ERR(dentry)) {
		ret = PTR_ERR(dentry);
	} else {
		ret = d_inode(dentry) == file_inode(p->file) ?
			vfs_unlink(mnt_idmap(dev->directory->f_path.mnt), dir, dentry, NULL) : -ESTALE;
		dput(dentry);
	}
	inode_unlock(dir);
	mnt_drop_write(dev->directory->f_path.mnt);
	if (!ret)
		ret = vfs_fsync(dev->directory, 0);
	if (!ret) {
		filp_close(p->file, NULL);
		kvfree(p->refs);
		memset(p, 0, sizeof(*p));
	}
out:
	revert_creds(old);
	return ret;
}

/* Root-selected references only; callers have already retired both old roots. */
static int trim_parts(struct dynblk_device *dev)
{
	u32 id;
	int ret;

	for (id = 0; id < DB_PARTS; id++) {
		struct db_part *p = &dev->parts[id];
		u32 last;

		if (!p->file)
			continue;
		last = DIV_ROUND_UP_ULL(i_size_read(file_inode(p->file)), DB_BLOCK);
		while (last > (id ? 1 : 3) && !p->refs[last - 1])
			last--;
		if (id && last == 1) {
			if (dev->root->incarnations[id])
				return -EUCLEAN;
			ret = remove_part(dev, id);
		} else if (i_size_read(file_inode(p->file)) > (u64)last * DB_BLOCK) {
			const struct cred *old = override_creds(dev->creation_cred);

			ret = vfs_truncate(&p->file->f_path, (u64)last * DB_BLOCK);
			if (!ret)
				ret = vfs_fsync(p->file, 0);
			revert_creds(old);
		} else {
			ret = 0;
		}
		if (ret)
			return ret;
		cond_resched();
	}
	return 0;
}

static void active_location(struct dynblk_device *dev, u64 location)
{
	u32 id = part_id(location);

	dev->root->incarnations[id] = cpu_to_le64(dev->parts[id].incarnation);
}

static u32 node_index(u32 level, u64 logical)
{
	return node_starts[level] + (logical >> (6 + 7 * level));
}

static u32 node_level(u32 index)
{
	u32 level = DB_HEIGHT - 1;

	while (level && index < node_starts[level])
		level--;
	return level;
}

static u64 node_base(u32 index)
{
	u32 level = node_level(index);

	return (u64)(index - node_starts[level]) << (6 + 7 * level);
}

static bool valid_pointer(struct dynblk_device *dev, const struct db_pointer *p)
{
	u64 location = le64_to_cpu(p->location);
	u32 id = part_id(location), offset = (u32)location;

	if (!location)
		return zero(p, sizeof(*p));
	return id < DB_PARTS && offset >= (id ? DB_BLOCK : 3 * DB_BLOCK) &&
		!(offset % DB_BLOCK) && offset <= dev->part_limit - DB_BLOCK &&
		p->generation && !p->reserved;
}

static void make_pointer(struct dynblk_device *dev, struct db_pointer *p, u64 location, const void *page)
{
	memset(p, 0, sizeof(*p));
	p->location = cpu_to_le64(location);
	p->generation = cpu_to_le64(dev->generation + 1);
	p->crc = *(__le32 *)(page + DB_BLOCK - 4);
}

static int read_node(struct dynblk_device *dev, const struct db_pointer *p, u32 level, u64 base,
		     u64 parent_generation, struct db_node *node)
{
	u32 i, count = 0;
	int ret;

	if (!valid_pointer(dev, p) || !p->location ||
	    le64_to_cpu(p->generation) > parent_generation)
		return -EUCLEAN;
	ret = page_io(dev, le64_to_cpu(p->location), node, false);
	if (ret)
		return ret;
	if (!sealed(node) || p->crc != node->crc || p->generation != node->generation ||
	    memcmp(node->magic, "DBTREE01", 8) || memcmp(node->uuid, dev->volume_uuid, 16) ||
	    node->base != cpu_to_le64(base) || node->level != cpu_to_le32(level) ||
	    !zero(node->reserved, sizeof(node->reserved)))
		return -EUCLEAN;
	if (level) {
		for (i = 0; i < DB_FANOUT; i++) {
			struct db_pointer *child = &node->children[i];
			u64 logical = base + ((u64)i << (6 + 7 * (level - 1)));

			if (!valid_pointer(dev, child) || (child->location &&
			    (logical >= dev->capacity / DB_BLOCK ||
			     le64_to_cpu(child->generation) > le64_to_cpu(node->generation))))
				return -EUCLEAN;
			count += !!child->location;
		}
		i = sizeof(node->children);
	} else {
		for (i = 0; i < DB_CHUNK; i++) {
			struct db_value *v = &node->values[i];

			if (!valid_value(dev, v, base + i, le64_to_cpu(node->generation)) ||
			    (v->location && base + i >= dev->capacity / DB_BLOCK))
				return -EUCLEAN;
			count += !!v->location;
		}
		i = sizeof(node->values);
	}
	return count && count == le32_to_cpu(node->count) &&
		zero(node->bytes + i, sizeof(node->bytes) - i) ? 0 : -EUCLEAN;
}

static int dirty_path(struct dynblk_device *dev, u32 index)
{
	u32 level, i;
	u64 base;

	if (index >= DB_NODES)
		return -EUCLEAN;
	level = node_level(index);
	base = node_base(index);
	for (; level < DB_HEIGHT; level++) {
		index = node_index(level, base);
		for (i = 0; i < dev->stage.nr_dirty; i++)
			if (dev->stage.dirty[i].index == index)
				break;
		if (i != dev->stage.nr_dirty)
			continue;
		if (i == DB_DIRTY)
			return -E2BIG;
		dev->stage.dirty[i].index = index;
		dev->stage.dirty[i].old = dev->tree_index[index];
		dev->stage.nr_dirty++;
	}
	return 0;
}

/* Build children first; only the dirty paths change in the resident pointer index. */
static int write_tree(struct dynblk_device *dev)
{
	struct db_node *node = &dev->tree_stack[0];
	u32 level, d, i;
	int ret;

	for (level = 0; level < DB_HEIGHT; level++) {
		for (d = 0; d < dev->stage.nr_dirty; d++) {
			u32 index = dev->stage.dirty[d].index, count = 0;
			u64 base = node_base(index), location;
			struct db_pointer *p = &dev->tree_index[index];

			if (node_level(index) != level)
				continue;
			if (p->location) {
				ret = read_node(dev, p, level, base, dev->generation, node);
				if (ret)
					return ret;
			}
			memset(node, 0, DB_BLOCK);
			memcpy(node->magic, "DBTREE01", 8);
			memcpy(node->uuid, dev->volume_uuid, 16);
			node->generation = cpu_to_le64(dev->generation + 1);
			node->base = cpu_to_le64(base);
			node->level = cpu_to_le32(level);
			if (level) {
				for (i = 0; i < DB_FANOUT; i++) {
					u64 logical = base + ((u64)i << (6 + 7 * (level - 1)));

					if (logical >= DB_LIMIT / DB_BLOCK)
						break;
					node->children[i] = dev->tree_index[node_index(level - 1, logical)];
					count += !!node->children[i].location;
				}
			} else {
				struct db_value *values = map_slot(dev, base);

				if (values)
					memcpy(node->values, values, sizeof(node->values));
				for (i = 0; i < DB_CHUNK; i++)
					count += !!node->values[i].location;
			}
			memset(p, 0, sizeof(*p));
			if (!count)
				continue;
			node->count = cpu_to_le32(count);
			seal(node);
			ret = allocate(dev, 1, true, &location);
			if (ret)
				return ret;
			ret = page_io(dev, location, node, true);
			if (ret)
				return ret;
			make_pointer(dev, p, location, node);
		}
	}
	return 0;
}

static void prune_map(struct dynblk_device *dev)
{
	u32 i;

	for (i = 0; i < dev->stage.count; i++) {
		u64 index = dev->stage.logical[i] / DB_CHUNK;
		void *chunk = xa_load(&dev->mapping, index);

		if (!chunk || !zero(chunk, DB_BLOCK))
			continue;
		xa_erase(&dev->mapping, index);
		free_page((unsigned long)chunk);
		dev->map_chunks--;
	}
}

/* Leave host headroom for a victim and bounded dirty-path transactions. */
static int working_room(struct dynblk_device *dev)
{
	struct kstatfs st;
	u64 largest = 0, free_bytes, needed;
	u32 id;
	int ret;

	if (dev->collecting)
		return 0;
	ret = vfs_statfs(&dev->directory->f_path, &st);
	if (ret)
		return ret;
	if (st.f_bsize <= 0 || st.f_bsize > (1U << 25) ||
	    st.f_bavail > U64_MAX / st.f_bsize)
		return -EOVERFLOW;
	free_bytes = st.f_bavail * st.f_bsize;
	for (id = 0; id < DB_PARTS; id++)
		largest = max(largest, min_t(u64, dev->part_limit,
			      ((u64)dev->parts[id].gc_pages + dev->parts[id].meta_pages) * DB_BLOCK));
	needed = largest + 2 * DB_IO +
		2 * (DB_DIRTY + 1) * DB_BLOCK +
		2 * (DB_PARTS + 1) * st.f_bsize;
	return free_bytes >= needed ? 0 : -ENOSPC;
}

static int flush_payload(struct dynblk_device *dev, u32 bytes)
{
	u64 location;
	u32 pages = DIV_ROUND_UP(bytes, DB_BLOCK), i;
	int ret;

	if (!bytes)
		return 0;
	if (bytes > DB_REGION || dev->stage.nr_allocations == DB_BATCH)
		return -E2BIG;
	ret = allocate(dev, pages, false, &location);
	if (ret)
		return ret;
	dev->stage.allocations[dev->stage.nr_allocations] = location;
	dev->stage.allocation_pages[dev->stage.nr_allocations++] = pages;
	ret = file_io(dev, dev->parts[part_id(location)].file, dev->packed, pages * DB_BLOCK,
		      (u32)location, true);
	if (ret)
		return ret;
	for (i = 0; i < dev->stage.count; i++) {
		struct db_value *v = &dev->transaction->entries[i].value;

		if (!dev->stage.relative[i])
			continue;
		v->location = cpu_to_le64(le64_to_cpu(v->location) + location);
		dev->stage.relative[i] = false;
	}
	memset(dev->packed, 0, DB_REGION);
	return 0;
}

static int prepare_payload(struct dynblk_device *dev)
{
	u32 i = 0, used = 0, j;
	int ret;

	memset(dev->packed, 0, DB_REGION);
	memset(dev->stage.relative, 0, sizeof(dev->stage.relative));
	while (i < dev->stage.count) {
		struct db_value blob = {};
		u32 n = 1, len = 2 * DB_REGION, output, crc;
		void *source = dev->raw + i * DB_BLOCK;
		bool encoded = false;

		if (!dev->collecting && dev->codec && !(dev->stage.logical[i] % DB_SUBBLOCKS) &&
		    dev->stage.count - i >= DB_SUBBLOCKS) {
			for (j = 1; j < DB_SUBBLOCKS; j++)
				if (dev->stage.logical[i + j] != dev->stage.logical[i] + j)
					break;
			if (j == DB_SUBBLOCKS)
				n = DB_SUBBLOCKS;
		}
		if (zero(source, n * DB_BLOCK)) {
			i += n;
			continue;
		}
		output = n * DB_BLOCK;
		if (dev->collecting) {
			blob = dev->stage.old[i];
			/* A collection batch never splits a logical compression region. */
			for (j = 0; j < i; j++)
				if (dev->transaction->entries[j].value.length && same_blob(&dev->stage.old[j], &blob))
					break;
			if (j < i) {
				struct db_value *v = &dev->transaction->entries[i].value;

				*v = dev->transaction->entries[j].value;
				v->original_crc = blob.original_crc;
				v->decoded_offset = blob.decoded_offset;
				dev->stage.relative[i] = dev->stage.relative[j];
				i++;
				continue;
			}
			len = le32_to_cpu(blob.length);
			output = le32_to_cpu(blob.decoded_length);
			if (!valid_value(dev, &blob, dev->stage.logical[i], dev->generation))
				return -EUCLEAN;
			ret = file_io(dev, dev->parts[part_id(le64_to_cpu(blob.location))].file,
				      dev->scratch, len, (u32)le64_to_cpu(blob.location), false);
			if (ret)
				return ret;
			if (checksum(dev->scratch, len) != le32_to_cpu(blob.stored_crc))
				return -EUCLEAN;
			source = dev->scratch;
			encoded = !!blob.flags;
		} else if (dev->codec) {
			ret = crypto_comp_compress(dev->codec, source, output, dev->scratch, &len);
			if (ret)
				return ret;
			if (!len)
				return -EIO;
			if (len < output) {
				source = dev->scratch;
				encoded = true;
			} else {
				/* Raw fallback stays independently replaceable at 4KiB. */
				n = 1;
				len = output = DB_BLOCK;
			}
		} else {
			len = output = DB_BLOCK;
		}
		if (used + len > DB_REGION) {
			ret = flush_payload(dev, used);
			if (ret)
				return ret;
			used = 0;
		}
		memcpy(dev->packed + used, source, len);
		crc = checksum(dev->packed + used, len);
		for (j = 0; j < n; j++) {
			struct db_value *v = &dev->transaction->entries[i + j].value;
			void *block = dev->raw + (i + j) * DB_BLOCK;

			if (zero(block, DB_BLOCK))
				continue;
			v->location = cpu_to_le64(used);
			v->version = cpu_to_le64(dev->generation + 1);
			v->length = cpu_to_le32(len);
			v->stored_crc = cpu_to_le32(crc);
			v->original_crc = cpu_to_le32(checksum(block, DB_BLOCK));
			v->flags = cpu_to_le32(encoded);
			v->decoded_length = cpu_to_le32(output);
			v->decoded_offset = dev->collecting ? blob.decoded_offset : cpu_to_le32(j * DB_BLOCK);
			dev->stage.relative[i + j] = true;
		}
		used += len;
		i += n;
	}
	return flush_payload(dev, used);
}

/* Predict the exact region-at-a-time packing performed by collection. */
static void region_estimate(struct dynblk_device *dev, u64 base, u32 pages[DB_PARTS])
{
	u32 used[DB_PARTS] = {}, id;
	u64 logical;

	memset(pages, 0, DB_PARTS * sizeof(*pages));
	for (logical = base; logical < base + DB_SUBBLOCKS; logical++) {
		const struct db_value *v = map_slot(dev, logical);
		u32 bytes = value_charge(dev, logical, v);

		if (!bytes)
			continue;
		id = part_id(le64_to_cpu(v->location));
		if (used[id] + bytes > DB_REGION) {
			pages[id] += DIV_ROUND_UP(used[id], DB_BLOCK);
			used[id] = 0;
		}
		used[id] += bytes;
	}
	for (id = 0; id < DB_PARTS; id++)
		pages[id] += DIV_ROUND_UP(used[id], DB_BLOCK);
}

static void region_account(struct dynblk_device *dev, bool add)
{
	u32 i, id, pages[DB_PARTS];
	u64 previous = U64_MAX;

	for (i = 0; i < dev->stage.count; i++) {
		u64 base = round_down(dev->stage.logical[i], (u64)DB_SUBBLOCKS), logical;

		if (base == previous)
			continue;
		previous = base;
		region_estimate(dev, base, pages);
		for (id = 0; id < DB_PARTS; id++) {
			if (add)
				dev->stage.next_gc[id] += pages[id];
			else
				dev->stage.next_gc[id] -= pages[id];
		}
		for (logical = base; logical < base + DB_SUBBLOCKS; logical++) {
			const struct db_value *v = map_slot(dev, logical);
			u32 charge = value_charge(dev, logical, v), id;

			if (!charge)
				continue;
			id = part_id(le64_to_cpu(v->location));
			if (add)
				dev->stage.next_live[id] += charge;
			else
				dev->stage.next_live[id] -= charge;
		}
	}
}

/* RAM staging is private under state_lock; no global map serialization occurs. */
static int commit_staged(struct dynblk_device *dev, u64 new_capacity)
{
	u64 new_transaction, old_mapped = dev->mapped_blocks;
	u32 i, j, new_tree_pages = dev->tree_pages;
	int ret;

	if (dev->fenced || dev->generation == U64_MAX) {
		dev->fenced = true;
		return -EIO;
	}
	if (dev->stage.count > DB_BATCH || !valid_capacity(new_capacity) || new_capacity < dev->capacity)
		return -EINVAL;
	for (i = 0; i < dev->stage.count; i++)
		if (dev->stage.logical[i] >= dev->capacity / DB_BLOCK ||
		    (i && dev->stage.logical[i] <= dev->stage.logical[i - 1]))
			return -EINVAL;
	ret = working_room(dev);
	if (ret)
		goto fail_committed;
	memcpy(dev->other_root, dev->root, DB_BLOCK);
	dev->stage.nr_allocations = dev->stage.nr_dirty = 0;
	for (i = 0; i < DB_PARTS; i++) {
		dev->stage.next_refs[i] = dev->parts[i].live_refs;
		dev->stage.next_meta[i] = dev->parts[i].meta_pages;
		dev->stage.next_gc[i] = dev->parts[i].gc_pages;
		dev->stage.next_live[i] = dev->parts[i].live_bytes;
	}
	memset(dev->transaction, 0, DB_BLOCK);
	memcpy(dev->transaction->magic, "DBTXN001", 8);
	memcpy(dev->transaction->uuid, dev->volume_uuid, 16);
	dev->transaction->generation = cpu_to_le64(dev->generation + 1);
	dev->transaction->previous = cpu_to_le64(dev->generation);
	dev->transaction->capacity = cpu_to_le64(new_capacity);
	dev->transaction->count = cpu_to_le32(dev->stage.count);
	for (i = 0; i < dev->stage.count; i++) {
		dev->transaction->entries[i].logical = cpu_to_le64(dev->stage.logical[i]);
		memset(&dev->stage.old[i], 0, sizeof(dev->stage.old[i]));
		if (map_slot(dev, dev->stage.logical[i]))
			dev->stage.old[i] = *map_slot(dev, dev->stage.logical[i]);
		if (!zero(dev->raw + i * DB_BLOCK, DB_BLOCK)) {
			ret = reserve_map(dev, dev->stage.logical[i]);
			if (ret)
				goto fail_unstaged;
		}
	}
	ret = prepare_payload(dev);
	if (ret)
		goto fail_unstaged;
	region_account(dev, false);
	for (i = 0; i < dev->stage.count; i++) {
		struct db_value *v = &dev->transaction->entries[i].value;

		dev->mapped_blocks += !!v->location;
		dev->mapped_blocks -= !!dev->stage.old[i].location;
		if (dev->stage.old[i].location)
			dev->stage.next_refs[part_id(le64_to_cpu(dev->stage.old[i].location))]--;
		if (v->location)
			dev->stage.next_refs[part_id(le64_to_cpu(v->location))]++;
		if (map_slot(dev, dev->stage.logical[i]))
			*map_slot(dev, dev->stage.logical[i]) = *v;
	}
	region_account(dev, true);
	for (i = 0; i < dev->stage.count; i++) {
		ret = dirty_path(dev, node_index(0, dev->stage.logical[i]));
		if (ret)
			goto fail;
	}
	if (dev->gc_node != DB_NO_NODE) {
		ret = dirty_path(dev, dev->gc_node);
		if (ret)
			goto fail;
	}
	ret = write_tree(dev);
	if (ret)
		goto fail;
	for (i = 0; i < dev->stage.nr_dirty; i++) {
		u64 old = le64_to_cpu(dev->stage.dirty[i].old.location);
		u64 new = le64_to_cpu(dev->tree_index[dev->stage.dirty[i].index].location);

		if (old) {
			dev->stage.next_refs[part_id(old)]--;
			dev->stage.next_meta[part_id(old)]--;
			new_tree_pages--;
		}
		if (new) {
			dev->stage.next_refs[part_id(new)]++;
			dev->stage.next_meta[part_id(new)]++;
			new_tree_pages++;
		}
	}
	ret = allocate(dev, 1, true, &new_transaction);
	if (ret)
		goto fail;
	seal(dev->transaction);
	ret = page_io(dev, new_transaction, dev->transaction, true);
	if (ret)
		goto fail;
	if (dev->root->transaction.location) {
		i = part_id(le64_to_cpu(dev->root->transaction.location));
		dev->stage.next_refs[i]--;
		dev->stage.next_meta[i]--;
	}
	dev->stage.next_refs[part_id(new_transaction)]++;
	dev->stage.next_meta[part_id(new_transaction)]++;
	dev->root->generation = cpu_to_le64(dev->generation + 1);
	dev->root->capacity = cpu_to_le64(new_capacity);
	dev->root->mappings = cpu_to_le64(dev->mapped_blocks);
	dev->root->tree_pages = cpu_to_le32(new_tree_pages);
	dev->root->tree_height = cpu_to_le32(DB_HEIGHT);
	dev->root->tree = dev->tree_index[DB_NODES - 1];
	make_pointer(dev, &dev->root->transaction, new_transaction, dev->transaction);
	for (i = 0; i < DB_PARTS; i++)
		dev->root->incarnations[i] = !i || dev->stage.next_refs[i] ?
			cpu_to_le64(dev->parts[i].incarnation) : 0;
	ret = sync_parts(dev);
	if (!ret)
		ret = publish_root(dev);
	if (ret)
		goto fail;
	/* Both fallback roots now name the new tree. Only now can old pages be reused. */
	dev->generation++;
	dev->capacity = new_capacity;
	dev->tree_pages = new_tree_pages;
	dev->cached_blob.location = 0;
	for (i = 0; i < dev->stage.nr_allocations; i++)
		for (j = 0; j < dev->stage.allocation_pages[i]; j++)
			release_page(dev, dev->stage.allocations[i] + j * DB_BLOCK);
	for (i = 0; i < dev->stage.count; i++) {
		ret = payload_refs(dev, &dev->transaction->entries[i].value, true);
		if (!ret)
			ret = payload_refs(dev, &dev->stage.old[i], false);
		if (ret)
			goto fail_committed;
	}
	for (i = 0; i < dev->stage.nr_dirty; i++)
		if (dev->stage.dirty[i].old.location)
			release_page(dev, le64_to_cpu(dev->stage.dirty[i].old.location));
	if (dev->other_root->transaction.location)
		release_page(dev, le64_to_cpu(dev->other_root->transaction.location));
	dev->stored_bytes = 0;
	for (i = 0; i < DB_PARTS; i++) {
		dev->parts[i].live_refs = dev->stage.next_refs[i];
		dev->parts[i].meta_pages = dev->stage.next_meta[i];
		dev->parts[i].gc_pages = dev->stage.next_gc[i];
		dev->parts[i].live_bytes = dev->stage.next_live[i];
		dev->stored_bytes += dev->stage.next_live[i];
	}
	prune_map(dev);
	ret = trim_parts(dev);
	if (ret)
		goto fail_committed;
	return 0;
fail:
	for (i = 0; i < dev->stage.nr_dirty; i++)
		dev->tree_index[dev->stage.dirty[i].index] = dev->stage.dirty[i].old;
	for (i = 0; i < dev->stage.count; i++)
		if (map_slot(dev, dev->stage.logical[i]))
			*map_slot(dev, dev->stage.logical[i]) = dev->stage.old[i];
	dev->mapped_blocks = old_mapped;
	memcpy(dev->root, dev->other_root, DB_BLOCK);
fail_unstaged:
	prune_map(dev);
fail_committed:
	dev->fenced = true;
	return ret;
}

/* Collect a victim into other parts, using the same durable COW path as writes. */
static int collect_part(struct dynblk_device *dev)
{
	u64 best = U64_MAX;
	u32 id, victim = DB_PARTS, group, i;
	unsigned long index;
	struct db_value *chunk;
	int ret = 0;

	for (id = 0; id < DB_PARTS; id++) {
		struct db_part *p = &dev->parts[id];
		u64 span, useful;

		if (!p->file || !p->live_refs)
			continue;
		span = i_size_read(file_inode(p->file)) - (id ? DB_BLOCK : 3 * DB_BLOCK);
		/* Encoded density alone mistakes unavoidable page padding for garbage. */
		useful = ((u64)p->gc_pages + p->meta_pages) * DB_BLOCK;
		if (span < 2 * DB_IO || useful > span * 3 / 4 || useful >= best)
			continue;
		best = useful;
		victim = id;
	}
	if (victim == DB_PARTS)
		return 0;
	dev->collecting = true;
	dev->avoid_part = victim;
	xa_for_each(&dev->mapping, index, chunk) {
		for (group = 0; group < DB_CHUNK; group += DB_SUBBLOCKS) {
			dev->stage.count = 0;
			for (i = 0; i < DB_SUBBLOCKS; i++) {
				u64 logical = (u64)index * DB_CHUNK + group + i;
				struct db_value *v = map_slot(dev, logical);

				if (!v || !v->location || part_id(le64_to_cpu(v->location)) != victim)
					continue;
				ret = read_value(dev, v, dev->raw + dev->stage.count * DB_BLOCK);
				if (ret)
					goto out;
				dev->stage.logical[dev->stage.count++] = logical;
			}
			if (!dev->stage.count)
				continue;
			ret = commit_staged(dev, dev->capacity);
			if (ret)
				goto out;
		}
		cond_resched();
	}
	/* Payload evacuation alone does not move cold tree nodes on the victim. */
	dev->stage.count = 0;
	for (i = 0; i < DB_NODES; i++) {
		if (!dev->tree_index[i].location || part_id(le64_to_cpu(dev->tree_index[i].location)) != victim)
			continue;
		dev->gc_node = i;
		ret = commit_staged(dev, dev->capacity);
		if (ret)
			goto out;
		cond_resched();
	}
	dev->gc_node = DB_NO_NODE;
	if (part_id(le64_to_cpu(dev->root->transaction.location)) == victim)
		ret = commit_staged(dev, dev->capacity);
out:
	dev->stage.count = 0;
	dev->gc_node = DB_NO_NODE;
	dev->avoid_part = -1;
	dev->collecting = false;
	return ret;
}

static int valid_root(struct dynblk_device *dev, struct db_root *r)
{
	u64 gen = le64_to_cpu(r->generation), maps = le64_to_cpu(r->mappings);
	u32 pages = le32_to_cpu(r->tree_pages);

	if (!sealed(r))
		return 0;
	if (memcmp(r->magic, "DBROOT01", 8) || memcmp(r->uuid, dev->volume_uuid, 16) ||
	    !gen || !valid_capacity(le64_to_cpu(r->capacity)) ||
	    maps > le64_to_cpu(r->capacity) / DB_BLOCK ||
	    pages > DB_NODES || !!pages != !!r->tree.location ||
	    !!maps != !!pages || r->tree_height != cpu_to_le32(DB_HEIGHT) ||
	    !valid_pointer(dev, &r->tree) || !valid_pointer(dev, &r->transaction) ||
	    le64_to_cpu(r->tree.generation) > gen ||
	    r->incarnations[0] != cpu_to_le64(dev->parts[0].incarnation) ||
	    !zero(r->reserved, sizeof(r->reserved)) ||
	    (gen == 1 && (maps || r->transaction.location)) ||
	    (gen > 1 && (!r->transaction.location || r->transaction.generation != r->generation)))
		return -EUCLEAN;
	return 1;
}

static int mark_metadata(struct dynblk_device *dev, u64 location)
{
	u32 id = part_id(location), offset = (u32)location;
	struct db_part *p;

	if (!location || id >= DB_PARTS || offset % DB_BLOCK ||
	    offset < (id ? DB_BLOCK : 3 * DB_BLOCK) || offset > dev->part_limit - DB_BLOCK ||
	    !dev->root->incarnations[id] || !dev->parts[id].file)
		return -EUCLEAN;
	p = &dev->parts[id];
	if (p->refs[offset / DB_BLOCK] ||
	    (u64)offset + DB_BLOCK > i_size_read(file_inode(p->file)))
		return -EUCLEAN;
	p->refs[offset / DB_BLOCK] = DB_BUSY;
	p->live_refs++;
	p->meta_pages++;
	return 0;
}

/* Four bounded recursion frames, each with its own preallocated page buffer. */
static int recover_tree(struct dynblk_device *dev, const struct db_pointer *p, u32 level, u64 base,
			u64 parent_generation)
{
	struct db_node *node;
	u32 index, i;
	int ret;

	if (level >= DB_HEIGHT || base >= dev->capacity / DB_BLOCK)
		return -EUCLEAN;
	index = node_index(level, base);
	if (index >= DB_NODES || dev->tree_index[index].location)
		return -EUCLEAN;
	node = &dev->tree_stack[level];
	ret = mark_metadata(dev, le64_to_cpu(p->location));
	if (!ret)
		ret = read_node(dev, p, level, base, parent_generation, node);
	if (ret)
		return ret;
	dev->tree_index[index] = *p;
	dev->tree_pages++;
	if (level) {
		for (i = 0; i < DB_FANOUT; i++) {
			if (!node->children[i].location)
				continue;
			ret = recover_tree(dev, &node->children[i], level - 1,
				base + ((u64)i << (6 + 7 * (level - 1))),
				le64_to_cpu(node->generation));
			if (ret)
				return ret;
		}
	} else {
		ret = reserve_map(dev, base);
		if (ret)
			return ret;
		memcpy(map_slot(dev, base), node->values, sizeof(node->values));
		dev->mapped_blocks += le32_to_cpu(node->count);
	}
	cond_resched();
	return 0;
}

static int recover(struct dynblk_device *dev)
{
	u32 id, i, count, pages[DB_PARTS];
	unsigned long index;
	struct db_value *chunk;
	int ret, a, b;

	memset(dev->root, 0, DB_BLOCK);
	memset(dev->other_root, 0, DB_BLOCK);
	dev->cached_blob.location = 0;
	/* Short root pages are torn, but real read errors are not discarded. */
	for (i = 1; i <= 2; i++) {
		loff_t pos = i * DB_BLOCK;
		ssize_t n = kernel_read(dev->parts[0].file, i == 1 ? dev->root : dev->other_root, DB_BLOCK, &pos);

		if (n < 0)
			return n;
	}
	a = valid_root(dev, dev->root);
	b = valid_root(dev, dev->other_root);
	if (a < 0 || b < 0 || (!a && !b))
		return -EUCLEAN;
	if (a && b && dev->root->generation == dev->other_root->generation &&
	    memcmp(dev->root, dev->other_root, DB_BLOCK))
		return -EUCLEAN;
	if (a && b) {
		u64 ga = le64_to_cpu(dev->root->generation), gb = le64_to_cpu(dev->other_root->generation);

		if ((ga > gb ? ga - gb : gb - ga) > 1)
			return -EUCLEAN;
	}
	if (!a || (b && le64_to_cpu(dev->other_root->generation) > le64_to_cpu(dev->root->generation)))
		memcpy(dev->root, dev->other_root, DB_BLOCK);
	dev->generation = le64_to_cpu(dev->root->generation);
	dev->capacity = le64_to_cpu(dev->root->capacity);
	for (id = 1; id < DB_PARTS; id++) {
		ret = open_part(dev, id, false);
		if (ret == -ENOENT && !dev->root->incarnations[id])
			continue;
		if (ret)
			return ret == -ENOENT ? -EUCLEAN : ret;
		if (dev->root->incarnations[id] &&
		    dev->root->incarnations[id] != cpu_to_le64(dev->parts[id].incarnation))
			return -EUCLEAN;
	}
	if (dev->root->transaction.location) {
		ret = mark_metadata(dev, le64_to_cpu(dev->root->transaction.location));
		if (ret)
			return ret;
	}
	if (dev->root->tree.location) {
		ret = recover_tree(dev, &dev->root->tree, DB_HEIGHT - 1, 0, dev->generation);
		if (ret)
			return ret;
	}
	if (dev->tree_pages != le32_to_cpu(dev->root->tree_pages) ||
	    dev->mapped_blocks != le64_to_cpu(dev->root->mappings))
		return -EUCLEAN;
	/* All tree pages are marked before any payload can claim a shared page. */
	xa_for_each(&dev->mapping, index, chunk) {
		for (i = 0; i < DB_CHUNK; i++) {
			u64 logical = (u64)index * DB_CHUNK + i;
			u32 charge, j;

			if (!chunk[i].location)
				continue;
			id = part_id(le64_to_cpu(chunk[i].location));
			if (!dev->root->incarnations[id])
				return -EUCLEAN;
			if (le32_to_cpu(chunk[i].decoded_length) == DB_REGION) {
				for (j = round_down(i, DB_SUBBLOCKS); j < i; j++)
					if (le32_to_cpu(chunk[j].decoded_length) == DB_REGION &&
					    !same_blob(&chunk[j], &chunk[i]))
						return -EUCLEAN;
			}
			ret = payload_refs(dev, &chunk[i], true);
			if (!ret)
				ret = read_value(dev, &chunk[i], dev->raw);
			if (ret)
				return ret;
			charge = value_charge(dev, logical, &chunk[i]);
			dev->stored_bytes += charge;
			dev->parts[id].live_bytes += charge;
			dev->parts[id].live_refs++;
		}
		for (i = 0; i < DB_CHUNK; i += DB_SUBBLOCKS) {
			region_estimate(dev, (u64)index * DB_CHUNK + i, pages);
			for (id = 0; id < DB_PARTS; id++)
				dev->parts[id].gc_pages += pages[id];
		}
		cond_resched();
	}
	for (id = 0; id < DB_PARTS; id++)
		if ((!id || !!dev->parts[id].live_refs) != !!dev->root->incarnations[id])
			return -EUCLEAN;
	if (dev->root->transaction.location) {
		ret = page_io(dev, le64_to_cpu(dev->root->transaction.location), dev->transaction, false);
		if (ret)
			return ret;
		count = le32_to_cpu(dev->transaction->count);
		if (!sealed(dev->transaction) || dev->transaction->crc != dev->root->transaction.crc ||
		    memcmp(dev->transaction->magic, "DBTXN001", 8) ||
		    memcmp(dev->transaction->uuid, dev->volume_uuid, 16) ||
		    dev->transaction->generation != dev->root->generation ||
		    le64_to_cpu(dev->transaction->previous) != dev->generation - 1 ||
		    dev->transaction->capacity != dev->root->capacity || count > DB_BATCH ||
		    dev->transaction->reserved || !zero(dev->transaction->padding, sizeof(dev->transaction->padding)) ||
		    !zero(&dev->transaction->entries[count], (DB_BATCH - count) * sizeof(struct db_entry)))
			return -EUCLEAN;
		for (i = 0; i < count; i++) {
			struct db_entry *e = &dev->transaction->entries[i];
			u64 logical = le64_to_cpu(e->logical);
			struct db_value *v = map_slot(dev, logical);

			if (logical >= dev->capacity / DB_BLOCK ||
			    (i && logical <= le64_to_cpu(dev->transaction->entries[i - 1].logical)) ||
			    (e->value.location && e->value.version != dev->root->generation) ||
			    (v ? memcmp(v, &e->value, sizeof(*v)) : !zero(&e->value, sizeof(e->value))))
				return -EUCLEAN;
		}
	}
	/* No disk modifications occur until every selected reference has validated. */
	ret = publish_root(dev);
	if (!ret)
		ret = trim_parts(dev);
	return ret;
}

struct db_request {
	struct work_struct work;
};

static void request_copy(struct dynblk_device *dev, struct request *rq, bool to_request)
{
	struct req_iterator iter;
	struct bio_vec bv;
	u32 copied = 0;

	rq_for_each_segment(bv, rq, iter) {
		u32 done = 0;

		while (done < bv.bv_len) {
			u32 offset = bv.bv_offset + done, within = offset % PAGE_SIZE;
			u32 len = min_t(u32, bv.bv_len - done, PAGE_SIZE - within);
			void *mapped = kmap_local_page(nth_page(bv.bv_page, offset / PAGE_SIZE));

			if (to_request)
				memcpy(mapped + within, dev->raw + copied, len);
			else
				memcpy(dev->raw + copied, mapped + within, len);
			kunmap_local(mapped);
			done += len;
			copied += len;
		}
	}
}

static int transfer(struct dynblk_device *dev, struct request *rq)
{
	u64 pos = (u64)blk_rq_pos(rq) << SECTOR_SHIFT;
	u32 len = blk_rq_bytes(rq), i;
	unsigned int op = req_op(rq);
	int ret;

	if (rq->cmd_flags & (REQ_NOWAIT | REQ_POLLED | REQ_ATOMIC))
		return -EOPNOTSUPP;
	if (op == REQ_OP_FLUSH)
		return len ? -EINVAL : sync_parts(dev);
	if (op != REQ_OP_READ && op != REQ_OP_WRITE && op != REQ_OP_DISCARD)
		return -EOPNOTSUPP;
	if (blk_rq_pos(rq) > dev->capacity >> SECTOR_SHIFT || pos > dev->capacity ||
	    len > dev->capacity - pos || len > DB_IO || pos % DB_BLOCK || len % DB_BLOCK)
		return -EIO;
	if (op != REQ_OP_READ && dev->fenced)
		return -EIO;
	if (rq->cmd_flags & REQ_PREFLUSH) {
		ret = sync_parts(dev);
		if (ret)
			return ret;
	}
	if (op == REQ_OP_READ) {
		for (i = 0; i < len / DB_BLOCK; i++) {
			ret = read_value(dev, map_slot(dev, pos / DB_BLOCK + i), dev->raw + i * DB_BLOCK);
			if (ret)
				return ret;
		}
		request_copy(dev, rq, true);
		return 0;
	}
	if (!len)
		return sync_parts(dev);
	ret = collect_part(dev);
	if (ret)
		return ret;
	dev->stage.count = len / DB_BLOCK;
	for (i = 0; i < dev->stage.count; i++)
		dev->stage.logical[i] = pos / DB_BLOCK + i;
	if (op == REQ_OP_DISCARD)
		memset(dev->raw, 0, len);
	else
		request_copy(dev, rq, false);
	return commit_staged(dev, dev->capacity);
}

static void process_request(struct work_struct *work)
{
	struct db_request *pdu = container_of(work, struct db_request, work);
	struct request *rq = blk_mq_rq_from_pdu(pdu);
	struct dynblk_device *dev = rq->q->queuedata;
	unsigned int noio = memalloc_noio_save();
	int ret;

	mutex_lock(&dev->state_lock);
	ret = transfer(dev, rq);
	/* Integrity failures also fence mutations; they never synthesize zero data. */
	if (ret && (req_op(rq) != REQ_OP_READ || ret == -EUCLEAN || ret == -EIO))
		dev->fenced = true;
	mutex_unlock(&dev->state_lock);
	memalloc_noio_restore(noio);
	blk_mq_end_request(rq, errno_to_blk_status(ret));
}

static blk_status_t queue_request(struct blk_mq_hw_ctx *hctx,
				 const struct blk_mq_queue_data *bd)
{
	struct db_request *pdu = blk_mq_rq_to_pdu(bd->rq);
	struct dynblk_device *dev = bd->rq->q->queuedata;

	blk_mq_start_request(bd->rq);
	queue_work(dev->worker, &pdu->work);
	return BLK_STS_OK;
}

static int init_request(struct blk_mq_tag_set *set, struct request *rq,
			unsigned int hctx, unsigned int node)
{
	struct db_request *pdu = blk_mq_rq_to_pdu(rq);

	INIT_WORK(&pdu->work, process_request);
	return 0;
}

static enum blk_eh_timer_return request_timeout(struct request *rq)
{
	return BLK_EH_RESET_TIMER;
}

static const struct blk_mq_ops mq_ops = {
	.queue_rq = queue_request,
	.init_request = init_request,
	.timeout = request_timeout,
};

static int block_open(struct gendisk *disk, blk_mode_t mode)
{
	struct dynblk_device *dev = disk->private_data;
	int ret = 0;

	(void)mode;
	mutex_lock(&dev->lifecycle_lock);
	if (dev->detaching)
		ret = -ENXIO;
	else
		dev->openers++;
	mutex_unlock(&dev->lifecycle_lock);
	return ret;
}

static void block_release(struct gendisk *disk)
{
	struct dynblk_device *dev = disk->private_data;

	mutex_lock(&dev->lifecycle_lock);
	WARN_ON_ONCE(!dev->openers);
	if (dev->openers)
		dev->openers--;
	mutex_unlock(&dev->lifecycle_lock);
}

static int block_ioctl(struct block_device *bdev, blk_mode_t mode,
		       unsigned int cmd, unsigned long arg)
{
	struct dynblk_device *dev = bdev->bd_disk->private_data;
	struct dynblk_status status = {};
	u64 bytes = 0;
	u32 id;
	unsigned int noio;
	int ret = 0;

	if (!dev || bdev_is_partition(bdev))
		return -ENOTTY;
	if (cmd != DYNBLK_GET && cmd != DYNBLK_GROW && cmd != DYNBLK_COOKIE)
		return -ENOTTY;
	if (cmd == DYNBLK_COOKIE)
		return copy_to_user((void __user *)arg, &dev->cookie, sizeof(dev->cookie)) ? -EFAULT : 0;
	if (cmd == DYNBLK_GROW) {
		if (!ns_capable(&init_user_ns, CAP_SYS_ADMIN) || !(mode & BLK_OPEN_WRITE))
			return -EPERM;
		if (copy_from_user(&bytes, (void __user *)arg, sizeof(bytes)))
			return -EFAULT;
	}
	noio = memalloc_noio_save();
	mutex_lock(&dev->state_lock);
	if (cmd == DYNBLK_GET) {
		status.version = DYNBLK_ABI_VERSION;
		status.flags = dev->fenced ? 1 : 0;
		memcpy(status.uuid, dev->volume_uuid, 16);
		memcpy(status.algorithm, dev->codec_name, 16);
		status.capacity = dev->capacity;
		status.original_bytes = dev->mapped_blocks * DB_BLOCK;
		status.stored_bytes = dev->stored_bytes;
		status.generation = dev->generation;
		status.part_limit = dev->part_limit;
		status.block_size = DB_BLOCK;
		status.max_parts = DB_PARTS;
		status.tree_height = DB_HEIGHT;
		status.map_memory_bytes = dev->map_chunks * DB_BLOCK +
			DB_NODES * sizeof(*dev->tree_index);
		status.compression_region_bytes = DB_REGION;
		status.max_capacity = DB_LIMIT;
		for (id = 0; id < DB_PARTS; id++) {
			status.active_parts += !!dev->root->incarnations[id];
			if (dev->parts[id].file)
				status.physical_bytes += i_size_read(file_inode(dev->parts[id].file));
		}
	} else if (dev->fenced) {
		ret = -EIO;
	} else if (!valid_capacity(bytes) || bytes < dev->capacity) {
		ret = -EINVAL;
	} else if (bytes != dev->capacity) {
		dev->stage.count = 0;
		ret = commit_staged(dev, bytes);
		/* A post-publication trim error cannot undo a committed growth. */
		set_capacity_and_notify(dev->disk, dev->capacity >> SECTOR_SHIFT);
	}
	mutex_unlock(&dev->state_lock);
	memalloc_noio_restore(noio);
	if (!ret && cmd == DYNBLK_GET &&
	    copy_to_user((void __user *)arg, &status, sizeof(status)))
		ret = -EFAULT;
	return ret;
}

static void close_storage(struct dynblk_device *dev)
{
	u32 id;
	unsigned long index;
	void *chunk;

	for (id = 0; id < DB_PARTS; id++) {
		if (dev->parts[id].file)
			filp_close(dev->parts[id].file, NULL);
		kvfree(dev->parts[id].refs);
	}
	if (dev->directory)
		filp_close(dev->directory, NULL);
	if (dev->creation_cred)
		put_cred(dev->creation_cred);
	if (dev->codec)
		crypto_free_comp(dev->codec);
	xa_for_each(&dev->mapping, index, chunk)
		free_page((unsigned long)chunk);
	xa_destroy(&dev->mapping);
	kvfree(dev->tree_index);
	kfree(dev->root);
	kfree(dev->other_root);
	kfree(dev->header);
	kvfree(dev->tree_stack);
	kfree(dev->transaction);
	kvfree(dev->raw);
	kvfree(dev->packed);
	kvfree(dev->scratch);
	kvfree(dev->decoded);
	kfree(dev->backing_filename);
	release_tree_index_budget(dev);
}

static int validate_attach(struct dynblk_attach *request)
{
	u64 size, part_limit;

	if (request->version != DYNBLK_ABI_VERSION || request->device != -1 || request->cookie ||
	    request->flags & ~DYNBLK_ATTACH_CREATE ||
	    request->map_memory_mb > DYNBLK_MAX_MAP_MEMORY_MB ||
	    strnlen(request->path, DYNBLK_PATH_MAX) == DYNBLK_PATH_MAX ||
	    !request->path[0])
		return -EINVAL;
	if (!request->map_memory_mb)
		request->map_memory_mb = DYNBLK_DEFAULT_MAP_MEMORY_MB;
	if (!(request->flags & DYNBLK_ATTACH_CREATE)) {
		if (request->size_bytes || request->part_limit_bytes ||
		    memchr_inv(request->algorithm, 0, sizeof(request->algorithm)))
			return -EINVAL;
		return 0;
	}
	size = request->size_bytes ?: (16ULL << 30);
	part_limit = request->part_limit_bytes ?: DB_DEFAULT_PART_LIMIT;
	if (!valid_capacity(size) || !valid_part_limit(part_limit) ||
	    !request->algorithm[0] || !memchr(request->algorithm, 0, sizeof(request->algorithm)))
		return -EINVAL;
	request->size_bytes = size;
	request->part_limit_bytes = part_limit;
	return 0;
}

static int attach_device(struct dynblk_attach *request)
{
	struct queue_limits limits = {
		.logical_block_size = DB_BLOCK,
		.physical_block_size = DB_BLOCK,
		.max_hw_sectors = DB_IO >> SECTOR_SHIFT,
		.max_segments = DB_IO / 512,
		.max_hw_discard_sectors = DB_IO >> SECTOR_SHIFT,
		.discard_granularity = DB_BLOCK,
		.features = BLK_FEAT_WRITE_CACHE | BLK_FEAT_FUA,
	};
	struct dynblk_device *dev;
	unsigned int noio;
	int index, ret;

	ret = validate_attach(request);
	if (ret)
		return ret;
	if (!ns_capable(&init_user_ns, CAP_SYS_ADMIN) || current_user_ns() != &init_user_ns)
		return -EPERM;
	dev = kzalloc(sizeof(*dev), GFP_KERNEL);
	if (!dev)
		return -ENOMEM;
	index = ida_alloc_max(&device_ids, DYNBLK_MAX_DEVICES - 1, GFP_KERNEL);
	if (index < 0) {
		kfree(dev);
		return index;
	}
	dev->index = index;
	dev->creating = !!(request->flags & DYNBLK_ATTACH_CREATE);
	dev->map_memory_mb = request->map_memory_mb;
	dev->part_limit = dev->creating ? request->part_limit_bytes : DB_DEFAULT_PART_LIMIT;
	dev->avoid_part = -1;
	dev->gc_node = DB_NO_NODE;
	do {
		get_random_bytes(&dev->cookie, sizeof(dev->cookie));
	} while (!dev->cookie);
	mutex_init(&dev->state_lock);
	mutex_init(&dev->lifecycle_lock);
	xa_init(&dev->mapping);
	dev->backing_filename = kstrdup(request->path, GFP_KERNEL);
	dev->creation_cred = get_current_cred();
	if (!dev->backing_filename) {
		ret = -ENOMEM;
		goto fail_storage;
	}
	ret = reserve_tree_index_budget(dev);
	if (ret)
		goto fail_storage;
	dev->root = kzalloc(DB_BLOCK, GFP_KERNEL);
	dev->other_root = kzalloc(DB_BLOCK, GFP_KERNEL);
	dev->header = kmalloc(DB_BLOCK, GFP_KERNEL);
	dev->tree_stack = kvcalloc(DB_HEIGHT, sizeof(*dev->tree_stack), GFP_KERNEL);
	dev->transaction = kmalloc(DB_BLOCK, GFP_KERNEL);
	dev->raw = kvzalloc(DB_IO, GFP_KERNEL);
	dev->packed = kvzalloc(DB_REGION, GFP_KERNEL);
	dev->scratch = kvzalloc(2 * DB_REGION, GFP_KERNEL);
	dev->decoded = kvzalloc(DB_REGION, GFP_KERNEL);
	dev->tree_index = kvcalloc(DB_NODES, sizeof(*dev->tree_index), GFP_KERNEL);
	if (!dev->root || !dev->other_root || !dev->header || !dev->transaction ||
	    !dev->raw || !dev->packed || !dev->scratch || !dev->decoded ||
	    !dev->tree_index || !dev->tree_stack) {
		ret = -ENOMEM;
		goto fail_storage;
	}
	ret = pin_directory(dev);
	if (ret)
		goto fail_storage;
	if (dev->creating) {
		ret = require_unused_namespace(dev, 0);
		if (ret)
			goto fail_storage;
		if (dev->part_limit > file_inode(dev->directory)->i_sb->s_maxbytes) {
			ret = -EFBIG;
			goto fail_storage;
		}
		ret = setup_codec(dev, request->algorithm);
		if (ret)
			goto fail_storage;
		generate_random_uuid(dev->volume_uuid);
	}
	noio = memalloc_noio_save();
	ret = open_part(dev, 0, dev->creating);
	if (!ret && dev->creating) {
		/* Recheck siblings after the O_EXCL part-0 create so a sibling racing the
		 * precheck cannot turn into a successfully published mixed namespace. */
		ret = require_unused_namespace(dev, 1);
		if (!ret) {
			dev->generation = 1;
			dev->capacity = request->size_bytes;
			memcpy(dev->root->magic, "DBROOT01", 8);
			memcpy(dev->root->uuid, dev->volume_uuid, 16);
			dev->root->generation = cpu_to_le64(dev->generation);
			dev->root->capacity = cpu_to_le64(dev->capacity);
			dev->root->tree_height = cpu_to_le32(DB_HEIGHT);
			active_location(dev, 0);
			ret = publish_root(dev);
		}
	} else if (!ret) {
		ret = recover(dev);
	}
	memalloc_noio_restore(noio);
	if (ret)
		goto fail_storage;
	dev->worker = alloc_ordered_workqueue("dynblk%d", WQ_MEM_RECLAIM, dev->index);
	if (!dev->worker) {
		ret = -ENOMEM;
		goto fail_storage;
	}
	dev->tags.ops = &mq_ops;
	dev->tags.nr_hw_queues = 1;
	dev->tags.queue_depth = 128;
	dev->tags.numa_node = NUMA_NO_NODE;
	dev->tags.cmd_size = sizeof(struct db_request);
	dev->tags.flags = BLK_MQ_F_SHOULD_MERGE;
	ret = blk_mq_alloc_tag_set(&dev->tags);
	if (ret)
		goto fail_worker;
	dev->disk = blk_mq_alloc_disk(&dev->tags, &limits, dev);
	if (IS_ERR(dev->disk)) {
		ret = PTR_ERR(dev->disk);
		dev->disk = NULL;
		goto fail_tags;
	}
	dev->disk->fops = &operations;
	dev->disk->private_data = dev;
	snprintf(dev->disk->disk_name, DISK_NAME_LEN, "dynblk%d", dev->index);
	set_capacity(dev->disk, dev->capacity >> SECTOR_SHIFT);
	ret = add_disk(dev->disk);
	if (ret)
		goto fail_disk;
	mutex_lock(&devices_lock);
	devices[dev->index] = dev;
	mutex_unlock(&devices_lock);
	__module_get(THIS_MODULE);
	request->device = dev->index;
	request->cookie = dev->cookie;
	pr_info("dynblk%d: format 1, %llu bytes, %s, COW radix tree / 64KiB regions\n",
		dev->index, dev->capacity, dev->codec_name);
	return 0;

fail_disk:
	put_disk(dev->disk);
fail_tags:
	blk_mq_free_tag_set(&dev->tags);
fail_worker:
	destroy_workqueue(dev->worker);
fail_storage:
	pr_err("dynblk%d: attachment failed: %d; partial files preserved\n", dev->index, ret);
	close_storage(dev);
	ida_free(&device_ids, dev->index);
	kfree(dev);
	return ret;
}

static int detach_device(u32 index, u64 cookie)
{
	struct dynblk_device *dev;
	unsigned int noio;
	int sync_error = 0;

	if (index >= DYNBLK_MAX_DEVICES || !cookie)
		return -ENODEV;
	mutex_lock(&devices_lock);
	dev = devices[index];
	if (!dev) {
		mutex_unlock(&devices_lock);
		return -ENODEV;
	}
	if (dev->cookie != cookie) {
		mutex_unlock(&devices_lock);
		return -ESTALE;
	}
	mutex_lock(&dev->lifecycle_lock);
	if (dev->detaching || dev->openers) {
		mutex_unlock(&dev->lifecycle_lock);
		mutex_unlock(&devices_lock);
		return -EBUSY;
	}
	dev->detaching = true;
	mutex_unlock(&dev->lifecycle_lock);
	mutex_unlock(&devices_lock);

	flush_workqueue(dev->worker);
	noio = memalloc_noio_save();
	mutex_lock(&dev->state_lock);
	if (!dev->fenced) {
		sync_error = sync_parts(dev);
		if (sync_error) {
			mutex_unlock(&dev->state_lock);
			memalloc_noio_restore(noio);
			mutex_lock(&dev->lifecycle_lock);
			dev->detaching = false;
			mutex_unlock(&dev->lifecycle_lock);
			return sync_error;
		}
	} else {
		sync_error = -EIO;
	}
	mutex_unlock(&dev->state_lock);
	memalloc_noio_restore(noio);
	if (sync_error)
		pr_warn("dynblk%u: detaching fenced device without final sync; recovery required on reattach\n",
			index);

	mutex_lock(&devices_lock);
	if (devices[index] != dev || dev->cookie != cookie) {
		mutex_unlock(&devices_lock);
		return -EUCLEAN;
	}
	devices[index] = NULL;
	mutex_unlock(&devices_lock);

	del_gendisk(dev->disk);
	put_disk(dev->disk);
	blk_mq_free_tag_set(&dev->tags);
	destroy_workqueue(dev->worker);
	close_storage(dev);
	ida_free(&device_ids, dev->index);
	pr_info("dynblk%u: detached\n", index);
	kfree(dev);
	module_put(THIS_MODULE);
	return 0;
}

static long control_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	void __user *user = (void __user *)arg;
	int ret;

	(void)file;
	if (!ns_capable(&init_user_ns, CAP_SYS_ADMIN) || current_user_ns() != &init_user_ns)
		return -EPERM;
	if (cmd == DYNBLK_ATTACH) {
		struct dynblk_attach *request = memdup_user(user, sizeof(*request));

		if (IS_ERR(request))
			return PTR_ERR(request);
		ret = attach_device(request);
		if (!ret && copy_to_user(user, request, sizeof(*request))) {
			detach_device(request->device, request->cookie);
			ret = -EFAULT;
		}
		kfree(request);
		return ret;
	}
	if (cmd == DYNBLK_DETACH) {
		struct dynblk_detach request;

		if (copy_from_user(&request, user, sizeof(request)))
			return -EFAULT;
		if (request.version != DYNBLK_ABI_VERSION || !request.cookie)
			return -EINVAL;
		return detach_device(request.device, request.cookie);
	}
	return -ENOTTY;
}

static const struct file_operations control_operations = {
	.owner = THIS_MODULE,
	.unlocked_ioctl = control_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = control_ioctl,
#endif
	.llseek = noop_llseek,
};

static struct miscdevice control_device = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "dynblk-control",
	.fops = &control_operations,
	.mode = 0600,
};

static int __init dynblk_init(void)
{
	BUILD_BUG_ON(sizeof(struct db_header) != DB_BLOCK);
	BUILD_BUG_ON(sizeof(struct db_root) != DB_BLOCK);
	BUILD_BUG_ON(sizeof(struct db_pointer) != 24);
	BUILD_BUG_ON(sizeof(struct db_value) != 40);
	BUILD_BUG_ON(sizeof(struct db_entry) != 48);
	BUILD_BUG_ON(sizeof(struct db_node) != DB_BLOCK);
	BUILD_BUG_ON(sizeof(struct db_transaction) != DB_BLOCK);
	BUILD_BUG_ON(sizeof(struct dynblk_status) != 128);
	BUILD_BUG_ON(sizeof(struct dynblk_detach) != 16);
	BUILD_BUG_ON(sizeof(struct dynblk_attach) >= (1U << _IOC_SIZEBITS));
	if (!IS_ENABLED(CONFIG_FILE_LOCKING) || PAGE_SIZE != DB_BLOCK)
		return -EOPNOTSUPP;
	if (!tree_index_budget_mb ||
	    ((u64)tree_index_budget_mb << 20) < (u64)DB_NODES * sizeof(struct db_pointer))
		return -EINVAL;
	return misc_register(&control_device);
}

static void __exit dynblk_exit(void)
{
	u32 index;

	misc_deregister(&control_device);
	for (index = 0; index < DYNBLK_MAX_DEVICES; index++)
		WARN_ON_ONCE(devices[index]);
	WARN_ON_ONCE(tree_index_bytes);
	ida_destroy(&device_ids);
}

module_init(dynblk_init);
module_exit(dynblk_exit);
MODULE_LICENSE("GPL");
MODULE_VERSION("1.0.0");
MODULE_DESCRIPTION("Self-contained COW compressed file-backed block device");

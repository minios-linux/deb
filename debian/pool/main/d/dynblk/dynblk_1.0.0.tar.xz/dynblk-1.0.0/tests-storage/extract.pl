#!/usr/bin/perl
use strict;
use warnings;
my $admission = @ARGV && $ARGV[0] eq '--admission' ? shift @ARGV : '';
local $/;
my $source = <>;
if ($admission) {
    my ($constants) = $source =~ /^(#define DB_BLOCK .*?)(?=^struct db_header)/ms;
    my ($limits) = $source =~ /\bstruct queue_limits limits = (\{.*?^\t\});/ms;
    die "missing production constants/queue limits" unless $constants && $limits;
    print $constants, "\nstatic u64 part_limit = DB_DEFAULT_PART_LIMIT;\n";
    print "static const struct queue_limits tested_limits = $limits;\n";
    for my $name (qw(geometry backing_attributes setup_codec)) {
        my ($function) = $source =~ /^(static [^\n]*\b\Q$name\E\(.*?^\}\n)/ms;
        die "missing function $name" unless $function;
        print "\n", $function;
    }
    exit;
}
my ($types) = $source =~ /^(#define DB_BLOCK .*?)(?=^static char \*filename)/ms;
my ($globals) = $source =~ /^(static struct db_part .*?)(?=^static struct gendisk)/ms;
die "missing production declarations" unless $types && $globals;
print $types, $globals;
for my $name (qw(checksum zero seal sealed valid_capacity valid_part_limit part_id location_of
    file_io page_io map_slot reserve_map allocate release_page valid_value same_blob value_charge
    payload_refs read_value sync_parts publish_root trim_parts active_location node_index
    node_level node_base valid_pointer make_pointer read_node dirty_path write_tree
    prune_map working_room flush_payload prepare_payload region_estimate region_account commit_staged
    collect_part valid_root mark_metadata recover_tree recover)) {
    my ($function) = $source =~ /^(static [^\n]*\b\Q$name\E\(.*?^\}\n)/ms;
    die "missing function $name" unless $function;
    print "\n", $function;
}

# Source-Extracted Storage Tests

Run `make -C tests-storage test` from the dynblk repository. Requires GCC,
Perl, zlib development headers/library and liblz4.so.1. Build output defaults to
`tests-storage/.build/`, private to that source checkout and created on demand.
For an external build directory pass `BUILD_DIR=/absolute/private/path` to either
`make test` or this runner. No module is loaded and no host device or filesystem
is formatted.

`extract.pl` extracts the real packed structures, state and named storage
functions from `../dynblk.c`. The harness supplies in-memory VFS/xarray and
liblz4 crypto adapters. It models volatile versus durable file contents, fsync
barriers, failed/torn writes, truncation, and reattachment. Default compilation
enables ASan, UBSan, warnings and -Werror.

`admission.c` additionally extracts the production queue initializer, geometry,
attribute admission and codec-dispatch functions. It checks the nonzero hardware
discard limit, Btrfs NULL/poison s_bdev safety, magic/block-size/cap constraints,
the fileattr input selector and rejection/error paths, ntfs3 compression and
conservative attribute masks, and all six codec dispatch names including lz4hc.
These tests use attribute/crypto-provider shims, not real mounted filesystems.

Coverage includes all radix boundaries, old/new atomic transaction outcomes,
independent subblock writes/discards into shared 64 KiB blobs, decode caching,
packed raw fallback, metadata/payload corruption, generation/CRC-bound pointers,
cycles/aliases, cold tree-node GC, predicted GC packing/no-churn, real 1 MiB file
caps and rollover/recreation, top-of-128-GiB mapping, and randomized workloads.
Write-count assertions prove four tree pages for a one-block mutation, at most
seven for a contiguous 128 KiB request, zero for capacity-only growth, and 97
for a worst-case arbitrary 32-leaf update. They are not throughput benchmarks.

The harness does NOT test actual kernel crypto providers, blk-mq or ioctl/FUA
plumbing, real O_PATH/pinned-open or Btrfs/ntfs3 attribute providers,
flock/credentials, real creation/directory barriers, real host ENOSPC,
filesystem metadata survival, or hardware power cuts.
Part opening and unlink are adapters, not extracted VFS implementations. Real
filesystem, blk-mq, ioctl and power-loss paths are covered by the VM suite.

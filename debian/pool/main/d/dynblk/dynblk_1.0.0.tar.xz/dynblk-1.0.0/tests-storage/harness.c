/* Source-extracted storage engine; VFS/xarray/crypto adapters, not a kernel VM. */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <zlib.h>

#include "../dynblk_uapi.h"

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#define __packed __attribute__((packed))
#define U16_MAX UINT16_MAX
#define U32_MAX UINT32_MAX
#define U64_MAX UINT64_MAX
#define cpu_to_le32(x) ((u32)(x))
#define cpu_to_le64(x) ((u64)(x))
#define le32_to_cpu(x) ((u32)(x))
#define le64_to_cpu(x) ((u64)(x))
#define DIV_ROUND_UP(x,y) (((x)+(y)-1)/(y))
#define DIV_ROUND_UP_ULL(x,y) DIV_ROUND_UP(x,y)
#define BIT_ULL(x) (UINT64_C(1) << (x))
#define min(x,y) ((x)<(y)?(x):(y))
#define max(x,y) ((x)>(y)?(x):(y))
#define min_t(type,x,y) min((type)(x),(type)(y))
#define round_down(x,y) ((x) & ~((__typeof__(x))(y)-1))
#define GFP_NOIO 0
#define cond_resched() ((void)0)
#define DEFINE_MUTEX(x) int x __attribute__((unused))
#define DEFINE_XARRAY(x) struct xarray x
#define xa_for_each(x,index,chunk) \
    for ((index)=0; (index)<(x)->end; (index)++) \
        if (((chunk)=(x)->slots[index]) != NULL)
#define file_inode(f) (&(f)->inode)
#define i_size_read(i) ((i)->size)
#define get_zeroed_page(gfp) ((unsigned long)calloc(1,4096))
#define free_page(p) free((void *)(p))

struct xarray { void *slots[524288]; u64 end; };
struct inode { u64 size; };
struct file;
struct path { struct file *file; };
struct file {
    struct inode inode;
    struct path f_path;
    u8 *bytes, *durable;
    u64 space, durable_size;
    bool exists, durable_exists;
    u64 incarnation;
};
struct cred { int dummy; };
struct crypto_comp { int dummy; };
struct kstatfs { long f_bsize; u64 f_bavail; };
static u64 host_free = 64ULL << 30;
static int vfs_statfs(struct path *path, struct kstatfs *st)
{
    (void)path;
    st->f_bsize=4096; st->f_bavail=host_free/4096;
    return 0;
}
static const struct cred *override_creds(const struct cred *cred) { return cred; }
static void revert_creds(const struct cred *cred) { (void)cred; }
static unsigned int map_memory_mb = 256;
static struct file files[64];
static int fault_at, event_count, fault_mode, torn_bytes;
static bool fault_injected;
static unsigned int tree_writes, decompressions, creations, removals;
static u64 write_bytes;
static int open_part(u32 id, bool exclusive);
static int remove_part(u32 id);

static void *xa_load(struct xarray *x, u64 index)
{
    assert(index < 524288);
    return x->slots[index];
}
static int xa_insert(struct xarray *x, u64 index, void *p, int gfp)
{
    (void)gfp;
    assert(index < 524288 && !x->slots[index]);
    x->slots[index] = p;
    if (index>=x->end) x->end=index+1;
    return 0;
}
static void xa_erase(struct xarray *x, u64 index) { x->slots[index] = NULL; }
static void *memchr_inv(const void *p, int c, size_t n)
{
    for (size_t i=0; i<n; i++)
        if (((const u8 *)p)[i] != c) return (void *)p+i;
    return NULL;
}
static u32 crc32_le(u32 seed, const void *p, size_t n)
{
    return (u32)crc32(seed ^ ~0U, p, n) ^ ~0U;
}
static bool inject(void)
{
    if (!fault_at || ++event_count!=fault_at) return false;
    fault_injected=true;
    return true;
}
static void ensure(struct file *f, u64 length)
{
    assert(length < 64 * 1024 * 1024);
    if (length <= f->space) return;
    u64 size = DIV_ROUND_UP(length, 65536) * 65536;
    f->bytes = realloc(f->bytes, size);
    f->durable = realloc(f->durable, size);
    assert(f->bytes && f->durable);
    memset(f->bytes + f->space, 0, size - f->space);
    memset(f->durable + f->space, 0, size - f->space);
    f->space = size;
}
static ssize_t kernel_write(struct file *f, const void *p, size_t n, loff_t *pos)
{
    bool fail = inject();
    write_bytes += n;
    if (n==4096 && !memcmp(p,"DBTREE01",8)) tree_writes++;
    ensure(f, *pos + n);
    if (fail) {
        if (fault_mode) {
            size_t k = min(n, (size_t)torn_bytes);
            memcpy(f->durable + *pos, p, k);
            if (k && (u64)*pos+k > f->durable_size) f->durable_size = *pos+k;
        }
        return -EIO;
    }
    memcpy(f->bytes + *pos, p, n);
    *pos += n;
    if ((u64)*pos > f->inode.size) f->inode.size = *pos;
    return n;
}
static ssize_t kernel_read(struct file *f, void *p, size_t n, loff_t *pos)
{
    if ((u64)*pos >= f->inode.size) return 0;
    n = min(n, f->inode.size - *pos);
    memcpy(p, f->bytes + *pos, n);
    *pos += n;
    return n;
}
static int vfs_fsync(struct file *f, int ignored)
{
    (void)ignored;
    bool fail = inject();
    if (!fail || fault_mode) {
        memcpy(f->durable, f->bytes, f->inode.size);
        f->durable_size = f->inode.size;
        f->durable_exists = f->exists;
    }
    return fail ? -EIO : 0;
}
static int vfs_truncate(struct path *path, u64 len)
{
    if (inject()) return -EIO;
    assert(len <= path->file->inode.size);
    path->file->inode.size = len;
    return 0;
}
extern int LZ4_compress_default(const char *, char *, int, int);
extern int LZ4_decompress_safe(const char *, char *, int, int);
static int crypto_comp_compress(struct crypto_comp *tfm, const void *src,
                               u32 len, void *dst, u32 *out)
{
    (void)tfm;
    int n = LZ4_compress_default(src, dst, len, *out);
    if (n <= 0) return -EIO;
    *out = n;
    return 0;
}
static int crypto_comp_decompress(struct crypto_comp *tfm, const void *src,
                                 u32 len, void *dst, u32 *out)
{
    (void)tfm;
    decompressions++;
    int n = LZ4_decompress_safe(src, dst, len, *out);
    if (n < 0) return -EIO;
    *out = n;
    return 0;
}

#include "production.inc"

static int open_part(u32 id, bool exclusive)
{
    struct file *f = &files[id];
    if (parts[id].file) return 0;
    if (exclusive && f->exists) return -EEXIST;
    if (!exclusive && !f->exists) return -ENOENT;
    if (exclusive) {
        creations++;
        f->exists = true;
        f->incarnation++;
        ensure(f, DB_BLOCK);
        memset(f->bytes, 0, DB_BLOCK);
        f->inode.size = DB_BLOCK;
        assert(!vfs_fsync(f, 0));
    }
    parts[id].file = f;
    parts[id].incarnation = f->incarnation;
    parts[id].refs = calloc(DB_PAGES, sizeof(u16));
    assert(parts[id].refs);
    parts[id].refs[0] = DB_BUSY;
    if (!id) parts[id].refs[1] = parts[id].refs[2] = DB_BUSY;
    parts[id].hint = id ? 1 : 3;
    f->f_path.file = f;
    return 0;
}
static int remove_part(u32 id)
{
    if (inject()) return -EIO;
    removals++;
    files[id].exists = files[id].durable_exists = false;
    files[id].inode.size = files[id].durable_size = 0;
    free(parts[id].refs);
    memset(&parts[id], 0, sizeof(parts[id]));
    return 0;
}
static void reset_ram(void)
{
    for (u32 i=0; i<mapping.end; i++) { free(mapping.slots[i]); mapping.slots[i]=NULL; }
    mapping.end=0;
    for (u32 i=0; i<DB_PARTS; i++) free(parts[i].refs);
    memset(parts, 0, sizeof(parts));
    generation = capacity = mapped_blocks = stored_bytes = map_chunks = 0;
    tree_pages = 0;
    memset(tree_index,0,DB_NODES*sizeof(*tree_index));
    cached_blob.location=0;
    gc_node=DB_NO_NODE;
    fenced = collecting = false;
    avoid_part = -1;
    stage.count = 0;
    stage.nr_dirty=stage.nr_allocations=0;
    fault_at = event_count = 0;
    fault_injected=false;
}
static void fresh(bool compressed)
{
    reset_ram();
    for (u32 i=0; i<DB_PARTS; i++) {
        free(files[i].bytes); free(files[i].durable);
    }
    memset(files, 0, sizeof(files));
    memset(root, 0, DB_BLOCK);
    memset(volume_uuid, 0x57, 16);
    memset(codec_name, 0, 16);
    strcpy(codec_name, compressed ? "lz4" : "none");
    codec = compressed ? (void *)1 : NULL;
    host_free=64ULL<<30;
    part_limit=1ULL<<20;
    assert(valid_part_limit(part_limit));
    assert(!open_part(0, true));
    directory = &files[0];
    generation = 1;
    capacity = 16ULL << 30;
    memcpy(root->magic, "DBROOT01", 8);
    memcpy(root->uuid, volume_uuid, 16);
    root->generation = generation;
    root->capacity = capacity;
    root->tree_height=DB_HEIGHT;
    active_location(0);
    assert(!publish_root());
}
static int reboot(void)
{
    reset_ram();
    for (u32 i=0; i<DB_PARTS; i++) {
        struct file *f = &files[i];
        f->exists = f->durable_exists;
        f->inode.size = f->durable_size;
        if (f->durable_size) memcpy(f->bytes, f->durable, f->durable_size);
    }
    assert(!open_part(0, false));
    return recover();
}
static int write_blocks(u32 first, u32 count, u8 byte)
{
    stage.count = count;
    for (u32 i=0; i<count; i++) stage.logical[i] = first+i;
    memset(raw, byte, count*DB_BLOCK);
    return commit_staged(capacity);
}
static void check_blocks(u32 first, u32 count, u8 byte)
{
    for (u32 i=0; i<count; i++) {
        assert(!read_value(map_slot(first+i), raw));
        assert(!memchr_inv(raw, byte, DB_BLOCK));
    }
}

static u64 physical_total(void)
{
    u64 bytes=0;
    for (u32 i=0; i<DB_PARTS; i++) {
        assert(files[i].inode.size<=part_limit);
        if (files[i].exists) bytes+=files[i].inode.size;
    }
    return bytes;
}

static void check_accounting(void)
{
    u64 refs[DB_PARTS]={0}, live[DB_PARTS]={0}, total=0, maps=0;
    u32 meta[DB_PARTS]={0}, gc[DB_PARTS]={0}, nodes=0;
    for (u32 index=0; index<mapping.end; index++) {
        struct db_value *values=mapping.slots[index];
        if (!values) continue;
        for (u32 i=0; i<DB_CHUNK; i++) {
            if (!values[i].location) continue;
            u32 id=part_id(values[i].location);
            refs[id]++; maps++;
            live[id]+=value_charge((u64)index*DB_CHUNK+i,&values[i]);
        }
        for (u32 group=0; group<DB_CHUNK; group+=DB_SUBBLOCKS) {
            u32 pages[DB_PARTS];
            region_estimate((u64)index*DB_CHUNK+group,pages);
            for (u32 id=0; id<DB_PARTS; id++) gc[id]+=pages[id];
        }
    }
    for (u32 i=0; i<DB_NODES; i++) {
        if (!tree_index[i].location) continue;
        u32 id=part_id(tree_index[i].location);
        refs[id]++; meta[id]++; nodes++;
        assert(parts[id].refs[(u32)tree_index[i].location/DB_BLOCK]==DB_BUSY);
    }
    if (root->transaction.location) {
        u32 id=part_id(root->transaction.location);
        refs[id]++; meta[id]++;
    }
    assert(maps==mapped_blocks && nodes==tree_pages);
    for (u32 i=0; i<DB_PARTS; i++) {
        assert(refs[i]==parts[i].live_refs && live[i]==parts[i].live_bytes &&
               meta[i]==parts[i].meta_pages && gc[i]==parts[i].gc_pages);
        assert((!i || !!refs[i])==!!root->incarnations[i]);
        total+=live[i];
    }
    assert(total==stored_bytes);
}

static void fill_random(void *buffer, u32 bytes, u32 seed)
{
    u8 *p=buffer;
    for (u32 i=0; i<bytes; i++) {
        seed^=seed<<13; seed^=seed>>17; seed^=seed<<5;
        p[i]=seed;
    }
}
int main(void)
{
    root = calloc(1, DB_BLOCK); other_root = calloc(1, DB_BLOCK);
    header = malloc(DB_BLOCK); transaction = malloc(DB_BLOCK);
    tree_stack=calloc(DB_HEIGHT,sizeof(*tree_stack));
    tree_index=calloc(DB_NODES,sizeof(*tree_index));
    raw = malloc(DB_IO); packed = malloc(DB_REGION); scratch = malloc(2*DB_REGION);
    decoded=malloc(DB_REGION);
    assert(sizeof(*root)==4096 && sizeof(*tree_stack)==4096 &&
           sizeof(*transaction)==4096 && sizeof(struct db_header)==4096 &&
           sizeof(struct dynblk_status)==128 && DYNBLK_GET==0x8080d700UL);

    for (int compressed=0; compressed<2; compressed++) {
        fresh(compressed);
        assert(files[0].inode.size == 12288 && !files[1].exists);
        assert(!write_blocks(0, 32, 0x41));
        if (compressed) assert(stored_bytes < DB_BLOCK);
        u64 peak = files[0].inode.size;
        for (int i=0; i<100; i++) {
            assert(!write_blocks(0, 32, 0x42+(i%20)));
            check_blocks(0, 32, 0x42+(i%20));
            if (files[0].inode.size > peak) peak = files[0].inode.size;
            if (!(i%10)) assert(!reboot());
        }
        assert(peak < 2*DB_IO + 16*DB_BLOCK);
        assert(!write_blocks(1, 30, 0));
        assert(mapped_blocks==2);
        assert(!reboot());
        check_blocks(1, 30, 0);
        assert(!write_blocks(0, 32, 0));
        assert(!mapped_blocks && !map_chunks);
        assert(!reboot());
        stage.count=0;
        assert(!commit_staged(32ULL<<30));
        assert(!reboot() && capacity==(32ULL<<30));
    }
    puts("PASS raw/LZ4 region COW, overwrite reuse, shared-page discard, empty map, grow, recovery");

    unsigned int trials=0, injected_trials=0;
    for (int compressed=0; compressed<2; compressed++)
      for (int mode=0; mode<2; mode++)
        for (int cut=0; cut<=4096; cut+=512)
          for (int event=1; event<=24; event++)
           for (int scenario=0; scenario<4; scenario++)
            for (int erase=0; erase<2; erase++) {
            fresh(compressed);
            u32 first=scenario==0?0:scenario==1?63:scenario==2?8191:1048575;
            assert(!write_blocks(first, 32, 0x31));
            assert(!write_blocks(20000,16,0x19));
            fault_at=event; event_count=0; fault_mode=mode; torn_bytes=cut;
            u8 replacement=erase?0:0x72;
            int ret = write_blocks(first, 32, replacement);
            if (ret) assert(fenced);
            assert(fault_injected==(ret<0));
            injected_trials+=fault_injected;
            assert(!reboot());
            assert(!read_value(map_slot(first), raw));
            u8 expected = ((u8 *)raw)[0];
            assert(expected==0x31 || expected==replacement);
            if (!ret) assert(expected==replacement);
            check_blocks(first, 32, expected);
            check_blocks(20000,16,0x19);
            assert(!write_blocks(first, 32, 0x56));
            assert(!reboot());
            check_blocks(first, 32, 0x56);
            check_blocks(20000,16,0x19);
            trials++;
          }
    printf("PASS %u write/discard fault-matrix trials (%u injected failures), all tree boundaries and reuse/reattach\n",
           trials,injected_trials);

    unsigned int partial_trials=0, partial_injected=0;
    for (int mode=0; mode<2; mode++)
      for (int cut=0; cut<=4096; cut+=512)
        for (int event=1; event<=20; event++)
          for (int erase=0; erase<2; erase++) {
            fresh(true);
            assert(!write_blocks(0,16,0x31));
            fault_at=event; event_count=0; fault_mode=mode; torn_bytes=cut;
            int ret=write_blocks(5,1,erase?0:0x72);
            partial_injected+=fault_injected;
            assert(fault_injected==(ret<0));
            assert(!reboot());
            assert(!read_value(map_slot(5),raw));
            u8 expected=((u8 *)raw)[0];
            assert(expected==0x31 || expected==(erase?0:0x72));
            if (!ret) assert(expected==(erase?0:0x72));
            check_blocks(0,5,0x31); check_blocks(6,10,0x31);
            check_blocks(5,1,expected);
            assert(!write_blocks(5,1,0x56));
            assert(!reboot());
            check_blocks(0,5,0x31); check_blocks(6,10,0x31); check_blocks(5,1,0x56);
            partial_trials++;
          }
    printf("PASS %u partial-group overwrite/discard crash trials (%u injected failures)\n",
           partial_trials,partial_injected);

    fresh(false);
    assert(!write_blocks(0, 32, 0x41));
    u64 loc=le64_to_cpu(map_slot(0)->location);
    files[part_id(loc)].durable[(u32)loc] ^= 1;
    assert(reboot()==-EUCLEAN);
    puts("PASS committed payload corruption rejects");

    fresh(false);
    for (u32 i=0; i<320; i+=32) assert(!write_blocks(i,32,0x67));
    assert(tree_pages==8);
    for (u32 i=0; i<256; i+=32) assert(!write_blocks(i,32,0));
    u64 before=generation;
    assert(!collect_part());
    assert(generation>before && parts[1].file);
    assert(!reboot());
    check_blocks(256,64,0x67);
    check_blocks(0,256,0);
    for (u32 i=256; i<320; i+=32) assert(!write_blocks(i,32,0));
    stage.count=0;
    avoid_part=1;
    assert(!commit_staged(capacity));
    avoid_part=-1;
    /* A tree-only transaction also relocates cold nodes before retirement. */
    collecting=true; avoid_part=1;
    for (u32 i=0; i<DB_NODES; i++) {
        if (!tree_index[i].location || part_id(tree_index[i].location)!=1) continue;
        gc_node=i; assert(!commit_staged(capacity));
    }
    gc_node=DB_NO_NODE; collecting=false; avoid_part=-1;
    assert(!files[1].exists);
    assert(!reboot());
    puts("PASS multi-leaf radix, automatic live relocation, lazy part and retirement");

    fresh(false);
    avoid_part=0;
    assert(!write_blocks(0,1,0x23));
    avoid_part=-1;
    assert(root->incarnations[1]);
    files[1].durable_exists=false;
    assert(reboot()==-EUCLEAN);
    puts("PASS missing active part rejects");

    fresh(true);
    stage.count=32;
    u8 *expected=malloc(DB_IO);
    assert(expected);
    memset(expected,0x51,DB_IO);
    u32 rng=0x137f938b;
    for (u32 i=DB_BLOCK; i<2*DB_BLOCK; i++) {
        rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
        expected[i]=rng;
    }
    memcpy(raw,expected,DB_IO);
    for (u32 i=0; i<32; i++) stage.logical[i]=i;
    assert(!commit_staged(capacity));
    assert(map_slot(1)->flags && map_slot(1)->decoded_length==DB_REGION);
    assert(!reboot());
    for (u32 i=0; i<32; i++) {
        assert(!read_value(map_slot(i),raw));
        assert(!memcmp(raw,expected+i*DB_BLOCK,DB_BLOCK));
    }
    assert(!write_blocks(0,1,0));
    assert(!write_blocks(2,30,0));
    assert(!reboot());
    assert(!read_value(map_slot(1),raw));
    assert(!memcmp(raw,expected+DB_BLOCK,DB_BLOCK));
    assert(!write_blocks(1,1,0));
    assert(!reboot() && !mapped_blocks);
    free(expected);
    puts("PASS mixed-entropy 64KiB group with surviving subblock after discard");

    fresh(false);
    assert(!write_blocks(0,1,0x35));
    host_free=0;
    assert(write_blocks(0,1,0x36)==-ENOSPC && fenced);
    host_free=64ULL<<30;
    assert(!reboot());
    check_blocks(0,1,0x35);
    puts("PASS physical workspace admission ENOSPC preserves committed mapping");

    fresh(false);
    assert(!write_blocks(0,1,0x35));
    struct db_root old_root=*root;
    /* Interrupt after durable A, leaving valid previous B. */
    fault_at=10; event_count=0; fault_mode=0; torn_bytes=0;
    assert(write_blocks(0,1,0x36)<0);
    struct db_root *selected=(void *)(files[0].durable+DB_BLOCK);
    assert(selected->generation==old_root.generation+1);
    assert(!memcmp(files[0].durable+2*DB_BLOCK,&old_root,DB_BLOCK));
    loc=selected->tree.location;
    files[part_id(loc)].durable[(u32)loc+100]^=1;
    assert(reboot()==-EUCLEAN);
    puts("PASS damaged selected tree rejects rather than stale-root fallback");

    unsigned int gc_injected=0;
    for (int event=1; event<=28; event++) {
        fresh(false);
        for (u32 i=0; i<320; i+=32) assert(!write_blocks(i,32,0x67));
        for (u32 i=0; i<256; i+=32) assert(!write_blocks(i,32,0));
        assert(!open_part(1,true));
        fault_at=event; event_count=0; fault_mode=1; torn_bytes=512;
        int gc_ret=collect_part();
        if (fault_injected) assert(gc_ret<0);
        gc_injected+=fault_injected;
        assert(!reboot());
        check_blocks(256,64,0x67);
        check_blocks(0,256,0);
    }
    printf("PASS 28 collection fault-matrix trials (%u injected failures), live/discarded data preserved\n",gc_injected);

    fresh(true);
    assert(!write_blocks(0,16,0x29));
    struct db_value original_group=*map_slot(0);
    for (u32 i=0; i<16; i++) {
        assert(same_blob(map_slot(i),&original_group));
        assert(map_slot(i)->decoded_length==DB_REGION && map_slot(i)->decoded_offset==i*DB_BLOCK);
    }
    assert(stored_bytes==original_group.length);
    cached_blob.location=0; decompressions=0;
    check_blocks(0,16,0x29);
    assert(decompressions==1);
    tree_writes=0; write_bytes=0;
    assert(!write_blocks(5,1,0x49));
    assert(tree_writes==4 && write_bytes<=DB_BLOCK*8);
    assert(map_slot(5)->decoded_length==DB_BLOCK && !map_slot(5)->decoded_offset);
    for (u32 i=0; i<16; i++)
        if (i!=5) assert(same_blob(map_slot(i),&original_group));
    assert(stored_bytes==original_group.length+map_slot(5)->length);
    check_accounting();
    assert(!reboot());
    for (u32 i=0; i<16; i++) check_blocks(i,1,i==5?0x49:0x29);
    assert(!write_blocks(0,5,0));
    assert(!write_blocks(6,10,0));
    assert(stored_bytes==map_slot(5)->length);
    check_accounting();
    assert(!reboot());
    check_blocks(5,1,0x49);
    puts("PASS 64KiB sharing, single-decode cache, independent 4KiB overwrite and unique blob accounting");

    fresh(true);
    stage.count=16;
    memset(raw,0x43,DB_REGION); memset(raw,0,DB_BLOCK);
    for (u32 i=0; i<16; i++) stage.logical[i]=i;
    assert(!commit_staged(capacity));
    assert(!map_slot(0)->location && map_slot(1)->decoded_length==DB_REGION);
    assert(stored_bytes==map_slot(1)->length);
    assert(!reboot());
    check_blocks(0,1,0); check_blocks(1,15,0x43);
    puts("PASS zero first subblock stays unmapped inside a shared compression group");

    fresh(true);
    stage.count=1; stage.logical[0]=1;
    fill_random(raw,DB_BLOCK,0x71933511);
    u32 raw_crc=checksum(raw,DB_BLOCK);
    assert(!commit_staged(capacity));
    assert(!map_slot(1)->flags && map_slot(1)->decoded_length==DB_BLOCK);
    assert(!reboot()); assert(!read_value(map_slot(1),raw));
    assert(checksum(raw,DB_BLOCK)==raw_crc);
    puts("PASS incompressible independent 4KiB raw fallback");

    fresh(true);
    stage.count=2; stage.logical[0]=1; stage.logical[1]=2;
    memset(raw,0x25,DB_BLOCK);
    fill_random(raw+DB_BLOCK,DB_BLOCK,0x71491125);
    raw_crc=checksum(raw+DB_BLOCK,DB_BLOCK);
    assert(!commit_staged(capacity));
    assert(!map_slot(2)->flags && ((u32)map_slot(2)->location)%DB_BLOCK);
    assert(!write_blocks(1,1,0));
    assert(!reboot());
    assert(!read_value(map_slot(2),raw) && checksum(raw,DB_BLOCK)==raw_crc);
    assert(!write_blocks(2,1,0));
    assert(!reboot() && !mapped_blocks);
    puts("PASS packed raw fallback crossing two allocation pages survives neighboring discard");

    fresh(true);
    assert(!write_blocks(0,16,0x31));
    struct db_value invalid=*map_slot(0);
    decompressions=0;
    invalid.length=U32_MAX;
    assert(read_value(&invalid,raw)==-EUCLEAN);
    invalid=*map_slot(0); invalid.decoded_length=U32_MAX;
    assert(read_value(&invalid,raw)==-EUCLEAN);
    invalid=*map_slot(0); invalid.decoded_offset=DB_REGION;
    assert(read_value(&invalid,raw)==-EUCLEAN);
    invalid=*map_slot(0); invalid.version=U64_MAX;
    assert(read_value(&invalid,raw)==-EUCLEAN);
    assert(!decompressions);
    assert(!valid_part_limit(DB_MIN_PART_LIMIT-DB_BLOCK));
    assert(valid_part_limit(DB_MIN_PART_LIMIT) && valid_part_limit(DB_DEFAULT_PART_LIMIT));
    assert(!valid_part_limit(DB_DEFAULT_PART_LIMIT+DB_BLOCK) && !valid_part_limit(DB_MIN_PART_LIMIT+1));
    puts("PASS malformed blob lengths/offsets/versions reject before decode, part-cap bounds");

    fresh(false);
    /* Cold mappings populate many leaves and all internal levels. */
    for (u32 i=0; i<128; i++) assert(!write_blocks(i*64,1,0x15));
    assert(tree_pages>128);
    struct db_pointer cold=tree_index[node_index(0,127*64)];
    tree_writes=0; write_bytes=0;
    assert(!write_blocks(0,1,0x51));
    assert(tree_writes==4 && write_bytes==8*DB_BLOCK);
    assert(!memcmp(&cold,&tree_index[node_index(0,127*64)],sizeof(cold)));
    tree_writes=0;
    assert(!write_blocks(8191,32,0x61));
    assert(tree_writes<=7);
    stage.count=0; tree_writes=0;
    assert(!commit_staged(DB_LIMIT));
    assert(tree_writes==0);
    assert(!write_blocks(DB_LIMIT/DB_BLOCK-1,1,0x73));
    assert(!reboot());
    check_blocks(DB_LIMIT/DB_BLOCK-1,1,0x73);
    check_blocks(127*64,1,0x15);
    check_blocks(8191,32,0x61);
    check_accounting();
    puts("PASS constant dirty-path write bound with cold leaves, parent boundary, grow and 128GiB top index");

    fresh(false);
    stage.count=0; assert(!commit_staged(DB_LIMIT));
    for (u32 pass=0; pass<3; pass++) {
        stage.count=32;
        for (u32 i=0; i<32; i++) stage.logical[i]=(u64)i<<20;
        memset(raw,0x64+pass,DB_IO);
        tree_writes=0;
        assert(!commit_staged(capacity));
        assert(tree_writes==97 && stage.nr_dirty==97);
        assert(!reboot());
        for (u32 i=0; i<32; i++) check_blocks(i<<20,1,0x64+pass);
        check_accounting();
    }
    puts("PASS worst-case 32 scattered mappings: 97 dirty nodes, every root branch, rollover and reuse");

    fresh(false);
    unsigned int created_before=creations, removed_before=removals;
    for (u32 i=0; i<768; i+=32) assert(!write_blocks(i,32,0x41));
    assert(creations>=created_before+3);
    assert(physical_total()>2*part_limit);
    assert(!reboot());
    check_blocks(0,768,0x41);
    for (u32 i=0; i<640; i+=32) {
        assert(!write_blocks(i,32,0));
        assert(!collect_part());
    }
    for (u32 i=0; i<4; i++) assert(!collect_part());
    assert(removals>removed_before);
    assert(!reboot());
    check_blocks(0,640,0); check_blocks(640,128,0x41);
    for (u32 i=0; i<768; i+=32) assert(!write_blocks(i,32,0x62));
    assert(!reboot()); check_blocks(0,768,0x62);
    check_accounting();
    puts("PASS real 1MiB capped rollover, discard/collection, part removal/recreation and cap enforcement");

    fresh(true);
    /* Pin a cold leaf on part 0 while its payload lives elsewhere. */
    avoid_part=0;
    assert(!write_blocks(0,16,0x38));
    avoid_part=-1;
    gc_node=node_index(0,0); stage.count=0;
    assert(!commit_staged(capacity)); gc_node=DB_NO_NODE;
    assert(part_id(tree_index[node_index(0,0)].location)==0);
    for (u32 i=64; i<384; i+=32) {
        avoid_part=1;
        assert(!write_blocks(i,32,0x57));
        avoid_part=-1;
    }
    for (u32 i=64; i<384; i+=32) assert(!write_blocks(i,32,0));
    /* Add unreachable durable tail to model reclaimable post-crash allocation. */
    struct file *f0=&files[0];
    ensure(f0,part_limit/2);
    f0->inode.size=part_limit/2;
    assert(!vfs_fsync(f0,0));
    assert(!collect_part());
    assert(part_id(tree_index[node_index(0,0)].location)!=0);
    assert(!reboot()); check_blocks(0,16,0x38);
    check_accounting();
    puts("PASS automatic cold tree-node evacuation independent of victim payload ownership");

    fresh(true);
    for (u32 i=0; i<1536; i+=16) assert(!write_blocks(i,16,0x33));
    for (u32 i=0; i<1536; i+=16) assert(!write_blocks(i,1,0x44));
    u64 bytes_before_gc=stored_bytes;
    assert(!collect_part());
    assert(stored_bytes==bytes_before_gc);
    assert(!reboot());
    for (u32 i=0; i<1536; i+=16) {
        check_blocks(i,1,0x44); check_blocks(i+1,15,0x33);
    }
    check_accounting();
    puts("PASS GC preserves partially overwritten shared blobs without encoded-byte inflation");

    fresh(true);
    for (u32 i=0; i<1536; i+=16) assert(!write_blocks(i,16,0x33));
    u64 stable_generation=generation;
    for (u32 i=0; i<8; i++) assert(!collect_part());
    assert(generation==stable_generation);
    assert(!reboot()); stable_generation=generation;
    for (u32 i=0; i<8; i++) assert(!collect_part());
    assert(generation==stable_generation);
    puts("PASS no GC churn on already packed compressed regions, including after recovery");

    fresh(false);
    assert(!write_blocks(0,1,0x25));
    struct db_pointer previous_leaf=tree_index[node_index(0,0)];
    u8 stale_page[DB_BLOCK];
    memcpy(stale_page,files[part_id(previous_leaf.location)].durable+(u32)previous_leaf.location,DB_BLOCK);
    assert(!write_blocks(0,1,0x26));
    struct db_pointer current_leaf=tree_index[node_index(0,0)];
    memcpy(files[part_id(current_leaf.location)].durable+(u32)current_leaf.location,stale_page,DB_BLOCK);
    assert(reboot()==-EUCLEAN);
    puts("PASS checksum-valid stale leaf cannot satisfy a newer generation/CRC-bound edge");

    fresh(false);
    assert(!write_blocks(0,1,0x25));
    loc=root->tree.location;
    struct db_node *cycle=(void *)(files[part_id(loc)].durable+(u32)loc);
    cycle->children[0]=root->tree;
    seal(cycle);
    root->tree.crc=cycle->crc;
    seal(root);
    memcpy(files[0].durable+DB_BLOCK,root,DB_BLOCK);
    memcpy(files[0].durable+2*DB_BLOCK,root,DB_BLOCK);
    assert(reboot()==-EUCLEAN);
    puts("PASS valid-CRC tree alias/cycle rejected without recovery writes");

    fresh(true);
    u8 *mirror=calloc(1024,DB_BLOCK);
    assert(mirror);
    rng=0x1833d37b;
    for (u32 step=0; step<1200; step++) {
        rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
        u32 blocks=step%3==0?16:step%3==1?1:32;
        u32 first=rng%(1024-blocks+1);
        if (!(step%4)) first=round_down(first,DB_SUBBLOCKS);
        assert(!collect_part());
        stage.count=blocks;
        for (u32 i=0; i<blocks; i++) stage.logical[i]=first+i;
        if (!(step%11)) fill_random(raw,blocks*DB_BLOCK,rng);
        else memset(raw,step%5 ? (step%251)+1 : 0,blocks*DB_BLOCK);
        memcpy(mirror+first*DB_BLOCK,raw,blocks*DB_BLOCK);
        tree_writes=0;
        assert(!commit_staged(capacity) && tree_writes<=7);
        if (!(step%25)) {
            check_accounting();
            assert(!reboot());
            for (u32 i=0; i<1024; i++) {
                assert(!read_value(map_slot(i),raw));
                assert(!memcmp(raw,mirror+i*DB_BLOCK,DB_BLOCK));
            }
        }
        assert(physical_total()<16*part_limit);
    }
    assert(!reboot()); check_accounting();
    for (u32 i=0; i<1024; i++) {
        assert(!read_value(map_slot(i),raw));
        assert(!memcmp(raw,mirror+i*DB_BLOCK,DB_BLOCK));
    }
    free(mirror);
    puts("PASS 1200 mixed-size/entropy overwrite-discard operations with GC, accounting, bounded storage and reattach");

    fresh(false);
    generation=U64_MAX; stage.count=0;
    assert(commit_staged(capacity)==-EIO && fenced);
    puts("PASS generation exhaustion fences without wrapping publication");
    reset_ram();
    for (u32 i=0; i<DB_PARTS; i++) { free(files[i].bytes); free(files[i].durable); }
    free(root); free(other_root); free(header); free(transaction);
    free(raw); free(packed); free(scratch); free(decoded); free(tree_index); free(tree_stack);
    return 0;
}

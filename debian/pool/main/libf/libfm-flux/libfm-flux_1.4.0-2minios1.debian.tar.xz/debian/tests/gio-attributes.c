/* SPDX-License-Identifier: LGPL-2.1-or-later
 * Copyright 2026 crims0n <crims0n@minios.dev>
 * Sparse GIO metadata and the real menu/search VFS modules. */
#ifdef FM_TEST_BUILD
#include "fm.h"
#include "fm-module.h"
#else
#include <libfm/fm.h>
#include <libfm/fm-module.h>
#endif
#include <glib/gstdio.h>
#include <string.h>
#include <unistd.h>

static FmFileInfo *convert(GFile *file, GFileInfo *info)
{
    FmFileInfo *fi = fm_file_info_new_from_g_file_data(file, info, NULL);
    g_assert_nonnull(fi);
    g_assert_nonnull(fm_file_info_get_mime_type(fi));
    g_assert_nonnull(fm_file_info_get_icon(fi));
    return fi;
}

static void sparse_metadata(const char *root)
{
    gchar *name = g_build_filename(root, "fallback.txt", NULL);
    GFile *file = g_file_new_for_path(name);
    GFileInfo *info = g_file_info_new();
    FmFileInfo *fi;

    g_file_info_set_file_type(info, G_FILE_TYPE_DIRECTORY);
    g_file_info_set_display_name(info, "Virtual folder");
    fi = convert(file, info);
    g_assert_true(fm_file_info_is_dir(fi));
    g_assert_cmpstr(fm_file_info_get_disp_name(fi), ==, "Virtual folder");
    g_assert_cmpstr(fm_mime_type_get_type(fm_file_info_get_mime_type(fi)), ==, "inode/directory");
    g_assert_cmpint(fm_file_info_get_size(fi), ==, 0);
    g_assert_false(fm_file_info_is_symlink(fi));
    g_assert_false(fm_file_info_is_hidden(fi));
    g_assert_false(fm_file_info_is_backup(fi));
    g_assert_false(g_file_info_has_attribute(info, G_FILE_ATTRIBUTE_STANDARD_SIZE));
    fm_file_info_unref(fi);
    g_object_unref(info);
    g_print("PASS sparse directory metadata and display-name fallback\n");

    /* An incomplete remote/special object is not necessarily a symlink,
     * and may not supply even a MIME type, name or icon. */
    info = g_file_info_new();
    g_file_info_set_file_type(info, G_FILE_TYPE_SPECIAL);
    fi = convert(file, info);
    g_assert_cmpstr(fm_file_info_get_disp_name(fi), ==, "fallback.txt");
    g_assert_cmpstr(fm_mime_type_get_type(fm_file_info_get_mime_type(fi)), ==, "text/plain");
    fm_file_info_unref(fi);
    g_object_unref(info);
    g_print("PASS special object with no MIME/name/icon\n");

    info = g_file_info_new();
    g_file_info_set_file_type(info, G_FILE_TYPE_SYMBOLIC_LINK);
    fi = convert(file, info);
    g_assert_true(fm_file_info_is_symlink(fi));
    g_assert_null(fm_file_info_get_target(fi));
    fm_file_info_unref(fi);
    g_object_unref(info);
    g_print("PASS symlink with unavailable target\n");

    info = g_file_info_new();
    g_file_info_set_file_type(info, G_FILE_TYPE_REGULAR);
    g_file_info_set_name(info, "actual.txt");
    g_file_info_set_display_name(info, "Display name");
    g_file_info_set_edit_name(info, "Edit name");
    g_file_info_set_content_type(info, "text/plain");
    g_file_info_set_size(info, (goffset)4294967300ULL);
    g_file_info_set_is_hidden(info, TRUE);
    g_file_info_set_attribute_boolean(info, G_FILE_ATTRIBUTE_STANDARD_IS_BACKUP, TRUE);
    g_file_info_set_attribute_uint64(info, G_FILE_ATTRIBUTE_TIME_MODIFIED, 12345);
    fi = convert(file, info);
    g_assert_cmpstr(fm_file_info_get_disp_name(fi), ==, "Edit name");
    g_assert_cmpint(fm_file_info_get_size(fi), ==, (goffset)4294967300ULL);
    g_assert_cmpint(fm_file_info_get_mtime(fi), ==, 12345);
    g_assert_true(fm_file_info_is_hidden(fi));
    g_assert_true(fm_file_info_is_backup(fi));
    g_assert_false(fm_file_info_is_symlink(fi));
    fm_file_info_unref(fi);
    g_object_unref(info);
    g_print("PASS explicit attributes and 64-bit file size preserved\n");

    info = g_file_info_new();
    g_file_info_set_file_type(info, G_FILE_TYPE_REGULAR);
    g_file_info_set_name(info, "link.txt");
    g_file_info_set_display_name(info, "Link");
    g_file_info_set_content_type(info, "text/plain");
    g_file_info_set_is_symlink(info, TRUE);
    g_file_info_set_symlink_target(info, "target.txt");
    fi = convert(file, info);
    g_assert_true(fm_file_info_is_symlink(fi));
    g_assert_cmpstr(fm_file_info_get_target(fi), ==, "target.txt");
    fm_file_info_unref(fi);
    g_object_unref(info);
    g_object_unref(file);
    g_free(name);
    g_print("PASS explicit symlink flag and target preserved\n");
}

static guint search_count(const gchar *uri, const gchar *expected)
{
    GError *error = NULL;
    GFile *file = fm_file_new_for_uri(uri);
    GFileEnumerator *enu = g_file_enumerate_children(file, "standard::*",
                                      G_FILE_QUERY_INFO_NONE, NULL, &error);
    GFileInfo *info;
    guint count = 0;
    g_assert_no_error(error);
    g_assert_nonnull(enu);
    while ((info = g_file_enumerator_next_file(enu, NULL, &error)) != NULL)
    {
        GFile *child;
        FmFileInfo *fi;
        g_assert_cmpstr(g_file_info_get_name(info), ==, expected);
        /* The directory job resolves results against the enumerator's
         * current real folder, not a fictional search:// child. */
        child = g_file_get_child(g_file_enumerator_get_container(enu), expected);
        g_assert_nonnull(child);
        if (g_str_has_prefix(uri, "search://menu://"))
            g_assert_true(g_file_has_uri_scheme(child, "menu"));
        else
            g_assert_true(g_file_is_native(child));
        g_assert_true(g_file_query_exists(child, NULL));
        fi = convert(child, info);
        fm_file_info_unref(fi);
        g_object_unref(child);
        count++;
        g_object_unref(info);
    }
    g_assert_no_error(error);
    g_assert_true(g_file_enumerator_close(enu, NULL, &error));
    g_assert_no_error(error);
    g_object_unref(enu);
    g_object_unref(file);
    return count;
}

static void search_cases(const char *root)
{
    gchar *dir = g_build_filename(root, "native", NULL);
    gchar *sub = g_build_filename(dir, "sub", NULL);
    gchar *hidden = g_build_filename(dir, ".hidden", NULL);
    gchar *link = g_build_filename(dir, "link", NULL);
    gchar *file = g_build_filename(sub, "match.txt", NULL);
    gchar *hidden_file = g_build_filename(hidden, "match.txt", NULL);
    gchar *uri;
    g_assert_cmpint(g_mkdir_with_parents(sub, 0700), ==, 0);
    g_assert_cmpint(g_mkdir_with_parents(hidden, 0700), ==, 0);
    g_assert_true(g_file_set_contents(file, "abc", 3, NULL));
    g_assert_true(g_file_set_contents(hidden_file, "abc", 3, NULL));
    g_assert_cmpint(symlink(sub, link), ==, 0);
    uri = g_strdup_printf("search://%s?recursive=1&show_hidden=0&name=match.txt", dir);
    g_assert_cmpuint(search_count(uri, "match.txt"), ==, 1);
    g_free(uri);
    uri = g_strdup_printf("search://%s?recursive=1&show_hidden=0&name=match.txt&min_size=3&max_size=3", dir);
    g_assert_cmpuint(search_count(uri, "match.txt"), ==, 1);
    g_free(uri);
    uri = g_strdup_printf("search://%s?recursive=1&show_hidden=0&name=match.txt&min_size=4", dir);
    g_assert_cmpuint(search_count(uri, "match.txt"), ==, 0);
    g_free(uri);
    /* Fedora PR126: a valueless parameter must not dereference NULL,
     * and later valid parameters must still be parsed. */
    uri = g_strdup_printf("search://%s?show_hidden&recursive=1&name=match.txt&show_hidden=0", dir);
    g_assert_cmpuint(search_count(uri, "match.txt"), ==, 1);
    g_free(uri);
    uri = g_strdup_printf("search://%s?recursive=1&show_hidden=0&name=match.txt&max_size", dir);
    g_assert_cmpuint(search_count(uri, "match.txt"), ==, 1);
    g_free(uri);
    g_print("PASS valueless search URI parameters are ignored\n");
    g_free(hidden_file);
    g_free(file);
    g_free(link);
    g_free(hidden);
    g_free(sub);
    g_free(dir);
    g_print("PASS recursive search, hidden directories, symlink exclusion, size filters\n");
}

static void virtual_cases(void)
{
    GError *error = NULL;
    GFile *file = fm_file_new_for_uri("menu://applications/");
    GFileInfo *info = g_file_query_info(file, "standard::*", G_FILE_QUERY_INFO_NONE, NULL, &error);
    g_assert_no_error(error);
    g_assert_nonnull(info);
    FmFileInfo *fi = convert(file, info);
    g_assert_true(fm_file_info_is_dir(fi));
    g_assert_nonnull(fm_file_info_get_disp_name(fi));
    fm_file_info_unref(fi);
    g_object_unref(info);
    g_object_unref(file);
    g_print("PASS real virtual application-menu root\n");

    file = fm_file_new_for_uri("search://menu://applications/?recursive=1&show_hidden=1&name=minios-gio-fixture.desktop");
    info = g_file_query_info(file, "standard::*", G_FILE_QUERY_INFO_NONE, NULL, &error);
    g_assert_no_error(error);
    g_assert_nonnull(info);
    fi = convert(file, info);
    g_assert_true(fm_file_info_is_dir(fi));
    fm_file_info_unref(fi);
    g_object_unref(info);
    g_object_unref(file);
    g_print("PASS real virtual search root\n");
    g_assert_cmpuint(search_count("search://menu://applications/?recursive=1&show_hidden=1&name=minios-gio-fixture.desktop", "minios-gio-fixture.desktop"), ==, 1);
    g_assert_cmpuint(search_count("search://menu://applications/?recursive=1&show_hidden=1&name=minios-gio-fixture.desktop&max_size=10", "minios-gio-fixture.desktop"), ==, 0);
    g_print("PASS recursive menu search without size; unknown size does not satisfy filter\n");
}

int main(int argc, char **argv)
{
    if (argc < 2 || argc > 3)
        return 2;
    if (argc == 3)
        g_assert_true(fm_modules_add_directory(argv[2]));
    g_assert_true(fm_init(NULL));
    sparse_metadata(argv[1]);
    search_cases(argv[1]);
    virtual_cases();
    fm_finalize();
    return 0;
}

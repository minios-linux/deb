/* SPDX-License-Identifier: LGPL-2.1-or-later
 * Copyright 2026 crims0n <crims0n@minios.dev>
 * Real GIO/GTK regressions. Run each case in a private HOME. */
#ifdef FM_TEST_BUILD
#include "fm-gtk.h"
#else
#include <libfm/fm-gtk.h>
#endif
#include <glib/gstdio.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <utime.h>

typedef struct { guint inserted, deleted, reordered, batches, reloads; } Counts;
static void pump(guint ms)
{
    gint64 end = g_get_monotonic_time() + ((gint64)ms * 1000);
    do {
        while (g_main_context_iteration(NULL, FALSE)) {}
        g_usleep(1000);
    } while (g_get_monotonic_time() < end);
}
static void put(const gchar *path, const gchar *value)
{
    gint fd = g_open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    g_assert_cmpint(fd, >=, 0);
    g_assert_cmpint(write(fd, value, strlen(value)), ==, (gssize)strlen(value));
    g_assert_cmpint(close(fd), ==, 0);
}
static void touch_at(const gchar *path, time_t time)
{
    struct utimbuf times = { time, time };
    g_assert_cmpint(utime(path, &times), ==, 0);
}
static gchar *model_names(GtkTreeModel *model)
{
    GString *out = g_string_new(NULL);
    GtkTreeIter it;
    gboolean valid = gtk_tree_model_get_iter_first(model, &it);
    while (valid) {
        FmFileInfo *fi = NULL;
        gtk_tree_model_get(model, &it, FM_FOLDER_MODEL_COL_INFO, &fi, -1);
        if (out->len) g_string_append_c(out, ',');
        g_string_append(out, fm_path_get_basename(fm_file_info_get_path(fi)));
        /* COL_INFO is a borrowed G_TYPE_POINTER. */
        valid = gtk_tree_model_iter_next(model, &it);
    }
    return g_string_free(out, FALSE);
}
static void expect_names(GtkTreeModel *model, const gchar *expected)
{
    gint64 deadline = g_get_monotonic_time() + 5000000;
    gchar *actual;
    for (;;) {
        actual = model_names(model);
        if (!strcmp(actual, expected) || g_get_monotonic_time() >= deadline) break;
        g_free(actual);
        pump(10);
    }
    g_assert_cmpstr(actual, ==, expected);
    g_free(actual);
    /* Let asynchronous metadata updates arrive before checking identities. */
    pump(200);
    actual = model_names(model);
    g_assert_cmpstr(actual, ==, expected);
    g_free(actual);
}
static void row_inserted(GtkTreeModel *m, GtkTreePath *p, GtkTreeIter *i, Counts *c)
{ (void)m; (void)p; (void)i; c->inserted++; }
static void row_deleted(GtkTreeModel *m, GtkTreePath *p, Counts *c)
{ (void)m; (void)p; c->deleted++; }
static void rows_reordered(GtkTreeModel *m, GtkTreePath *p, GtkTreeIter *i, gint *o, Counts *c)
{ (void)m; (void)p; (void)i; (void)o; c->reordered++; }
static void files_changed(FmFolder *f, GSList *items, Counts *c)
{ (void)f; (void)items; c->batches++; }
static void start_loading(FmFolder *f, Counts *c)
{ (void)f; c->reloads++; }
static GtkTreeRowReference *remember(FmFolderModel *model, const gchar *name, GtkTreeIter *iter)
{
    g_assert_true(fm_folder_model_find_iter_by_filename(model, iter, name));
    GtkTreePath *path = gtk_tree_model_get_path(GTK_TREE_MODEL(model), iter);
    GtkTreeRowReference *ref = gtk_tree_row_reference_new(GTK_TREE_MODEL(model), path);
    gtk_tree_path_free(path);
    return ref;
}
static void assert_reference(GtkTreeRowReference *ref, FmFileInfo *expected)
{
    g_assert_true(gtk_tree_row_reference_valid(ref));
    GtkTreeModel *model = gtk_tree_row_reference_get_model(ref);
    GtkTreePath *path = gtk_tree_row_reference_get_path(ref);
    GtkTreeIter it;
    FmFileInfo *fi = NULL;
    g_assert_true(gtk_tree_model_get_iter(model, &it, path));
    gtk_tree_model_get(model, &it, FM_FOLDER_MODEL_COL_INFO, &fi, -1);
    g_assert_true(fi == expected);
    /* COL_INFO is a borrowed G_TYPE_POINTER. */
    gtk_tree_path_free(path);
}
static void assert_selected(GtkTreeSelection *selection, FmFolderModel *model, const gchar *name)
{
    GtkTreeIter it;
    g_assert_true(fm_folder_model_find_iter_by_filename(model, &it, name));
    g_assert_true(gtk_tree_selection_iter_is_selected(selection, &it));
}
static FmFolder *open_folder(const gchar *path)
{
    FmFolder *folder = fm_folder_from_path_name(path);
    gint64 end = g_get_monotonic_time() + 5000000;
    while (!fm_folder_is_loaded(folder) && g_get_monotonic_time() < end) pump(10);
    g_assert_true(fm_folder_is_loaded(folder));
    return folder;
}
static void model_case(const gchar *which, const gchar *root)
{
    gboolean directory = g_str_has_prefix(which, "directory-");
    gboolean descending = g_str_has_suffix(which, "-desc");
    gboolean unicode = !strcmp(which, "unicode");
    gboolean ext = !strcmp(which, "extension");
    const gchar *first = directory ? "a-dir" : unicode ? "ёжик.txt" : ext ? "a.aaa" : "a.txt";
    const gchar *last = directory ? "z-dir" : unicode ? "яблоко.txt" : ext ? "z.zzz" : "z.txt";
    const gchar *second = ext ? "b.mid" : "b.txt";
    gchar *left = g_build_filename(root, "left", NULL);
    gchar *right = g_build_filename(root, "right", NULL);
    g_assert_cmpint(g_mkdir_with_parents(left, 0700), ==, 0);
    g_assert_cmpint(g_mkdir_with_parents(right, 0700), ==, 0);
    gchar *a = g_build_filename(left, first, NULL);
    gchar *b = g_build_filename(left, second, NULL);
    gchar *z = g_build_filename(left, last, NULL);
    gchar *temp = g_build_filename(left, "temporary", NULL);
    gchar *hidden = g_build_filename(left, ".hidden", NULL);
    gchar *remote = g_build_filename(right, "remote.txt", NULL);
    if (directory) g_assert_cmpint(g_mkdir(a,0700), ==, 0); else put(a, "source\n");
    put(b, "target-data\n");
    touch_at(a, 100); touch_at(b, 200);
    FmFolder *folder = open_folder(left);
    FmFolderModel *model = fm_folder_model_new(folder, FALSE);
    FmFolderModelCol column = FM_FOLDER_MODEL_COL_NAME;
    FmSortMode mode = descending ? FM_SORT_DESCENDING : FM_SORT_ASCENDING;
    if (!strcmp(which,"directory-mixed")) mode |= FM_SORT_NO_FOLDER_FIRST;
    if (g_str_has_prefix(which,"size-")) column=FM_FOLDER_MODEL_COL_SIZE;
    if (g_str_has_prefix(which,"mtime-")) column=FM_FOLDER_MODEL_COL_MTIME;
    if (ext) column=FM_FOLDER_MODEL_COL_EXT;
    fm_folder_model_set_sort(model, column, mode);
    pump(250);
    if (!strcmp(which,"unsorted")) fm_folder_model_set_sort(model, FM_FOLDER_MODEL_COL_UNSORTED, mode);
    FmFileInfo *original = fm_file_info_ref(fm_folder_get_file_by_name(folder,first));
    FmFileInfo *other = fm_file_info_ref(fm_folder_get_file_by_name(folder,second));
    GtkTreeIter it, bit;
    GtkTreeRowReference *ref = remember(model, first, &it);
    GtkTreeRowReference *bref = remember(model, second, &bit);
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    GtkWidget *view = gtk_tree_view_new_with_model(GTK_TREE_MODEL(model));
    gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(view), -1, "Name", gtk_cell_renderer_text_new(), "text", FM_FOLDER_MODEL_COL_NAME, NULL);
    gtk_container_add(GTK_CONTAINER(window),view);
    gtk_widget_show_all(window);
    GtkTreePath *cursor = gtk_tree_model_get_path(GTK_TREE_MODEL(model), &it);
    gtk_tree_view_set_cursor(GTK_TREE_VIEW(view), cursor, NULL, FALSE);
    gtk_tree_path_free(cursor);
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(view));
    gtk_tree_selection_set_mode(selection, GTK_SELECTION_MULTIPLE);
    gtk_tree_selection_select_iter(selection, &it);
    if (!strcmp(which,"multiple-selection")) gtk_tree_selection_select_iter(selection,&bit);
    pump(100);
    Counts counts={0};
    g_signal_connect(model,"row-inserted",G_CALLBACK(row_inserted),&counts);
    g_signal_connect(model,"row-deleted",G_CALLBACK(row_deleted),&counts);
    g_signal_connect(model,"rows-reordered",G_CALLBACK(rows_reordered),&counts);
    g_signal_connect(folder,"files-changed",G_CALLBACK(files_changed),&counts);
    g_signal_connect(folder,"start-loading",G_CALLBACK(start_loading),&counts);
    const gchar *expected = descending ? "z.txt,b.txt" : "b.txt,z.txt";
    gboolean preserve=TRUE, row_preserved=TRUE, overwritten=FALSE, deleted=FALSE;
    if (unicode) expected="b.txt,яблоко.txt";
    if (ext) expected="b.mid,z.zzz";
    if (directory) expected=(!strcmp(which,"directory-mixed")) ? "b.txt,z-dir" : "z-dir,b.txt";
    if (!strcmp(which,"unsorted")) expected="z.txt,b.txt";
    if (!strcmp(which,"overwrite") || !strcmp(which,"overwrite-recreate") || !strcmp(which,"overwrite-delete") || !strcmp(which,"overwrite-chain")) {
        g_assert_cmpint(g_rename(a,b), ==, 0);
        overwritten=TRUE; last=second; expected=second;
        if (!strcmp(which,"overwrite-recreate")) { put(a,"replacement\n"); expected="a.txt,b.txt"; }
        if (!strcmp(which,"overwrite-delete")) { g_assert_cmpint(g_unlink(b), ==, 0); expected=""; deleted=TRUE; row_preserved=FALSE; }
        if (!strcmp(which,"overwrite-chain")) { g_assert_cmpint(g_rename(b,z), ==, 0); expected="z.txt"; last="z.txt"; }
    } else if (!strcmp(which,"delete-recreate")) {
        g_assert_cmpint(g_unlink(a), ==, 0); put(a,"source\n");
        expected="a.txt,b.txt";last=first;
    } else if (!strcmp(which,"chain")) {
        g_assert_cmpint(g_rename(a,temp), ==, 0); g_assert_cmpint(g_rename(temp,z), ==, 0);
    } else if (!strcmp(which,"swap-chain")) {
        g_assert_cmpint(g_rename(a,temp), ==, 0); g_assert_cmpint(g_rename(b,a), ==, 0); g_assert_cmpint(g_rename(temp,z), ==, 0);
        expected="a.txt,z.txt";
    } else if (!strcmp(which,"delete")) {
        g_assert_cmpint(g_rename(a,z), ==, 0); g_assert_cmpint(g_unlink(z), ==, 0);
        expected=second; deleted=TRUE; row_preserved=FALSE;
    } else if (!strcmp(which,"hidden")) {
        g_assert_cmpint(g_rename(a,hidden), ==, 0); expect_names(GTK_TREE_MODEL(model),second);
        g_assert_false(gtk_tree_row_reference_valid(ref));
        g_assert_cmpint(g_rename(hidden,z), ==, 0); row_preserved=FALSE;
    } else if (!strcmp(which,"move")) {
        g_assert_cmpint(g_rename(a,remote), ==, 0); expect_names(GTK_TREE_MODEL(model),second);
        g_assert_cmpint(g_rename(remote,z), ==, 0); preserve=FALSE; row_preserved=FALSE;
    } else {
        g_assert_cmpint(g_rename(a,z), ==, 0);
        if (g_str_has_prefix(which,"size-")) put(z,"a much longer source value than the other file\n");
        if (g_str_has_prefix(which,"mtime-")) touch_at(z,300);
    }
    expect_names(GTK_TREE_MODEL(model),expected);
    g_assert_cmpuint(counts.reloads, ==, 0);
    if (!deleted) {
        FmFileInfo *result=fm_folder_get_file_by_name(folder,last);
        g_assert_nonnull(result);
        g_assert_true((result==original)==preserve);
        if (row_preserved) {
            assert_reference(ref, original);
            assert_selected(selection,model,last);
            GtkTreePath *cur=NULL;
            gtk_tree_view_get_cursor(GTK_TREE_VIEW(view),&cur,NULL);
            GtkTreePath *now=gtk_tree_row_reference_get_path(ref);
            g_assert_nonnull(cur); g_assert_cmpint(gtk_tree_path_compare(cur,now), ==, 0);
            gtk_tree_path_free(cur); gtk_tree_path_free(now);
        }
        if (!directory) {
            gchar *path=fm_path_to_str(fm_file_info_get_path(result)), *contents=NULL;
            g_assert_true(g_file_get_contents(path,&contents,NULL,NULL));
            const gchar *wanted=g_str_has_prefix(which,"size-") ? "a much longer source value than the other file\n" : "source\n";
            g_assert_cmpstr(contents, ==, wanted); g_free(path); g_free(contents);
        }
    }
    if (!row_preserved) g_assert_false(gtk_tree_row_reference_valid(ref));
    if (overwritten) g_assert_false(gtk_tree_row_reference_valid(bref));
    else assert_reference(bref,other);
    if (!strcmp(which,"multiple-selection")) {
        assert_selected(selection,model,second);
        g_assert_cmpint(gtk_tree_selection_count_selected_rows(selection), ==, 2);
    }
    if (!strcmp(which,"overwrite-recreate")) {
        FmFileInfo *newfi=fm_folder_get_file_by_name(folder,first);
        g_assert_nonnull(newfi); g_assert_true(newfi!=original);
    }
    if (row_preserved && !overwritten) {
        g_assert_cmpuint(counts.inserted, ==, 0); g_assert_cmpuint(counts.deleted, ==, 0);
        g_assert_cmpuint(counts.reordered, ==, counts.batches);
    }
    if (!strcmp(which,"batch")) {
        GSList *batch=NULL;
        batch=g_slist_prepend(batch,original); batch=g_slist_prepend(batch,other);
        guint before=counts.reordered;
        g_signal_emit_by_name(folder,"files-changed",batch);
        g_assert_cmpuint(counts.reordered-before, ==, 1);
        g_slist_free(batch); assert_reference(ref,original); assert_selected(selection,model,last);
    }
    g_print("PASS %s: sorted model, identities, selection and notifications\n",which);
    gtk_tree_row_reference_free(ref); gtk_tree_row_reference_free(bref);
    gtk_widget_destroy(window);
    fm_file_info_unref(original); fm_file_info_unref(other);
    g_object_unref(model); g_object_unref(folder); pump(50);
    g_free(a);g_free(b);g_free(z);g_free(temp);g_free(hidden);g_free(remote);g_free(left);g_free(right);
}
static gchar *template_names(void)
{
    GList *list=fm_template_list_all(TRUE), *strings=NULL, *item;
    for (item=list; item; item=item->next)
        strings=g_list_prepend(strings,g_strdup(fm_template_get_name(item->data,NULL)));
    strings=g_list_sort(strings,(GCompareFunc)g_strcmp0);
    GString *out=g_string_new(NULL);
    for(item=strings;item;item=item->next) {
        if(out->len) g_string_append_c(out,',');
        g_string_append(out,item->data);
    }
    g_list_free_full(strings,g_free); g_list_free_full(list,g_object_unref);
    return g_string_free(out,FALSE);
}
static void expect_templates(const gchar *expected)
{
    gint64 end=g_get_monotonic_time()+5000000;
    gchar *actual;
    for (;;) {
        actual=template_names();
        if(!strcmp(actual,expected) || g_get_monotonic_time()>=end) break;
        g_free(actual); pump(10);
    }
    g_assert_cmpstr(actual,==,expected); g_free(actual); pump(150);
}
static void template_case(const gchar *which, const gchar *root)
{
    gchar *dir=g_build_filename(g_get_home_dir(),"Templates",NULL);
    gchar *a=g_build_filename(dir,"a.txt",NULL), *b=g_build_filename(dir,"b.txt",NULL);
    gchar *z=g_build_filename(dir,"z.txt",NULL), *tmp=g_build_filename(dir,"tmp.txt",NULL);
    gchar *outside=g_build_filename(root,"outside.txt",NULL);
    put(a,"template source\n"); put(b,"template target\n");
    expect_templates("a.txt,b.txt");
    const gchar *expected="b.txt,z.txt", *last="z.txt";
    if(!strcmp(which,"template-overwrite")) {
        g_assert_cmpint(g_rename(a,b),==,0); expected="b.txt"; last="b.txt";
    } else if(!strcmp(which,"template-chain")) {
        g_assert_cmpint(g_rename(a,tmp),==,0); g_assert_cmpint(g_rename(tmp,z),==,0);
    } else if(!strcmp(which,"template-move")) {
        g_assert_cmpint(g_rename(a,outside),==,0); expect_templates("b.txt");
        g_assert_cmpint(g_rename(outside,z),==,0);
    } else if(!strcmp(which,"template-delete")) {
        g_assert_cmpint(g_rename(a,z),==,0); g_assert_cmpint(g_unlink(z),==,0);
        expected="b.txt"; last=NULL;
    } else g_assert_cmpint(g_rename(a,z),==,0);
    expect_templates(expected);
    if(last) {
        GList *list=fm_template_list_all(TRUE),*entry;
        gboolean found=FALSE;
        for(entry=list;entry;entry=entry->next) {
            FmTemplate *templ=entry->data;
            if(!strcmp(fm_template_get_name(templ,NULL),last)) {
                gchar *dest=g_build_filename(root,"from-template.txt",NULL),*data=NULL;
                GFile *file=g_file_new_for_path(dest); GError *error=NULL;
                g_assert_true(fm_template_create_file(templ,file,&error,FALSE));
                g_assert_no_error(error);
                g_assert_true(g_file_get_contents(dest,&data,NULL,NULL));
                g_assert_cmpstr(data,==,"template source\n");
                g_free(data);g_free(dest);g_object_unref(file);found=TRUE;
            }
        }
        g_assert_true(found);g_list_free_full(list,g_object_unref);
    }
    g_print("PASS %s: template events and copied contents\n",which);
    g_free(dir);g_free(a);g_free(b);g_free(z);g_free(tmp);g_free(outside);
}
int main(int argc,char **argv)
{
    if(argc!=3) { g_printerr("Usage: %s CASE WORKDIR\n",argv[0]);return 2; }
    gtk_init(NULL,NULL);
    FmConfig *config=fm_config_new();
    config->template_type_once=FALSE;config->only_user_templates=TRUE;
    g_assert_true(fm_gtk_init(config));g_object_unref(config);
    if(g_str_has_prefix(argv[1],"template-")) template_case(argv[1],argv[2]);
    else model_case(argv[1],argv[2]);
    fm_gtk_finalize();return 0;
}

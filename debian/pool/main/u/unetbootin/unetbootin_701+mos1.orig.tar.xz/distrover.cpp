/*
distrover.cpp from UNetbootin <http://unetbootin.github.io/>
Copyright (C) 2007-2024 Geza Kovacs <geza0kovacs@gmail.com>

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License at <http://www.gnu.org/licenses/> for more details.
*/

#ifndef ubuntuverlist
#define ubuntuverlist \
"16.04_NetInstall" << "16.04_NetInstall_x64" << "16.04_HdMedia" << "16.04_HdMedia_x64" << "16.04_Live" << "16.04_Live_x64" << \
"18.04_NetInstall" << "18.04_NetInstall_x64" << "18.04_HdMedia" << "18.04_HdMedia_x64" << "18.04_Live_x64" << \
"20.04_Live_x64" << "22.04_Live_x64" << "24.04_Live_x64" << \
"Daily_Live" << "Daily_Live_x64"
#endif


distroselect->addItem(unetbootin::tr("== Select Distribution =="), (QStringList() << unetbootin::tr("== Select Version ==") <<
unetbootin::tr("Welcome to <a href=\"https://unetbootin.github.io/\">UNetbootin</a>, the Universal Netboot Installer. Usage:"
	"<ol><li>Select a distribution and version to download from the list above, or manually specify files to load below.</li>"
	"<li>Select an installation type, and press OK to begin installing.</li></ol>") <<
unetbootin::tr("== Select Version ==")));

distroselect->addItem("Arch Linux", (QStringList() << "core" <<
unetbootin::tr("<b>Homepage:</b> <a href=\"https://www.archlinux.org/\">https://www.archlinux.org</a><br/>"
	"<b>Description:</b> Arch Linux is a lightweight distribution optimized for speed and flexibility.<br/>"
	"<b>Install Notes:</b> The default version allows for installation over the internet (FTP).") <<
"core" << "core_x64" << "netinstall" << "netinstall_x64"));

distroselect->addItem("Debian", (QStringList() << "Stable_NetInstall" <<
unetbootin::tr("<b>Homepage:</b> <a href=\"https://www.debian.org/\">https://www.debian.org</a><br/>"
	"<b>Description:</b> Debian is a community-developed Linux distribution that supports a wide variety of architectures and offers a large repository of packages.<br/>"
	"<b>Install Notes:</b> The NetInstall version allows for installation over FTP. If you would like to use a pre-downloaded install iso, use the HdMedia option, and then place the install iso file on the root directory of your hard drive or USB drive") <<
"Stable_NetInstall" << "Stable_NetInstall_x64" << "Stable_HdMedia" << "Stable_HdMedia_x64" << "Testing_NetInstall" << "Testing_NetInstall_x64" << "Testing_HdMedia" << "Testing_HdMedia_x64" << "Unstable_NetInstall" << "Unstable_NetInstall_x64" << "Unstable_HdMedia" << "Unstable_HdMedia_x64"));

distroselect->addItem("Kubuntu", (QStringList() << "24.04_Live_x64" <<
unetbootin::tr("<b>Homepage:</b> <a href=\"https://www.kubuntu.org/\">https://www.kubuntu.org</a><br/>"
	"<b>Description:</b> Kubuntu is an official Ubuntu derivative featuring the KDE desktop.<br/>"
	"<b>Install Notes:</b> The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive") <<
ubuntuverlist));

distroselect->addItem("Linux Mint", (QStringList() << "19.2_Live" <<
unetbootin::tr("<b>Homepage:</b> <a href=\"https://linuxmint.com/\">https://linuxmint.com</a><br/>"
	"<b>Description:</b> Linux Mint is a user-friendly Ubuntu-based distribution which includes additional proprietary codecs and other software by default.<br/>"
	"<b>Install Notes:</b> The Live version allows for booting in Live mode, from which the installer can optionally be launched.") <<
    "19.2_Live" << "19.2_Live_x64"<<"19.3_Live"<<"19.3_Live_x64"<<"20_Live_x64"<<"20.1_Live_x64"<<"20.2_Live_x64"<<"20.3_Live_x64"<<"21_Live_x64"<<"21.1_Live_x64"));

distroselect->addItem("Lubuntu", (QStringList() << "24.04_Live_x64" <<
unetbootin::tr("<b>Homepage:</b> <a href=\"https://www.lubuntu.net/\">https://www.lubuntu.net</a><br/>"
	"<b>Description:</b> Lubuntu is an official Ubuntu derivative featuring the LXDE desktop.<br/>"
	"<b>Install Notes:</b> The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive") <<
ubuntuverlist));

distroselect->addItem("Slax", (QStringList() << "12.2.0_Live_x64" <<
unetbootin::tr("<b>Homepage:</b> <a href=\"https://www.slax.org/\">https://www.slax.org/</a><br/>"
    "<b>Description:</b> Slax is a modern, portable, and modular Linux operating system.<br/>"
    "<b>Install Notes:</b> The Live version allows booting into a live environment.") <<
"12.2.0_Live" << "12.2.0_Live_x64" << "15.0.4_Live" << "15.0.4_Live_x64"));

distroselect->addItem("SliTaz", (QStringList() << "Stable_Live" <<
unetbootin::tr("<b>Homepage:</b> <a href=\"http://www.slitaz.org/en/\">http://www.slitaz.org/en</a><br/>"
	"<b>Description:</b> SliTaz is a lightweight, desktop-oriented micro distribution.<br/>"
	"<b>Install Notes:</b> The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.") <<
"Stable_Live" << "Cooking_Live"));

distroselect->addItem("Ubuntu", (QStringList() << "24.04_Live_x64" <<
unetbootin::tr("<b>Homepage:</b> <a href=\"https://www.ubuntu.com/\">https://www.ubuntu.com</a><br/>"
	"<b>Description:</b> Ubuntu is a user-friendly Debian-based distribution. It is currently the most popular Linux desktop distribution.<br/>"
	"<b>Install Notes:</b> The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive") <<
ubuntuverlist));

distroselect->addItem("Xubuntu", (QStringList() << "24.04_Live_x64" <<
unetbootin::tr("<b>Homepage:</b> <a href=\"https://www.xubuntu.org/\">https://www.xubuntu.org</a><br/>"
	"<b>Description:</b> Xubuntu is an official Ubuntu derivative featuring the XFCE desktop.<br/>"
	"<b>Install Notes:</b> The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive") <<
ubuntuverlist));

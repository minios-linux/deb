/*
distrolst.cpp from UNetbootin <http://unetbootin.github.io/>
Copyright (C) 2007-2024 Geza Kovacs <geza0kovacs@gmail.com>

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License at <http://www.gnu.org/licenses/> for more details.
*/

#ifndef debianrelnamereplace
#define debianrelnamereplace \
	relname \
	.replace("unstable", "sid") \
    .replace("testing", "trixie") \
    .replace("stable", "bookworm");
#endif

#ifndef ubunturelnamereplace
#define ubunturelnamereplace \
	relname \
	.replace("24.10", "ocular") \
	.replace("24.04", "noble") \
	.replace("23.10", "mantic") \
    .replace("23.04", "lunar") \
    .replace("22.10", "kinetic") \
    .replace("22.04", "jammy") \
    .replace("21.10", "impish") \
    .replace("21.04", "hirsute") \
    .replace("20.10", "groovy") \
    .replace("20.04", "focal") \
    .replace("19.10", "eoan") \
    .replace("19.04", "disco") \
    .replace("18.10", "cosmic") \
    .replace("18.04", "bionic") \
    .replace("17.10", "artful") \
    .replace("17.04", "zesty") \
    .replace("16.10", "yakkety") \
    .replace("16.04", "xenial") \
    .replace("15.10", "wily") \
    .replace("15.04", "vivid") \
    .replace("14.10", "utopic") \
    .replace("14.04", "trusty") \
	.replace("13.10", "saucy") \
	.replace("13.04", "raring") \
	.replace("12.10", "quantal") \
	.replace("12.04", "precise") \
	.replace("11.10", "oneiric") \
	.replace("11.04", "natty") \
	.replace("10.10", "maverick") \
	.replace("10.04", "lucid") \
	.replace("9.10", "karmic") \
	.replace("9.04", "jaunty") \
	.replace("8.10", "intrepid") \
	.replace("8.04", "hardy") \
	.replace("7.10", "gutsy") \
	.replace("7.04", "feisty") \
	.replace("6.10", "edgy") \
	.replace("6.06", "dapper");
#endif

#ifndef ubuntunetinst
#define ubuntunetinst \
	if (ishdmedia) \
	{ \
		ubunturelnamereplace \
		downloadfile(QString("http://archive.ubuntu.com/ubuntu/dists/%1/main/installer-%2/current/images/hd-media/vmlinuz").arg(relname, cpuarch), QString("%1ubnkern").arg(targetPath)); \
		downloadfile(QString("http://archive.ubuntu.com/ubuntu/dists/%1/main/installer-%2/current/images/hd-media/initrd.gz").arg(relname, cpuarch), QString("%1ubninit").arg(targetPath)); \
		postinstmsg = unetbootin::tr("\n*IMPORTANT* Before rebooting, place an Ubuntu alternate (not desktop) install iso file on the root directory of your hard drive or USB drive. These can be obtained from cdimage.ubuntu.com"); \
	} \
	else if (isnetinstall) \
	{ \
		ubunturelnamereplace \
		downloadfile(QString("http://archive.ubuntu.com/ubuntu/dists/%1/main/installer-%2/current/images/netboot/ubuntu-installer/%2/linux").arg(relname, cpuarch), QString("%1ubnkern").arg(targetPath)); \
		downloadfile(QString("http://archive.ubuntu.com/ubuntu/dists/%1/main/installer-%2/current/images/netboot/ubuntu-installer/%2/initrd.gz").arg(relname, cpuarch), QString("%1ubninit").arg(targetPath)); \
	}
#endif



#ifdef STDUNETBOOTIN


if (nameDistro == "Arch Linux")
{
	if (isarch64)
	{
		cpuarch = "x86_64";
	}
	else
	{
		cpuarch = "i686";
	}
	downloadfile(fileFilterNetDir(QStringList() <<
	"http://mirrors.kernel.org/archlinux/iso/latest/" <<
	"http://distro.ibiblio.org/archlinux/iso/latest/" <<
	"http://mirror.rit.edu/archlinux/iso/latest/"
	, 3072000, 2048576000, QList<QRegExp>() <<
	QRegExp("^arch", Qt::CaseInsensitive) <<
	QRegExp("^archlinux", Qt::CaseInsensitive) <<
	QRegExp(".iso$", Qt::CaseInsensitive) <<
	QRegExp(cpuarch, Qt::CaseInsensitive) <<
	QRegExp(relname, Qt::CaseInsensitive)
	), isotmpf);
	extractiso(isotmpf);
}


if (nameDistro == "Debian")
{
	if (isarch64)
	{
		cpuarch = "amd64";
	}
	else
	{
		cpuarch = "i386";
	}
	if (islivecd)
	{
		debianrelnamereplace
		downloadfile(QString("http://live.debian.net/cdimage/%1-builds/current/%2/debian-live-%1-%2-gnome-desktop.iso").arg(relname, cpuarch), isotmpf);
		extractiso(isotmpf);
	}
	else if (ishdmedia)
	{
		downloadfile(QString("http://ftp.debian.org/debian/dists/%1/main/installer-%2/current/images/hd-media/vmlinuz").arg(relname, cpuarch), QString("%1ubnkern").arg(targetPath));
		downloadfile(QString("http://ftp.debian.org/debian/dists/%1/main/installer-%2/current/images/hd-media/initrd.gz").arg(relname, cpuarch), QString("%1ubninit").arg(targetPath));
		postinstmsg = unetbootin::tr("\n*IMPORTANT* Before rebooting, place a Debian install iso file on the root directory of your hard drive or USB drive. These can be obtained from cdimage.debian.org");
	}
	else
	{
		downloadfile(QString("http://ftp.debian.org/debian/dists/%1/main/installer-%2/current/images/netboot/debian-installer/%2/linux").arg(relname, cpuarch), QString("%1ubnkern").arg(targetPath));
		downloadfile(QString("http://ftp.debian.org/debian/dists/%1/main/installer-%2/current/images/netboot/debian-installer/%2/initrd.gz").arg(relname, cpuarch), QString("%1ubninit").arg(targetPath));
	}
}


if (nameDistro == "Kubuntu")
{
	if (isarch64)
	{
		cpuarch = "amd64";
	}
	else
	{
		cpuarch = "i386";
	}
	if (relname == "daily")
	{
		downloadfile(fileFilterNetDir(QStringList() <<
		"http://cdimage.ubuntu.com/kubuntu/daily-live/current/"
		, 61440000, 1048576000, QList<QRegExp>() <<
		QRegExp(".iso$", Qt::CaseInsensitive) <<
		QRegExp("desktop\\S{0,}.iso$", Qt::CaseInsensitive) <<
		QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive)
		), isotmpf);
		extractiso(isotmpf);
	}
	else
	{
		if (islivecd)
		{
			downloadfile(fileFilterNetDir(QStringList() <<
			"http://cdimage.ubuntu.com/kubuntu/releases/"+relname+"/release"
			, 524288000, 1048576000, QList<QRegExp>() <<
			QRegExp(".iso$", Qt::CaseInsensitive) <<
			QRegExp(cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("kubuntu\\S{0,}"+relname+"\\S{0,}desktop\\S{0,}"+cpuarch+"\\S{0,}.iso$", Qt::CaseInsensitive) <<
			QRegExp("kubuntu-"+relname+"\\S{0,}-desktop-"+cpuarch+".iso$", Qt::CaseInsensitive)
			), isotmpf);
			extractiso(isotmpf);
		}
	}
	ubuntunetinst
}


if (nameDistro == "Linux Mint")
{
    if (isarch64)
    {
        cpuarch = "64";
    }
	else
    {
        cpuarch = "32";
	}
	QList<QRegExp> mintregex = QList<QRegExp>() <<
		QRegExp(".iso$", Qt::CaseInsensitive) <<
		QRegExp("linuxmint", Qt::CaseInsensitive) <<
        QRegExp(cpuarch, Qt::CaseInsensitive) <<
        QRegExp("^((?!nocodecs).)*$", Qt::CaseInsensitive) <<
        QRegExp("cinnamon", Qt::CaseInsensitive);
	downloadfile(fileFilterNetDir(QStringList() <<
	QString("http://ftp.jaist.ac.jp/pub/Linux/linuxmint/isos/stable/%1/").arg(relname) <<
	QString("http://ftp.riken.jp/pub/Linux/linuxmint/isos/stable/%1/").arg(relname) <<
	QString("http://ftp.mgts.by/pub/linuxmint/isos/stable/%1/").arg(relname) <<
	QString("http://ftp.klid.dk/ftp/linuxmint/stable/%1/").arg(relname) <<
	QString("http://ftp5.gwdg.de/pub/linux/debian/mint/stable/%1/").arg(relname) <<
	QString("http://mirror.netcologne.de/linuxmint/iso/stable/%1/").arg(relname) <<
	QString("http://ftp.cc.uoc.gr/mirrors/linux/linuxmint/stable/%1/").arg(relname) <<
	QString("http://ftp.heanet.ie/pub/linuxmint.com/stable/%1/").arg(relname) <<
	QString("http://mirror.csclub.uwaterloo.ca/linuxmint/stable/%1/").arg(relname) <<
	QString("http://mirror.aarnet.edu.au/pub/linuxmint/stable/%1/").arg(relname) <<
	QString("http://free.nchc.org.tw/linuxmint/isos/stable/%1/").arg(relname) <<
	QString("http://ftp.kaist.ac.kr/linuxmint-iso/stable/%1/").arg(relname) <<
	QString("http://ftp.acc.umu.se/mirror/linuxmint.com/iso/stable/%1/").arg(relname) <<
	QString("http://mirror.yandex.ru/linuxmint/stable/%1/").arg(relname) <<
	QString("http://www.mirrorservice.org/sites/www.linuxmint.com/pub/linuxmint.com/stable/%1/").arg(relname) <<
	QString("http://ftp.icm.edu.pl/pub/Linux/dist/linuxmint/isos/stable/%1/").arg(relname) <<
	QString("http://ftp.fau.de/mint/iso/stable/%1/").arg(relname) <<
	QString("http://mirrors.ocf.berkeley.edu/linux-mint/stable/%1/").arg(relname)
	, 61440000, 1048576000, mintregex), isotmpf);
	extractiso(isotmpf);
}


if (nameDistro == "Lubuntu")
{
	if (isarch64)
	{
		cpuarch = "amd64";
	}
	else
	{
		cpuarch = "i386";
	}
	if (relname == "daily")
	{
		downloadfile(fileFilterNetDir(QStringList() <<
		"http://cdimage.ubuntu.com/lubuntu/daily-live/current/"
		, 61440000, 1048576000, QList<QRegExp>() <<
		QRegExp(".iso$", Qt::CaseInsensitive) <<
		QRegExp("desktop\\S{0,}.iso$", Qt::CaseInsensitive) <<
		QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive)
		), isotmpf);
		extractiso(isotmpf);
	}
	else
	{
		if (islivecd)
		{
			downloadfile(fileFilterNetDir(QStringList() <<
			"http://cdimage.ubuntu.com/lubuntu/releases/"+relname+"/release"
			, 524288000, 1048576000, QList<QRegExp>() <<
			QRegExp(".iso$", Qt::CaseInsensitive) <<
			QRegExp(cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("lubuntu\\S{0,}"+relname+"\\S{0,}desktop\\S{0,}"+cpuarch+"\\S{0,}.iso$", Qt::CaseInsensitive) <<
			QRegExp("lubuntu-"+relname+"\\S{0,}-desktop-"+cpuarch+".iso$", Qt::CaseInsensitive)
			), isotmpf);
			extractiso(isotmpf);
		}
	}
	ubuntunetinst
}


if (nameDistro == "SliTaz")
{
	if (relname == "webboot")
	{
		instIndvfl("gpxe", QString("%1ubnkern").arg(targetPath));
		kernelOpts = "url=http://mirror.slitaz.org/pxe/pxelinux.0";
		slinitrdLine = "";
		initrdLine = "";
		initrdOpts = "";
		initrdLoc = "";
	}
	else
	{
		downloadfile(fileFilterNetDir(QStringList() <<
		QString("http://mirror.slitaz.org/iso/%1/").arg(relname)
		, 3072000, 1048576000, QList<QRegExp>() <<
		QRegExp("^slitaz", Qt::CaseInsensitive) <<
		QRegExp(".iso$", Qt::CaseInsensitive) <<
		QRegExp("^slitaz-\\S{1,}.iso$", Qt::CaseInsensitive)
		), isotmpf);
		extractiso(isotmpf);
	}
}


if (nameDistro == "Ubuntu")
{
	if (isarch64)
	{
		cpuarch = "amd64";
	}
	else
	{
		cpuarch = "i386";
	}
	if (relname == "daily")
	{
		downloadfile(fileFilterNetDir(QStringList() <<
		"http://cdimage.ubuntu.com/daily-live/current/"
		, 61440000, 1048576000, QList<QRegExp>() <<
		QRegExp(".iso$", Qt::CaseInsensitive) <<
		QRegExp("desktop\\S{0,}.iso$", Qt::CaseInsensitive) <<
		QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive)
		), isotmpf);
		extractiso(isotmpf);
	}
	else
	{
		if (islivecd)
		{
			downloadfile(fileFilterNetDir(QStringList() <<
			"http://releases.ubuntu.com/"+relname <<
			"http://releases.ubuntu.com/releases/"+relname <<
//			"ftp://releases.ubuntu.com/releases/.pool/" <<
			"http://mirrors.gigenet.com/ubuntu/"+relname <<
			"http://www.gtlib.gatech.edu/pub/ubuntu-releases/"+relname <<
			"http://ftp.wayne.edu/ubuntu/releases/"+relname <<
			"http://ftp.kaist.ac.kr/ubuntu-cd/"+relname <<
			"http://free.nchc.org.tw/ubuntu-cd/"+relname <<
			"http://ftp.ubuntu-tw.org/ubuntu-releases/"+relname <<
			"http://mirrors.kernel.org/ubuntu-releases/"+relname <<
			"http://mirrors.mit.edu/ubuntu-releases/"+relname <<
			"http://mirror.umd.edu/ubuntu-iso/"+relname <<
			"http://mirror.uoregon.edu/ubuntu-releases/"+relname <<
			"http://ftp.jaist.ac.jp/pub/Linux/ubuntu-releases/"+relname <<
			"http://mirror.csclub.uwaterloo.ca/ubuntu-releases/"+relname <<
			"http://ubuntu.mirrors.ovh.net/ubuntu-releases/"+relname <<
			"http://mirror.ox.ac.uk/sites/releases.ubuntu.com/releases/"+relname <<
			"http://ubuntu.mirrors.proxad.net/"+relname
			, 524288000, 1048576000, QList<QRegExp>() <<
			QRegExp(".iso$", Qt::CaseInsensitive) <<
			QRegExp(cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("ubuntu\\S{0,}"+relname+"\\S{0,}desktop\\S{0,}"+cpuarch+"\\S{0,}.iso$", Qt::CaseInsensitive) <<
			QRegExp("ubuntu-"+relname+"\\S{0,}-desktop-"+cpuarch+".iso$", Qt::CaseInsensitive)
			), isotmpf);
			extractiso(isotmpf);
		}
	}
	ubuntunetinst
}


if (nameDistro == "Xubuntu")
{
	if (isarch64)
	{
		cpuarch = "amd64";
	}
	else
	{
		cpuarch = "i386";
	}
	if (relname == "daily")
	{
		downloadfile(fileFilterNetDir(QStringList() <<
		"http://cdimage.ubuntu.com/xubuntu/daily-live/current/"
		, 61440000, 1048576000, QList<QRegExp>() <<
		QRegExp(".iso$", Qt::CaseInsensitive) <<
		QRegExp("desktop\\S{0,}.iso$", Qt::CaseInsensitive) <<
		QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive)
		), isotmpf);
		extractiso(isotmpf);
	}
	else
	{
		if (islivecd)
		{
			downloadfile(fileFilterNetDir(QStringList() <<
			"http://cdimage.ubuntu.com/xubuntu/releases/"+relname+"/release"
			, 524288000, 1048576000, QList<QRegExp>() <<
			QRegExp(".iso$", Qt::CaseInsensitive) <<
			QRegExp(cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("desktop-"+cpuarch+".iso$", Qt::CaseInsensitive) <<
			QRegExp("xubuntu\\S{0,}"+relname+"\\S{0,}desktop\\S{0,}"+cpuarch+"\\S{0,}.iso$", Qt::CaseInsensitive) <<
			QRegExp("xubuntu-"+relname+"\\S{0,}-desktop-"+cpuarch+".iso$", Qt::CaseInsensitive)
			), isotmpf);
			extractiso(isotmpf);
		}
	}
	ubuntunetinst
}


if (nameDistro == "Slax")
{
    if (isarch64)
    {
        cpuarch = "64bit";
    }
    else
    {
        cpuarch = "32bit";
    }

    if (relname.startsWith("12.2.0"))
    {
       downloadfile(QString("https://ftp.sh.cvut.cz/slax/Slax-12.x/slax-%1-debian-12.2.0.iso").arg(cpuarch), isotmpf);
    }
    else if (relname.startsWith("15.0.4"))
    {
        downloadfile(QString("https://ftp.sh.cvut.cz/slax/Slax-15.x/slax-%1-slackware-15.0.4.iso").arg(cpuarch), isotmpf);
    }


    extractiso(isotmpf);
}


#endif
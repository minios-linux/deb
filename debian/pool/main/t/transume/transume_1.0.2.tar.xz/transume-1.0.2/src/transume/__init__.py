"""Transume GTK frontend."""

__version__ = "1.0.2"

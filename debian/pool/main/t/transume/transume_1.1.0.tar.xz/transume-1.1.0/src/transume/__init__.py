"""Transume GTK frontend."""

__version__ = "1.1.0"

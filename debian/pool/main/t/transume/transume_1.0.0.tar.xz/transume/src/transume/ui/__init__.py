"""Widgets and pages for the Transume frontend."""
